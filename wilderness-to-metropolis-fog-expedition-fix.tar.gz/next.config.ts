import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  output: "standalone",
  /* config options here */
  typescript: {
    ignoreBuildErrors: true,
  },
  reactStrictMode: false,
  devIndicators: false,
  allowedDevOrigins: ["https://preview-chat-deb34041-5394-41b8-8f70-10e0698eec22.space-z.ai"],
};

export default nextConfig;
