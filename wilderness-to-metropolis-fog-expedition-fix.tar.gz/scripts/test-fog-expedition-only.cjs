// Regression test: building/road placement and city-defense battles must not reveal fog.
// Run after installing project dependencies: npm run test:fog
const assert = require('node:assert/strict');
const fs = require('node:fs');
const ts = require('typescript');

require.extensions['.ts'] = (module, filename) => {
  const source = fs.readFileSync(filename, 'utf8');
  const compiled = ts.transpileModule(source, {
    compilerOptions: {
      module: ts.ModuleKind.CommonJS,
      target: ts.ScriptTarget.ES2020,
      esModuleInterop: true,
    },
  }).outputText;
  module._compile(compiled, filename);
};

const { GameEngine } = require('../src/lib/game/engine.ts');

function exploredCount(engine) {
  let count = 0;
  for (const chunk of engine.terrain.chunks.values()) {
    for (const tile of chunk.tiles) if (tile.explored) count++;
  }
  return count;
}

function findBuildableRoadAtFogEdge(engine) {
  for (const chunk of engine.terrain.chunks.values()) {
    for (const tile of chunk.tiles) {
      if (!tile.explored || tile.occupied || !engine.canPlace('path', tile.x, tile.y).ok) continue;
      let hasFogNearby = false;
      for (let dy = -5; dy <= 5 && !hasFogNearby; dy++) {
        for (let dx = -5; dx <= 5; dx++) {
          if (dx * dx + dy * dy > 25) continue;
          const neighbor = engine.terrain.peek(tile.x + dx, tile.y + dy);
          if (neighbor && !neighbor.explored) {
            hasFogNearby = true;
            break;
          }
        }
      }
      if (hasFogNearby) return tile;
    }
  }
  return null;
}

// A road at the frontier used to reveal a 5-tile radius and allow chain expansion.
const roadEngine = new GameEngine(123456789, 1);
const roadSpot = findBuildableRoadAtFogEdge(roadEngine);
assert(roadSpot, 'test setup: expected a legal road tile beside unexplored fog');
const beforeRoad = exploredCount(roadEngine);
assert(roadEngine.place('path', roadSpot.x, roadSpot.y), 'road placement should succeed');
assert.equal(exploredCount(roadEngine), beforeRoad, 'placing a road must not reveal fog');
console.log('PASS: road placement does not reveal fog');

// Ordinary player buildings must not become an alternate exploration method.
let buildingSpot = null;
for (const chunk of roadEngine.terrain.chunks.values()) {
  for (const tile of chunk.tiles) {
    if (tile.explored && !tile.occupied && roadEngine.canPlace('tent', tile.x, tile.y).ok) {
      buildingSpot = tile;
      break;
    }
  }
  if (buildingSpot) break;
}
assert(buildingSpot, 'test setup: expected a legal tent tile');
const beforeBuilding = exploredCount(roadEngine);
assert(roadEngine.place('tent', buildingSpot.x, buildingSpot.y), 'tent placement should succeed');
assert.equal(exploredCount(roadEngine), beforeBuilding, 'placing an ordinary building must not reveal fog');
console.log('PASS: ordinary building placement does not reveal fog');

// Random city-defense events must not grant free exploration either.
const defenseEngine = new GameEngine(987654321, 1);
Object.defineProperty(defenseEngine, 'squadSize', { configurable: true, get: () => 2 });
const beforeDefense = exploredCount(defenseEngine);
assert(defenseEngine.startBattle('defense'), 'test setup: city-defense battle should start');
assert.equal(exploredCount(defenseEngine), beforeDefense, 'a city-defense battle must not reveal fog');
console.log('PASS: city-defense battles do not reveal fog');

// Keep expedition travel and arrival as the legitimate exploration mechanism.
const engineSource = fs.readFileSync(require.resolve('../src/lib/game/engine.ts'), 'utf8');
assert.match(engineSource, /this\.terrain\.reveal\(Math\.round\(e\.x\),\s*Math\.round\(e\.y\),\s*EXP_REVEAL_RADIUS\)/);
assert.match(engineSource, /this\.terrain\.reveal\(e\.tx,\s*e\.ty,\s*EXP_ARRIVE_REVEAL\)/);
console.log('PASS: expedition travel and arrival still reveal fog');
