// ===== 城市统计面板 =====
'use client';
import { useGame } from '@/lib/game/store';
import { RES_ORDER, RES_META, ERAS, DIFFICULTIES } from '@/lib/game/constants';
import { BUILDING_DEFS, CATEGORY_META } from '@/lib/game/buildings';
import { GIcon } from './GameIcon';
import { cn } from '@/lib/utils';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';

export function StatsPanel() {
  const snap = useGame(s => s.snap);
  const engine = useGame(s => s.engine);
  const show = useGame(s => s.showStats);
  const setPanel = useGame(s => s.setPanel);
  if (!snap || !engine) return null;

  const catCounts: Record<string, number> = {};
  for (const b of engine.buildings.values()) {
    const cat = BUILDING_DEFS[b.defId].category;
    catCounts[cat] = (catCounts[cat] ?? 0) + 1;
  }

  return (
    <Dialog open={show} onOpenChange={v => setPanel('showStats', v)}>
      <DialogContent className="max-w-md bg-stone-900 border-stone-700 text-stone-100 max-h-[85vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-amber-200">
            <GIcon name="BarChart3" size={18} /> 城市统计 · {ERAS[snap.era].name} · {DIFFICULTIES[snap.difficulty]?.name ?? '标准'}
          </DialogTitle>
        </DialogHeader>

        <div className="rounded-xl border border-stone-700 bg-stone-800/40 p-3 space-y-1.5">
          {RES_ORDER.map(k => {
            const st = snap.stats[k];
            return (
              <div key={k} className="flex items-center justify-between text-xs">
                <span className="flex items-center gap-1.5">
                  <GIcon name={RES_META[k].icon} size={13} style={{ color: RES_META[k].color }} />
                  <span className="text-stone-300">{RES_META[k].name}</span>
                </span>
                <span className="flex items-center gap-2 tabular-nums">
                  <span className="text-emerald-400">+{st.produce.toFixed(1)}</span>
                  {st.consume > 0.01 && <span className="text-red-400">-{st.consume.toFixed(1)}</span>}
                  <span className={cn('font-bold w-14 text-right', st.net >= 0 ? 'text-stone-100' : 'text-red-400')}>
                    {st.net >= 0 ? '+' : ''}{st.net.toFixed(1)}/日
                  </span>
                </span>
              </div>
            );
          })}
        </div>

        <div className="grid grid-cols-2 gap-2">
          <div className="rounded-xl border border-stone-700 bg-stone-800/40 p-3 space-y-1.5 text-xs">
            <div className="text-stone-400 font-bold">城市</div>
            <div className="flex justify-between"><span className="text-stone-400">人口</span><span className="font-bold">{snap.pop} / {snap.popCap}</span></div>
            <div className="flex justify-between"><span className="text-stone-400">劳动力</span><span className="font-bold">{snap.workersEmployed} / {snap.workersTotal}</span></div>
            <div className="flex justify-between" title="闲人会在街上闲逛; 上班的人在工作岗位上, 不占用画面"><span className="text-stone-400">闲逛闲人</span><span className="font-bold text-amber-200">{Math.max(0, snap.workersTotal - snap.workersEmployed)}</span></div>
            <div className="flex justify-between"><span className="text-stone-400">建筑总数</span><span className="font-bold">{snap.buildings}</span></div>
            <div className="flex justify-between"><span className="text-stone-400">剩余树林</span><span className="font-bold">{snap.treeCount} 格</span></div>
            <div className="flex justify-between"><span className="text-stone-400">已过天数</span><span className="font-bold">{snap.day} 天</span></div>
          </div>
          <div className="rounded-xl border border-stone-700 bg-stone-800/40 p-3 space-y-1.5 text-xs">
            <div className="text-stone-400 font-bold">设施</div>
            {Object.entries(CATEGORY_META).map(([cat, meta]) => (
              <div key={cat} className="flex justify-between">
                <span className="text-stone-400">{meta.name}</span>
                <span className="font-bold">{catCounts[cat] ?? 0}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="rounded-xl border border-stone-700 bg-stone-800/40 p-3 space-y-1.5 text-xs">
          <div className="text-stone-400 font-bold">人口与社会</div>
          <div className="flex justify-between" title="幸福>55且粮食充足时, 人口自然增长"><span className="text-stone-400 flex items-center gap-1"><GIcon name="Baby" size={12} className="text-pink-300" />生育率</span><span className="font-bold">{snap.birthRate.toFixed(2)} 人/日</span></div>
          <div className="flex justify-between" title="幸福越高吸引力越强, 广播塔+60%, 地价加成"><span className="text-stone-400 flex items-center gap-1"><GIcon name="Magnet" size={12} className="text-cyan-300" />移民吸引力</span><span className="font-bold">{snap.attraction.toFixed(2)} 人/日</span></div>
          <div className="flex justify-between" title="岗位总数 vs 劳动力"><span className="text-stone-400 flex items-center gap-1"><GIcon name="Briefcase" size={12} className="text-orange-300" />就业</span><span className="font-bold">{snap.workersEmployed}/{snap.workersTotal} · 岗位 {snap.jobsTotal}</span></div>
          <div className="flex justify-between" title="服务/教育/水电拉高, 污染噪音拉低; 影响税收与移民"><span className="text-stone-400 flex items-center gap-1"><GIcon name="Gem" size={12} className="text-amber-300" />平均地价</span><span className={cn('font-bold', snap.landValue < 30 ? 'text-red-300' : snap.landValue > 60 ? 'text-amber-200' : '')}>{snap.landValue} / 100</span></div>
          <div className="flex justify-between" title="市政预算额外开支"><span className="text-stone-400 flex items-center gap-1"><GIcon name="Wallet" size={12} className="text-cyan-300" />预算超支</span><span className="font-bold">{snap.budgetCost}/日</span></div>
          {(snap.tradeSpent > 0 || snap.tradeEarned > 0) && (
            <div className="flex justify-between" title="集市自动进出口 (今日)"><span className="text-stone-400 flex items-center gap-1"><GIcon name="ArrowLeftRight" size={12} className="text-emerald-300" />今日贸易</span><span className="font-bold tabular-nums"><span className="text-red-300">-{snap.tradeSpent}</span> <span className="text-emerald-300">+{snap.tradeEarned}</span></span></div>
          )}
          <div className="flex justify-between" title="战斗胜场"><span className="text-stone-400 flex items-center gap-1"><GIcon name="Trophy" size={12} className="text-amber-300" />战斗胜场</span><span className="font-bold">{snap.battleWins}</span></div>
          <div className="flex justify-between" title="进行中的远征"><span className="text-stone-400 flex items-center gap-1"><GIcon name="Compass" size={12} className="text-cyan-300" />远征中</span><span className="font-bold">{snap.expeditions.length} 支</span></div>
          {snap.loan > 0 && (
            <div className="flex justify-between" title="银行贷款日息 0.8%"><span className="text-stone-400 flex items-center gap-1"><GIcon name="Landmark" size={12} className="text-red-300" />未偿贷款</span><span className="font-bold text-red-300">{snap.loan} (日息 {Math.ceil(snap.loan * 0.008)})</span></div>
          )}
          <div className="flex justify-between" title="图书馆产出, 研究时每卷抵15资金"><span className="text-stone-400 flex items-center gap-1"><GIcon name="Scroll" size={12} className="text-indigo-300" />典籍</span><span className="font-bold">{snap.scrolls} 卷</span></div>
          {snap.waterBufferCap > 0 && (
            <div className="flex justify-between" title="蓄水池缓冲, 供水波动时先行垫付"><span className="text-stone-400 flex items-center gap-1"><GIcon name="Database" size={12} className="text-teal-300" />蓄水缓冲</span><span className="font-bold">{snap.waterBuffer} / {snap.waterBufferCap}</span></div>
          )}
        </div>

        <div className="rounded-xl border border-stone-700 bg-stone-800/40 p-3 space-y-1.5 text-xs">
          <div className="text-stone-400 font-bold">公共事业</div>
          <div className="flex justify-between">
            <span className="text-stone-400 flex items-center gap-1"><GIcon name="Zap" size={12} className="text-amber-300" />电力</span>
            <span className={cn('font-bold', snap.powerDemand > snap.powerSupply ? 'text-red-400' : '')}>供 {snap.powerSupply} / 需 {snap.powerDemand}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-stone-400 flex items-center gap-1"><GIcon name="Droplets" size={12} className="text-teal-300" />水</span>
            <span className={cn('font-bold', snap.waterDemand > snap.waterSupply ? 'text-red-400' : '')}>供 {snap.waterSupply} / 需 {snap.waterDemand}</span>
          </div>
          {snap.foodDaysLeft >= 0 && (
            <div className="flex justify-between">
              <span className="text-stone-400 flex items-center gap-1"><GIcon name="Wheat" size={12} className="text-yellow-400" />存粮</span>
              <span className={cn('font-bold', snap.foodDaysLeft < 3 ? 'text-red-400' : '')}>可支撑 {snap.foodDaysLeft.toFixed(1)} 天</span>
            </div>
          )}
        </div>

        <div className="text-[11px] text-stone-500 leading-relaxed">
          提示: 画面上只显示闲逛的闲人与少量路人, 上班中的居民在工作岗位上;
          幸福度由公园、学校、照明等设施提升, 被工厂污染、水电短缺、住房拥挤、夜间漆黑拉低;
          秩序由图腾、警察局提升。幸福 &lt; 30 可能爆发暴乱, 核电厂在秩序过低时有泄漏风险。
        </div>
      </DialogContent>
    </Dialog>
  );
}
