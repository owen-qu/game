// ===== 时代与科技面板 =====
'use client';
import { useGame } from '@/lib/game/store';
import { RESEARCH_DEFS } from '@/lib/game/buildings';
import { RES_META, ERAS, ERA_COLORS } from '@/lib/game/constants';
import { gameAudio } from '@/lib/game/audio';
import { GIcon } from './GameIcon';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';

export function TechPanel() {
  const snap = useGame(s => s.snap);
  const engine = useGame(s => s.engine);
  const show = useGame(s => s.showTech);
  const setPanel = useGame(s => s.setPanel);
  if (!snap || !engine) return null;
  const era = ERAS[snap.era];
  const next = ERAS[snap.era + 1];
  const progress = engine.eraProgress();
  const researches = Object.values(RESEARCH_DEFS).filter(r => r.era <= snap.era);

  return (
    <Dialog open={show} onOpenChange={v => setPanel('showTech', v)}>
      <DialogContent className="max-w-lg bg-stone-900 border-stone-700 text-stone-100 max-h-[85vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-amber-200">
            <GIcon name="FlaskConical" size={18} /> 时代与科技
          </DialogTitle>
        </DialogHeader>

        {/* 当前时代 */}
        <div className="rounded-xl border p-3" style={{ borderColor: ERA_COLORS[snap.era] + '80', background: ERA_COLORS[snap.era] + '15' }}>
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full" style={{ background: ERA_COLORS[snap.era] }} />
            <span className="font-bold" style={{ color: ERA_COLORS[snap.era] }}>{era.name}</span>
            <span className="text-xs text-stone-400">{era.slogan}</span>
          </div>
        </div>

        {/* 下一时代 */}
        {next && (
          <div className="rounded-xl border border-stone-700 bg-stone-800/40 p-3 space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <GIcon name="Trophy" size={15} className="text-amber-300" />
                <span className="text-sm font-bold text-stone-200">晋升「{next.name}」</span>
              </div>
              <span className="text-[10px] text-stone-500">{next.slogan}</span>
            </div>
            <div className="space-y-1">
              {progress.items.map((it, i) => (
                <div key={i} className="flex items-center justify-between text-xs">
                  <span className={cn('flex items-center gap-1.5', it.done ? 'text-emerald-400' : 'text-stone-400')}>
                    {it.done ? <GIcon name="Check" size={12} /> : <span className="w-3 h-3 rounded-full border border-stone-500 inline-block" />}
                    {it.label}
                  </span>
                  <span className="tabular-nums text-stone-400">{it.value}</span>
                </div>
              ))}
            </div>
            <Button className="w-full font-bold" disabled={!progress.ok}
              onClick={() => { engine.advanceEra(); setPanel('showTech', false); }}>
              {progress.ok ? `进入「${next.name}」` : '条件未满足'}
            </Button>
          </div>
        )}

        {/* 研究 */}
        <div className="space-y-2">
          <div className="text-sm font-bold text-stone-200 flex items-center gap-1.5">
            <GIcon name="Sparkles" size={14} className="text-amber-300" /> 科技研究
          </div>
          <div className="grid grid-cols-1 gap-2">
            {researches.map(r => {
              const done = snap.research.includes(r.id);
              const affordable = Object.entries(r.cost).every(([k, v]) => snap.res[k as keyof typeof snap.res] >= (v ?? 0));
              return (
                <div key={r.id} className={cn('rounded-xl border p-2.5 flex items-center gap-3',
                  done ? 'border-emerald-800 bg-emerald-950/40' : 'border-stone-700 bg-stone-800/40')}>
                  <div className="flex-1">
                    <div className="text-xs font-bold text-stone-100">{r.name}
                      <span className="ml-1.5 text-[10px] font-normal text-stone-500">{ERAS[r.era].name}</span>
                    </div>
                    <div className="text-[11px] text-stone-400">{r.desc}</div>
                  </div>
                  {done ? (
                    <span className="flex items-center gap-1 text-xs text-emerald-400 font-bold"><GIcon name="Check" size={13} />已研究</span>
                  ) : (
                    <div className="flex flex-col items-end gap-1">
                      <div className="flex gap-1.5">
                        {Object.entries(r.cost).map(([k, v]) => (
                          <span key={k} className="flex items-center gap-0.5 text-[10px]">
                            <GIcon name={RES_META[k as keyof typeof RES_META].icon} size={10} style={{ color: RES_META[k as keyof typeof RES_META].color }} />
                            <span className={affordable ? 'text-stone-300' : 'text-red-400'}>{v}</span>
                          </span>
                        ))}
                      </div>
                      <Button size="sm" className="h-6 text-[11px] px-3" disabled={!affordable}
                        onClick={() => {
                          if (engine.doResearch(r.id)) gameAudio.playSfx('research');
                        }}>研究</Button>
                    </div>
                  )}
                </div>
              );
            })}
            {researches.length === 0 && <div className="text-xs text-stone-500 text-center py-2">当前时代暂无可研究科技</div>}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
