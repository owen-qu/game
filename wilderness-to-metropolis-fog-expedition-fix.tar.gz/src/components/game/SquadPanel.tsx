// ===== 战队面板 (军备升级 / 战队配置) =====
'use client';
import { useState } from 'react';
import { useGame } from '@/lib/game/store';
import { gameAudio } from '@/lib/game/audio';
import { WEAPON_TIERS, ARMOR_TIERS } from '@/lib/game/buildings';
import { RES_META } from '@/lib/game/constants';
import { GIcon } from './GameIcon';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import type { ResourceKey } from '@/lib/game/types';

export function SquadPanel() {
  const snap = useGame(s => s.snap);
  const engine = useGame(s => s.engine);
  const setPanel = useGame(s => s.setPanel);
  const show = useGame(s => s.showSquad);
  const [, force] = useState(0);
  if (!show || !snap || !engine) return null;

  const close = () => setPanel('showSquad', false);
  const wNext = WEAPON_TIERS[snap.weaponTier + 1];
  const aNext = ARMOR_TIERS[snap.armorTier + 1];
  const hasArmory = engine.hasBuilding('armory');
  const hasArmorShop = engine.hasBuilding('armory2');
  const barracks = [...engine.buildings.values()].filter(b => b.defId === 'barracks' && b.progress >= 1).length;

  const canAfford = (cost: Partial<Record<ResourceKey, number>> | null) => {
    if (!cost) return false;
    return (Object.entries(cost) as [ResourceKey, number][]).every(([k, v]) => snap.res[k] >= v);
  };

  const doWeapon = () => {
    if (engine.upgradeWeapon()) { gameAudio.playSfx('research'); force(x => x + 1); }
    else gameAudio.playSfx('error');
  };
  const doArmor = () => {
    if (engine.upgradeArmor()) { gameAudio.playSfx('research'); force(x => x + 1); }
    else gameAudio.playSfx('error');
  };

  return (
    <div className="fixed inset-0 z-40 flex items-center justify-center p-3 md:p-4">
      <div className="absolute inset-0 bg-black/55 backdrop-blur-[2px]" onClick={close} />
      <div className="relative w-full max-w-[520px] max-h-[88vh] overflow-y-auto game-scroll rounded-2xl border border-amber-800/50 bg-stone-950/95 shadow-2xl">
        <div className="flex items-center justify-between px-4 py-3 border-b border-stone-800 bg-gradient-to-r from-amber-950/60 to-transparent sticky top-0 z-10 backdrop-blur">
          <div className="flex items-center gap-2">
            <GIcon name="Swords" size={17} className="text-amber-300" />
            <div>
              <div className="text-sm font-black text-amber-100">战队 · 军备</div>
              <div className="text-[10px] text-stone-400">战斗将按速度决定行动顺序, 招式各有威力与命中</div>
            </div>
          </div>
          <Button size="icon" variant="ghost" className="h-7 w-7" onClick={close}><GIcon name="X" size={15} /></Button>
        </div>

        <div className="p-4 space-y-4">
          {/* 战队规模 */}
          <div className="rounded-xl border border-stone-700/70 bg-stone-900/70 p-3">
            <div className="flex items-center justify-between mb-2">
              <span className="text-[12px] font-bold text-stone-200 flex items-center gap-1.5">
                <GIcon name="Users" size={13} className="text-amber-300" /> 战队规模
              </span>
              <span className="text-lg font-black text-amber-200 tabular-nums">{snap.squadSize} <span className="text-[10px] text-stone-500">/ 8 人</span></span>
            </div>
            <div className="flex gap-1">
              {[0, 1, 2, 3, 4, 5, 6, 7].map(n => (
                <div key={n} className={cn('h-1.5 flex-1 rounded-full',
                  snap.squadSize > n ? 'bg-amber-500' : 'bg-stone-800')} />
              ))}
            </div>
            <p className="text-[10px] text-stone-400 mt-2 leading-snug">
              {barracks === 0
                ? '⚠ 尚未建造「训练场」—— 没有战队时, 野兽与袭击者将长驱直入。'
                : `已有 ${barracks} 座训练场 (首座解锁 2 人, 每加建 +1.5, 上限 8)。队员来自城市人口, 战斗中阵亡会永久损失人口。`}
            </p>
          </div>

          {/* v5: 载具部队 */}
          <div className="rounded-xl border border-stone-700/70 bg-stone-900/70 p-3">
            <div className="flex items-center justify-between mb-2">
              <span className="text-[12px] font-bold text-stone-200 flex items-center gap-1.5">
                <GIcon name="Truck" size={13} className="text-emerald-300" /> 载具部队
              </span>
              <span className="text-[10px] text-stone-500">城防自动参战 · 远征可编入</span>
            </div>
            <div className="grid grid-cols-3 gap-2">
              {([
                { key: 'apc', name: '装甲车', icon: 'Truck', built: '装甲车库' },
                { key: 'tank', name: '主战坦克', icon: 'ShieldAlert', built: '重型军工' },
                { key: 'heli', name: '武装直升机', icon: 'Rocket', built: '直升机坪' },
              ] as const).map(v => {
                const total = [...engine.buildings.values()].filter(b =>
                  b.progress >= 1 && (v.key === 'apc' ? b.defId === 'garage' : v.key === 'tank' ? b.defId === 'tank_plant' : b.defId === 'helipad')).length;
                const readyN = snap.vehicles[v.key];
                return (
                  <div key={v.key} className={cn('rounded-lg border px-2 py-2 text-center',
                    total > 0 ? (readyN > 0 ? 'border-emerald-800/70 bg-emerald-950/30' : 'border-stone-700 bg-stone-800/60') : 'border-stone-800 bg-stone-900/50 opacity-60')}>
                    <GIcon name={v.icon} size={16} className={readyN > 0 ? 'text-emerald-300 mx-auto' : 'text-stone-500 mx-auto'} />
                    <div className="text-[10px] font-bold text-stone-200 mt-1">{v.name}</div>
                    <div className="text-[13px] font-black tabular-nums mt-0.5">
                      {total === 0 ? <span className="text-stone-600">未建造</span>
                        : readyN > 0 ? <span className="text-emerald-300">×{readyN} 就绪</span>
                          : <span className="text-orange-400">重建中…</span>}
                    </div>
                    {total === 0 && <div className="text-[8px] text-stone-600 mt-0.5">需{v.built}</div>}
                  </div>
                );
              })}
            </div>
            <p className="text-[10px] text-stone-400 mt-2 leading-snug">
              每座载具库常备一辆载具: 城防战自动参战, 远征时可在派遣面板编入 (消耗石油, 大幅提速)。战损后 3 日重建。
            </p>
          </div>

          {/* 武器等级 */}
          <div className="rounded-xl border border-stone-700/70 bg-stone-900/70 p-3">
            <div className="flex items-center justify-between mb-2">
              <span className="text-[12px] font-bold text-stone-200 flex items-center gap-1.5">
                <GIcon name="Sword" size={13} className="text-orange-300" /> 武器等级
              </span>
              <span className="text-[11px] text-stone-300">当前: <b className="text-orange-200">{WEAPON_TIERS[snap.weaponTier].name}</b> (攻击 +{WEAPON_TIERS[snap.weaponTier].atk})</span>
            </div>
            <div className="flex gap-1 mb-2">
              {WEAPON_TIERS.map((t, i) => (
                <div key={t.name} className={cn('flex-1 rounded text-center text-[8px] py-1 truncate',
                  i <= snap.weaponTier ? 'bg-orange-800/70 text-orange-100' : 'bg-stone-800 text-stone-500')}
                  title={t.name}>{t.name}</div>
              ))}
            </div>
            {wNext ? (
              <div className="flex items-center justify-between rounded-lg bg-stone-800/60 border border-stone-700 px-2.5 py-2">
                <div>
                  <div className="text-[11px] font-bold text-stone-100">升级至「{wNext.name}」</div>
                  <div className="text-[10px] text-stone-400">全队攻击 +{wNext.atk - WEAPON_TIERS[snap.weaponTier].atk}</div>
                  <div className="flex gap-2 mt-1">
                    {wNext.cost && (Object.entries(wNext.cost) as [ResourceKey, number][]).map(([k, v]) => (
                      <span key={k} className={cn('flex items-center gap-0.5 text-[10px] font-bold', snap.res[k] >= v ? 'text-stone-300' : 'text-red-400')}>
                        <GIcon name={RES_META[k].icon} size={10} style={{ color: RES_META[k].color }} />{v}
                      </span>
                    ))}
                  </div>
                </div>
                <Button size="sm" className="h-8 px-3 text-[11px] bg-orange-700 hover:bg-orange-600 text-white"
                  disabled={!hasArmory || !canAfford(wNext.cost)} onClick={doWeapon}>
                  {hasArmory ? '锻造' : '需军械坊'}
                </Button>
              </div>
            ) : (
              <div className="text-[11px] text-stone-500 text-center py-1.5">已达最高武器等级 ✦</div>
            )}
          </div>

          {/* 盔甲等级 */}
          <div className="rounded-xl border border-stone-700/70 bg-stone-900/70 p-3">
            <div className="flex items-center justify-between mb-2">
              <span className="text-[12px] font-bold text-stone-200 flex items-center gap-1.5">
                <GIcon name="Shield" size={13} className="text-sky-300" /> 盔甲等级
              </span>
              <span className="text-[11px] text-stone-300">当前: <b className="text-sky-200">{ARMOR_TIERS[snap.armorTier].name}</b> (防御 +{ARMOR_TIERS[snap.armorTier].def})</span>
            </div>
            <div className="flex gap-1 mb-2">
              {ARMOR_TIERS.map((t, i) => (
                <div key={t.name} className={cn('flex-1 rounded text-center text-[8px] py-1 truncate',
                  i <= snap.armorTier ? 'bg-sky-800/70 text-sky-100' : 'bg-stone-800 text-stone-500')}
                  title={t.name}>{t.name}</div>
              ))}
            </div>
            {aNext ? (
              <div className="flex items-center justify-between rounded-lg bg-stone-800/60 border border-stone-700 px-2.5 py-2">
                <div>
                  <div className="text-[11px] font-bold text-stone-100">升级至「{aNext.name}」</div>
                  <div className="text-[10px] text-stone-400">全队防御 +{aNext.def - ARMOR_TIERS[snap.armorTier].def} · 体力 +5</div>
                  <div className="flex gap-2 mt-1">
                    {aNext.cost && (Object.entries(aNext.cost) as [ResourceKey, number][]).map(([k, v]) => (
                      <span key={k} className={cn('flex items-center gap-0.5 text-[10px] font-bold', snap.res[k] >= v ? 'text-stone-300' : 'text-red-400')}>
                        <GIcon name={RES_META[k].icon} size={10} style={{ color: RES_META[k].color }} />{v}
                      </span>
                    ))}
                  </div>
                </div>
                <Button size="sm" className="h-8 px-3 text-[11px] bg-sky-700 hover:bg-sky-600 text-white"
                  disabled={!hasArmorShop || !canAfford(aNext.cost)} onClick={doArmor}>
                  {hasArmorShop ? '打造' : '需甲胄坊'}
                </Button>
              </div>
            ) : (
              <div className="text-[11px] text-stone-500 text-center py-1.5">已达最高盔甲等级 ✦</div>
            )}
          </div>

          {/* 战绩 */}
          <div className="grid grid-cols-3 gap-2 text-center">
            <div className="rounded-lg bg-stone-900/70 border border-stone-700/60 py-2">
              <div className="text-lg font-black text-emerald-300 tabular-nums">{snap.battleWins}</div>
              <div className="text-[9px] text-stone-500">战斗胜利</div>
            </div>
            <div className="rounded-lg bg-stone-900/70 border border-stone-700/60 py-2">
              <div className="text-lg font-black text-red-400 tabular-nums">{engine.battleLosses}</div>
              <div className="text-[9px] text-stone-500">战斗失败</div>
            </div>
            <div className="rounded-lg bg-stone-900/70 border border-stone-700/60 py-2">
              <div className="text-lg font-black text-cyan-300 tabular-nums">{snap.expeditions.length}</div>
              <div className="text-[9px] text-stone-500">远征进行中</div>
            </div>
          </div>

          <p className="text-[10px] text-stone-500 leading-relaxed">
            敌人会随时代进化: 荒野的野兽 → 村落时代的野人 → 工业时代的匪帮 → 现代的叛军装甲。远征越远, 遭遇的敌人越强, 战利品也越丰厚。「队列操练」科技可提升全队体力 15%。
          </p>
        </div>
      </div>
    </div>
  );
}
