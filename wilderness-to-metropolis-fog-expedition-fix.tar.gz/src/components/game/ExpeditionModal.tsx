// ===== 远征派遣确认面板 (v5: 8 人 + 载具编组) =====
'use client';
import { useMemo, useState } from 'react';
import { useGame } from '@/lib/game/store';
import { gameAudio } from '@/lib/game/audio';
import { GIcon } from './GameIcon';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

type Vehicles = { apc: number; tank: number; heli: number };
const NO_VEHICLES: Vehicles = { apc: 0, tank: 0, heli: 0 };

const VEHICLE_META: { key: keyof Vehicles; name: string; icon: string; oil: number; desc: string }[] = [
  { key: 'apc', name: '装甲车', icon: 'Truck', oil: 6, desc: '提速 35% · 减轻地形减速 · 战力强' },
  { key: 'tank', name: '主战坦克', icon: 'ShieldAlert', oil: 10, desc: '提速 15% · 主炮葵靡 · 高防御' },
  { key: 'heli', name: '直升机', icon: 'Rocket', oil: 16, desc: '提速 120% · 无视地形 · 火箭弹' },
];

export function ExpeditionModal() {
  const engine = useGame(s => s.engine);
  const renderer = useGame(s => s.renderer);
  const target = useGame(s => s.expeditionTarget);
  const setTarget = useGame(s => s.setExpeditionTarget);
  const [members, setMembers] = useState(2);
  const [vehicles, setVehicles] = useState<Vehicles>(NO_VEHICLES);

  const ready = engine ? engine.readyVehicles : NO_VEHICLES;
  const preview = useMemo(() => {
    if (!engine || !target) return null;
    return engine.expeditionPreview(target.x, target.y, members, vehicles);
  }, [engine, target, members, vehicles]);

  if (!engine || !target || !preview) return null;

  const maxMembers = Math.max(1, Math.min(engine.squadSize, 8));
  const tooClose = preview.dist < 10;
  const noFood = engine.res.food < preview.foodCost;
  const noOil = engine.res.oil < preview.oilCost;
  const hasAnyVehicle = ready.apc + ready.tank + ready.heli > 0;
  const vehicleCount = vehicles.apc + vehicles.tank + vehicles.heli;

  const toggleVehicle = (key: keyof Vehicles) => {
    setVehicles(v => {
      const next = { ...v };
      if (next[key] > 0) next[key] = 0;
      else if (ready[key] > 0) next[key] = 1;
      return next;
    });
  };

  const close = () => {
    setTarget(null);
    setVehicles(NO_VEHICLES);
    renderer?.focusOn(target.x, target.y);
  };

  const launch = () => {
    const r = engine.startExpedition(target.x, target.y, members, vehicles);
    if (r.ok) {
      gameAudio.playSfx('march');
      renderer?.setMode({ type: 'none' });
      useGame.setState({ mode: { type: 'none' } });
      setTarget(null);
      setVehicles(NO_VEHICLES);
      renderer?.focusOn(target.x, target.y);
    } else {
      engine.notify('expedition', '无法派遣远征队', r.reason ?? '条件不满足', 'bad');
      gameAudio.playSfx('error');
    }
  };

  return (
    <div className="fixed inset-0 z-40 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/50 backdrop-blur-[2px]" onClick={close} />
      <div className="relative w-full max-w-[440px] rounded-2xl border border-cyan-800/60 bg-stone-950/95 shadow-2xl overflow-hidden max-h-[92vh] overflow-y-auto game-scroll">
        <div className="flex items-center gap-2 px-4 py-3 border-b border-stone-800 bg-gradient-to-r from-cyan-950/70 to-transparent">
          <GIcon name="Compass" size={17} className="text-cyan-300" />
          <div>
            <div className="text-sm font-black text-cyan-100">派遣远征队</div>
            <div className="text-[10px] text-stone-400">目标: ({target.x}, {target.y}){preview.inFog ? ' · 迷雾区域' : ''}</div>
          </div>
        </div>

        <div className="p-4 space-y-3">
          {tooClose ? (
            <div className="rounded-lg bg-red-950/60 border border-red-800 px-3 py-2.5 text-[11px] text-red-300 leading-relaxed">
              目标距城市仅 <b>{preview.dist}</b> 格 —— 不足 10 格不算远征。附近的树木石块可直接用「开荒」派人采集。
            </div>
          ) : (
            <>
              {/* 队员选择 (最多 8 人) */}
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <span className="text-[11px] text-stone-300 font-bold flex items-center gap-1">
                    <GIcon name="Users" size={12} className="text-amber-300" /> 远征队员
                  </span>
                  <span className="text-[10px] text-stone-500">战队上限 {maxMembers} 人{engine.squadSize === 0 && ' (需训练场)'}</span>
                </div>
                <div className="grid grid-cols-8 gap-1">
                  {[1, 2, 3, 4, 5, 6, 7, 8].map(n => (
                    <button key={n} disabled={n > maxMembers}
                      onClick={() => setMembers(n)}
                      className={cn('h-8 rounded-lg border text-[12px] font-black transition-all',
                        members === n ? 'border-amber-400 bg-amber-950/70 text-amber-200 scale-105'
                          : n > maxMembers ? 'border-stone-800 bg-stone-900/50 text-stone-600 cursor-not-allowed'
                            : 'border-stone-700 bg-stone-800/60 text-stone-300 hover:border-stone-500')}>
                      {n}
                    </button>
                  ))}
                </div>
              </div>

              {/* v5 载具编组 */}
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <span className="text-[11px] text-stone-300 font-bold flex items-center gap-1">
                    <GIcon name="Truck" size={12} className="text-emerald-300" /> 随队载具
                  </span>
                  <span className="text-[10px] text-stone-500">
                    {hasAnyVehicle ? '点击编入 (油耗一次付清)' : '建造装甲车库/重型军工/直升机坪解锁'}
                  </span>
                </div>
                <div className="grid grid-cols-3 gap-1.5">
                  {VEHICLE_META.map(v => {
                    const can = ready[v.key] > 0;
                    const on = vehicles[v.key] > 0;
                    return (
                      <button key={v.key} disabled={!can}
                        onClick={() => toggleVehicle(v.key)}
                        className={cn('rounded-lg border px-1.5 py-1.5 text-left transition-all',
                          on ? 'border-emerald-400 bg-emerald-950/60 scale-[1.03]'
                            : can ? 'border-stone-700 bg-stone-800/60 hover:border-stone-500'
                              : 'border-stone-800 bg-stone-900/50 opacity-50 cursor-not-allowed')}>
                        <div className="flex items-center gap-1">
                          <GIcon name={v.icon} size={12} className={on ? 'text-emerald-300' : 'text-stone-400'} />
                          <span className={cn('text-[10.5px] font-black', on ? 'text-emerald-200' : 'text-stone-300')}>{v.name}</span>
                        </div>
                        <div className="text-[8.5px] text-stone-500 mt-0.5 leading-tight">{v.desc}</div>
                        <div className="text-[8.5px] text-orange-400/80 mt-0.5">油耗 {v.oil} 石油</div>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* 行程信息 */}
              <div className="grid grid-cols-2 gap-2 text-[11px]">
                <div className="rounded-lg bg-stone-800/60 border border-stone-700/60 px-2.5 py-2">
                  <div className="text-stone-400 text-[10px]">路程</div>
                  <div className="font-black text-stone-100 tabular-nums">{preview.dist} 格</div>
                </div>
                <div className="rounded-lg bg-stone-800/60 border border-stone-700/60 px-2.5 py-2">
                  <div className="text-stone-400 text-[10px]">单程耗时 (1×){vehicleCount > 0 && ' · 载具加速'}</div>
                  <div className={cn('font-black tabular-nums', vehicleCount > 0 ? 'text-emerald-300' : 'text-stone-100')}>{(preview.etaSec / 60).toFixed(1)} 分钟</div>
                </div>
                <div className={cn('rounded-lg border px-2.5 py-2',
                  noFood ? 'bg-red-950/60 border-red-800' : 'bg-stone-800/60 border-stone-700/60')}>
                  <div className="text-stone-400 text-[10px]">预计全程耗粮</div>
                  <div className={cn('font-black tabular-nums', noFood ? 'text-red-300' : 'text-amber-200')}>{preview.foodCost} 食物</div>
                </div>
                <div className={cn('rounded-lg border px-2.5 py-2',
                  noOil ? 'bg-red-950/60 border-red-800' : 'bg-stone-800/60 border-stone-700/60')}>
                  <div className="text-stone-400 text-[10px]">载具油耗</div>
                  <div className={cn('font-black tabular-nums', noOil ? 'text-red-300' : 'text-orange-300')}>{preview.oilCost} 石油</div>
                </div>
              </div>

              {preview.ruin && (
                <div className="rounded-lg bg-indigo-950/50 border border-indigo-800/60 px-3 py-2 flex items-start gap-2">
                  <GIcon name="Landmark" size={14} className="text-indigo-300 mt-0.5 shrink-0" />
                  <div>
                    <div className="text-[11px] font-bold text-indigo-200">目标处发现「{preview.ruin}」</div>
                    <div className="text-[10px] text-stone-400 leading-snug">远征队抵达后将自动搜刮, 获得物资。石碑类遗迹还会解读出典籍。</div>
                  </div>
                </div>
              )}

              {preview.inFog && (
                <div className="rounded-lg bg-cyan-950/40 border border-cyan-900/60 px-3 py-2 flex items-start gap-2">
                  <GIcon name="CloudFog" size={14} className="text-cyan-300 mt-0.5 shrink-0" />
                  <div className="text-[10px] text-stone-300 leading-snug">
                    迷雾区域 —— 远征队将沿途揭开视野 (半径 4), 抵达后进一步探索周边 (半径 6)。
                  </div>
                </div>
              )}

              {(noFood || noOil) && (
                <div className="rounded-lg bg-red-950/60 border border-red-800 px-3 py-2 text-[11px] text-red-300">
                  {noFood && <div>⚠ 存粮不足 (现有 {Math.floor(engine.res.food)}, 需约 {preview.foodCost})。</div>}
                  {noOil && <div>⚠ 石油不足 (现有 {Math.floor(engine.res.oil)}, 载具需 {preview.oilCost}) —— 可减少载具或暂缓出发。</div>}
                </div>
              )}
            </>
          )}
        </div>

        <div className="flex gap-2 px-4 pb-4">
          <Button variant="secondary" className="flex-1 h-9 text-xs" onClick={close}>取消</Button>
          <Button className="flex-1 h-9 text-xs bg-cyan-700 hover:bg-cyan-600 text-white font-black"
            disabled={tooClose || noFood || noOil || engine.squadSize === 0} onClick={launch}>
            <GIcon name="Send" size={13} className="mr-1" /> 出发!
          </Button>
        </div>
      </div>
    </div>
  );
}

/** 远征队状态条 (左下角, 常驻显示) */
export function ExpeditionBar() {
  const snap = useGame(s => s.snap);
  const renderer = useGame(s => s.renderer);
  if (!snap || snap.expeditions.length === 0) return null;
  const STATE_LABEL: Record<string, string> = { outbound: '行军中', scavenge: '搜刮中', returning: '返程中' };
  const STATE_ICON: Record<string, string> = { outbound: 'Footprints', scavenge: 'Landmark', returning: 'Undo2' };
  const fmtEta = (sec: number) => sec > 90 ? `${(sec / 60).toFixed(1)}分` : `${Math.round(sec)}秒`;
  return (
    <div className="fixed left-2 bottom-[132px] md:bottom-[128px] z-20 pointer-events-auto space-y-1.5">
      {snap.expeditions.map(e => {
        const vCount = (e.vehicles?.apc ?? 0) + (e.vehicles?.tank ?? 0) + (e.vehicles?.heli ?? 0);
        return (
          <button key={e.id} onClick={() => renderer?.focusOn(e.tx, e.ty)}
            title={`剩余约 ${fmtEta(e.etaSec)} (1×速度) · 每秒耗粮 ${e.foodPerSec}`}
            className="flex items-center gap-2 rounded-lg border border-cyan-800/70 bg-stone-950/90 backdrop-blur px-2.5 py-1.5 shadow-lg hover:border-cyan-500 transition-colors">
            <GIcon name={STATE_ICON[e.state] ?? 'Compass'} size={13} className="text-cyan-300" />
            <div className="text-left">
              <div className="text-[10px] font-bold text-cyan-100">远征队 #{e.id} · {STATE_LABEL[e.state]}</div>
              <div className="text-[9px] text-stone-400 tabular-nums">
                {e.members}人{vCount > 0 ? ` + ${vCount}载具` : ''} · 已行 {e.traveled}/{e.dist} 格 · 剩 {fmtEta(e.etaSec)} · 粮 {e.foodPerSec}/秒
              </div>
            </div>
            <div className="w-14 h-1 rounded-full bg-stone-800 overflow-hidden">
              <div className="h-full bg-cyan-500 rounded-full transition-all"
                style={{ width: `${Math.min(100, (e.traveled / Math.max(1, e.dist)) * 100)}%` }} />
            </div>
          </button>
        );
      })}
    </div>
  );
}
