// ===== 开发者模式面板 =====
'use client';
import { useState } from 'react';
import { useGame } from '@/lib/game/store';
import { RES_ORDER, RES_META, ERAS, ERA_COLORS, DEV_SPEEDS } from '@/lib/game/constants';
import { GameEngine } from '@/lib/game/engine';
import { GIcon } from './GameIcon';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Slider } from '@/components/ui/slider';
import { Switch } from '@/components/ui/switch';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import type { ResourceKey, TileTerrain } from '@/lib/game/types';

// ---------- 小部件 ----------
function DevSection({ title, icon, children }: { title: string; icon?: string; children: React.ReactNode }) {
  return (
    <div className="rounded-xl border border-stone-700/70 bg-stone-800/40 p-2.5 space-y-2">
      <div className="flex items-center gap-1.5 text-[11px] font-bold text-amber-200/90">
        {icon && <GIcon name={icon} size={12} />} {title}
      </div>
      {children}
    </div>
  );
}

function NumRow({ label, icon, value, onSet, onAdd, color }: {
  label: string; icon?: string; value: string | number; onSet: (n: number) => void; onAdd: (n: number) => void; color?: string;
}) {
  const [txt, setTxt] = useState(String(value));
  // 外部值变化时同步输入框 (渲染期同步, 避免 effect 级联)
  const [prev, setPrev] = useState(value);
  if (value !== prev) { setPrev(value); setTxt(String(value)); }
  return (
    <div className="flex items-center gap-1.5">
      <div className="flex items-center gap-1 w-[64px] shrink-0">
        {icon && <GIcon name={icon} size={12} style={color ? { color } : undefined} />}
        <span className="text-[11px] text-stone-300">{label}</span>
      </div>
      <Input value={txt} onChange={e => setTxt(e.target.value)}
        onKeyDown={e => { if (e.key === 'Enter') { const n = parseFloat(txt); if (!Number.isNaN(n)) onSet(n); } }}
        className="h-7 flex-1 min-w-0 bg-stone-900 border-stone-600 text-[12px] tabular-nums px-1.5" />
      <Button size="sm" variant="secondary" className="h-7 px-2 text-[11px]" onClick={() => { const n = parseFloat(txt); if (!Number.isNaN(n)) onSet(n); }}>设为</Button>
      <Button size="sm" variant="outline" className="h-7 px-2 text-[11px]" onClick={() => onAdd(100)}>+100</Button>
      <Button size="sm" variant="outline" className="h-7 px-2 text-[11px]" onClick={() => onAdd(1000)}>+1k</Button>
      <Button size="sm" variant="outline" className="h-7 px-2 text-[11px] text-red-300" onClick={() => onSet(0)}>清零</Button>
    </div>
  );
}

function DevSlider({ label, icon, value, min = 0, max = 100, onCommit }: {
  label: string; icon?: string; value: number; min?: number; max?: number; onCommit: (v: number) => void;
}) {
  const [v, setV] = useState(value);
  const [prev, setPrev] = useState(value);
  if (value !== prev) { setPrev(value); setV(value); }
  return (
    <div className="space-y-1">
      <div className="flex items-center justify-between">
        <span className="flex items-center gap-1 text-[11px] text-stone-300">{icon && <GIcon name={icon} size={12} />}{label}</span>
        <span className="text-[11px] font-bold tabular-nums text-amber-200">{Math.round(v)}</span>
      </div>
      <Slider value={[v]} min={min} max={max} step={1}
        onValueChange={vals => setV(vals[0])}
        onValueCommit={vals => onCommit(vals[0])} />
    </div>
  );
}

const EVT_BUTTONS: { id: string; name: string; icon: string; tone: string }[] = [
  { id: 'fire', name: '火灾', icon: 'Flame', tone: 'bg-red-950/70 hover:bg-red-900/70 border-red-800 text-red-200' },
  { id: 'storm', name: '暴雨', icon: 'CloudRain', tone: 'bg-sky-950/70 hover:bg-sky-900/70 border-sky-800 text-sky-200' },
  { id: 'riot', name: '暴乱', icon: 'Swords', tone: 'bg-orange-950/70 hover:bg-orange-900/70 border-orange-800 text-orange-200' },
  { id: 'accident', name: '车祸', icon: 'CarFront', tone: 'bg-yellow-950/70 hover:bg-yellow-900/70 border-yellow-800 text-yellow-200' },
  { id: 'plague', name: '疫病', icon: 'AlertTriangle', tone: 'bg-lime-950/70 hover:bg-lime-900/70 border-lime-800 text-lime-200' },
  { id: 'quake', name: '地震', icon: 'Mountain', tone: 'bg-stone-800/70 hover:bg-stone-700/70 border-stone-600 text-stone-200' },
  { id: 'beast', name: '野兽袭击', icon: 'Dog', tone: 'bg-red-950/70 hover:bg-red-900/70 border-red-800 text-red-200' },
  { id: 'raid', name: '野人来犯', icon: 'User', tone: 'bg-orange-950/70 hover:bg-orange-900/70 border-orange-800 text-orange-200' },
  { id: 'bandit', name: '匪帮勒索', icon: 'Skull', tone: 'bg-stone-800/70 hover:bg-stone-700/70 border-stone-600 text-stone-200' },
  { id: 'rebel', name: '叛军来袭', icon: 'ShieldAlert', tone: 'bg-red-950/70 hover:bg-red-900/70 border-red-800 text-red-200' },
  { id: 'harvest', name: '丰收', icon: 'Wheat', tone: 'bg-emerald-950/70 hover:bg-emerald-900/70 border-emerald-800 text-emerald-200' },
  { id: 'caravan', name: '商队', icon: 'CircleDollarSign', tone: 'bg-emerald-950/70 hover:bg-emerald-900/70 border-emerald-800 text-emerald-200' },
  { id: 'immigrant', name: '移民潮', icon: 'Users', tone: 'bg-teal-950/70 hover:bg-teal-900/70 border-teal-800 text-teal-200' },
  { id: 'deposit', name: '矿藏', icon: 'Cog', tone: 'bg-slate-800/70 hover:bg-slate-700/70 border-slate-600 text-slate-200' },
  { id: 'win', name: '直接胜利', icon: 'Trophy', tone: 'bg-amber-950/70 hover:bg-amber-900/70 border-amber-700 text-amber-200' },
];

const TERRAIN_BRUSHES: { id: string; name: string; icon: string; tone: string }[] = [
  { id: 'grass', name: '草地', icon: 'Sprout', tone: 'text-lime-300' },
  { id: 'forest', name: '森林', icon: 'TreePine', tone: 'text-green-300' },
  { id: 'hill', name: '丘陵', icon: 'Mountain', tone: 'text-yellow-600' },
  { id: 'mountain', name: '山地', icon: 'MountainSnow', tone: 'text-stone-300' },
  { id: 'water', name: '水域', icon: 'Waves', tone: 'text-sky-300' },
  { id: 'sand', name: '沙滩', icon: 'SunMedium', tone: 'text-amber-200' },
  { id: 'rock', name: '岩石', icon: 'Gem', tone: 'text-slate-200' },
  { id: 'clear', name: '清除', icon: 'Trash2', tone: 'text-red-300' },
];

// ---------- 主面板 ----------
export function DevPanel() {
  const snap = useGame(s => s.snap);
  const engine = useGame(s => s.engine);
  const renderer = useGame(s => s.renderer);
  const show = useGame(s => s.showDev);
  const setPanel = useGame(s => s.setPanel);
  const mode = useGame(s => s.mode);
  const setMode = useGame(s => s.setMode);
  const [brushSize, setBrushSize] = useState(1);
  const [happiness, setHappiness] = useState(60);
  const [order, setOrder] = useState(60);
  const [pop, setPop] = useState('');
  const [day, setDay] = useState('');
  const [hour, setHour] = useState(8);

  // 外部游戏状态 → 表单同步 (渲染期同步模式)
  const live = {
    happiness: snap?.happiness ?? 60,
    order: snap?.order ?? 60,
    hour: Math.floor(snap?.hour ?? 8),
    pop: snap?.pop ?? 0,
    day: snap?.day ?? 1,
  };
  const [livePrev, setLivePrev] = useState(live);
  if (live.happiness !== livePrev.happiness || live.order !== livePrev.order || live.hour !== livePrev.hour
    || live.pop !== livePrev.pop || live.day !== livePrev.day) {
    setLivePrev(live);
    setHappiness(live.happiness); setOrder(live.order); setHour(live.hour);
    setPop(String(live.pop)); setDay(String(live.day));
  }

  if (!snap || !engine || !show || !snap.devMode) return null;

  const activeBrush = mode.type === 'terrain' ? mode.terrain : null;

  const pickBrush = (id: string) => {
    if (activeBrush === id) {
      setMode({ type: 'none' });
      renderer?.setMode({ type: 'none' });
      return;
    }
    setMode({ type: 'terrain', terrain: id, brush: brushSize });
    renderer?.setMode({ type: 'terrain', terrain: id, brush: brushSize });
  };

  return (
    <div className="fixed top-12 right-2 bottom-24 z-40 w-[min(92vw,390px)] flex flex-col">
      <div className="flex-1 rounded-2xl bg-stone-950/95 backdrop-blur-md border border-amber-800/50 shadow-2xl overflow-hidden flex flex-col">
        {/* 头部 */}
        <div className="flex items-center justify-between px-3 py-2 bg-gradient-to-r from-amber-950/80 to-stone-900/60 border-b border-amber-900/40">
          <div className="flex items-center gap-2">
            <span className="flex items-center justify-center w-6 h-6 rounded-md bg-amber-600/20 border border-amber-700/50">
              <GIcon name="Bug" size={13} className="text-amber-300" />
            </span>
            <div>
              <div className="text-[13px] font-black text-amber-100 tracking-wide">开发者模式</div>
              <div className="text-[9px] text-amber-600/90">DEVELOPER CONSOLE · 按键 ` 可快速开关</div>
            </div>
          </div>
          <div className="flex items-center gap-1.5">
            {snap.freeBuild && (
              <span className="px-1.5 py-0.5 rounded bg-emerald-900/70 border border-emerald-700 text-[9px] font-bold text-emerald-300">免费建造中</span>
            )}
            <Button size="icon" variant="ghost" className="h-7 w-7 text-stone-400 hover:text-stone-100" onClick={() => setPanel('showDev', false)}>
              <GIcon name="X" size={14} />
            </Button>
          </div>
        </div>

        {/* 标签页 */}
        <Tabs defaultValue="res" className="flex-1 flex flex-col overflow-hidden">
          <TabsList className="mx-2 mt-2 grid grid-cols-6 h-8 bg-stone-900 border border-stone-800 shrink-0">
            {[
              ['res', '资源', 'CircleDollarSign'],
              ['city', '城市', 'Users'],
              ['time', '时间', 'Clock3'],
              ['evt', '事件', 'CloudRain'],
              ['map', '地形', 'Mountain'],
              ['save', '存档', 'Save'],
            ].map(([k, name, icon]) => (
              <TabsTrigger key={k} value={k} className="text-[10px] px-0 flex flex-col gap-0.5 py-1 data-[state=active]:bg-amber-700/40 h-auto">
                <GIcon name={icon} size={12} />
                {name}
              </TabsTrigger>
            ))}
          </TabsList>

          <div className="flex-1 overflow-y-auto p-2 space-y-2 game-scroll">
            {/* ============ 资源 ============ */}
            <TabsContent value="res" className="space-y-2 mt-0">
              <DevSection title="资源修改 (回车或点击「设为」生效)" icon="CircleDollarSign">
                {RES_ORDER.map(k => (
                  <NumRow key={k} label={RES_META[k].name} icon={RES_META[k].icon} color={RES_META[k].color}
                    value={Math.floor(snap.res[k])}
                    onSet={n => engine.devSetRes(k as ResourceKey, n)}
                    onAdd={n => engine.devAddRes(k as ResourceKey, n)} />
                ))}
              </DevSection>
              <div className="grid grid-cols-3 gap-1.5">
                <Button size="sm" className="h-8 text-[11px] bg-emerald-800 hover:bg-emerald-700" onClick={() => engine.devAddAll(500)}>全部 +500</Button>
                <Button size="sm" className="h-8 text-[11px] bg-emerald-800 hover:bg-emerald-700" onClick={() => { engine.devSetRes('money', 100000); }}>资金 +10万</Button>
                <Button size="sm" variant="outline" className="h-8 text-[11px]" onClick={() => engine.devAddAll(5000)}>全部 +5000</Button>
              </div>
              <p className="text-[10px] text-stone-500 leading-relaxed px-1">资源上限仍受仓库影响; 超出部分会截断。如需无限制, 打开「城市」页的免费建造。</p>
            </TabsContent>

            {/* ============ 城市 ============ */}
            <TabsContent value="city" className="space-y-2 mt-0">
              <DevSection title="人口" icon="Users">
                <div className="flex items-center gap-1.5">
                  <Input value={pop} onChange={e => setPop(e.target.value)} placeholder={`当前 ${snap.pop}`}
                    className="h-7 flex-1 bg-stone-900 border-stone-600 text-[12px] tabular-nums px-1.5" />
                  <Button size="sm" variant="secondary" className="h-7 px-2 text-[11px]" onClick={() => { const n = parseInt(pop); if (!Number.isNaN(n)) engine.devSetPop(n); }}>设为</Button>
                  <Button size="sm" variant="outline" className="h-7 px-2 text-[11px]" onClick={() => engine.devAddPop(-50)}>-50</Button>
                  <Button size="sm" variant="outline" className="h-7 px-2 text-[11px]" onClick={() => engine.devAddPop(-5)}>-5</Button>
                  <Button size="sm" variant="outline" className="h-7 px-2 text-[11px]" onClick={() => engine.devAddPop(5)}>+5</Button>
                  <Button size="sm" variant="outline" className="h-7 px-2 text-[11px]" onClick={() => engine.devAddPop(50)}>+50</Button>
                </div>
                <p className="text-[10px] text-stone-500">当前 {snap.pop} / 住房上限 {snap.popCap} · 劳动力 {snap.workersEmployed}/{snap.workersTotal}</p>
              </DevSection>

              <DevSection title="幸福度与秩序" icon="Smile">
                <DevSlider label="幸福度" icon="Smile" value={happiness} onCommit={v => engine.devSetHappiness(v)} />
                <DevSlider label="秩序" icon="Scale" value={order} onCommit={v => engine.devSetOrder(v)} />
              </DevSection>

              <DevSection title="时代" icon="Sparkles">
                <div className="grid grid-cols-5 gap-1">
                  {ERAS.map(e => (
                    <button key={e.index} onClick={() => engine.devSetEra(e.index)}
                      className={cn('rounded-lg border px-1 py-1.5 text-[9px] font-bold leading-tight transition-colors',
                        snap.era === e.index ? 'border-amber-400 bg-amber-800/50 text-amber-100' : 'border-stone-700 bg-stone-800/60 text-stone-300 hover:bg-stone-700/60')}>
                      <span className="block w-1.5 h-1.5 rounded-full mx-auto mb-0.5" style={{ background: ERA_COLORS[e.index] }} />
                      {e.name}
                    </button>
                  ))}
                </div>
                <Button size="sm" className="w-full h-8 text-[11px] bg-sky-800 hover:bg-sky-700" onClick={() => engine.devUnlockAllResearch()}>
                  <GIcon name="FlaskConical" size={12} className="mr-1" /> 一键解锁全部科技 ({snap.research.length} 项已研)
                </Button>
              </DevSection>

              <DevSection title="作弊开关" icon="Cog">
                <div className="flex items-center justify-between">
                  <div>
                    <div className="text-[11px] text-stone-200 font-bold">免费建造</div>
                    <div className="text-[9px] text-stone-500">建造、拆除、研究不消耗任何资源</div>
                  </div>
                  <Switch checked={snap.freeBuild} onCheckedChange={v => engine.devSetFreeBuild(v)} />
                </div>
                <div className="grid grid-cols-2 gap-1.5">
                  <Button size="sm" variant="outline" className="h-8 text-[11px]" onClick={() => engine.devRepairAll()}>
                    <GIcon name="Hammer" size={12} className="mr-1" /> 万能维修
                  </Button>
                  <Button size="sm" variant="outline" className="h-8 text-[11px]" onClick={() => engine.devClearWeather()}>
                    <GIcon name="CloudSun" size={12} className="mr-1" /> 解除天灾
                  </Button>
                </div>
              </DevSection>
            </TabsContent>

            {/* ============ 时间 ============ */}
            <TabsContent value="time" className="space-y-2 mt-0">
              <DevSection title="日期与时刻" icon="Clock3">
                <div className="flex items-center gap-1.5">
                  <span className="text-[11px] text-stone-300 w-10">天数</span>
                  <Input value={day} onChange={e => setDay(e.target.value)} placeholder={`第 ${snap.day} 天`}
                    className="h-7 flex-1 bg-stone-900 border-stone-600 text-[12px] tabular-nums px-1.5" />
                  <Button size="sm" variant="secondary" className="h-7 px-2 text-[11px]" onClick={() => { const n = parseInt(day); if (!Number.isNaN(n)) engine.devSetDay(n); }}>设为</Button>
                </div>
                <DevSlider label="时刻" icon="Sun" value={hour} max={23} onCommit={v => { setHour(v); engine.devSetHour(v); }} />
              </DevSection>

              <DevSection title="游戏速度" icon="Gauge">
                <div className="grid grid-cols-6 gap-1">
                  {DEV_SPEEDS.map(s => (
                    <button key={s} onClick={() => { engine.speed = s; }}
                      className={cn('rounded-lg border py-1.5 text-[11px] font-bold transition-colors',
                        snap.speed === s ? 'border-amber-400 bg-amber-800/50 text-amber-100' : 'border-stone-700 bg-stone-800/60 text-stone-300 hover:bg-stone-700/60')}>
                      {s === 0 ? '❚❚' : `${s}×`}
                    </button>
                  ))}
                </div>
                <p className="text-[10px] text-stone-500">10× / 25× 为开发者高速档, 适合观察城市长期演化。空格键暂停。</p>
              </DevSection>

              <DevSection title="时间倍率 (全局)" icon="FastForward">
                <p className="text-[10px] text-stone-400 leading-relaxed">
                  当前 1 游戏小时 = 4 真实秒 (1×速度下全天约 96 秒)。
                  嫌一天太快可用 0.5×慢速 MOD 思路: 保持 1× 并降低速度档即可; 高速档用于快进。
                </p>
              </DevSection>
            </TabsContent>

            {/* ============ 事件 ============ */}
            <TabsContent value="evt" className="space-y-2 mt-0">
              <DevSection title="灾难事件 (立即触发)" icon="AlertTriangle">
                <div className="grid grid-cols-3 gap-1.5">
                  {EVT_BUTTONS.filter(e => ['fire', 'storm', 'riot', 'accident', 'plague', 'quake'].includes(e.id)).map(e => (
                    <button key={e.id} onClick={() => engine.devTriggerEvent(e.id)}
                      className={cn('flex items-center justify-center gap-1 rounded-lg border py-2 text-[11px] font-bold transition-colors', e.tone)}>
                      <GIcon name={e.icon} size={13} /> {e.name}
                    </button>
                  ))}
                </div>
              </DevSection>
              <DevSection title="敌袭链 (触发战斗, 需战队)" icon="Swords">
                <div className="grid grid-cols-2 gap-1.5">
                  {EVT_BUTTONS.filter(e => ['beast', 'raid', 'bandit', 'rebel'].includes(e.id)).map(e => (
                    <button key={e.id} onClick={() => engine.devTriggerEvent(e.id)}
                      className={cn('flex items-center justify-center gap-1 rounded-lg border py-2 text-[11px] font-bold transition-colors', e.tone)}>
                      <GIcon name={e.icon} size={13} /> {e.name}
                    </button>
                  ))}
                </div>
                <p className="text-[10px] text-stone-500">战斗中世界时间暂停。无战队时会提示失败。</p>
              </DevSection>
              <DevSection title="幸运事件" icon="Sparkles">
                <div className="grid grid-cols-3 gap-1.5">
                  {EVT_BUTTONS.filter(e => ['harvest', 'caravan', 'immigrant', 'deposit', 'win'].includes(e.id)).map(e => (
                    <button key={e.id} onClick={() => engine.devTriggerEvent(e.id)}
                      className={cn('flex items-center justify-center gap-1 rounded-lg border py-2 text-[11px] font-bold transition-colors', e.tone)}>
                      <GIcon name={e.icon} size={13} /> {e.name}
                    </button>
                  ))}
                </div>
              </DevSection>
              <p className="text-[10px] text-stone-500 leading-relaxed px-1">
                事件触发遵循实际规则: 火灾会优先选择工业建筑; 车祸需要城市里有道路; 移民会突破住房上限。
              </p>
            </TabsContent>

            {/* ============ 地形 ============ */}
            <TabsContent value="map" className="space-y-2 mt-0">
              <DevSection title="地形刷 (选中后在地图上点击/拖动绘制)" icon="Mountain">
                <div className="grid grid-cols-4 gap-1.5">
                  {TERRAIN_BRUSHES.map(b => (
                    <button key={b.id} onClick={() => pickBrush(b.id)}
                      className={cn('flex flex-col items-center gap-0.5 rounded-lg border py-2 text-[10px] font-bold transition-colors',
                        activeBrush === b.id ? 'border-amber-400 bg-amber-900/40' : 'border-stone-700 bg-stone-800/60 hover:bg-stone-700/60')}>
                      <GIcon name={b.icon} size={15} className={b.tone} />
                      {b.name}
                    </button>
                  ))}
                </div>
                <DevSlider label="森林刷半径" icon="TreePine" value={brushSize} max={4} onCommit={v => {
                  setBrushSize(v);
                  if (activeBrush) {
                    setMode({ type: 'terrain', terrain: activeBrush, brush: v });
                    renderer?.setMode({ type: 'terrain', terrain: activeBrush, brush: v });
                  }
                }} />
                {activeBrush && (
                  <div className="flex items-center justify-between rounded-lg bg-amber-950/50 border border-amber-800/60 px-2 py-1.5">
                    <span className="text-[10px] text-amber-200">地形刷激活: {TERRAIN_BRUSHES.find(b => b.id === activeBrush)?.name}</span>
                    <Button size="sm" variant="ghost" className="h-6 px-2 text-[10px] text-stone-300" onClick={() => pickBrush(activeBrush)}>取消</Button>
                  </div>
                )}
              </DevSection>

              <DevSection title="快捷地形操作" icon="Sparkles">
                <div className="grid grid-cols-2 gap-1.5">
                  <Button size="sm" variant="outline" className="h-8 text-[11px]" onClick={() => {
                    const cc = engine.cityCenter();
                    engine.devPlantForest(cc.x + 14, cc.y, 10);
                  }}>
                    <GIcon name="TreePine" size={12} className="mr-1" /> 城旁种大片林
                  </Button>
                  <Button size="sm" variant="outline" className="h-8 text-[11px] text-red-300" onClick={() => engine.devClearTrees()}>
                    <GIcon name="Trash2" size={12} className="mr-1" /> 清空全部树木
                  </Button>
                  <Button size="sm" variant="outline" className="h-8 text-[11px] text-cyan-300" onClick={() => engine.devRevealAll()}>
                    <GIcon name="CloudFog" size={12} className="mr-1" /> 揭开迷雾 (半径90)
                  </Button>
                  <Button size="sm" variant="outline" className="h-8 text-[11px]" onClick={() => {
                    const cc = engine.cityCenter();
                    engine.devRevealAt(cc.x + 20, cc.y + 12, 8);
                  }}>
                    <GIcon name="Compass" size={12} className="mr-1" /> 远处揭一块雾
                  </Button>
                </div>
                <p className="text-[10px] text-stone-500 leading-relaxed">
                  无限世界: 地形按 16×16 区块随探索生成。伐木营地/锯木厂需周围有树林, 采石场/矿井需丘陵山地。
                </p>
              </DevSection>
            </TabsContent>

            {/* ============ 存档 ============ */}
            <TabsContent value="save" className="space-y-2 mt-0">
              <DevSection title="存档管理" icon="Save">
                <div className="grid grid-cols-2 gap-1.5">
                  <Button size="sm" className="h-8 text-[11px] bg-sky-800 hover:bg-sky-700" onClick={() => { engine.save(); engine.notify('info', '已保存', '进度已写入浏览器。', 'good'); }}>
                    立即保存
                  </Button>
                  <Button size="sm" variant="destructive" className="h-8 text-[11px]" onClick={() => {
                    if (confirm('确定清除存档并回到标题画面吗?')) {
                      GameEngine.clearSave();
                      window.location.reload();
                    }
                  }}>
                    清档并重启
                  </Button>
                </div>
              </DevSection>
              <DevSection title="游戏状态" icon="BarChart3">
                <div className="grid grid-cols-2 gap-x-3 gap-y-1 text-[11px]">
                  <div className="flex justify-between"><span className="text-stone-500">种子</span><span className="tabular-nums">{engine.seed}</span></div>
                  <div className="flex justify-between"><span className="text-stone-500">建筑</span><span className="tabular-nums">{snap.buildings}</span></div>
                  <div className="flex justify-between"><span className="text-stone-500">树林</span><span className="tabular-nums">{snap.treeCount}</span></div>
                  <div className="flex justify-between"><span className="text-stone-500">科技</span><span className="tabular-nums">{snap.research.length}</span></div>
                  <div className="flex justify-between"><span className="text-stone-500">已探索区块</span><span className="tabular-nums">{engine.terrain.chunks.size}</span></div>
                  <div className="flex justify-between"><span className="text-stone-500">遗迹总数</span><span className="tabular-nums">{engine.terrain.ruins.length}</span></div>
                  <div className="flex justify-between"><span className="text-stone-500">电网</span><span className="tabular-nums">{snap.pipePowerConnected}/{snap.pipePowerTotal}</span></div>
                  <div className="flex justify-between"><span className="text-stone-500">水网</span><span className="tabular-nums">{snap.pipeWaterConnected}/{snap.pipeWaterTotal}</span></div>
                  <div className="flex justify-between"><span className="text-stone-500">电力</span><span className="tabular-nums">{snap.powerSupply}/{snap.powerDemand}</span></div>
                  <div className="flex justify-between"><span className="text-stone-500">战队/战绩</span><span className="tabular-nums">{snap.squadSize}人 · {snap.battleWins}胜</span></div>
                </div>
              </DevSection>
              <p className="text-[10px] text-stone-500 leading-relaxed px-1">
                开发者模式不会写入存档, 重启游戏后自动关闭。控制台可访问 window.__game 调试引擎与渲染器。
              </p>
            </TabsContent>
          </div>
        </Tabs>
      </div>
    </div>
  );
}
