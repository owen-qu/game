// ===== 事件通知流 =====
'use client';
import { useEffect, useState } from 'react';
import { useGame } from '@/lib/game/store';
import { GIcon } from './GameIcon';
import { cn } from '@/lib/utils';

const KIND_META: Record<string, { icon: string; label: string }> = {
  fire: { icon: 'Flame', label: '火灾' },
  storm: { icon: 'CloudRain', label: '暴雨' },
  riot: { icon: 'Swords', label: '暴乱' },
  accident: { icon: 'CarFront', label: '事故' },
  nuclear: { icon: 'Radiation', label: '核事故' },
  harvest: { icon: 'Wheat', label: '丰收' },
  caravan: { icon: 'Store', label: '商队' },
  immigrant: { icon: 'Users', label: '移民' },
  deposit: { icon: 'Mountain', label: '矿藏' },
  info: { icon: 'Sparkles', label: '城市' },
  plague: { icon: 'AlertTriangle', label: '疫病' },
  quake: { icon: 'Mountain', label: '地震' },
  festival: { icon: 'PartyPopper', label: '庆典' },
  beast: { icon: 'Dog', label: '野兽' },
  raid: { icon: 'User', label: '野人' },
  bandit: { icon: 'Skull', label: '匪帮' },
  rebel: { icon: 'ShieldAlert', label: '叛军' },
  wedding: { icon: 'Heart', label: '喜事' },
  strike: { icon: 'Megaphone', label: '罢工' },
  birth: { icon: 'Baby', label: '新生儿' },
  expedition: { icon: 'Compass', label: '远征' },
  ruin: { icon: 'Landmark', label: '遗迹' },
  battle: { icon: 'Swords', label: '战斗' },
};

export function EventFeed() {
  const notifications = useGame(s => s.notifications);
  const [now, setNow] = useState(Date.now());
  useEffect(() => {
    const t = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(t);
  }, []);
  const visible = notifications.filter(n => now - n.ts < 12000).slice(0, 4);
  if (visible.length === 0) return null;

  return (
    <div className="fixed left-2 top-[64px] md:top-[68px] z-20 w-[270px] space-y-1.5 pointer-events-none">
      {visible.map(n => {
        const meta = KIND_META[n.kind] ?? KIND_META.info;
        return (
          <div key={n.id}
            className={cn('flex items-start gap-2 rounded-xl border px-2.5 py-2 backdrop-blur-md shadow-lg animate-[slideIn_.25s_ease-out]',
              n.tone === 'bad' ? 'bg-red-950/85 border-red-800' :
                n.tone === 'good' ? 'bg-emerald-950/85 border-emerald-800' :
                  'bg-stone-900/85 border-stone-700')}>
            <GIcon name={meta.icon} size={15}
              className={cn('mt-0.5 shrink-0', n.tone === 'bad' ? 'text-red-400' : n.tone === 'good' ? 'text-emerald-400' : 'text-amber-300')} />
            <div className="min-w-0">
              <div className={cn('text-xs font-bold',
                n.tone === 'bad' ? 'text-red-200' : n.tone === 'good' ? 'text-emerald-200' : 'text-stone-100')}>
                {n.title}
              </div>
              <div className="text-[10px] leading-snug text-stone-400 line-clamp-2">{n.detail}</div>
            </div>
          </div>
        );
      })}
    </div>
  );
}
