// ===== 图标映射 =====
'use client';
import {
  Route, Waypoints, Tent, Home, Warehouse, Building, Building2, Landmark,
  Cherry, Sprout, Beef, Fish, Tractor, FlaskConical, Axe, Hammer, Pickaxe, Fuel,
  Factory, Wind, Radiation, Droplet, GlassWater, Waves, Flame, Database, Package,
  Store, TrainFront, GraduationCap, Cross, Shield, FireExtinguisher, Trees,
  ShoppingBag, Plane, Wheat, TreePine, Mountain, Cog, CircleDollarSign,
  Users, Smile, Scale, Zap, Droplets, Clock3, Pause, Play, FastForward,
  Gauge, BookOpen, BarChart3, Save, X, Trash2, Check, Lock, AlertTriangle,
  CloudRain, Swords, CarFront, Sparkles, Trophy, Skull, Sun, Moon, CloudSun,
  MapPin, Hourglass,
  Bug, Eye, Volume2, VolumeX, Music, Gem, SunMedium, MountainSnow,
  Coins, Biohazard, RotateCw, CheckCircle2, Cable, Layers, Briefcase, Church, Leaf, Ship, Train,
  Lightbulb, Lamp,
} from 'lucide-react';

const MAP: Record<string, React.ComponentType<{ size?: number | string; className?: string; strokeWidth?: number; style?: React.CSSProperties }>> = {
  Route, Waypoints, Tent, Home, Warehouse, Building, Building2, Landmark,
  Cherry, Sprout, Beef, Fish, Tractor, FlaskConical, Axe, Hammer, Pickaxe, Fuel,
  Factory, Wind, Radiation, Droplet, GlassWater, Waves, Flame, Database, Package,
  Store, TrainFront, GraduationCap, Cross, Shield, FireExtinguisher, Trees,
  ShoppingBag, Plane, Wheat, TreePine, Mountain, Cog, CircleDollarSign,
  Users, Smile, Scale, Zap, Droplets, Clock3, Pause, Play, FastForward,
  Gauge, BookOpen, BarChart3, Save, X, Trash2, Check, Lock, AlertTriangle,
  CloudRain, Swords, CarFront, Sparkles, Trophy, Skull, Sun, Moon, CloudSun, MapPin, Hourglass,
  Bug, Eye, Volume2, VolumeX, Music, Gem, SunMedium, MountainSnow, Coins, Biohazard,
  RotateCw, CheckCircle2, Cable, Layers, Briefcase, Church, Leaf, Ship, Train,
  Lightbulb, Lamp,
};
// 地铁站图标: Tunnel 不存在, 借用 Train
MAP['Tunnel'] = Train;
// 草地刷借用 Sprout 图标
MAP['Sprout2'] = MAP['Sprout'];

export function GIcon({ name, size = 16, className, strokeWidth = 2, style }: {
  name: string; size?: number | string; className?: string; strokeWidth?: number; style?: React.CSSProperties;
}) {
  const C = MAP[name] ?? MapPin;
  return <C size={size} className={className} strokeWidth={strokeWidth} style={style} />;
}
