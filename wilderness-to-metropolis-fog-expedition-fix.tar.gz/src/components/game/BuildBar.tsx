// ===== 底部建造菜单 =====
'use client';
import { useGame } from '@/lib/game/store';
import { BUILDING_DEFS, CATEGORY_META } from '@/lib/game/buildings';
import { RES_META, ERAS } from '@/lib/game/constants';
import { GIcon } from './GameIcon';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';

const CATS = ['road', 'pipe', 'housing', 'food', 'resource', 'power', 'water', 'light', 'military', 'civic'];

export function BuildBar() {
  const snap = useGame(s => s.snap);
  const engine = useGame(s => s.engine);
  const renderer = useGame(s => s.renderer);
  const mode = useGame(s => s.mode);
  const activeCategory = useGame(s => s.activeCategory);
  const setCategory = useGame(s => s.setCategory);
  const setMode = useGame(s => s.setMode);
  const setSelected = useGame(s => s.setSelected);
  if (!snap || !engine) return null;

  const buildings = Object.values(BUILDING_DEFS).filter(d => d.category === activeCategory);
  const setBuild = (defId: string | null) => {
    if (!defId) {
      setMode({ type: 'none' });
      renderer?.setMode({ type: 'none' });
      return;
    }
    if (mode.type === 'build' && mode.defId === defId) {
      setMode({ type: 'none' });
      renderer?.setMode({ type: 'none' });
      return;
    }
    setMode({ type: 'build', defId });
    renderer?.setMode({ type: 'build', defId });
    setSelected(null);
    renderer?.selectBuilding(null);
  };

  return (
    <div className="fixed bottom-0 inset-x-0 z-30 p-1.5 md:p-2.5 flex justify-center pointer-events-none">
      <div className="pointer-events-auto w-full max-w-[980px] bg-stone-900/88 backdrop-blur-md border border-stone-700/60 rounded-2xl shadow-2xl overflow-hidden">
        {/* 分类 */}
        <div className="flex items-center gap-1 px-2 pt-1.5 pb-1 border-b border-stone-800/80">
          <Button size="sm" variant={mode.type === 'chop' ? 'default' : 'ghost'}
            className={cn('h-7 gap-1 px-2 text-xs', mode.type === 'chop' ? 'bg-lime-700 hover:bg-lime-600' : 'text-lime-300 hover:text-lime-200')}
            onClick={() => {
              if (mode.type === 'chop') { setMode({ type: 'none' }); renderer?.setMode({ type: 'none' }); }
              else { setMode({ type: 'chop' }); renderer?.setMode({ type: 'chop' }); setSelected(null); }
            }} title="砍树 / 采石 / 搜刮已探索的遗迹: 开荒获得资源">
            <GIcon name="Axe" size={13} /> 开荒
          </Button>
          <Button size="sm" variant={mode.type === 'explore' ? 'default' : 'ghost'}
            className={cn('h-7 gap-1 px-2 text-xs', mode.type === 'explore' ? 'bg-cyan-700 hover:bg-cyan-600 text-white' : 'text-cyan-300 hover:text-cyan-200')}
            onClick={() => {
              if (mode.type === 'explore') { setMode({ type: 'none' }); renderer?.setMode({ type: 'none' }); }
              else {
                setMode({ type: 'explore' }); renderer?.setMode({ type: 'explore' }); setSelected(null);
                if (engine.squadSize === 0) {
                  engine.notify('expedition', '还没有战队', '派遣远征需要战队队员 —— 先建设「训练场」(军事分类)。', 'bad');
                }
              }
            }} title="远征: 点击 10 格以外的目标 (迷雾中亦可), 派出远征队探索世界、搜刮遗迹">
            <GIcon name="Compass" size={13} /> 远征
          </Button>
          <Button size="sm" variant={mode.type === 'demolish' ? 'default' : 'ghost'}
            className={cn('h-7 gap-1 px-2 text-xs', mode.type === 'demolish' ? 'bg-red-800 hover:bg-red-700' : 'text-red-300 hover:text-red-200')}
            onClick={() => {
              if (mode.type === 'demolish') { setMode({ type: 'none' }); renderer?.setMode({ type: 'none' }); }
              else { setMode({ type: 'demolish' }); renderer?.setMode({ type: 'demolish' }); setSelected(null); }
            }} title="拆除建筑, 返还 35% 造价">
            <GIcon name="Trash2" size={13} /> 拆除
          </Button>
          <div className="w-px h-5 bg-stone-700 mx-1" />
          <div className="flex items-center gap-1 overflow-x-auto flex-1">
            {CATS.map(c => {
              const meta = CATEGORY_META[c];
              const active = activeCategory === c;
              return (
                <button key={c} onClick={() => setCategory(c)}
                  className={cn('flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-medium whitespace-nowrap transition-colors',
                    active ? 'bg-amber-600 text-stone-950' : 'text-stone-300 hover:bg-stone-800')}>
                  <GIcon name={meta.icon} size={13} /> {meta.name}
                </button>
              );
            })}
          </div>
          {mode.type !== 'none' && (
            <Button size="sm" variant="ghost" className="h-7 px-2 text-xs text-stone-400" onClick={() => setBuild(null)}>
              ESC 取消
            </Button>
          )}
        </div>
        {/* 建筑 */}
        <div className="flex gap-1.5 p-1.5 overflow-x-auto">
          {buildings.map(def => {
            const unlocked = def.era <= snap.era;
            const afford = Object.entries(def.cost).every(([k, v]) => snap.res[k as keyof typeof snap.res] >= (v ?? 0));
            const active = mode.type === 'build' && mode.defId === def.id;
            return (
              <button key={def.id} disabled={!unlocked}
                onClick={() => setBuild(def.id)}
                title={unlocked ? def.desc : `需要「${ERAS[def.era].name}」解锁`}
                className={cn('relative flex flex-col items-center justify-between shrink-0 w-[78px] h-[92px] p-1.5 rounded-xl border transition-all overflow-hidden',
                  active ? 'border-amber-400 bg-amber-950/60 ring-2 ring-amber-400/60 scale-[1.03]' :
                    unlocked ? 'border-stone-700/70 bg-stone-800/50 hover:border-stone-500 hover:bg-stone-800' :
                      'border-stone-800 bg-stone-900/60 opacity-50 cursor-not-allowed')}>
                <GIcon name={def.icon} size={19} className={unlocked ? 'text-amber-200' : 'text-stone-500'} />
                <span className="text-[10px] font-medium text-stone-100 text-center leading-none">{def.name}</span>
                <div className="flex flex-col items-center gap-[1px] w-full">
                  {unlocked ? (
                    <>
                      {(Object.entries(def.cost).slice(0, 2)).map(([k, v]) => (
                        <div key={k} className="flex items-center gap-0.5" title={`${RES_META[k as keyof typeof RES_META].name} ${v}`}>
                          <GIcon name={RES_META[k as keyof typeof RES_META].icon} size={9} style={{ color: RES_META[k as keyof typeof RES_META].color }} />
                          <span className={cn('text-[9px] tabular-nums', afford ? 'text-stone-300' : 'text-red-400')}>{v}</span>
                        </div>
                      ))}
                      {def.housing && <span className="text-[9px] text-emerald-300 whitespace-nowrap">住{def.housing}人</span>}
                    </>
                  ) : (
                    <span className="flex items-center gap-1 text-[9px] text-stone-400"><GIcon name="Lock" size={9} />{ERAS[def.era].name}</span>
                  )}
                </div>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}
