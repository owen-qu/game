// ===== 右侧信息面板 =====
'use client';
import { useGame } from '@/lib/game/store';
import { BUILDING_DEFS } from '@/lib/game/buildings';
import { RES_META } from '@/lib/game/constants';
import { GIcon } from './GameIcon';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';

export function InfoPanel() {
  const snap = useGame(s => s.snap);
  const engine = useGame(s => s.engine);
  const renderer = useGame(s => s.renderer);
  const selected = useGame(s => s.selected);
  const mode = useGame(s => s.mode);
  const linePreview = useGame(s => s.linePreview);
  const setSelected = useGame(s => s.setSelected);
  if (!snap || !engine) return null;

  let body: React.ReactNode = null;
  let title: React.ReactNode = null;

  if (selected && engine.buildings.has(selected.id)) {
    const def = BUILDING_DEFS[selected.defId];
    const b = engine.buildings.get(selected.id)!;
    const eff = Math.round((selected.efficiency || 0) * 100);
    const need = Math.ceil(def.workers * (engine.research.includes('automation') ? 0.5 : 1));
    const building = selected.progress < 1;
    const canRotate = !def.road && def.category !== 'pipe' && !def.pipe;
    const lv = engine.landValues.get(selected.id) ?? 0;
    title = (
      <div className="flex items-center gap-2">
        <GIcon name={def.icon} size={18} className="text-amber-300" />
        <div>
          <div className="text-sm font-bold text-stone-100">{def.name}{building ? ' (施工中)' : ''}</div>
          <div className="text-[10px] text-stone-400">坐标 ({b.x}, {b.y}) · {building ? '开工' : '建成'}于第 {b.builtDay} 天 · 朝向 {['南', '西', '北', '东'][selected.rot % 4]}</div>
        </div>
      </div>
    );
    body = (
      <div className="space-y-2.5">
        <p className="text-[11px] leading-relaxed text-stone-300">{def.desc}</p>
        {building && (
          <div className="rounded-lg bg-sky-950/60 border border-sky-800 px-2 py-1.5">
            <div className="flex justify-between text-[10px] text-sky-300 mb-1">
              <span>建造进度</span><span>{Math.round(selected.progress * 100)}%</span>
            </div>
            <div className="h-1.5 bg-stone-800 rounded-full overflow-hidden">
              <div className="h-full bg-sky-400 transition-all" style={{ width: `${selected.progress * 100}%` }} />
            </div>
          </div>
        )}
        {!building && selected.alerts.length > 0 && (
          <div className="rounded-lg bg-red-950/70 border border-red-800 px-2 py-1.5 space-y-1">
            <div className="flex items-center gap-1.5 text-[11px] font-bold text-red-300">
              <span className="inline-flex items-center justify-center w-4 h-4 rounded-full bg-red-600 text-white text-[9px] font-black animate-pulse">!</span>
              发现 {selected.alerts.length} 个问题
            </div>
            {selected.alerts.map((a, i) => (
              <div key={i} className="flex items-start gap-1 text-[10px] text-red-200 leading-snug">
                <span className="text-red-400 mt-[1px]">▸</span>{a}
              </div>
            ))}
          </div>
        )}
        {!building && selected.alerts.length === 0 && (
          <div className="flex items-center gap-1.5 rounded-lg bg-emerald-950/50 border border-emerald-800/60 px-2 py-1.5">
            <GIcon name="CheckCircle2" size={13} className="text-emerald-400" />
            <span className="text-[11px] text-emerald-300">运转正常</span>
          </div>
        )}
        {selected.fire > 0 && (
          <div className="flex items-center gap-1.5 rounded-lg bg-red-950/70 border border-red-800 px-2 py-1.5">
            <GIcon name="Flame" size={14} className="text-orange-400 animate-pulse" />
            <span className="text-[11px] text-red-300 font-bold">火灾中! 剩余 {Math.ceil(selected.fire)} 小时</span>
          </div>
        )}
        {selected.damaged && selected.fire <= 0 && (
          <div className="flex items-center gap-1.5 rounded-lg bg-amber-950/60 border border-amber-800 px-2 py-1.5">
            <GIcon name="AlertTriangle" size={13} className="text-amber-400" />
            <span className="text-[11px] text-amber-300">建筑受损, 效率 -50% (无法修复, 可拆除重建)</span>
          </div>
        )}
        {selected.strike > 0 && (
          <div className="flex items-center gap-1.5 rounded-lg bg-purple-950/60 border border-purple-800 px-2 py-1.5">
            <GIcon name="Megaphone" size={13} className="text-purple-400 animate-pulse" />
            <span className="text-[11px] text-purple-300 font-bold">工人罢工中 (剩余 {selected.strike} 天) — 提升幸福度可避免</span>
          </div>
        )}
        <div className="grid grid-cols-2 gap-1.5 text-[11px]">
          <div className="flex justify-between bg-stone-800/60 rounded-md px-2 py-1">
            <span className="text-stone-400">耐久</span>
            <span className={cn('font-bold tabular-nums', selected.hp < 50 ? 'text-red-400' : 'text-stone-200')}>{Math.max(0, Math.round(selected.hp))}%</span>
          </div>
          {need > 0 && (
            <div className="flex justify-between items-center bg-stone-800/60 rounded-md px-1.5 py-1 gap-1">
              <span className="text-stone-400">工人</span>
              <div className="flex items-center gap-1">
                <button className="w-[18px] h-[18px] rounded flex items-center justify-center bg-stone-700 hover:bg-stone-600 text-stone-200 disabled:opacity-40"
                  disabled={selected.workers <= 0}
                  onClick={() => { engine.setWorkers(selected.id, selected.workers - 1); }}>
                  <GIcon name="Minus" size={10} />
                </button>
                <span className={cn('font-bold tabular-nums w-9 text-center', selected.workers < need ? 'text-amber-400' : 'text-emerald-400')}>{selected.workers}/{need}</span>
                <button className="w-[18px] h-[18px] rounded flex items-center justify-center bg-stone-700 hover:bg-stone-600 text-stone-200 disabled:opacity-40"
                  disabled={selected.workers >= need || snap.workersEmployed >= snap.workersTotal}
                  onClick={() => { engine.setWorkers(selected.id, selected.workers + 1); }}>
                  <GIcon name="Plus" size={10} />
                </button>
              </div>
            </div>
          )}
          {def.housing && (
            <div className="flex justify-between bg-stone-800/60 rounded-md px-2 py-1">
              <span className="text-stone-400">容纳</span>
              <span className="font-bold text-emerald-400">{def.housing} 人</span>
            </div>
          )}
          {def.powerOut && (
            <div className="flex justify-between bg-stone-800/60 rounded-md px-2 py-1">
              <span className="text-stone-400">供电</span>
              <span className="font-bold text-amber-300">{def.powerOut}</span>
            </div>
          )}
          {def.waterOut && (
            <div className="flex justify-between bg-stone-800/60 rounded-md px-2 py-1">
              <span className="text-stone-400">供水</span>
              <span className="font-bold text-teal-300">{def.waterOut}</span>
            </div>
          )}
          {def.powerNeed && (
            <div className="flex justify-between bg-stone-800/60 rounded-md px-2 py-1">
              <span className="text-stone-400">耗电</span>
              <span className="font-bold text-amber-300">{def.powerNeed}</span>
            </div>
          )}
          {def.waterNeed && (
            <div className="flex justify-between bg-stone-800/60 rounded-md px-2 py-1">
              <span className="text-stone-400">耗水</span>
              <span className="font-bold text-teal-300">{def.waterNeed}</span>
            </div>
          )}
          {def.housing && (
            <div className="flex justify-between bg-stone-800/60 rounded-md px-2 py-1" title="地价: 服务/教育/水电拉高, 污染噪音拉低; 影响税收与移民">
              <span className="text-stone-400">地价</span>
              <span className={cn('font-bold', lv < 30 ? 'text-red-300' : lv > 60 ? 'text-amber-200' : 'text-stone-200')}>{lv} / 100</span>
            </div>
          )}
        </div>
        {def.produce && Object.keys(def.produce).length > 0 && (
          <div className="rounded-lg bg-stone-800/60 px-2 py-1.5">
            <div className="text-[10px] text-stone-400 mb-1">每日产出 (当前效率 {eff}%)</div>
            <div className="flex flex-wrap gap-2">
              {Object.entries(def.produce).map(([k, v]) => (
                <span key={k} className="flex items-center gap-1 text-[11px] font-bold">
                  <GIcon name={RES_META[k as keyof typeof RES_META].icon} size={11} style={{ color: RES_META[k as keyof typeof RES_META].color }} />
                  +{(v * (selected.efficiency || 0)).toFixed(1)}
                </span>
              ))}
            </div>
          </div>
        )}
        {def.effects?.pollution && (
          <div className="flex items-center gap-1.5 text-[11px] text-red-300">
            <GIcon name="Factory" size={12} /> 污染: 半径 {def.radius} 内住房幸福 -{def.effects.pollution} · 附近水井出水下降
          </div>
        )}
        {def.effects?.happiness && (
          <div className="flex items-center gap-1.5 text-[11px] text-emerald-300">
            <GIcon name="Smile" size={12} /> 半径 {def.radius} 内幸福 +{def.effects.happiness}
          </div>
        )}
        {def.effects?.order && (
          <div className="flex items-center gap-1.5 text-[11px] text-amber-300">
            <GIcon name="Scale" size={12} /> 半径 {def.radius} 内秩序 +{def.effects.order}
          </div>
        )}
        {def.light && (
          <div className="flex items-center gap-1.5 text-[11px] text-yellow-200">
            <GIcon name="Lightbulb" size={12} /> 夜间照明半径 {def.light}{def.powerNeed ? ' · 耗电需接电网' : ''}
          </div>
        )}
        <div className="flex gap-1.5">
          {canRotate && (
            <Button variant="secondary" size="sm" className="flex-1 h-7 text-xs"
              onClick={() => { engine.rotateBuilding(selected.id); }}>
              <GIcon name="RotateCw" size={13} className="mr-1" /> 旋转朝向
            </Button>
          )}
          <Button variant="destructive" size="sm" className={cn('h-7 text-xs', canRotate ? 'flex-1' : 'w-full')}
            onClick={() => {
              engine.removeBuilding(selected.id, true);
              renderer?.selectBuilding(null);
              setSelected(null);
            }}>
            <GIcon name="Trash2" size={13} className="mr-1" /> 拆除
          </Button>
        </div>
      </div>
    );
  } else if (mode.type === 'build') {
    const def = BUILDING_DEFS[mode.defId];
    const isLine = !!(def.road || def.pipe);
    const buildDays = engine.buildDaysOf(def);
    title = (
      <div className="flex items-center gap-2">
        <GIcon name={def.icon} size={18} className="text-amber-300" />
        <div>
          <div className="text-sm font-bold text-stone-100">建造 · {def.name}</div>
          <div className="text-[10px] text-amber-400/80">{isLine ? '点击两点 → 自动连成一条线' : '点击地面放置 · 右键拖动旋转视角'}</div>
        </div>
      </div>
    );
    body = (
      <div className="space-y-2">
        <p className="text-[11px] leading-relaxed text-stone-300">{def.desc}</p>
        {isLine && (
          <div className={cn('rounded-lg px-2 py-1.5 border', linePreview ? 'bg-amber-950/60 border-amber-700' : 'bg-stone-800/60 border-stone-700')}>
            {linePreview ? (
              <>
                <div className="text-[11px] text-amber-200 font-bold">已选 {linePreview.count} 格</div>
                <div className="flex flex-wrap gap-1.5 mt-1">
                  {Object.entries(linePreview.cost).map(([k, v]) => (
                    <span key={k} className="flex items-center gap-1 text-[10px] font-bold text-stone-200">
                      <GIcon name={RES_META[k as keyof typeof RES_META].icon} size={10} style={{ color: RES_META[k as keyof typeof RES_META].color }} />
                      {v}
                    </span>
                  ))}
                </div>
                <div className="text-[10px] text-stone-400 mt-1">点击终点完成铺设 · ESC 取消</div>
              </>
            ) : (
              <div className="text-[11px] text-stone-300">先点击<span className="text-amber-300 font-bold">起点</span>, 再点击终点, 两点间自动连成道路 (拐弯处走 L 形)。</div>
            )}
          </div>
        )}
        {!isLine && (
          <div className="flex items-center gap-1.5 text-[11px] text-stone-400">
            <GIcon name="RotateCw" size={12} className="text-amber-400" /> 按 <kbd className="px-1 bg-stone-800 rounded text-stone-200">R</kbd> 键旋转朝向
          </div>
        )}
        <div className="flex flex-wrap gap-2">
          {Object.entries(def.cost).map(([k, v]) => {
            const afford = snap.res[k as keyof typeof snap.res] >= (v ?? 0);
            return (
              <span key={k} className={cn('flex items-center gap-1 text-[11px] font-bold', afford ? 'text-stone-200' : 'text-red-400')}>
                <GIcon name={RES_META[k as keyof typeof RES_META].icon} size={11} style={{ color: RES_META[k as keyof typeof RES_META].color }} />
                {v}
              </span>
            );
          })}
        </div>
        <div className="flex flex-wrap gap-x-3 gap-y-1 text-[10px] text-stone-400">
          {def.size > 1 && <span>占地 {def.size}×{def.size}</span>}
          {buildDays >= 0.1 && <span className="flex items-center gap-1"><GIcon name="Hammer" size={10} /> 工期 {buildDays >= 1 ? buildDays.toFixed(1) + ' 天' : Math.round(buildDays * 24) + ' 小时'}</span>}
        </div>
      </div>
    );
  } else {
    return null;
  }

  return (
    <div className="fixed right-2 top-[64px] md:top-[68px] z-20 w-[240px] max-h-[calc(100vh-220px)] overflow-y-auto">
      <div className="bg-stone-900/88 backdrop-blur-md border border-stone-700/60 rounded-xl p-3 shadow-2xl">
        {title}
        <div className="mt-2.5">{body}</div>
      </div>
    </div>
  );
}
