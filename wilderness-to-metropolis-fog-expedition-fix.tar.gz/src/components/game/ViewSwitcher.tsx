// ===== 数据视图切换器 (左侧竖条 · v5 管网专业化) =====
'use client';
import { useGame } from '@/lib/game/store';
import { VIEW_MODES } from '@/lib/game/constants';
import { GIcon } from './GameIcon';
import { cn } from '@/lib/utils';

interface LegendItem { c: string; t: string }
const VIEW_LEGEND: Record<string, LegendItem[]> = {
  happiness: [{ c: '#4ade80', t: '幸福加成' }, { c: '#ef4444', t: '污染/噪音减益' }, { c: '#3a3a3a', t: '无影响' }],
  power: [
    { c: '#22c55e', t: '接入 · 电压满' }, { c: '#a3e635', t: '电压 ~85%' },
    { c: '#fb923c', t: '低压! 效率下降' }, { c: '#ff2222', t: '断电 / 干线过载' },
    { c: '#3b82f6', t: '电厂 (输出口)' }, { c: '#a78bfa', t: '变电站 (升压)' },
    { c: '#facc15', t: '地下电缆干线' }, { c: '#93c5fd', t: '建筑接口线' },
  ],
  water: [
    { c: '#22c55e', t: '接入 · 水压满' }, { c: '#a3e635', t: '水压 ~85%' },
    { c: '#fb923c', t: '低压! 效率下降' }, { c: '#ff2222', t: '断水 / 水管超压' },
    { c: '#0ea5e9', t: '水厂 (输出口)' }, { c: '#22d3ee', t: '泵站 (增压)' },
    { c: '#facc15', t: '地下水管干线' }, { c: '#7dd3fc', t: '建筑接口线' },
  ],
  light: [{ c: '#fbbf24', t: '夜间照明覆盖' }, { c: '#141e33', t: '漆黑 (住房恐慌)' }],
  landvalue: [{ c: '#d9a536', t: '黄金地段' }, { c: '#4a8a6a', t: '一般' }, { c: '#232c3a', t: '贫瘠' }],
  noise: [{ c: '#fb923c', t: '越红噪音越严重' }, { c: '#2f3a2f', t: '安静' }],
  pollution: [{ c: '#ef4444', t: '越红污染越严重' }, { c: '#2f3a2f', t: '清洁' }],
  road: [{ c: '#60a5fa', t: '道路' }, { c: '#64748b', t: '沿线建筑' }],
};

const VIEW_TINT: Record<string, string> = {
  happiness: 'text-lime-300',
  power: 'text-amber-300',
  water: 'text-sky-300',
  light: 'text-yellow-200',
  noise: 'text-orange-300',
  pollution: 'text-red-300',
  road: 'text-blue-300',
};

export function ViewSwitcher() {
  const snap = useGame(s => s.snap);
  const renderer = useGame(s => s.renderer);
  const viewMode = useGame(s => s.viewMode);
  const setViewMode = useGame(s => s.setViewMode);
  if (!snap || !renderer) return null;

  const pick = (id: string) => {
    const next = viewMode === id ? 'none' : id;
    setViewMode(next);
    renderer.setViewMode(next as any);
  };

  const legend = viewMode !== 'none' ? VIEW_LEGEND[viewMode] : null;
  // v5: 电力/供水读数 (负荷 + 过载警告 + 接入率)
  let stats: { label: string; ok: boolean; text: string }[] = [];
  if (viewMode === 'power' && snap.powerDemand > 0) {
    stats = [
      { label: '发电 / 需求', ok: snap.powerSupply >= snap.powerDemand, text: `${snap.powerSupply} / ${snap.powerDemand}` },
      { label: '电网接入', ok: snap.pipePowerConnected >= snap.pipePowerTotal, text: `${snap.pipePowerConnected}/${snap.pipePowerTotal}` },
    ];
    if (snap.gridWarnings.power > 0) stats.push({ label: '⚡ 过载干线', ok: false, text: `${snap.gridWarnings.power} 条` });
  } else if (viewMode === 'water' && snap.waterDemand > 0) {
    stats = [
      { label: '供水 / 需求', ok: snap.waterSupply >= snap.waterDemand, text: `${snap.waterSupply} / ${snap.waterDemand}` },
      { label: '水网接入', ok: snap.pipeWaterConnected >= snap.pipeWaterTotal, text: `${snap.pipeWaterConnected}/${snap.pipeWaterTotal}` },
    ];
    if (snap.gridWarnings.water > 0) stats.push({ label: '💧 超压水管', ok: false, text: `${snap.gridWarnings.water} 条` });
  }

  return (
    <div className="fixed left-2 top-24 z-30 flex flex-col gap-1 pointer-events-auto">
      <div className="flex flex-col gap-1 bg-stone-900/85 backdrop-blur-md border border-stone-700/60 rounded-xl p-1 shadow-lg">
        {VIEW_MODES.map(v => {
          const active = viewMode === v.id;
          return (
            <button key={v.id} onClick={() => pick(v.id)} title={v.id === 'none' ? '普通视图' : `${v.name}视图`}
              className={cn('relative flex items-center justify-center w-8 h-8 rounded-lg transition-all',
                active ? 'bg-amber-600 text-stone-950 scale-105' : 'text-stone-300 hover:bg-stone-800',
                v.id !== 'none' && !active && VIEW_TINT[v.id])}>
              <GIcon name={v.icon} size={15} />
              {active && v.id !== 'none' && (
                <span className="absolute -right-1 top-1/2 -translate-y-1/2 w-1 h-5 rounded-full bg-amber-400" />
              )}
            </button>
          );
        })}
      </div>
      {viewMode !== 'none' && (
        <div className="w-[176px] bg-stone-900/90 backdrop-blur-md border border-amber-800/50 rounded-lg px-2 py-1.5 shadow-lg">
          <div className="text-[11px] font-black text-amber-200 tracking-wider">
            {VIEW_MODES.find(v => v.id === viewMode)?.name}视图
          </div>
          {stats.map((s, i) => (
            <div key={i} className="mt-1 flex items-center justify-between rounded-md bg-black/40 px-1.5 py-1">
              <span className="text-[9.5px] text-stone-400">{s.label}</span>
              <span className={cn('text-[10.5px] font-black tabular-nums', s.ok ? 'text-emerald-400' : 'text-red-400 animate-pulse')}>
                {s.text}
              </span>
            </div>
          ))}
          {legend && (
            <div className="mt-1 space-y-0.5">
              {legend.map((l, i) => (
                <div key={i} className="flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded-[3px] border border-black/50 shrink-0" style={{ background: l.c }} />
                  <span className="text-[9px] text-stone-300 leading-tight">{l.t}</span>
                </div>
              ))}
            </div>
          )}
          {(viewMode === 'power' || viewMode === 'water') && (
            <div className="mt-1 pt-1 border-t border-stone-800 text-[8.5px] text-stone-500 leading-tight">
              地下管线按最短路径自动路由; 线色=负载 (绿→黄→红=过载, 会短路/爆管)。流动光点 = 资源流向。紫/青环 = 变电站/泵站增压范围。
            </div>
          )}
        </div>
      )}
    </div>
  );
}
