// ===== 人力分配面板 (手动指派工人) =====
'use client';
import { useState } from 'react';
import { useGame } from '@/lib/game/store';
import { gameAudio } from '@/lib/game/audio';
import { GIcon } from './GameIcon';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

export function LaborPanel() {
  const snap = useGame(s => s.snap);
  const engine = useGame(s => s.engine);
  const setPanel = useGame(s => s.setPanel);
  const show = useGame(s => s.showLabor);
  const [, force] = useState(0);
  const [filter, setFilter] = useState<'all' | 'short'>('short');
  if (!show || !snap || !engine) return null;

  const close = () => setPanel('showLabor', false);

  // 需要工人的建筑 (每次渲染重算, 列表不大)
  const workables = (() => {
    const list: { id: number; name: string; icon: string; workers: number; need: number; eff: number; built: boolean }[] = [];
    if (engine) {
      for (const b of engine.buildings.values()) {
        const def = engine.def(b.defId);
        const need = Math.ceil(def.workers * (engine.research.includes('automation') ? 0.5 : 1));
        if (need <= 0) continue;
        list.push({
          id: b.id, name: def.name, icon: def.icon,
          workers: b.workers, need, eff: b.efficiency, built: b.progress >= 1,
        });
      }
    }
    return list.sort((a, b) => (a.workers / a.need) - (b.workers / b.need) || b.need - a.need);
  })();

  const shown = filter === 'short' ? workables.filter(w => w.workers < w.need) : workables;
  const employed = snap.workersEmployed;
  const total = snap.workersTotal;

  const setWorkers = (id: number, n: number) => {
    engine.setWorkers(id, n);
    force(x => x + 1);
  };

  return (
    <div className="fixed inset-0 z-40 flex items-center justify-center p-3 md:p-4">
      <div className="absolute inset-0 bg-black/55 backdrop-blur-[2px]" onClick={close} />
      <div className="relative w-full max-w-[560px] max-h-[86vh] flex flex-col rounded-2xl border border-emerald-800/50 bg-stone-950/95 shadow-2xl overflow-hidden">
        <div className="flex items-center justify-between px-4 py-3 border-b border-stone-800 bg-gradient-to-r from-emerald-950/60 to-transparent">
          <div className="flex items-center gap-2">
            <GIcon name="ClipboardList" size={17} className="text-emerald-300" />
            <div>
              <div className="text-sm font-black text-emerald-100">人力调度</div>
              <div className="text-[10px] text-stone-400 tabular-nums">
                在岗 {employed} / 劳动力 {total} · 闲置 {snap.idleWorkers} 人 {snap.idleWorkers > 8 && '· 闲置过多影响幸福'}
              </div>
            </div>
          </div>
          <Button size="icon" variant="ghost" className="h-7 w-7" onClick={close}><GIcon name="X" size={15} /></Button>
        </div>

        {/* 工具条 */}
        <div className="flex items-center gap-1.5 px-3 py-2 border-b border-stone-800/80 bg-black/30">
          <button onClick={() => setFilter('short')}
            className={cn('px-2.5 py-1 rounded-md text-[11px] font-bold', filter === 'short' ? 'bg-emerald-900/70 text-emerald-200' : 'text-stone-500 hover:text-stone-300')}>
            缺人岗位 ({workables.filter(w => w.workers < w.need).length})
          </button>
          <button onClick={() => setFilter('all')}
            className={cn('px-2.5 py-1 rounded-md text-[11px] font-bold', filter === 'all' ? 'bg-emerald-900/70 text-emerald-200' : 'text-stone-500 hover:text-stone-300')}>
            全部岗位 ({workables.length})
          </button>
          <div className="flex-1" />
          <Button size="sm" variant="outline" className="h-7 text-[10px]"
            onClick={() => { engine.autoAssignLabor(); gameAudio.playSfx('order'); force(x => x + 1); }}
            title="一键按 食物→水→电→资源→市政 优先级自动配满">
            <GIcon name="Wand2" size={11} className="mr-1" /> 一键分配
          </Button>
        </div>

        {/* 列表 */}
        <div className="flex-1 overflow-y-auto game-scroll p-3 space-y-1.5">
          {shown.length === 0 && (
            <div className="py-10 text-center text-[12px] text-stone-500">
              {filter === 'short' ? '✓ 所有岗位人员齐备' : '暂无需要工人的建筑'}
            </div>
          )}
          {shown.map(w => {
            const full = w.workers >= w.need;
            return (
              <div key={w.id} className={cn('flex items-center gap-2.5 rounded-lg border px-2.5 py-2',
                !w.built ? 'border-stone-800/60 bg-stone-900/40 opacity-60'
                  : full ? 'border-emerald-900/50 bg-stone-900/70'
                    : 'border-amber-900/60 bg-amber-950/20')}>
                <GIcon name={w.icon} size={15} className={full ? 'text-emerald-300' : 'text-amber-300'} />
                <div className="min-w-0 flex-1">
                  <div className="text-[11.5px] font-bold text-stone-100 truncate">
                    {w.name}{!w.built && <span className="text-stone-500 text-[9px] ml-1">(施工中)</span>}
                  </div>
                  <div className="text-[9px] text-stone-500">
                    效率 {Math.round(w.eff * 100)}%{w.eff < 0.99 && w.workers < w.need && ' · 人手不足'}
                  </div>
                </div>
                {/* 步进器 */}
                <div className="flex items-center gap-1">
                  <Button size="icon" variant="secondary" className="h-6 w-6 rounded-md"
                    disabled={w.workers <= 0}
                    onClick={() => { setWorkers(w.id, w.workers - 1); gameAudio.playSfx('click'); }}>
                    <GIcon name="Minus" size={11} />
                  </Button>
                  <span className={cn('text-[12px] font-black tabular-nums w-12 text-center',
                    full ? 'text-emerald-300' : 'text-amber-300')}>
                    {w.workers}/{w.need}
                  </span>
                  <Button size="icon" variant="secondary" className="h-6 w-6 rounded-md"
                    disabled={full || employed >= total}
                    onClick={() => { setWorkers(w.id, w.workers + 1); gameAudio.playSfx('click'); }}>
                    <GIcon name="Plus" size={11} />
                  </Button>
                </div>
              </div>
            );
          })}
        </div>

        <div className="px-4 py-2.5 border-t border-stone-800 bg-black/30 text-[10px] text-stone-500 leading-relaxed">
          工人需手动指派 (更专业也更硬核)。新建筑完工后不会自动配人, 请及时来此调度; 「一键分配」按生存优先级补满岗位。
        </div>
      </div>
    </div>
  );
}
