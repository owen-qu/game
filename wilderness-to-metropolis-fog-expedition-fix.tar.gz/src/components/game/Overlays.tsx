// ===== 电影化主菜单 / 时代晋升 / 结局 覆盖层 =====
'use client';
import { useEffect, useRef, useState } from 'react';
import { useGame } from '@/lib/game/store';
import { GameEngine } from '@/lib/game/engine';
import { MenuScene, MENU_ERAS } from '@/lib/game/menuScene';
import { gameAudio } from '@/lib/game/audio';
import { ERAS, ERA_COLORS, DIFFICULTIES } from '@/lib/game/constants';
import { GIcon } from './GameIcon';
import { cn } from '@/lib/utils';

const ACT_LABELS = ['第一幕', '第二幕', '第三幕', '第四幕', '终幕'];

export function StartOverlay({ onStart }: { onStart: (engine: GameEngine) => void }) {
  const show = useGame(s => s.showStart);
  const setPanel = useGame(s => s.setPanel);
  const [seed, setSeed] = useState(0);
  const [mounted, setMounted] = useState(false);
  const [act, setAct] = useState(0);
  const [captionKey, setCaptionKey] = useState(0);
  const [musicOn, setMusicOn] = useState(false);
  const [difficulty, setDifficulty] = useState(1);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const sceneRef = useRef<MenuScene | null>(null);

  // 挂载后再渲染含随机数/localStorage 的内容, 避免 SSR 水合不匹配
  useEffect(() => { setMounted(true); setSeed(Math.floor(Math.random() * 1e9)); }, []);
  const hasSave = mounted && GameEngine.hasSave();

  // 3D 序章场景
  useEffect(() => {
    if (!show || !canvasRef.current || sceneRef.current) return;
    const ms = new MenuScene(canvasRef.current, seed);
    ms.onEraChange = (era) => { setAct(era); setCaptionKey(k => k + 1); };
    ms.onAudioState = (era, hour) => {
      // 已开启配乐时, 跟随幕次切换原声
      if (gameAudio.started && !gameAudio.isMuted) gameAudio.setGameState(era, hour, 0, 0);
    };
    sceneRef.current = ms;
    return () => { ms.dispose(); sceneRef.current = null; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [show]);

  // 首次交互 → 开启电影配乐
  useEffect(() => {
    if (!show) return;
    const kick = () => {
      gameAudio.ensure();
      gameAudio.restore();
      setMusicOn(gameAudio.started && !gameAudio.isMuted);
      if (gameAudio.started) gameAudio.setGameState(act, MENU_ERAS[act].hour, 0, 0);
      window.removeEventListener('pointerdown', kick);
    };
    window.addEventListener('pointerdown', kick);
    return () => window.removeEventListener('pointerdown', kick);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [show]);

  if (!show) return null;
  const info = MENU_ERAS[act];

  const startNew = () => {
    setPanel('showStart', false);
    onStart(new GameEngine(seed || Math.floor(Math.random() * 1e9), difficulty));
  };
  const continueSave = () => {
    const e = GameEngine.load();
    if (e) { setPanel('showStart', false); onStart(e); }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-black select-none">
      {/* 实时 3D 序章 */}
      <canvas ref={canvasRef} className="absolute inset-0 w-full h-full" />
      {/* 电影滤镜层 */}
      <div className="absolute inset-0 cine-vignette pointer-events-none" />
      <div className="absolute inset-0 cine-grain opacity-[0.05] pointer-events-none mix-blend-overlay" />
      <div className="absolute inset-x-0 top-0 bg-black cine-bar-top pointer-events-none" />
      <div className="absolute inset-x-0 bottom-0 bg-black cine-bar-bottom pointer-events-none" />
      {/* 顶部渐隐, 保证文字可读 */}
      <div className="absolute inset-x-0 top-0 h-[30vh] bg-gradient-to-b from-black/58 via-black/16 to-transparent pointer-events-none" />
      <div className="absolute inset-x-0 bottom-0 h-[26vh] bg-gradient-to-t from-black/62 via-black/18 to-transparent pointer-events-none" />

      {/* 主体 UI */}
      <div className="absolute inset-0 flex flex-col items-center justify-between py-[7.5vh] px-4 menu-fade">
        {/* ===== 标题区 ===== */}
        <div className="relative text-center">
          <div className="rise-in flex items-center justify-center gap-3 mb-3" style={{ animationDelay: '0.15s' }}>
            <span className="h-px w-14 bg-gradient-to-r from-transparent to-amber-500/70" />
            <span className="text-[10px] tracking-[0.5em] text-amber-200/80 font-medium">从荒野, 到都会</span>
            <span className="h-px w-14 bg-gradient-to-l from-transparent to-amber-500/70" />
          </div>
          <h1 className="relative text-[13vw] md:text-[86px] leading-none font-black tracking-[0.18em] [filter:drop-shadow(0_4px_28px_rgba(240,190,90,0.32))]">
            {'荒野筑城'.split('').map((ch, i) => (
              <span key={i} className="title-char bg-gradient-to-b from-[#fdf3d3] via-[#f3cf7e] to-[#b97f2a] bg-clip-text text-transparent" style={{ animationDelay: `${0.25 + i * 0.16}s` }}>{ch}</span>
            ))}
          </h1>
          <div className="rise-in mt-3 text-[10px] md:text-[11px] tracking-[0.42em] text-stone-400/90" style={{ animationDelay: '1.15s' }}>
            WILDERNESS&nbsp;TO&nbsp;METROPOLIS
          </div>
        </div>

        {/* ===== 按钮区 ===== */}
        <div className="flex flex-col items-center gap-3 w-full max-w-[420px]">
          {hasSave && (
            <button key="cont" onClick={continueSave}
              className="btn-cine btn-cine-primary rise-in w-full h-[52px] rounded-xl text-[17px] font-black tracking-[0.2em]"
              style={{ animationDelay: '1.3s' }}>
              <span className="flex items-center justify-center gap-2">
                <GIcon name="Play" size={17} /> 继续上次的城市
              </span>
            </button>
          )}
          <button key="new" onClick={startNew}
            className={cn('btn-cine rise-in w-full h-[52px] rounded-xl text-[17px] font-black tracking-[0.2em]',
              !hasSave ? 'btn-cine-primary' : 'text-amber-100')}
            style={{ animationDelay: hasSave ? '1.42s' : '1.3s' }}>
            <span className="flex items-center justify-center gap-2">
              <GIcon name="Tent" size={17} /> 开启新的征程
            </span>
          </button>

          {/* 难度选择 (仅新游戏) */}
          <div className="rise-in w-full grid grid-cols-3 gap-2" style={{ animationDelay: '1.48s' }}>
            {DIFFICULTIES.map(d => (
              <button key={d.id} onClick={() => setDifficulty(d.id)}
                className={cn('rounded-lg border px-2 py-2 text-center transition-all',
                  difficulty === d.id
                    ? d.id === 0 ? 'border-emerald-400 bg-emerald-950/60' : d.id === 2 ? 'border-red-400 bg-red-950/60' : 'border-amber-400 bg-amber-950/60'
                    : 'border-stone-700/50 bg-black/35 hover:border-stone-500')}
                title={d.desc}>
                <div className={cn('text-[13px] font-black tracking-widest',
                  difficulty === d.id ? (d.id === 0 ? 'text-emerald-200' : d.id === 2 ? 'text-red-200' : 'text-amber-200') : 'text-stone-300')}>
                  {d.name}
                </div>
                <div className="text-[8.5px] text-stone-500 mt-0.5 leading-tight">{d.desc}</div>
              </button>
            ))}
          </div>

          <button key="seed" onClick={() => setSeed(Math.floor(Math.random() * 1e9))}
            className="rise-in text-[11px] text-stone-400 hover:text-amber-200 transition-colors tracking-wider underline-offset-4 hover:underline"
            style={{ animationDelay: '1.54s' }}>
            世界种子 <span className="tabular-nums text-stone-300">#{seed}</span> · 点击更换
          </button>
          {!musicOn && (
            <div className="rise-in flex items-center gap-1.5 text-[10px] text-stone-500 note-float" style={{ animationDelay: '1.66s' }}>
              <GIcon name="Music" size={11} className="text-amber-400/70" /> 点击画面任意处, 开启原创电影配乐
            </div>
          )}
        </div>
      </div>

      {/* ===== 幕次字幕 (右下, 跟随 3D 场景轮转) ===== */}
      <div className="absolute right-[4vw] bottom-[7.8vh] text-right pointer-events-none select-none">
        <div key={captionKey}>
          <div className="act-caption text-[11px] tracking-[0.5em] text-amber-300/90 font-semibold">
            {ACT_LABELS[act]}
          </div>
          <div className="act-slogan mt-1.5 text-[26px] md:text-[32px] font-black tracking-[0.28em] text-stone-100/95"
            style={{ textShadow: '0 2px 18px rgba(0,0,0,0.8)' }}>
            {info.name}
          </div>
          <div className="act-slogan mt-2 text-[11px] tracking-[0.14em] text-stone-400">{info.slogan}</div>
        </div>
      </div>

      {/* 底部信息 */}
      <div className="absolute inset-x-0 bottom-[1.4vh] flex items-center justify-center gap-4 text-[9px] tracking-[0.18em] text-stone-400/80 pointer-events-none">
        <span>3D 城市建造模拟</span>
        <span className="text-amber-500/50">◆</span>
        <span>沙盒自由建设</span>
        <span className="text-amber-500/50">◆</span>
        <span>自动存档于浏览器</span>
      </div>
    </div>
  );
}

/** 时代晋升 · 电影化仪式 */
export function EraAdvanceOverlay() {
  const snap = useGame(s => s.snap);
  const [shownEra, setShownEra] = useState<number | null>(null);
  const [closing, setClosing] = useState(false);
  const prevEra = useRef<number | null>(null);
  const snapRef = useRef(snap);
  const timers = useRef<ReturnType<typeof setTimeout>[]>([]);
  useEffect(() => { snapRef.current = snap; });

  // 只依赖时代编号: 避免高频 UI 快照刷新误清定时器导致动画卡死
  useEffect(() => {
    const s = snapRef.current;
    if (!s) return;
    if (prevEra.current == null) { prevEra.current = s.era; return; }
    if (s.era > prevEra.current && s.era > 0) {
      prevEra.current = s.era;
      setShownEra(s.era);
      setClosing(false);
      timers.current.forEach(clearTimeout);
      timers.current = [
        setTimeout(() => setClosing(true), 3900),
        setTimeout(() => setShownEra(null), 4800),
      ];
    } else {
      prevEra.current = s.era;
    }
  }, [snap?.era]);

  useEffect(() => () => { timers.current.forEach(clearTimeout); }, []);

  if (shownEra == null || !snap) return null;
  const era = ERAS[shownEra];
  return (
    <div className={cn('fixed inset-0 z-40 pointer-events-none flex items-center justify-center overflow-hidden',
      closing && 'era-fade-out')}>
      {/* 金色光芒 + 渐变底 */}
      <div className="absolute inset-0 bg-gradient-to-b from-black/55 via-black/35 to-black/60" />
      <div className="absolute -inset-[30vmax] era-rays" />
      <div className="absolute inset-0 cine-vignette" />
      <div className="relative text-center px-6">
        <div className="era-slogan text-[11px] tracking-[0.6em] mb-4 font-semibold"
          style={{ color: ERA_COLORS[shownEra] }}>
          {ACT_LABELS[shownEra - 1] ?? '新纪元'} · 时 代 晋 升
        </div>
        <h2 className="era-title text-[9vw] md:text-[64px] leading-none font-black text-transparent">
          <span className="bg-gradient-to-b from-[#fdf3d3] via-[#f3cf7e] to-[#b97f2a] bg-clip-text text-transparent drop-shadow-[0_4px_26px_rgba(240,190,90,0.4)]">
            {era.name}
          </span>
        </h2>
        <div className="era-line h-px mx-auto my-5 bg-gradient-to-r from-transparent via-amber-400/80 to-transparent" />
        <div className="era-slogan text-[13px] md:text-[15px] tracking-[0.3em] text-stone-200/90">{era.slogan}</div>
        <div className="era-slogan mt-6 inline-flex items-center gap-5 rounded-full border border-amber-500/30 bg-black/45 backdrop-blur-md px-6 py-2.5 text-[11px] text-stone-300 tracking-wider">
          <span className="flex items-center gap-1.5"><GIcon name="Users" size={12} className="text-amber-300" />人口 {snap.pop}</span>
          <span className="w-px h-3.5 bg-amber-500/25" />
          <span className="flex items-center gap-1.5"><GIcon name="Clock3" size={12} className="text-amber-300" />第 {snap.day} 天</span>
          <span className="w-px h-3.5 bg-amber-500/25" />
          <span className="flex items-center gap-1.5"><GIcon name="Building2" size={12} className="text-amber-300" />{snap.buildings} 座建筑</span>
        </div>
      </div>
    </div>
  );
}

export function GameOverOverlay({ onRestart }: { onRestart: () => void }) {
  const snap = useGame(s => s.snap);
  const [dismissed, setDismissed] = useState(false);
  if (!snap?.gameOver || dismissed) return null;
  const win = snap.gameOver.win;
  return (
    <div className={cn('fixed inset-0 z-50 flex items-center justify-center p-4 overflow-hidden',
      win ? 'bg-gradient-to-b from-amber-950/92 via-stone-950/94 to-stone-950' : 'bg-gradient-to-b from-red-950/92 via-stone-950/94 to-stone-950')}>
      {win && <div className="absolute -inset-[30vmax] era-rays" />}
      <div className="absolute inset-0 cine-vignette" />
      <div className="relative max-w-md w-full text-center space-y-5 rise-in">
        <div className={cn('mx-auto w-[72px] h-[72px] rounded-full flex items-center justify-center badge-pulse',
          win ? 'bg-amber-500/15 border border-amber-400/50' : 'bg-red-500/15 border border-red-500/50')}>
          <GIcon name={win ? 'Trophy' : 'Skull'} size={34} className={win ? 'text-amber-300' : 'text-red-400'} />
        </div>
        <h2 className={cn('text-4xl font-black tracking-[0.2em]', win ? 'text-amber-200' : 'text-red-300')}>
          {win ? '大都会落成' : '城市覆灭'}
        </h2>
        <div className="h-px w-48 mx-auto bg-gradient-to-r from-transparent via-stone-500/60 to-transparent" />
        <p className="text-sm text-stone-300 leading-relaxed">{snap.gameOver.reason}</p>
        <div className="text-xs text-stone-500 tracking-wider">第 {snap.day} 天 · 人口 {snap.pop} · {snap.buildings} 座建筑</div>
        {win && (
          <button className="btn-cine btn-cine-primary w-full h-12 rounded-xl text-base font-black tracking-[0.15em]"
            onClick={() => setDismissed(true)}>
            继续沙盒建设
          </button>
        )}
        {!win && (
          <button className="btn-cine w-full h-12 rounded-xl text-base font-black tracking-[0.15em] text-red-200 border-red-500/40"
            onClick={onRestart}>
            重新开始
          </button>
        )}
      </div>
    </div>
  );
}
