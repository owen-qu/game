// ===== v5 地图内战斗面板 (战斗发生在真实地图上, 本组件只负责 UI) =====
'use client';
import { useEffect, useRef, useState } from 'react';
import { useGame } from '@/lib/game/store';
import { gameAudio } from '@/lib/game/audio';
import type { BattleState, BattleUnit } from '@/lib/game/types';
import { GIcon } from './GameIcon';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import { RES_META } from '@/lib/game/constants';
import type { ResourceKey } from '@/lib/game/types';

const ENV_LABEL: Record<BattleState['env'], string> = {
  wild: '荒野遭遇', village: '村落保卫战', city: '城市攻防战', ruin: '遗迹争夺战',
};

function UnitBar({ u, innerRef }: { u: BattleUnit; innerRef: (el: HTMLDivElement | null) => void }) {
  const hpPct = Math.max(0, (u.hp / u.maxHp) * 100);
  return (
    <div ref={innerRef} className="absolute left-0 top-0 pointer-events-none z-10 w-[88px] -translate-x-1/2 -translate-y-full opacity-0 transition-opacity duration-300">
      <div className={cn('px-1.5 py-0.5 rounded-md border backdrop-blur-sm shadow-lg',
        u.side === 'player' ? 'bg-stone-900/85 border-amber-800/70' : 'bg-stone-900/85 border-red-900/70')}>
        <div className="flex items-center justify-between gap-1">
          <span className={cn('text-[9px] font-bold truncate', u.side === 'player' ? 'text-amber-200' : 'text-red-300')}>
            {u.name.replace(' (队长)', '·长')}
          </span>
          <span className="hp-num text-[8px] text-stone-400 tabular-nums">{Math.ceil(u.hp)}</span>
        </div>
        <div className="mt-0.5 h-[5px] rounded-full bg-stone-950 overflow-hidden border border-black/50">
          <div className={cn('hp-fill h-full transition-all duration-300 rounded-full',
            hpPct > 50 ? 'bg-emerald-500' : hpPct > 22 ? 'bg-amber-500' : 'bg-red-500')}
            style={{ width: `${hpPct}%` }} />
        </div>
      </div>
    </div>
  );
}

export function BattleModal() {
  const engine = useGame(s => s.engine);
  const renderer = useGame(s => s.renderer);
  const [, setTick] = useState(0);
  const bRef = useRef<BattleState | null>(null);
  const seenFloats = useRef<Set<number>>(new Set());
  const floatsRef = useRef<HTMLDivElement>(null);
  const barEls = useRef<Map<string, HTMLDivElement>>(new Map());
  const [showLog, setShowLog] = useState(false);

  // 战斗状态轮询 (按钮与战报)
  useEffect(() => {
    if (!engine) return;
    const iv = setInterval(() => {
      const prev = bRef.current;
      bRef.current = engine.battle;
      if (prev !== engine.battle) seenFloats.current.clear();
      setTick(t => t + 1);
    }, 150);
    return () => clearInterval(iv);
  }, [engine]);

  const b = engine ? engine.battle : null;

  // 血条跟随 + 飘字 (读取主渲染器的战场投影)
  useEffect(() => {
    if (!b) return;
    let raf = 0;
    const loop = () => {
      raf = requestAnimationFrame(loop);
      const bt = bRef.current;
      if (!bt || !renderer) return;
      for (const u of bt.units) {
        const el = barEls.current.get(u.uid);
        if (!el) continue;
        const p = renderer.battleProject(u.uid);
        if (!p.visible) { el.style.opacity = '0'; continue; }
        el.style.opacity = u.alive ? '1' : '0';
        el.style.transform = `translate(${p.x}px, ${p.y}px) translate(-50%, -100%)`;
        const bar = el.querySelector('.hp-fill') as HTMLElement | null;
        const num = el.querySelector('.hp-num') as HTMLElement | null;
        const pct = Math.max(0, (u.hp / u.maxHp) * 100);
        if (bar) {
          bar.style.width = `${pct}%`;
          bar.className = cn('hp-fill h-full transition-all duration-300 rounded-full',
            pct > 50 ? 'bg-emerald-500' : pct > 22 ? 'bg-amber-500' : 'bg-red-500');
        }
        if (num) num.textContent = String(Math.ceil(u.hp));
      }
      // 飘字
      const fl = floatsRef.current;
      if (fl) {
        for (const ft of bt.floatTexts) {
          if (seenFloats.current.has(ft.key)) continue;
          seenFloats.current.add(ft.key);
          const p = renderer.battleProject(ft.uid);
          const span = document.createElement('span');
          span.className = 'battle-float absolute text-lg font-black whitespace-nowrap';
          span.style.left = `${p.x + (Math.random() - 0.5) * 40}px`;
          span.style.top = `${p.y - 8}px`;
          span.style.color = ft.tone === 'bad' ? '#f87171' : ft.tone === 'good' ? '#4ade80' : '#e2e8f0';
          span.style.textShadow = '0 2px 8px rgba(0,0,0,0.9)';
          span.textContent = ft.text;
          fl.appendChild(span);
          window.setTimeout(() => span.remove(), 1300);
        }
      }
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [engine, renderer, b?.id]);

  if (!engine || !b) return null;

  const activeUnit = b.units.find(u => u.uid === b.activeUid);
  const isPlayerTurn = b.phase === 'select' && activeUnit?.side === 'player';
  const over = b.phase === 'over';

  const doMove = (moveId: string) => {
    if (!isPlayerTurn) return;
    engine.battleAction(moveId);
    setTick(t => t + 1);
  };

  const doFlee = () => {
    gameAudio.playSfx('flee');
    engine.battleFlee();
  };

  const confirmEnd = () => {
    const r = b.result;
    if (r === 'win') gameAudio.playSfx('victory');
    else if (r === 'lose') gameAudio.playSfx('defeat');
    engine.confirmBattleEnd();
  };

  return (
    <div className="fixed inset-0 z-40 select-none pointer-events-none">
      {/* 单位血条 (跟随地图上的单位投影) */}
      <div className="absolute inset-0">
        {b.units.map(u => (
          <UnitBar key={u.uid} u={u} innerRef={el => {
            if (el) barEls.current.set(u.uid, el);
            else barEls.current.delete(u.uid);
          }} />
        ))}
        <div ref={floatsRef} className="absolute inset-0 pointer-events-none z-20" />
      </div>

      {/* 顶部战况横幅 */}
      <div className="absolute top-14 left-1/2 -translate-x-1/2 flex items-center gap-3 px-4 py-1.5 rounded-full border border-red-800/60 bg-stone-950/85 backdrop-blur-md shadow-lg">
        <span className="w-2.5 h-2.5 rounded-full bg-red-500 animate-pulse" />
        <span className="text-[12px] font-black text-red-300 tracking-widest">{b.title}</span>
        <span className="text-[10px] text-stone-500 tracking-wider">{ENV_LABEL[b.env]} · 第 {b.round} 回合 · ({b.pos.x}, {b.pos.y})</span>
        <span className="text-[9px] text-stone-600 hidden md:inline">战斗中城市时间暂停</span>
      </div>

      {/* 结算卡片 */}
      {over && (
        <div className="absolute inset-0 z-30 flex items-center justify-center bg-black/45 backdrop-blur-[2px] pointer-events-auto">
          <div className={cn('rounded-xl border p-5 text-center max-w-[86%] shadow-2xl',
            b.result === 'win' ? 'border-emerald-700/60 bg-emerald-950/80'
              : b.result === 'lose' ? 'border-red-800/60 bg-red-950/80' : 'border-stone-700 bg-stone-900/90')}>
            <div className="text-xl font-black tracking-[0.2em] mb-1.5">
              {b.result === 'win' ? <span className="text-emerald-300">🏆 战斗胜利</span>
                : b.result === 'lose' ? <span className="text-red-300">☠ 全军覆没</span>
                  : <span className="text-stone-300">🏳 成功撤退</span>}
            </div>
            {b.casualties > 0 && (
              <div className="text-[11px] text-red-300 mb-2">💔 {b.casualties} 名队员壮烈牺牲, 人口 -{b.casualties}</div>
            )}
            {b.rewards && (
              <div className="flex items-center justify-center flex-wrap gap-3 mb-2">
                {(Object.entries(b.rewards) as [ResourceKey, number][]).map(([k, v]) => (
                  <span key={k} className="flex items-center gap-1 text-[13px] font-bold text-stone-200">
                    <GIcon name={RES_META[k].icon} size={14} style={{ color: RES_META[k].color }} />
                    +{Math.round(v)} {RES_META[k].name}
                  </span>
                ))}
              </div>
            )}
            <div className="text-[10px] text-stone-500 mb-3">
              {b.result === 'win' ? '战利品已存入城市仓库' : b.result === 'lose' ? '远征失败, 城市遭受损失' : '小队撤出战斗, 未获得战利品'}
            </div>
            <Button className="h-9 px-8 bg-amber-600 hover:bg-amber-500 text-stone-950 font-black" onClick={confirmEnd}>
              返回城市
            </Button>
          </div>
        </div>
      )}

      {/* 底部操作台 */}
      {!over && (
        <div className="absolute bottom-3 left-1/2 -translate-x-1/2 w-[min(94vw,760px)] pointer-events-auto">
          <div className="rounded-2xl border-2 border-stone-700/70 bg-stone-950/92 backdrop-blur-md shadow-2xl overflow-hidden">
            {/* 行动序列条 */}
            <div className="flex items-center gap-1.5 px-3 pt-2 overflow-x-auto game-scroll">
              <span className="text-[9px] text-stone-500 shrink-0 tracking-wider">行动序列</span>
              {b.turnOrder.slice(b.turnIdx, b.turnIdx + 9).map((uid, i) => {
                const u = b.units.find(x => x.uid === uid);
                if (!u || !u.alive) return null;
                const isNow = i === 0;
                return (
                  <div key={uid + i}
                    className={cn('flex items-center gap-1 rounded-full border px-1.5 py-0.5 shrink-0 transition-all',
                      isNow ? 'border-amber-400 bg-amber-950/70 scale-110' : u.side === 'player' ? 'border-amber-900/50 bg-stone-900/80' : 'border-red-900/50 bg-stone-900/80',
                      !isNow && 'opacity-70')}
                    title={`${u.name} · 速度${u.spd}`}>
                    <GIcon name={u.icon} size={11} style={{ color: u.color }} />
                    <span className={cn('text-[9px] font-bold truncate max-w-[52px]', u.side === 'player' ? 'text-amber-200' : 'text-red-300')}>
                      {u.name.replace(' (队长)', '')}
                    </span>
                  </div>
                );
              })}
            </div>

            {/* 操作区 */}
            <div className="px-3 md:px-4 py-2.5">
              {isPlayerTurn && activeUnit ? (
                <div>
                  <div className="flex items-center gap-2 mb-1.5 text-[10.5px] flex-wrap">
                    <span className="text-stone-400">轮到</span>
                    <span className="text-amber-300 font-black">{activeUnit.name}</span>
                    <span className="flex items-center gap-0.5 text-stone-500"><GIcon name="Swords" size={10} className="text-orange-400" />{activeUnit.atk}</span>
                    <span className="flex items-center gap-0.5 text-stone-500"><GIcon name="Shield" size={10} className="text-sky-400" />{activeUnit.def}</span>
                    <span className="flex items-center gap-0.5 text-stone-500"><GIcon name="Wind" size={10} className="text-emerald-400" />{activeUnit.spd}</span>
                    <div className="flex-1" />
                    <Button size="sm" variant="ghost" className="h-6 text-[11px] text-stone-400 hover:text-red-300"
                      onClick={doFlee} title="撤退: 立即脱离战斗, 可能被追击">
                      <GIcon name="Flag" size={12} className="mr-1" /> 撤退
                    </Button>
                  </div>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                    {activeUnit.moves.map(mv => (
                      <button key={mv.id} onClick={() => doMove(mv.id)}
                        className={cn('rounded-lg border px-2.5 py-1.5 text-left transition-all hover:scale-[1.03] active:scale-95',
                          mv.kind === 'heavy' ? 'border-orange-800/70 bg-orange-950/40 hover:border-orange-600'
                            : mv.kind === 'guard' ? 'border-sky-800/70 bg-sky-950/40 hover:border-sky-600'
                              : mv.kind === 'special' ? 'border-purple-800/70 bg-purple-950/40 hover:border-purple-600'
                                : 'border-stone-700 bg-stone-800/60 hover:border-stone-500')}>
                        <div className="flex items-center justify-between">
                          <span className="text-[12px] font-black text-stone-100">{mv.name}</span>
                          <span className="text-[9px] text-stone-400">{Math.round(mv.accuracy * 100)}%</span>
                        </div>
                        <div className="text-[9px] text-stone-500 mt-0.5 leading-tight">{mv.desc}</div>
                        {mv.power > 0 && (
                          <div className="mt-0.5 text-[9px] text-amber-500/80 font-bold">威力 {Math.round(mv.power * 100)}%</div>
                        )}
                      </button>
                    ))}
                  </div>
                </div>
              ) : (
                <div className="h-[74px] flex items-center justify-center">
                  <div className="flex items-center gap-2 text-[12px] text-stone-400">
                    <span className="w-2 h-2 rounded-full bg-red-500 animate-ping" />
                    <span>{activeUnit ? `${activeUnit.name} 正在行动……` : '敌方行动中……'}</span>
                  </div>
                </div>
              )}
              {/* 战报 */}
              <div className="mt-1.5 flex items-start gap-2 border-t border-stone-800/70 pt-1.5">
                <button onClick={() => setShowLog(!showLog)} className="text-[9px] text-stone-500 hover:text-amber-300 shrink-0">
                  战报 ({b.log.length}) {showLog ? '▲' : '▼'}
                </button>
                {showLog ? (
                  <div className="flex-1 h-[46px] overflow-y-auto game-scroll">
                    {b.log.map((l, i) => (
                      <div key={i} className={cn('text-[10.5px] leading-snug',
                        l.tone === 'good' ? 'text-emerald-300' : l.tone === 'bad' ? 'text-red-300' : 'text-stone-400')}>{l.text}</div>
                    ))}
                  </div>
                ) : (
                  <div className="flex-1 truncate text-[10.5px] text-stone-400">
                    {b.log[0] ? <span className={b.log[0].tone === 'good' ? 'text-emerald-300' : b.log[0].tone === 'bad' ? 'text-red-300' : ''}>{b.log[0].text}</span> : ''}
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
