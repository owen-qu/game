// ===== 游戏主容器 =====
'use client';
import { useCallback, useEffect, useRef, useState } from 'react';
import { useGame } from '@/lib/game/store';
import { GameEngine } from '@/lib/game/engine';
import { GameRenderer } from '@/lib/game/renderer';
import { gameAudio } from '@/lib/game/audio';
import { BUILDING_DEFS } from '@/lib/game/buildings';
import { TopBar } from './TopBar';
import { BuildBar } from './BuildBar';
import { InfoPanel } from './InfoPanel';
import { EventFeed } from './EventFeed';
import { TechPanel } from './TechPanel';
import { StatsPanel } from './StatsPanel';
import { HelpModal } from './HelpModal';
import { DevPanel } from './DevPanel';
import { ViewSwitcher } from './ViewSwitcher';
import { StartOverlay, GameOverOverlay, EraAdvanceOverlay } from './Overlays';
import { BattleModal } from './BattleModal';
import { ExpeditionModal, ExpeditionBar } from './ExpeditionModal';
import { SquadPanel } from './SquadPanel';
import { LaborPanel } from './LaborPanel';

export default function GameShell() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const rendererRef = useRef<GameRenderer | null>(null);
  const engineRef = useRef<GameEngine | null>(null);
  const [ready, setReady] = useState(false);
  const setEngine = useGame(s => s.setEngine);
  const setSnap = useGame(s => s.setSnap);
  const setSelected = useGame(s => s.setSelected);
  const setMode = useGame(s => s.setMode);
  const setPanel = useGame(s => s.setPanel);
  const mode = useGame(s => s.mode);

  const modeRef = useRef(mode);
  useEffect(() => { modeRef.current = mode; }, [mode]);
  const lastEraRef = useRef(0);
  const lastOverRef = useRef(false);
  const lastNotifIdRef = useRef(0);
  const lastBattleRef = useRef(false);

  const syncUI = useCallback(() => {
    const e = engineRef.current;
    if (!e) return;
    const snap = e.snapshot();
    setSnap(snap, [...e.notifications]);
    // 音频状态同步 (时代/昼夜/天灾) + 时代晋升号角
    gameAudio.setGameState(snap.era, snap.hour, snap.eventActive.storm, snap.eventActive.riot);
    if (snap.era !== lastEraRef.current) {
      if (lastEraRef.current < snap.era) {
        gameAudio.playSfx('era');
        rendererRef.current?.eraCinematic();   // 电影运镜: 镜头缓缓拉高环视新城
        rendererRef.current?.refreshLampSprites(); // 新时代路灯
        rendererRef.current?.rebuildWires();
      }
      lastEraRef.current = snap.era;
    }
    if (snap.gameOver && !lastOverRef.current) {
      gameAudio.playSfx(snap.gameOver.win ? 'win' : 'lose');
    }
    lastOverRef.current = !!snap.gameOver;
    // 战斗音乐切换
    const battleNow = !!e.battle;
    if (battleNow !== lastBattleRef.current) {
      gameAudio.setBattle(battleNow);
      if (battleNow) gameAudio.playSfx('battle');
      lastBattleRef.current = battleNow;
    }
    // 新通知里的财运事件 → 金币叮当 / 新生儿 / 遗迹
    for (const ntf of e.notifications) {
      if (ntf.id <= lastNotifIdRef.current) continue;
      if (ntf.id > lastNotifIdRef.current) lastNotifIdRef.current = ntf.id;
      if (ntf.kind === 'caravan' || ntf.kind === 'deposit' || ntf.kind === 'harvest') gameAudio.playSfx('coin');
      else if (ntf.kind === 'birth') gameAudio.playSfx('baby');
      else if (ntf.kind === 'ruin') gameAudio.playSfx('discover');
    }
    if (e.notifications.length === 0) lastNotifIdRef.current = 0;
    // 更新选中建筑实时数据
    const st = useGame.getState();
    if (st.selected) {
      const b = e.buildings.get(st.selected.id);
      if (b) {
        setSelected({ id: b.id, defId: b.defId, hp: b.hp, fire: b.fire, workers: b.workers, efficiency: b.efficiency, damaged: !!b.damaged, progress: b.progress, alerts: [...(b.alerts ?? [])], rot: b.rot, strike: b.strike ?? 0 });
      } else {
        setSelected(null);
      }
    }
  }, [setSnap, setSelected]);

  // 启动新游戏 / 载入存档
  const handleStart = useCallback((engine: GameEngine) => {
    if (!canvasRef.current) return;
    // 清理旧渲染器
    rendererRef.current?.dispose();
    engineRef.current = engine;
    lastEraRef.current = engine.era;
    lastOverRef.current = false;
    // 用户手势内激活音频 (浏览器自动播放策略)
    gameAudio.ensure();
    gameAudio.restore();
    const renderer = new GameRenderer(canvasRef.current, engine, {
      onTileClick: (x, y) => {
        const e = engineRef.current;
        const r = rendererRef.current;
        if (!e || !r) return;
        const m = modeRef.current;
        if (m.type === 'build') {
          const def = BUILDING_DEFS[m.defId];
          if (def.road || def.pipe) {
            // 道路/管线: 两点连线建设
            r.buildLineClick(x, y);
          } else {
            const ok = e.place(m.defId, x, y, r.buildRot);
            if (!ok) {
              const check = e.canPlace(m.defId, x, y);
              e.notify('info', '无法建造', check.reason ?? '位置不合适', 'bad');
              gameAudio.playSfx('error');
            }
          }
        } else if (m.type === 'chop') {
          // 开荒: 派最近的空闲居民走过去执行, 而非点击即得
          const res = r.addChopTask(x, y);
          if (!res.ok && res.reason) {
            e.notify('info', '无法指派', res.reason, 'bad');
          }
        } else if (m.type === 'explore') {
          // 远征: 打开派遣确认面板 (点击处即目标)
          useGame.setState({ expeditionTarget: { x, y } });
          gameAudio.playSfx('order');
        } else if (m.type === 'demolish') {
          const b = e.buildingAt(x, y);
          if (b) {
            e.removeBuilding(b.id, true);
            r.selectBuilding(null);
            setSelected(null);
          }
        } else if (m.type === 'terrain') {
          // 开发者地形刷 (按住拖动连续绘制)
          if (m.terrain === 'rock') e.devAddRock(x, y);
          else if (m.terrain === 'forest') e.devPlantForest(x, y, m.brush);
          else e.devSetTerrain(x, y, m.terrain as any);
        } else {
          // 点空地取消选择
          setSelected(null);
          r.selectBuilding(null);
        }
      },
      onBuildingClick: (id) => {
        const e = engineRef.current;
        const r = rendererRef.current;
        if (!e || !r) return;
        if (id < 0) { setSelected(null); r.selectBuilding(null); return; }
        const m = modeRef.current;
        if (m.type === 'demolish') {
          e.removeBuilding(id, true);
          r.selectBuilding(null);
          setSelected(null);
          return;
        }
        const b = e.buildings.get(id);
        if (!b) return;
        setSelected({ id: b.id, defId: b.defId, hp: b.hp, fire: b.fire, workers: b.workers, efficiency: b.efficiency, damaged: !!b.damaged, progress: b.progress, alerts: [...(b.alerts ?? [])], rot: b.rot, strike: b.strike ?? 0 });
        r.selectBuilding(id);
        gameAudio.playSfx('select');
      },
      onHover: (x, y) => {
        useGame.setState({ hoverTile: { x, y } });
      },
      syncUI,
      onSfx: (name) => { gameAudio.playSfx(name as any); },
      onLinePreview: (count, cost) => {
        useGame.setState({ linePreview: count > 0 ? { count, cost } : null });
      },
    });
    rendererRef.current = renderer;
    setEngine(engine, renderer);
    setReady(true);
    syncUI();
    // 调试 / 高级玩家控制台
    (window as any).__game = { engine, renderer, audio: gameAudio };
  }, [setEngine, syncUI, setSelected]);

  // ESC 取消模式 / 空格暂停 / 反引号开发者模式
  useEffect(() => {
    const onKey = (ev: KeyboardEvent) => {
      const r = rendererRef.current;
      const e = engineRef.current;
      if (ev.key === 'Escape') {
        if (!r || !e) return;
        // 先关闭最上层面板
        const st = useGame.getState();
        if (st.showLabor) { setPanel('showLabor', false); return; }
        if (st.showSquad) { setPanel('showSquad', false); return; }
        if (st.showTech) { setPanel('showTech', false); return; }
        if (st.showStats) { setPanel('showStats', false); return; }
        if (st.showHelp) { setPanel('showHelp', false); return; }
        if (st.expeditionTarget) { useGame.setState({ expeditionTarget: null }); return; }
        r.cancelLine();
        setMode({ type: 'none' });
        r.setMode({ type: 'none' });
        useGame.setState({ linePreview: null });
      }
      if (ev.code === 'Space' && !ev.repeat) {
        ev.preventDefault();
        if (e) e.speed = e.speed === 0 ? 1 : 0;
      }
      if (ev.key === '`' && !ev.repeat) {
        if (!e) return;
        ev.preventDefault();
        if (!e.devMode) {
          e.devEnable();
          e.notify('info', '开发者模式已开启', '资源、时间、事件、地形尽在掌控。', 'info');
        }
        setPanel('showDev', !useGame.getState().showDev);
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [setMode, setPanel]);

  // 重新开始
  const handleRestart = useCallback(() => {
    setPanel('showStart', true);
    setSelected(null);
    useGame.setState({ snap: null, notifications: [], showDev: false, viewMode: 'none' });
    rendererRef.current?.dispose();
    rendererRef.current = null;
    engineRef.current = null;
    setReady(false);
  }, [setPanel, setSelected]);

  // 页面卸载时保存
  useEffect(() => {
    const onUnload = () => { engineRef.current?.save(); };
    window.addEventListener('beforeunload', onUnload);
    return () => window.removeEventListener('beforeunload', onUnload);
  }, []);

  return (
    <div className="fixed inset-0 bg-stone-950 overflow-hidden select-none">
      <canvas ref={canvasRef} className="w-full h-full block touch-none" />
      {ready && (
        <>
          <TopBar />
          <BuildBar />
          <InfoPanel />
          <EventFeed />
          <TechPanel />
          <StatsPanel />
          <HelpModal />
          <DevPanel />
          <ViewSwitcher />
          <EraAdvanceOverlay />
          <ExpeditionBar />
          <ExpeditionModal />
          <SquadPanel />
          <LaborPanel />
          <BattleModal />
          <GameOverOverlay onRestart={handleRestart} />
        </>
      )}
      <StartOverlay onStart={handleStart} />
    </div>
  );
}
