// ===== 顶栏资源 HUD =====
'use client';
import { useState } from 'react';
import { useGame } from '@/lib/game/store';
import { RES_ORDER, RES_META, ERAS, ERA_COLORS, SPEEDS, DEV_SPEEDS, BUDGET_DEPTS, DIFFICULTIES } from '@/lib/game/constants';
import { gameAudio } from '@/lib/game/audio';
import { GIcon } from './GameIcon';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Switch } from '@/components/ui/switch';
import { cn } from '@/lib/utils';

function ResChip({ k }: { k: typeof RES_ORDER[number] }) {
  const snap = useGame(s => s.snap);
  if (!snap) return null;
  const meta = RES_META[k];
  const v = snap.res[k];
  const cap = snap.resCap[k];
  const net = snap.stats[k].net;
  const showCap = k !== 'money' && cap < 900000;
  return (
    <div className="flex flex-col items-center px-1.5 min-w-[54px] max-w-[72px]" title={`${meta.name} ${Math.floor(v)}${showCap ? ` / ${cap}` : ''} · 每日净 ${net >= 0 ? '+' : ''}${net.toFixed(1)}`}>
      <div className="flex items-center gap-1">
        <GIcon name={meta.icon} size={13} style={{ color: meta.color }} className="shrink-0" />
        <span className="text-[13px] font-bold tabular-nums leading-none whitespace-nowrap">
          {k === 'money' ? Math.floor(v).toLocaleString() : Math.floor(v)}
          {showCap && <span className="text-[9px] text-stone-400 font-normal">/{cap}</span>}
        </span>
      </div>
      <div className={cn('text-[9px] leading-tight tabular-nums whitespace-nowrap',
        net > 0.01 ? 'text-emerald-400' : net < -0.01 ? 'text-red-400' : 'text-stone-500')}>
        {net >= 0 ? '▲' : '▼'}{Math.abs(net).toFixed(1)}/日
      </div>
    </div>
  );
}

function Meter({ icon, label, value, warn, danger }: { icon: string; label: string; value: number; warn?: number; danger?: number }) {
  const snap = useGame(s => s.snap);
  if (!snap) return null;
  const hue = value <= (danger ?? 0) ? 'bg-red-500' : value <= (warn ?? 40) ? 'bg-amber-500' : 'bg-emerald-500';
  return (
    <div className="flex items-center gap-1.5 px-1.5" title={`${label}: ${Math.round(value)}%`}>
      <GIcon name={icon} size={14} className="text-stone-300 shrink-0" />
      <div className="w-10 h-1.5 rounded-full bg-stone-700 overflow-hidden">
        <div className={cn('h-full rounded-full transition-all', hue)} style={{ width: `${Math.min(100, value)}%` }} />
      </div>
      <span className="text-[10px] text-stone-300 tabular-nums w-6">{Math.round(value)}</span>
    </div>
  );
}

/** 音乐音量控制气泡 */
function AudioControl() {
  const [open, setOpen] = useState(false);
  const [muted, setMuted] = useState(() => gameAudio.isMuted);
  const [music, setMusic] = useState(() => Math.round(gameAudio.volumes.music * 100));
  const [sfx, setSfx] = useState(() => Math.round(gameAudio.volumes.sfx * 100));

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button size="icon" variant="ghost"
          className={cn('h-7 w-7', muted ? 'text-stone-500' : 'text-emerald-300 hover:text-emerald-200')}
          title="原创配乐 · 音量设置">
          <GIcon name={muted ? 'VolumeX' : 'Music'} size={15} />
        </Button>
      </PopoverTrigger>
      <PopoverContent side="bottom" align="end" className="w-56 bg-stone-900 border-stone-700 text-stone-100 p-3 space-y-3">
        <div className="text-xs font-bold text-amber-200 flex items-center gap-1.5">
          <GIcon name="Music" size={13} /> 原创配乐 · 音效
        </div>
        <div className="space-y-1">
          <div className="flex justify-between text-[11px]"><span className="text-stone-300">音乐</span><span className="tabular-nums text-stone-400">{music}</span></div>
          <Slider value={[music]} min={0} max={100} step={1}
            onValueChange={v => { setMusic(v[0]); gameAudio.setVolumes(v[0] / 100, sfx / 100); }} />
        </div>
        <div className="space-y-1">
          <div className="flex justify-between text-[11px]"><span className="text-stone-300">音效</span><span className="tabular-nums text-stone-400">{sfx}</span></div>
          <Slider value={[sfx]} min={0} max={100} step={1}
            onValueChange={v => { setSfx(v[0]); gameAudio.setVolumes(music / 100, v[0] / 100); }} />
        </div>
        <div className="flex items-center justify-between pt-1 border-t border-stone-800">
          <span className="text-[11px] text-stone-300">全部静音</span>
          <Switch checked={muted} onCheckedChange={v => { setMuted(gameAudio.toggleMute()); }} />
        </div>
        <p className="text-[9px] text-stone-500 leading-tight">配乐随时代演进: 部落鼓谣 → 田园牧歌 → 工业进行曲 → 电气浪潮 → 都会颂歌, 夜晚自动变安静。</p>
      </PopoverContent>
    </Popover>
  );
}

/** 市政政策 · 税率 */
function TaxPolicyControl() {
  const snap = useGame(s => s.snap);
  const engine = useGame(s => s.engine);
  const [, force] = useState(0);
  if (!snap || !engine) return null;
  const opts = [
    { v: 0, name: '轻税', desc: '税收 70% · 居民幸福 +', tone: 'emerald' },
    { v: 1, name: '正常', desc: '税收 100% · 无额外影响', tone: 'amber' },
    { v: 2, name: '重税', desc: '税收 132% · 居民幸福 -', tone: 'red' },
  ] as const;
  return (
    <Popover>
      <PopoverTrigger asChild>
        <Button size="icon" variant="ghost"
          className={cn('h-7 w-7',
            snap.taxPolicy === 2 ? 'text-red-400' : snap.taxPolicy === 0 ? 'text-emerald-300' : 'text-stone-200 hover:text-amber-300')}
          title="市政政策 · 税率">
          <GIcon name="Coins" size={15} />
        </Button>
      </PopoverTrigger>
      <PopoverContent side="bottom" align="end" className="w-60 bg-stone-900 border-stone-700 text-stone-100 p-3 space-y-2">
        <div className="text-xs font-bold text-amber-200 flex items-center gap-1.5">
          <GIcon name="Coins" size={13} /> 市政政策 · 税率
        </div>
        {opts.map(o => (
          <button key={o.v}
            onClick={() => { engine.setTaxPolicy(o.v); force(x => x + 1); }}
            className={cn('w-full flex items-center justify-between rounded-lg border px-2.5 py-1.5 text-left transition-colors',
              snap.taxPolicy === o.v
                ? o.tone === 'emerald' ? 'border-emerald-600 bg-emerald-950/70'
                  : o.tone === 'red' ? 'border-red-600 bg-red-950/70'
                    : 'border-amber-600 bg-amber-950/70'
                : 'border-stone-700/70 bg-stone-800/50 hover:bg-stone-800')}>
            <div>
              <div className={cn('text-xs font-bold',
                snap.taxPolicy === o.v
                  ? o.tone === 'emerald' ? 'text-emerald-300' : o.tone === 'red' ? 'text-red-300' : 'text-amber-300'
                  : 'text-stone-200')}>{o.name}</div>
              <div className="text-[10px] text-stone-400">{o.desc}</div>
            </div>
            {snap.taxPolicy === o.v && <GIcon name="Check" size={14} className="text-stone-300" />}
          </button>
        ))}
        <p className="text-[9px] text-stone-500 leading-tight pt-1 border-t border-stone-800">税收是市政收入的大头: 轻税损财但得民心, 重税敛财但积民怨, 请按城市阶段灵活调整。</p>
      </PopoverContent>
    </Popover>
  );
}

/** 市政预算 · 五部门滑杆 */
function BudgetControl() {
  const snap = useGame(s => s.snap);
  const engine = useGame(s => s.engine);
  if (!snap || !engine) return null;
  return (
    <Popover>
      <PopoverTrigger asChild>
        <Button size="icon" variant="ghost"
          className={cn('h-7 w-7', snap.budgetCost > 1 ? 'text-amber-300' : 'text-stone-200 hover:text-cyan-300')}
          title="市政预算 · 五部门拨款">
          <GIcon name="Wallet" size={15} />
        </Button>
      </PopoverTrigger>
      <PopoverContent side="bottom" align="end" className="w-72 bg-stone-900 border-stone-700 text-stone-100 p-3 space-y-2.5">
        <div className="flex items-center justify-between">
          <div className="text-xs font-bold text-cyan-200 flex items-center gap-1.5">
            <GIcon name="Wallet" size={13} /> 市政预算
          </div>
          <span className={cn('text-[10px] tabular-nums font-bold', snap.budgetCost > 0 ? 'text-red-300' : 'text-emerald-300')}>
            额外开支 {snap.budgetCost > 0 ? '+' : ''}{snap.budgetCost}/日
          </span>
        </div>
        {BUDGET_DEPTS.map(d => {
          const v = snap.budgets[d.key] ?? 1;
          return (
            <div key={d.key} className="space-y-0.5">
              <div className="flex items-center justify-between">
                <span className="flex items-center gap-1 text-[11px] text-stone-300" title={d.desc}>
                  <GIcon name={d.icon} size={12} className={v >= 1.15 ? 'text-emerald-300' : v <= 0.85 ? 'text-red-300' : 'text-stone-400'} /> {d.name}
                </span>
                <span className={cn('text-[10px] font-bold tabular-nums', v > 1.01 ? 'text-emerald-300' : v < 0.99 ? 'text-red-300' : 'text-stone-400')}>
                  {Math.round(v * 100)}%
                </span>
              </div>
              <Slider value={[Math.round(v * 100)]} min={50} max={150} step={5}
                onValueChange={vals => engine.setBudget(d.key, vals[0] / 100)} />
            </div>
          );
        })}
        <p className="text-[9px] text-stone-500 leading-relaxed pt-1 border-t border-stone-800">
          拨款影响对应部门的覆盖半径与效果 (50%~150%), 超支部分按日扣款。警察/医疗/教育拉高地价, 消防减少火灾损失, 道路提升产业效率。
        </p>
      </PopoverContent>
    </Popover>
  );
}

/** 画质选项 */
function QualityControl() {
  const snap = useGame(s => s.snap);
  const engine = useGame(s => s.engine);
  const renderer = useGame(s => s.renderer);
  const [, force] = useState(0);
  if (!snap || !engine || !renderer) return null;
  const opts = [
    { v: 'low' as const, name: '低', desc: '关闭阴影/粒子减半 — 流畅优先', icon: 'Gauge' },
    { v: 'med' as const, name: '中', desc: '标准画质 — 均衡体验', icon: 'Monitor' },
    { v: 'high' as const, name: '高', desc: '软阴影 4K + ACES 调色 + 更多光源', icon: 'Sparkles' },
  ];
  return (
    <Popover>
      <PopoverTrigger asChild>
        <Button size="icon" variant="ghost" className="h-7 w-7 text-stone-200 hover:text-cyan-300" title="画质选项">
          <GIcon name="Sparkles" size={15} />
        </Button>
      </PopoverTrigger>
      <PopoverContent side="bottom" align="end" className="w-60 bg-stone-900 border-stone-700 text-stone-100 p-2 space-y-1">
        <div className="text-xs font-bold text-cyan-200 flex items-center gap-1.5 px-1 pb-1">
          <GIcon name="Sparkles" size={13} /> 画质</div>
        {opts.map(o => (
          <button key={o.v} onClick={() => { engine.devSetQuality(o.v); renderer.applyQuality(o.v); force(x => x + 1); }}
            className={cn('w-full flex items-center justify-between rounded-lg border px-2.5 py-1.5 text-left transition-colors',
              snap.quality === o.v ? 'border-cyan-600 bg-cyan-950/70' : 'border-stone-700/70 bg-stone-800/50 hover:bg-stone-800')}>
            <div className="flex items-center gap-2">
              <GIcon name={o.icon} size={13} className={snap.quality === o.v ? 'text-cyan-300' : 'text-stone-400'} />
              <div>
                <div className={cn('text-xs font-bold', snap.quality === o.v ? 'text-cyan-200' : 'text-stone-200')}>{o.name}</div>
                <div className="text-[9px] text-stone-500">{o.desc}</div>
              </div>
            </div>
            {snap.quality === o.v && <GIcon name="Check" size={13} className="text-cyan-300" />}
          </button>
        ))}
      </PopoverContent>
    </Popover>
  );
}

/** 银行信贷 (需建银行) */
function LoanControl() {
  const snap = useGame(s => s.snap);
  const engine = useGame(s => s.engine);
  const [, force] = useState(0);
  if (!snap || !engine) return null;
  const hasBank = engine.hasBuilding('bank');
  return (
    <Popover>
      <PopoverTrigger asChild>
        <Button size="icon" variant="ghost"
          className={cn('h-7 w-7', snap.loan > 0 ? 'text-red-400 animate-pulse' : hasBank ? 'text-emerald-300 hover:text-emerald-200' : 'text-stone-600')}
          title={hasBank ? '银行 · 信贷' : '建造银行后解锁信贷'}>
          <GIcon name="Landmark" size={15} />
        </Button>
      </PopoverTrigger>
      <PopoverContent side="bottom" align="end" className="w-64 bg-stone-900 border-stone-700 text-stone-100 p-3 space-y-2">
        <div className="text-xs font-bold text-emerald-200 flex items-center gap-1.5">
          <GIcon name="Landmark" size={13} /> 银行 · 信贷
        </div>
        {!hasBank ? (
          <p className="text-[10px] text-stone-500 leading-relaxed">建造「银行」后解锁: 贷款加速发展 (日息 0.8%), 存款自动生息 (0.3%/日)。</p>
        ) : (
          <>
            <div className="rounded-lg bg-stone-800/60 border border-stone-700 px-2.5 py-2 text-[11px] flex justify-between">
              <span className="text-stone-400">未偿贷款</span>
              <span className={cn('font-black tabular-nums', snap.loan > 0 ? 'text-red-300' : 'text-emerald-300')}>{snap.loan} 资金</span>
            </div>
            {snap.loan > 0 ? (
              <>
                <div className="text-[10px] text-stone-500">每日利息 {Math.ceil(snap.loan * 0.008)} 资金 · 结余 {Math.floor(snap.res.money)} 资金</div>
                <Button size="sm" className="w-full h-8 text-xs bg-emerald-700 hover:bg-emerald-600 text-white"
                  disabled={snap.res.money < snap.loan}
                  onClick={() => { if (engine.repayLoan()) { gameAudio.playSfx('repay'); force(x => x + 1); } }}>
                  <GIcon name="Check" size={12} className="mr-1" /> 一次性还清 {snap.loan}
                </Button>
              </>
            ) : (
              <>
                <div className="text-[10px] text-stone-500">借款立即到账, 发展快人一步 —— 但要按时还:</div>
                {[300, 800, 2000].map(amt => (
                  <button key={amt} onClick={() => { if (engine.borrowLoan(amt)) { gameAudio.playSfx('loan'); force(x => x + 1); } }}
                    className="w-full flex items-center justify-between rounded-lg border border-stone-700 bg-stone-800/50 hover:border-emerald-600 px-2.5 py-1.5 text-left transition-colors">
                    <span className="text-xs font-bold text-stone-200">贷款 {amt}</span>
                    <span className="text-[10px] text-stone-500">日息 {Math.ceil(amt * 0.008)}</span>
                  </button>
                ))}
              </>
            )}
          </>
        )}
      </PopoverContent>
    </Popover>
  );
}

export function TopBar() {
  const snap = useGame(s => s.snap);
  const engine = useGame(s => s.engine);
  const setPanel = useGame(s => s.setPanel);
  if (!snap) return null;
  const era = ERAS[snap.era];
  const hour = snap.hour;
  const minute = snap.minute ?? 0;
  const timeStr = `${String(hour).padStart(2, '0')}:${String(minute).padStart(2, '0')}`;
  const isNight = hour < 6 || hour >= 19;
  const storm = snap.eventActive.storm > 0;
  const riot = snap.eventActive.riot > 0;

  const speeds = snap.devMode ? DEV_SPEEDS : SPEEDS;
  const speedIcons = ['Pause', 'Play', 'FastForward', 'Gauge', 'Rocket', 'Rocket'];
  const speedTitles = ['暂停', '正常', '2×', '4×', '10× (开发)', '25× (开发)'];

  const toggleDev = () => {
    if (!engine) return;
    if (!engine.devMode) {
      engine.devEnable();
      engine.notify('info', '开发者模式已开启', '资源、时间、事件、地形尽在掌控。按 ` 键快速开关。', 'info');
    }
    setPanel('showDev', !useGame.getState().showDev);
  };

  return (
    <div className="fixed top-0 inset-x-0 z-30 pointer-events-none">
      <div className="mx-auto max-w-[1400px] p-1.5 md:p-2.5 flex flex-wrap gap-1.5 md:gap-2 items-stretch justify-center">
        {/* 时代 + 时间 */}
        <div className="pointer-events-auto flex items-center gap-2 bg-stone-900/85 backdrop-blur-md border border-stone-700/60 rounded-xl px-3 py-1.5 shadow-lg">
          <div className="flex flex-col">
            <div className="flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full animate-pulse" style={{ background: ERA_COLORS[snap.era] }} />
              <span className="text-sm font-bold text-stone-100">{era.name}</span>
              <span className="text-[10px] text-stone-400">第 {snap.day} 天</span>
              {snap.devMode && (
                <span className="px-1 rounded bg-amber-900/70 border border-amber-700/60 text-[8px] font-black text-amber-300 tracking-wider">DEV</span>
              )}
              {snap.freeBuild && (
                <span className="px-1 rounded bg-emerald-900/70 border border-emerald-700/60 text-[8px] font-black text-emerald-300">免费建造</span>
              )}
            </div>
            <div className="flex items-center gap-1 text-[10px] text-stone-400">
              <GIcon name={isNight ? 'Moon' : storm ? 'CloudRain' : 'Sun'} size={11} className={storm ? 'text-slate-300' : isNight ? 'text-indigo-200' : 'text-amber-300'} />
              <span className="tabular-nums" style={{ minWidth: 34 }}>{timeStr}</span>
              {snap.taxPolicy === 2 && <span className="text-red-400 font-bold" title="重税中">重税</span>}
              {snap.taxPolicy === 0 && <span className="text-emerald-400 font-bold" title="轻税中">轻税</span>}
              {storm && <span className="text-slate-300">暴雨 ×{snap.eventActive.storm}天</span>}
              {riot && <span className="text-red-400 font-bold">⚠ 暴乱中 ×{snap.eventActive.riot}天</span>}
            </div>
          </div>
        </div>

        {/* 资源 */}
        <div className="pointer-events-auto flex items-center bg-stone-900/85 backdrop-blur-md border border-stone-700/60 rounded-xl px-1 py-1 shadow-lg divide-x divide-stone-700/50 overflow-x-auto game-scroll max-w-full">
          {RES_ORDER.map(k => <ResChip key={k} k={k} />)}
        </div>

        {/* 人口 / 情绪 / 水电 */}
        <div className="pointer-events-auto flex items-center gap-1.5 md:gap-2 bg-stone-900/85 backdrop-blur-md border border-stone-700/60 rounded-xl px-2 py-1.5 shadow-lg overflow-x-auto game-scroll max-w-full">
          <div className="flex items-center gap-1" title={`人口 ${snap.pop} / ${snap.popCap} · 劳动力 ${snap.workersEmployed}/${snap.workersTotal}`}>
            <GIcon name="Users" size={14} className="text-amber-200" />
            <span className="text-sm font-bold tabular-nums">{snap.pop}</span>
            <span className="text-[10px] text-stone-400">/{snap.popCap}</span>
          </div>
          {snap.scrolls > 0 && (
            <button className="flex items-center gap-0.5 px-1 rounded bg-indigo-950/70 border border-indigo-800/60" title="典籍 (图书馆产出): 研究科技时每卷自动抵 15 资金">
              <GIcon name="Scroll" size={11} className="text-indigo-300" />
              <span className="text-[10px] font-bold text-indigo-200 tabular-nums">{snap.scrolls}</span>
            </button>
          )}
          {snap.idleWorkers > 0 && (
            <button onClick={() => setPanel('showLabor', true)} title="闲置劳动力 — 点击打开人力调度"
              className="flex items-center gap-0.5 px-1 rounded bg-amber-950/70 border border-amber-800/60 hover:border-amber-500">
              <GIcon name="UserRound" size={11} className="text-amber-300" />
              <span className="text-[10px] font-bold text-amber-200 tabular-nums">闲{snap.idleWorkers}</span>
            </button>
          )}
          <div className="w-px h-6 bg-stone-700" />
          <Meter icon="Smile" label="幸福度" value={snap.happiness} warn={45} danger={30} />
          <Meter icon="Scale" label="秩序" value={snap.order} warn={40} danger={25} />
          <Meter icon="Gem" label="地价" value={snap.landValue} warn={35} danger={20} />
          <div className="w-px h-6 bg-stone-700" />
          <div className="flex flex-col gap-0.5" title={`生育率 ${snap.birthRate.toFixed(2)}/日 · 移民吸引力 ${snap.attraction.toFixed(2)}/日`}>
            <div className="flex items-center gap-1" title={`电力 供${snap.powerSupply} / 需${snap.powerDemand}`}>
              <GIcon name="Zap" size={12} className={snap.powerDemand > snap.powerSupply ? 'text-red-400' : 'text-amber-300'} />
              <span className={cn('text-[11px] font-bold tabular-nums', snap.powerDemand > snap.powerSupply ? 'text-red-400' : 'text-stone-200')}>{snap.powerSupply}/{snap.powerDemand}</span>
            </div>
            <div className="flex items-center gap-1" title={`水 供${snap.waterSupply} / 需${snap.waterDemand}${snap.waterBufferCap > 0 ? ` · 蓄水池缓冲 ${snap.waterBuffer}/${snap.waterBufferCap}` : ''}`}>
              <GIcon name="Droplets" size={12} className={snap.waterDemand > snap.waterSupply && snap.waterBuffer <= 0 ? 'text-red-400' : 'text-teal-300'} />
              <span className={cn('text-[11px] font-bold tabular-nums', snap.waterDemand > snap.waterSupply && snap.waterBuffer <= 0 ? 'text-red-400' : 'text-stone-200')}>{snap.waterSupply}/{snap.waterDemand}</span>
            </div>
          </div>
          {snap.foodDaysLeft >= 0 && snap.foodDaysLeft < 5 && (
            <div className="flex items-center gap-1 px-1 rounded bg-red-950/80 border border-red-800" title="存粮告急">
              <GIcon name="Hourglass" size={12} className="text-red-400" />
              <span className="text-[10px] text-red-300">粮{snap.foodDaysLeft.toFixed(0)}天</span>
            </div>
          )}
        </div>

        {/* 速度 + 菜单 */}
        <div className="pointer-events-auto flex items-center gap-1 bg-stone-900/85 backdrop-blur-md border border-stone-700/60 rounded-xl px-2 py-1.5 shadow-lg">
          {speeds.map((s, i) => (
            <Button key={s} size="icon" variant={snap.speed === s ? 'default' : 'ghost'}
              className={cn('h-7 w-7', snap.speed === s && 'bg-amber-600 hover:bg-amber-500 text-stone-950',
                s >= 10 && snap.speed !== s && 'text-amber-500/80')}
              onClick={() => { if (engine) engine.speed = s as any; }}
              title={speedTitles[i] ?? `${s}×`}>
              <GIcon name={speedIcons[i] ?? 'Gauge'} size={13} />
            </Button>
          ))}
          <div className="w-px h-6 bg-stone-700 mx-1" />
          <TaxPolicyControl />
          <BudgetControl />
          <AudioControl />
          <QualityControl />
          <LoanControl />
          <Button size="icon" variant="ghost" className="h-7 w-7 text-stone-200 hover:text-emerald-300 relative"
            onClick={() => setPanel('showLabor', true)} title="人力调度 · 手动分配工人">
            <GIcon name="ClipboardList" size={15} />
            {snap.idleWorkers > 0 && (
              <span className="absolute -top-0.5 -right-0.5 min-w-[13px] h-[13px] px-0.5 rounded-full bg-amber-500 text-stone-950 text-[8px] font-black flex items-center justify-center">
                {snap.idleWorkers > 99 ? '99' : snap.idleWorkers}
              </span>
            )}
          </Button>
          <Button size="icon" variant="ghost" className="h-7 w-7 text-stone-200 hover:text-orange-300"
            onClick={() => setPanel('showSquad', true)} title="战队 · 军备 (武器/盔甲升级)">
            <GIcon name="Swords" size={15} />
          </Button>
          <Button size="icon" variant="ghost" className="h-7 w-7 text-stone-200 hover:text-amber-300" onClick={() => setPanel('showTech', true)} title="时代与科技">
            <GIcon name="FlaskConical" size={15} />
          </Button>
          <Button size="icon" variant="ghost" className="h-7 w-7 text-stone-200 hover:text-amber-300" onClick={() => setPanel('showStats', true)} title="城市统计">
            <GIcon name="BarChart3" size={15} />
          </Button>
          <Button size="icon" variant="ghost" className="h-7 w-7 text-stone-200 hover:text-amber-300" onClick={() => { engine?.save(); engine?.notify('info', '已保存', '城市进度已保存到浏览器。', 'good'); }} title="保存">
            <GIcon name="Save" size={15} />
          </Button>
          <Button size="icon" variant="ghost" className="h-7 w-7 text-stone-200 hover:text-amber-300" onClick={() => setPanel('showHelp', true)} title="玩法指南">
            <GIcon name="BookOpen" size={15} />
          </Button>
          {/* 开发者模式 */}
          <Button size="icon" variant="ghost"
            className={cn('h-7 w-7', snap.devMode ? 'text-amber-300 bg-amber-950/60 hover:bg-amber-900/60' : 'text-stone-600 hover:text-amber-400')}
            onClick={toggleDev} title="开发者模式 (按键 ` 开关)">
            <GIcon name="Bug" size={15} />
          </Button>
        </div>
      </div>
    </div>
  );
}
