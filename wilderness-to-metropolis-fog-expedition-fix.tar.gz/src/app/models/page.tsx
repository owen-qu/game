// ===== 模型检视页 (开发用): 网格陈列所有模型, 截图排查颠倒/浮空/穿模 =====
'use client';
import { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { buildModel, modelKeys } from '@/lib/game/models';

const COLS = 6;
const PER_PAGE = COLS * 2;   // 每页 12 个
const CELL = 3.3;
const MAX_H = 2.5;           // 超高模型等比缩小展示 (避免遮挡后排)

function labelSprite(text: string): THREE.Sprite {
  const cv = document.createElement('canvas');
  cv.width = 256; cv.height = 56;
  const ctx = cv.getContext('2d')!;
  ctx.fillStyle = 'rgba(20,18,14,0.82)';
  ctx.roundRect(0, 0, 256, 56, 10);
  ctx.fill();
  ctx.fillStyle = '#f5e9c8';
  ctx.font = 'bold 26px "Noto Sans SC", sans-serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText(text, 128, 30, 240);
  const tex = new THREE.CanvasTexture(cv);
  tex.colorSpace = THREE.SRGBColorSpace;
  const spr = new THREE.Sprite(new THREE.SpriteMaterial({ map: tex, transparent: true, depthWrite: false }));
  spr.scale.set(1.7, 0.37, 1);
  return spr;
}

export default function ModelsPage() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [page, setPage] = useState(0);
  const keys = modelKeys();
  const pages = Math.ceil(keys.length / PER_PAGE);
  const pageKeys = keys.slice(page * PER_PAGE, (page + 1) * PER_PAGE);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas || pageKeys.length === 0) return;
    const renderer = new THREE.WebGLRenderer({ canvas, antialias: true });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x2a2622);
    const w = 1240, h = 900;
    renderer.setSize(w, h, false);
    // 正交相机: 接近游戏内视角的35°俯角, 网格均匀呈现
    const VW = 23;
    const VH = VW * (h / w);
    const camera = new THREE.OrthographicCamera(-VW / 2, VW / 2, VH / 2, -VH / 2, 0.1, 100);
    camera.position.set(0, 16, 22);
    camera.lookAt(0, 0.6, 0);

    scene.add(new THREE.HemisphereLight(0xfff4e0, 0x554433, 0.95));
    const sun = new THREE.DirectionalLight(0xffffff, 1.6);
    sun.position.set(6, 10, 7);
    sun.castShadow = true;
    sun.shadow.mapSize.set(2048, 2048);
    sun.shadow.camera.left = -12; sun.shadow.camera.right = 12;
    sun.shadow.camera.top = 10; sun.shadow.camera.bottom = -10;
    scene.add(sun);

    // 地面
    const ground = new THREE.Mesh(new THREE.PlaneGeometry(40, 30), new THREE.MeshStandardMaterial({ color: 0x4a4438, roughness: 1 }));
    ground.rotation.x = -Math.PI / 2;
    ground.receiveShadow = true;
    scene.add(ground);

    // 网格线
    const grid = new THREE.GridHelper(40, Math.round(40 / 0.65), 0x5a5244, 0x3d3830);
    (grid.material as THREE.Material).opacity = 0.5;
    (grid.material as THREE.Material).transparent = true;
    grid.position.y = 0.005;
    scene.add(grid);

    const rows = Math.ceil(pageKeys.length / COLS);
    pageKeys.forEach((key, i) => {
      const col = i % COLS, row = Math.floor(i / COLS);
      const x = (col - (COLS - 1) / 2) * CELL;
      const z = (row - (rows - 1) / 2) * (CELL + 1.5);
      const m = buildModel(key);
      // x/z 包围盒居中; y 保持原生 0 地面 (模型自带埋地裙边的会略微穿入地面, 属正常设计)
      const bbox = new THREE.Box3().setFromObject(m);
      const bh = bbox.max.y - bbox.min.y;
      if (bh > MAX_H) m.scale.multiplyScalar(MAX_H / bh);
      const b2 = new THREE.Box3().setFromObject(m);
      const cx = (b2.min.x + b2.max.x) / 2, cz = (b2.min.z + b2.max.z) / 2;
      m.position.set(x - cx, 0, z - cz);
      m.rotation.y = Math.PI / 5;   // 3/4 视角
      scene.add(m);
      // 红色接地标记环: 模型底部应贴合环所在平面
      const ring = new THREE.Mesh(
        new THREE.RingGeometry(0.62, 0.68, 28),
        new THREE.MeshBasicMaterial({ color: 0xff5533, transparent: true, opacity: 0.75, side: THREE.DoubleSide, depthWrite: false }),
      );
      ring.rotation.x = -Math.PI / 2;
      ring.position.set(x, 0.01, z);
      scene.add(ring);
      const spr = labelSprite(key);
      spr.position.set(x, 0.42, z + CELL / 2 - 0.2);
      spr.scale.set(2.1, 0.46, 1);
      scene.add(spr);
    });

    renderer.render(scene, camera);
    return () => {
      renderer.dispose();
      scene.traverse(o => {
        const m = o as THREE.Mesh;
        if (m.geometry) m.geometry.dispose();
      });
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [page, pageKeys.length, keys.join(',')]);

  return (
    <div className="min-h-screen bg-stone-950 flex flex-col items-center py-4 gap-3 select-none">
      <div className="flex items-center gap-4">
        <button onClick={() => setPage(p => Math.max(0, p - 1))} disabled={page === 0}
          className="px-3 py-1 rounded bg-stone-800 text-stone-200 text-sm disabled:opacity-30">‹ 上一页</button>
        <span className="text-stone-400 text-sm">模型检视 {page + 1} / {pages} — 红环 = 接地面</span>
        <button onClick={() => setPage(p => Math.min(pages - 1, p + 1))} disabled={page >= pages - 1}
          className="px-3 py-1 rounded bg-stone-800 text-stone-200 text-sm disabled:opacity-30">下一页 ›</button>
      </div>
      <canvas ref={canvasRef} className="rounded-xl border border-stone-700 shadow-2xl" style={{ width: 'min(1240px, 96vw)', height: 'auto', aspectRatio: '1240/900' }} />
    </div>
  );
}
