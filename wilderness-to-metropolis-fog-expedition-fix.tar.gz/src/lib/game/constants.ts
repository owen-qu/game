// ===== 荒野筑城 · 常量与调参 =====
import type { ResourceKey, EraDef } from './types';

export const GRID = 80;              // [已废弃] 无限世界: 地形按区块生成, 不再有固定尺寸
export const TILE = 1;               // 世界单位
export const DAY_HOURS = 24;         // 一天 = 24 游戏小时
export const HOUR_SEC = 12.5;        // 1x 速度下 1 游戏小时 = 12.5 真实秒 → 一天整 5 分钟
export const DAY_SEC = HOUR_SEC * DAY_HOURS; // 300s
export const SPEEDS = [0, 1, 2, 4];  // 暂停/1x/2x/4x
export const DEV_SPEEDS = [0, 1, 2, 4, 10, 25]; // 开发者模式额外速度

export const RES_META: Record<ResourceKey, { name: string; icon: string; color: string }> = {
  food:  { name: '食物', icon: 'Wheat',      color: '#facc15' },
  wood:  { name: '木材', icon: 'TreePine',   color: '#a16207' },
  stone: { name: '石料', icon: 'Mountain',   color: '#94a3b8' },
  metal: { name: '金属', icon: 'Cog',        color: '#7dd3fc' },
  oil:   { name: '石油', icon: 'Fuel',       color: '#fb923c' },
  money: { name: '资金', icon: 'CircleDollarSign', color: '#4ade80' },
};

export const RES_ORDER: ResourceKey[] = ['food', 'wood', 'stone', 'metal', 'oil', 'money'];

export const BASE_CAP: Record<ResourceKey, number> = {
  food: 300, wood: 300, stone: 220, metal: 120, oil: 90, money: 99999999,
};

// 时代需求: 全面重新平衡, 保证可以从部落一路升到现代都会
export const ERAS: EraDef[] = [
  {
    index: 0,
    name: '荒野部落',
    slogan: '几个人, 一片荒野, 篝火与星空',
    require: { pop: 8, resources: { food: 50, wood: 40 } },
  },
  {
    index: 1,
    name: '农耕村落',
    slogan: '春种秋收, 鸡犬相闻',
    require: { pop: 16, resources: { wood: 90, food: 80 } },
  },
  {
    index: 2,
    name: '工业城镇',
    slogan: '机器轰鸣, 烟囱林立',
    require: { pop: 30, resources: { money: 260, stone: 90 } },
  },
  {
    index: 3,
    name: '电气都市',
    slogan: '灯火通明, 车水马龙',
    require: { pop: 50, resources: { money: 900 }, powerNet: 15, hasBuilding: ['coal_plant'] },
  },
  {
    index: 4,
    name: '现代都会',
    slogan: '摩天大楼刺破天际, 你的城市与世界相连',
    require: { pop: 80, resources: { money: 2600 }, powerNet: 50 },
  },
];

export const ERA_COLORS = ['#d97706', '#65a30d', '#b45309', '#0ea5e9', '#e11d48'];

// 人口与工作
export const WORK_RATIO = 0.66;      // 可劳动人口比例(其余为孩童与养老者)
export const FOOD_PER_POP = 0.26;    // 每人每日消耗食物 (v4: 口粮翻倍 —— 食物短缺成为真实威胁)
export const TAX_PER_POP = 0.12;     // 每人每日基础纳税(随时代增长)

// 事件概率(每日)
export const EVT = {
  fire: 0.020,
  storm: 0.028,
  accident: 0.026,
  riot: 0.14,         // 幸福度<30 时每日触发概率
  nuclear: 0.008,     // 核电+秩序<50 时
  harvest: 0.050,
  caravan: 0.045,
  immigrant: 0.070,
  deposit: 0.032,
  festival: 0.030,    // 节日庆典(幸福+)
  plague: 0.012,      // 疫病(无医院时)
  quake: 0.006,       // 地震
};

// 数据视图
export const VIEW_MODES = [
  { id: 'none',       name: '普通',   icon: 'Eye' },
  { id: 'happiness',  name: '幸福',   icon: 'Smile' },
  { id: 'power',      name: '电力',   icon: 'Zap' },
  { id: 'water',      name: '供水',   icon: 'Droplets' },
  { id: 'landvalue',  name: '地价',   icon: 'Gem' },
  { id: 'light',      name: '光照',   icon: 'Lightbulb' },
  { id: 'noise',      name: '噪音',   icon: 'Volume2' },
  { id: 'pollution',  name: '污染',   icon: 'Factory' },
  { id: 'road',       name: '交通',   icon: 'CarFront' },
] as const;
export type ViewModeId = typeof VIEW_MODES[number]['id'];

// 贸易基准价 (每单位资源的进口价; 出口 = 60% 折价)。需集市 (era2+)
export const TRADE_PRICES: Partial<Record<ResourceKey, number>> = {
  food: 2, wood: 2, stone: 3, metal: 6, oil: 8,
};

// 难度: [事件倍率, 食耗倍率, 威胁加成, 贸易加价]
export const DIFFICULTIES = [
  { id: 0, name: '平和', desc: '事件更少 · 食耗 -8% · 敌人较弱', evt: 0.65, food: 0.92, threat: 0, trade: 1.0 },
  { id: 1, name: '标准', desc: '标准的世界节奏', evt: 1.0, food: 1.0, threat: 0, trade: 1.15 },
  { id: 2, name: '严酷', desc: '天灾频繁 · 食耗 +12% · 敌人更强 · 贸易加价', evt: 1.45, food: 1.12, threat: 1, trade: 1.3 },
] as const;

// 市政预算部门 (滑杆 50%~150%)
export const BUDGET_DEPTS = [
  { key: 'fire',   name: '消防', icon: 'FireExtinguisher', desc: '消防覆盖半径与火灾扑救速度' },
  { key: 'police', name: '治安', icon: 'Shield', desc: '警察覆盖半径与暴乱压制' },
  { key: 'health', name: '医疗', icon: 'Cross', desc: '医院覆盖半径与防疫能力' },
  { key: 'edu',    name: '教育', icon: 'GraduationCap', desc: '学校教育加成与劳动参与率' },
  { key: 'road',   name: '道路', icon: 'Route', desc: '道路生产加成与维护' },
] as const;
export type BudgetKey = typeof BUDGET_DEPTS[number]['key'];

export const SAVE_KEY = 'wildcity_save_v3';
