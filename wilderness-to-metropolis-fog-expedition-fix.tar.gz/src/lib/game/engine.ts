// ===== 荒野筑城 · 游戏引擎 v3 (无限世界/迷雾/远征/战斗/手动人力/市政机制) =====
import type {
  Building, BuildingDef, GameSpeed, ResourceKey, ResourceStat, UISnapshot, NotificationItem, EventKind,
  OverlayCell, TileTerrain, PipeKind, Expedition, BattleState, UtiliEdge, BlackoutIncident,
} from './types';
import { BASE_CAP, WORK_RATIO, FOOD_PER_POP, TAX_PER_POP, EVT, ERAS, HOUR_SEC, DAY_HOURS, SAVE_KEY, RES_META, DIFFICULTIES, TRADE_PRICES } from './constants';
import { BUILDING_DEFS, RESEARCH_DEFS, WEAPON_TIERS, ARMOR_TIERS } from './buildings';
import { World, World as WorldT, RUIN_TYPES } from './terrain';
import {
  createBattle, makePlayerSquad, makeEnemySquad, performMove, enemyChooseMove,
  fleeBattle, battleRewards,
} from './battle';

export interface FxItem {
  kind: 'fire' | 'extinguish' | 'stormOn' | 'stormOff' | 'riotOn' | 'riotOff' | 'place' | 'remove'
  | 'nuke' | 'chop' | 'complete' | 'rotate' | 'battle' | 'dig' | 'network' | 'reveal' | 'expedition';
  buildingId?: number; tx?: number; ty?: number;
}

const RES_KEYS: ResourceKey[] = ['food', 'wood', 'stone', 'metal', 'oil', 'money'];
const TERRAIN_LIST: TileTerrain[] = ['water', 'sand', 'grass', 'forest', 'hill', 'mountain'];

// 远征参数
const EXP_SPEED = 0.145;        // 1× 下每秒行进格数 (12 格单程 ≈ 83 秒)
const EXP_FOOD_PER_SEC = 0.105; // 每人每秒 (1×) 耗粮
const EXP_UPFRONT_FOOD = 4;     // 每人出发口粮
const EXP_REVEAL_RADIUS = 4;    // 行进途中揭开视野
const EXP_ARRIVE_REVEAL = 6;    // 抵达目标揭开视野
const EXP_ENCOUNTER_BASE = 0.3;
const EXP_SCAVENGE_SEC = 3.2;   // 搜刮遗迹耗时

export class GameEngine {
  seed: number;
  terrain: World;
  res: Record<ResourceKey, number> = { food: 80, wood: 60, stone: 15, metal: 0, oil: 0, money: 50 };
  era = 0;
  research: string[] = [];
  buildings = new Map<number, Building>();
  nextId = 1;
  day = 1;
  hour = 7;
  speed: GameSpeed = 1;
  pop = 5;
  happiness = 58;
  order = 62;
  stormDays = 0;
  riotDays = 0;
  gameOver: null | { win: boolean; reason: string } = null;
  winShown = false;
  taxPolicy = 1;
  private lastTaxNotifyDay = -99;

  // ---------- 远征 ----------
  expeditions: Expedition[] = [];
  nextExpId = 1;
  expNotified = new Set<number>();

  // ---------- 战斗 ----------
  battle: BattleState | null = null;
  nextBattleId = 1;
  battleWins = 0;
  battleLosses = 0;
  weaponTier = 0;
  armorTier = 0;
  /** v5: 就绪载具 (城防战自动参战) */
  get readyVehicles(): { apc: number; tank: number; heli: number } {
    const out = { apc: 0, tank: 0, heli: 0 };
    for (const b of this.buildings.values()) {
      if (b.progress < 1) continue;
      const d = this.def(b.defId);
      if (d.vehicle && !b.damaged && (b.vehicleReadyDay ?? 0) <= this.day) out[d.vehicle]++;
    }
    return out;
  }
  private battleAnimTimer = 0;
  private prevSpeedBeforeBattle = 1;
  private battleRandSeed = Date.now() % 100000;
  private battleRand = () => {
    this.battleRandSeed = (this.battleRandSeed * 1664525 + 1013904223) % 4294967296;
    return this.battleRandSeed / 4294967296;
  };

  // ---------- 市政独立机制 ----------
  scrolls = 0;            // 典籍 (图书馆)
  loan = 0;               // 未偿贷款 (银行)
  private loanNotifyDay = -99;
  birthAcc = 0;           // 生育累积
  birthRate = 0;
  attraction = 0;         // 移民吸引力 (人/日)
  immiAcc = 0;            // 移民累积
  waterBuffer = 0;        // 蓄水池缓冲
  waterBufferCap = 0;

  // ---------- 人力 (手动分配) ----------
  laborManual = true;

  // ---------- 市政预算 (五部门, 0.5~1.5) ----------
  budgets: Record<string, number> = { fire: 1, police: 1, health: 1, edu: 1, road: 1 };
  budgetCost = 0;            // 预算相对基准的额外每日开支

  // ---------- 地价 ----------
  landValues = new Map<number, number>();   // 住房建筑 id → 地价 0-100
  avgLandValue = 35;

  // ---------- 贸易 ----------
  tradeSpent = 0;            // 当日进口支出 (资金)
  tradeEarned = 0;           // 当日出口收入
  private tradeNotified = new Set<string>();

  // ---------- 难度 ----------
  difficulty = 1;            // 0平和 / 1标准 / 2严酷

  // 开发者模式
  devMode = false;
  freeBuild = false;
  devCapBoost: Partial<Record<ResourceKey, number>> = {};
  quality: 'low' | 'med' | 'high' = 'med';

  // 派生
  powerSupply = 0; powerDemand = 0; waterSupply = 0; waterDemand = 0;
  stats: Record<ResourceKey, ResourceStat> = emptyStats();
  notifications: NotificationItem[] = [];
  pendingFx: FxItem[] = [];
  rand: () => number;
  notifId = 1;
  autoSaveTimer = 0;
  viewMode: string = 'none';

  // 慢速缓存
  private slowTimer = 0;
  private eduGrid = new Map<number, number>();
  private coveredFire = new Set<number>();
  private coveredPolice = new Set<number>();
  private coveredHealth = new Set<number>();
  private pipePowered = new Set<number>();
  private pipeWatered = new Set<number>();
  /** v5 地下管网: 视图渲染用 (干线+接口线, 含负载/容量/事故态) */
  utilEdges: UtiliEdge[] = [];
  blackouts: BlackoutIncident[] = [];
  buildingVolt = new Map<number, number>();   // 建筑 → 电压% (0-100)
  buildingPress = new Map<number, number>();  // 建筑 → 水压% (0-100)
  gridWarnings = { power: 0, water: 0 };      // 过载干线数 (顶栏/视图用)
  networkVersion = 0;
  overlay: Map<number, OverlayCell> = new Map();
  pipePowerConnected = 0; pipePowerTotal = 0;
  pipeWaterConnected = 0; pipeWaterTotal = 0;
  private lastNetworkHash = '';
  private shortageNotified = { food: -99, water: -99, power: -99 };

  constructor(seed = Math.floor(Math.random() * 1e9), difficulty = 1) {
    this.seed = seed;
    this.difficulty = Math.max(0, Math.min(2, Math.floor(difficulty)));
    this.rand = this.mkRand(seed ^ 0x9e3779b9);
    this.terrain = new World(seed);
    this.placeInitialCamp();
    this.slowTick(true);
  }

  private mkRand(seed: number) {
    let a = seed >>> 0;
    return () => {
      a |= 0; a = (a + 0x6d2b79f5) | 0;
      let t = Math.imul(a ^ (a >>> 15), 1 | a);
      t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }

  /** 城市中心 (建筑质心, 供远征测距) */
  cityCenter(): { x: number; y: number } {
    let sx = 0, sy = 0, n = 0;
    for (const b of this.buildings.values()) {
      if (b.progress >= 1) { sx += b.x + b.size / 2; sy += b.y + b.size / 2; n++; }
    }
    if (n === 0) return { x: this.terrain.spawn.x, y: this.terrain.spawn.y };
    return { x: Math.round(sx / n), y: Math.round(sy / n) };
  }

  // ---------- 初始营地 ----------
  private placeInitialCamp() {
    const { x, y } = this.terrain.spawn;
    const wanted: string[] = ['tent', 'tent', 'campfire', 'berry'];
    const taken = new Set<string>();
    const offsets: [number, number][] = [
      [0, 0], [-1, -1], [1, -1], [-1, 1], [1, 1],
      [0, -1], [0, 1], [-1, 0], [1, 0],
      [-2, 0], [2, 0], [0, -2], [0, 2], [-2, -1], [2, 1], [-1, 2], [1, -2],
      [-2, -2], [2, 2], [-2, 2], [2, -2], [-3, 0], [3, 0], [0, -3], [0, 3],
    ];
    for (const defId of wanted) {
      const def = BUILDING_DEFS[defId];
      let placed = false;
      for (const [dx, dy] of offsets) {
        const px = x + dx, py = y + dy;
        if (taken.has(`${px},${py}`)) continue;
        if (this.canPlace(defId, px, py).ok) {
          this.createBuilding(def, px, py, true);
          taken.add(`${px},${py}`);
          placed = true;
          break;
        }
      }
      if (!placed) {
        for (let r = 4; r < 10 && !placed; r++) {
          for (let dy = -r; dy <= r && !placed; dy++)
            for (let dx = -r; dx <= r && !placed; dx++) {
              if (Math.max(Math.abs(dx), Math.abs(dy)) !== r) continue;
              const px = x + dx, py = y + dy;
              if (taken.has(`${px},${py}`)) continue;
              if (this.canPlace(defId, px, py).ok) {
                this.createBuilding(def, px, py, true);
                taken.add(`${px},${py}`);
                placed = true;
              }
            }
        }
      }
    }
    this.notify('info', '新的家园', `迷雾之外是无限的荒野。派出远征队探索远方、搜刮遗迹, 揭开脚下的世界。`, 'info');
  }

  // ---------- 建筑 ----------
  def(id: string): BuildingDef { return BUILDING_DEFS[id]; }

  canAfford(def: BuildingDef): boolean {
    if (this.freeBuild) return true;
    return RES_KEYS.every(k => (def.cost[k] ?? 0) <= this.res[k]);
  }

  isUnlocked(def: BuildingDef): boolean {
    if (def.era > this.era) return false;
    if (def.research && !this.research.includes(def.research)) return false;
    return true;
  }

  canPlace(defId: string, x: number, y: number): { ok: boolean; reason?: string } {
    const def = BUILDING_DEFS[defId];
    if (!def) return { ok: false, reason: '未知建筑' };
    if (!this.isUnlocked(def)) return { ok: false, reason: '尚未解锁' };
    if (!this.canAfford(def)) return { ok: false, reason: '资源不足' };
    for (let dy = 0; dy < def.size; dy++) {
      for (let dx = 0; dx < def.size; dx++) {
        const tx = x + dx, ty = y + dy;
        const t = this.terrain.peek(tx, ty);
        if (!t) return { ok: false, reason: '迷雾之外' };
        if (!t.explored) return { ok: false, reason: '尚未探索 (先派远征队)' };
        if (t.occupied) return { ok: false, reason: '此处已有建筑' };
        if (def.onWater) {
          if (t.terrain === 'mountain') return { ok: false, reason: '山脉无法平整' };
        } else {
          if (t.terrain === 'water') return { ok: false, reason: '不能建在水上' };
          if (t.terrain === 'mountain') return { ok: false, reason: '山脉无法平整' };
        }
      }
    }
    if (def.needsWater) {
      let ok = false;
      for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
        const t = this.terrain.peek(x + dx, y + dy);
        if (t && t.terrain === 'water') ok = true;
      }
      if (!ok) return { ok: false, reason: '必须紧邻水域' };
    }
    if (def.needsForest) {
      const n = this.countTerrainAround(x, y, def.needsForest, t => t.terrain === 'forest');
      if (n < def.needsForest) return { ok: false, reason: `周围 ${def.needsForest} 格内需要树林` };
    }
    if (def.needsRock) {
      const n = this.countTerrainAround(x, y, def.needsRock, t => t.terrain === 'hill' || t.terrain === 'mountain');
      if (n < def.needsRock) return { ok: false, reason: `周围 ${def.needsRock} 格内需要丘陵山地` };
    }
    if (def.needsRoad) {
      let ok = false;
      for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1], [1, 1], [-1, -1], [1, -1], [-1, 1]]) {
        const t = this.terrain.peek(x + dx, y + dy);
        if (t && t.buildingId >= 0) {
          const b = this.buildings.get(t.buildingId);
          if (b && this.def(b.defId).road) ok = true;
        }
      }
      if (!ok) return { ok: false, reason: '必须紧邻道路' };
    }
    return { ok: true };
  }

  private countTerrainAround(x: number, y: number, r: number, pred: (t: { terrain: string }) => boolean): number {
    let n = 0;
    for (let dy = -r; dy <= r; dy++)
      for (let dx = -r; dx <= r; dx++) {
        if (dx === 0 && dy === 0) continue;
        const t = this.terrain.peek(x + dx, y + dy);
        if (t && pred(t)) n++;
      }
    return n;
  }

  createBuilding(def: BuildingDef, x: number, y: number, free = false, rot = 0): Building {
    const instant = free || this.freeBuild || !!def.road || !!def.pipe || this.buildDaysOf(def) <= 0.001;
    const b: Building = {
      id: this.nextId++, defId: def.id, x, y, size: def.size,
      rot: ((Math.round(rot) % 4) + 4) % 4,
      hp: 100, fire: 0, workers: 0, efficiency: 1, builtDay: this.day,
      progress: instant ? 1 : 0,
      alerts: [],
      powered: true, watered: true, strike: 0,
    };
    this.buildings.set(b.id, b);
    for (let dy = 0; dy < def.size; dy++)
      for (let dx = 0; dx < def.size; dx++) {
        const t = this.terrain.ensure(x + dx, y + dy);
        t.occupied = true; t.buildingId = b.id;
        if (t.tree >= 0) this.removeTree(x + dx, y + dy, false);
      }
    if (!free && !this.freeBuild) {
      RES_KEYS.forEach(k => { this.res[k] -= def.cost[k] ?? 0; });
    }
    // 只有开局营地的初始建筑提供起始视野。
    // 玩家后续放置道路、管线或普通建筑都不能揭开战争迷雾；
    // 新区域必须由远征队沿途/抵达时探索，避免铺路链式扩张视野。
    if (free) {
      const startRevealR = def.size >= 2 ? 8 : 7;
      this.terrain.reveal(x, y, startRevealR);
    }
    this.pendingFx.push({ kind: 'place', buildingId: b.id });
    this.slowTimer = 99;
    return b;
  }

  buildDaysOf(def: BuildingDef): number {
    if (def.buildDays != null) return def.buildDays;
    let total = 0;
    for (const k of RES_KEYS) total += (def.cost[k] ?? 0) * (k === 'money' ? 0.004 : 1);
    return Math.min(0.8, 0.038 + total / 1000) * def.size;
  }

  place(defId: string, x: number, y: number, rot = 0): boolean {
    const c = this.canPlace(defId, x, y);
    if (!c.ok) return false;
    this.createBuilding(BUILDING_DEFS[defId], x, y, false, rot);
    return true;
  }

  placeLine(defId: string, tiles: { x: number; y: number }[]): { built: number; failed: number } {
    let built = 0, failed = 0;
    for (const t of tiles) {
      if (this.place(defId, t.x, t.y)) built++;
      else failed++;
    }
    return { built, failed };
  }

  rotateBuilding(id: number): boolean {
    const b = this.buildings.get(id);
    if (!b) return false;
    const def = this.def(b.defId);
    if (def.road || def.pipe) return false;
    b.rot = (b.rot + 1) % 4;
    this.pendingFx.push({ kind: 'rotate', buildingId: id });
    return true;
  }

  removeBuilding(id: number, refund = true): boolean {
    const b = this.buildings.get(id);
    if (!b) return false;
    const def = this.def(b.defId);
    this.buildings.delete(id);
    for (let dy = 0; dy < b.size; dy++)
      for (let dx = 0; dx < b.size; dx++) {
        const t = this.terrain.peek(b.x + dx, b.y + dy);
        if (t) { t.occupied = false; t.buildingId = -1; }
      }
    if (refund) {
      RES_KEYS.forEach(k => {
        const back = Math.floor((def.cost[k] ?? 0) * 0.35);
        this.addRes(k, back);
      });
    }
    this.pendingFx.push({ kind: 'remove', buildingId: id });
    this.slowTimer = 99;
    return true;
  }

  buildingAt(x: number, y: number): Building | null {
    const t = this.terrain.peek(x, y);
    if (!t || t.buildingId < 0) return null;
    return this.buildings.get(t.buildingId) ?? null;
  }

  // ---------- 手动开荒: 砍树 / 采石 / 搜刮遗迹 ----------
  chopAt(x: number, y: number): { wood: number; stone: number } {
    const out = { wood: 0, stone: 0 };
    const t = this.terrain.peek(x, y);
    if (!t || !t.explored || t.occupied) return out;
    if (t.tree >= 0) {
      this.removeTree(x, y, true);
      out.wood = this.research.includes('toolmaking') ? 5 : 4;
    } else if (t.rock) {
      t.rock = false;
      out.stone = this.research.includes('toolmaking') ? 4 : 3;
    }
    return out;
  }

  removeTree(x: number, y: number, grant: boolean) {
    const t = this.terrain.peek(x, y);
    if (!t) return;
    const idx = t.tree;
    if (idx < 0) return;
    t.tree = -1;
    t.terrain = 'grass';
    this.terrain.stats.forest--; this.terrain.stats.grass++;
    this.terrain.treeAt.delete(WorldT.key(x, y));
    const tr = this.terrain.trees[idx];
    if (tr) tr.dead = true;
    if (grant) this.addRes('wood', this.research.includes('toolmaking') ? 5 : 4);
    this.pendingFx.push({ kind: 'remove', buildingId: -1 - idx });
  }

  /** 遗迹搜刮 (点击派工或远征抵达) */
  scavengeRuin(x: number, y: number, byExpedition = false): Partial<Record<ResourceKey, number>> {
    const t = this.terrain.peek(x, y);
    const out: Partial<Record<ResourceKey, number>> = {};
    if (!t || t.ruin < 0) return out;
    const ruin = this.terrain.ruins[t.ruin];
    if (!ruin || ruin.scavenged) return out;
    ruin.scavenged = true;
    const eraScale = 1 + this.era * 0.5 + (byExpedition ? 0.6 : 0);
    const r = this.rand;
    let extraScrolls = 0;
    switch (ruin.type) {
      case 0: // 巨石阵: 石料金属
        out.stone = Math.round((18 + r() * 14) * eraScale);
        out.metal = Math.round((4 + r() * 6) * eraScale * 0.8);
        break;
      case 1: // 残破石塔: 资金金属
        out.money = Math.round((35 + r() * 40) * eraScale);
        out.metal = Math.round((5 + r() * 8) * eraScale * 0.7);
        break;
      case 2: // 远古营地: 食物木材
        out.food = Math.round((16 + r() * 16) * eraScale);
        out.wood = Math.round((14 + r() * 12) * eraScale);
        break;
      case 3: // 神秘石碑: 资金 + 典籍
        out.money = Math.round((25 + r() * 30) * eraScale);
        extraScrolls = 2;
        break;
      case 4: // 搁浅沉船: 木材 + 资金
        out.wood = Math.round((28 + r() * 22) * eraScale);
        out.money = Math.round((30 + r() * 35) * eraScale);
        break;
      case 5: // 废弃加油站: 石油 + 资金
        out.oil = Math.round((10 + r() * 12) * eraScale);
        out.money = Math.round((20 + r() * 25) * eraScale);
        break;
      case 6: // 坠毁无人机: 金属 + 典籍
        out.metal = Math.round((16 + r() * 14) * eraScale);
        extraScrolls = 1;
        out.money = Math.round((15 + r() * 20) * eraScale);
        break;
      case 7: // 掩埋地窖: 食物 + 石材
        out.food = Math.round((26 + r() * 20) * eraScale);
        out.stone = Math.round((8 + r() * 8) * eraScale);
        break;
      // ---- v5 新遗迹 ----
      case 8: // 废弃哨塔: 军火库 (金属 + 资金)
        out.metal = Math.round((14 + r() * 12) * eraScale);
        out.money = Math.round((40 + r() * 45) * eraScale);
        break;
      case 9: // 沉没码头: 木材 + 石料 + 资金
        out.wood = Math.round((22 + r() * 16) * eraScale);
        out.stone = Math.round((10 + r() * 10) * eraScale);
        out.money = Math.round((18 + r() * 22) * eraScale);
        break;
      case 10: // 巨型残骸: 金属 + 石油 + 典籍
        out.metal = Math.round((24 + r() * 18) * eraScale);
        out.oil = Math.round((8 + r() * 10) * eraScale);
        extraScrolls = 2;
        break;
      default: // case 11 神秘古井: 食物 + 资金 + 典籍
        out.food = Math.round((20 + r() * 18) * eraScale);
        out.money = Math.round((22 + r() * 26) * eraScale);
        extraScrolls = 1;
        break;
    }
    if (extraScrolls > 0) this.scrolls = Math.min(30, this.scrolls + extraScrolls);
    for (const k of RES_KEYS) if (out[k]) this.addRes(k, out[k]!);
    this.pendingFx.push({ kind: 'dig', tx: x, ty: y });
    const parts = RES_KEYS.filter(k => out[k]).map(k => `+${Math.round(out[k]!)} ${RES_META[k].name}`);
    const ruinName = RUIN_TYPES[ruin.type]?.name ?? '遗迹';
    this.notify('ruin', '遗迹搜刮完成', `${byExpedition ? '远征队' : '工人'}搜刮了${ruinName}: ${parts.join(' ')}${extraScrolls > 0 ? `, 并解读出 ${extraScrolls} 卷典籍` : ''}。`, 'good');
    return out;
  }

  ruinInfoAt(x: number, y: number): { type: number; scavenged: boolean } | null {
    const t = this.terrain.peek(x, y);
    if (!t || t.ruin < 0 || !t.explored) return null;
    const r = this.terrain.ruins[t.ruin];
    return r ? { type: r.type, scavenged: r.scavenged } : null;
  }

  // ---------- 远征 ----------
  /** 载具对行军的提速系数 */
  static vehicleSpeedMul(v: { apc: number; tank: number; heli: number }): number {
    return Math.min(2.2, 1 + v.apc * 0.35 + v.tank * 0.15 + v.heli * 1.2);
  }
  /** 载具单次远征油耗 */
  static vehicleOilCost(v: { apc: number; tank: number; heli: number }): number {
    return v.apc * 6 + v.tank * 10 + v.heli * 16;
  }

  expeditionPreview(tx: number, ty: number, members: number, vehicles = { apc: 0, tank: 0, heli: 0 }) {
    const cc = this.cityCenter();
    const dist = Math.max(Math.abs(tx - cc.x), Math.abs(ty - cc.y));
    const scoutMul = this.research.includes('scouting') ? 0.8 : 1;
    const foodCost = dist * 2 * EXP_FOOD_PER_SEC / EXP_SPEED * members * scoutMul / GameEngine.vehicleSpeedMul(vehicles) + members * EXP_UPFRONT_FOOD;
    const etaSec = dist / (EXP_SPEED * (this.research.includes('scouting') ? 1.3 : 1) * GameEngine.vehicleSpeedMul(vehicles));
    const oilCost = GameEngine.vehicleOilCost(vehicles);
    const t = this.terrain.peek(tx, ty);
    const inFog = !t || !t.explored;
    let ruin: string | null = null;
    if (t && t.ruin >= 0 && t.explored) ruin = RUIN_TYPES[this.terrain.ruins[t.ruin].type]?.name ?? null;
    return { dist, members, foodCost: Math.ceil(foodCost), oilCost, etaSec, ruin, inFog };
  }

  startExpedition(tx: number, ty: number, members: number, vehicles = { apc: 0, tank: 0, heli: 0 }): { ok: boolean; reason?: string } {
    if (this.expeditions.length >= 3) return { ok: false, reason: '最多同时派出 3 支远征队' };
    const cc = this.cityCenter();
    const dist = Math.max(Math.abs(tx - cc.x), Math.abs(ty - cc.y));
    if (dist < 10) return { ok: false, reason: '目标距城市不足 10 格, 不算远征 (附近资源直接开荒即可)' };
    const maxMembers = this.squadSize;
    if (members < 1) return { ok: false, reason: '至少需要 1 名队员' };
    if (members > maxMembers) return { ok: false, reason: `战队规模不足 (当前上限 ${maxMembers} 人, 建设训练场扩充)` };
    const ready = this.readyVehicles;
    if (vehicles.apc > ready.apc || vehicles.tank > ready.tank || vehicles.heli > ready.heli) {
      return { ok: false, reason: '载具不足 (部分正在重建)' };
    }
    const preview = this.expeditionPreview(tx, ty, members, vehicles);
    if (this.res.food < preview.foodCost) return { ok: false, reason: `食物不足: 全程约需 ${preview.foodCost} 食物` };
    const oilNeed = GameEngine.vehicleOilCost(vehicles);
    if (this.res.oil < oilNeed) return { ok: false, reason: `石油不足: 载具全程约需 ${oilNeed} 石油` };
    if (this.pop - members < 2) return { ok: false, reason: '城里得留守居民' };
    // 扣除出发口粮与油耗
    this.res.food = Math.max(0, this.res.food - members * EXP_UPFRONT_FOOD);
    this.res.oil = Math.max(0, this.res.oil - oilNeed);
    const e: Expedition = {
      id: this.nextExpId++, members,
      vehicles: { ...vehicles },
      x: cc.x, y: cc.y, sx: cc.x, sy: cc.y, tx, ty, dist,
      state: 'outbound', timer: 0, encounterDone: false,
      loot: {}, revealAcc: 0, speedMul: 1,
    };
    this.expeditions.push(e);
    const vParts: string[] = [];
    if (vehicles.apc) vParts.push(`装甲车×${vehicles.apc}`);
    if (vehicles.tank) vParts.push(`坦克×${vehicles.tank}`);
    if (vehicles.heli) vParts.push(`直升机×${vehicles.heli}`);
    this.notify('expedition', `远征队 #${e.id} 出发`, `${members} 名队员${vParts.length ? `携 ${vParts.join(' ')}` : ''}向 (${tx}, ${ty}) 进发 —— 单程约 ${(preview.etaSec / 60).toFixed(1)} 分钟 (1×速度)。途中有遭遇战风险, 请备足粮草。`, 'info');
    this.pendingFx.push({ kind: 'expedition' });
    return { ok: true };
  }

  private updateExpeditions(dtSec: number) {
    const scoutMul = this.research.includes('scouting') ? 1.3 : 1;
    const foodMul = this.research.includes('scouting') ? 0.8 : 1;
    for (let i = this.expeditions.length - 1; i >= 0; i--) {
      const e = this.expeditions[i];
      if (e.state === 'scavenge') {
        e.timer -= dtSec;
        if (e.timer <= 0) {
          const loot = this.scavengeRuin(e.tx, e.ty, true);
          for (const k of RES_KEYS) if (loot[k]) e.loot[k] = (e.loot[k] ?? 0) + loot[k]!;
          e.state = 'returning';
        }
        continue;
      }
      // 行进
      const target = e.state === 'outbound' ? { x: e.tx, y: e.ty } : { x: e.sx, y: e.sy };
      const dx = target.x - e.x, dy = target.y - e.y;
      const d = Math.hypot(dx, dy);
      if (d < 0.4) {
        if (e.state === 'outbound') {
          this.terrain.reveal(e.tx, e.ty, EXP_ARRIVE_REVEAL);
          const t = this.terrain.peek(e.tx, e.ty);
          if (t && t.ruin >= 0 && !this.terrain.ruins[t.ruin].scavenged) {
            e.state = 'scavenge'; e.timer = EXP_SCAVENGE_SEC;
            this.notify('expedition', `远征队 #${e.id} 发现遗迹`, '队员们开始搜刮……', 'info');
          } else {
            e.state = 'returning';
            this.notify('expedition', `远征队 #${e.id} 到达目的地`, '插上旗帜标记了这片新土地, 正在返程。', 'info');
          }
        } else {
          // 归队结算
          const parts = RES_KEYS.filter(k => (e.loot[k] ?? 0) > 0).map(k => `+${Math.round(e.loot[k]!)} ${RES_META[k].name}`);
          this.notify('expedition', `远征队 #${e.id} 凯旋`, parts.length > 0 ? `满载而归: ${parts.join(' ')}。` : '队员们平安归来 (此次没有搜刮到物资)。', 'good');
          for (const k of RES_KEYS) if (e.loot[k]) this.addRes(k, e.loot[k]!);
          this.happiness = Math.min(100, this.happiness + 2);
          this.expeditions.splice(i, 1);
          this.pendingFx.push({ kind: 'expedition' });
        }
        continue;
      }
      // 地形减速 (v5: 载具大幅减轻地形惩罚, 直升机完全无视)
      const tile = this.terrain.peek(Math.round(e.x), Math.round(e.y));
      let mul = 1;
      if (tile) {
        if (tile.terrain === 'water') mul = 0.45;
        else if (tile.terrain === 'mountain') mul = 0.5;
        else if (tile.terrain === 'hill') mul = 0.75;
      }
      if (e.vehicles.heli > 0) mul = 1;
      else if (e.vehicles.apc + e.vehicles.tank > 0) mul = Math.min(1, mul + 0.25);
      e.speedMul = e.speedMul * 0.9 + mul * 0.1;
      const vSpeed = GameEngine.vehicleSpeedMul(e.vehicles);
      const step = EXP_SPEED * scoutMul * vSpeed * e.speedMul * dtSec;
      e.x += (dx / d) * step;
      e.y += (dy / d) * step;
      // 沿途耗粮
      const foodUse = EXP_FOOD_PER_SEC * e.members * foodMul * dtSec;
      if (this.res.food > foodUse) {
        this.res.food -= foodUse;
      } else {
        this.res.food = 0;
        if (!this.expNotified.has(e.id)) {
          this.expNotified.add(e.id);
          this.notify('expedition', `远征队 #${e.id} 断粮!`, '城市储备见底, 远征队被迫提前返程。', 'bad');
          this.happiness -= 3;
        }
        if (e.state === 'outbound') e.state = 'returning';
      }
      // 沿途揭雾
      e.revealAcc += step;
      if (e.revealAcc > 2) {
        e.revealAcc = 0;
        this.terrain.reveal(Math.round(e.x), Math.round(e.y), EXP_REVEAL_RADIUS);
      }
      // 遭遇判定 (去程中段一次)
      if (e.state === 'outbound' && !e.encounterDone) {
        const traveled = Math.hypot(e.x - e.sx, e.y - e.sy);
        if (traveled > e.dist * 0.42) {
          e.encounterDone = true;
          const chance = EXP_ENCOUNTER_BASE + Math.min(0.32, e.dist * 0.007);
          if (this.rand() < chance) {
            this.startBattle('expedition', e.id);
          }
        }
      }
    }
  }

  // ---------- 战斗 ----------
  get squadSize(): number {
    let barracks = 0;
    for (const b of this.buildings.values()) {
      if (b.defId === 'barracks' && b.progress >= 1) barracks++;
    }
    if (barracks === 0) return 0;
    return Math.min(8, 2 + Math.max(0, barracks - 1) * 1.5 | 0);
  }

  upgradeWeapon(): boolean {
    const next = this.weaponTier + 1;
    if (next >= WEAPON_TIERS.length) return false;
    if (!this.hasBuilding('armory')) return false;
    const cost = WEAPON_TIERS[next].cost;
    if (!this.freeBuild && cost && !RES_KEYS.every(k => (cost[k] ?? 0) <= this.res[k])) return false;
    if (!this.freeBuild && cost) RES_KEYS.forEach(k => { this.res[k] -= cost[k] ?? 0; });
    this.weaponTier = next;
    this.notify('battle', '武器升级', `全城战队换装「${WEAPON_TIERS[next].name}」, 攻击 +${WEAPON_TIERS[next].atk}。`, 'good');
    return true;
  }

  upgradeArmor(): boolean {
    const next = this.armorTier + 1;
    if (next >= ARMOR_TIERS.length) return false;
    if (!this.hasBuilding('armory2')) return false;
    const cost = ARMOR_TIERS[next].cost;
    if (!this.freeBuild && cost && !RES_KEYS.every(k => (cost[k] ?? 0) <= this.res[k])) return false;
    if (!this.freeBuild && cost) RES_KEYS.forEach(k => { this.res[k] -= cost[k] ?? 0; });
    this.armorTier = next;
    this.notify('battle', '盔甲升级', `全城战队换装「${ARMOR_TIERS[next].name}」, 防御 +${ARMOR_TIERS[next].def}。`, 'good');
    return true;
  }

  /** 威胁等级: 时代 + 远征距离 */
  private threatFor(era: number, dist = 12): number {
    const distBonus = Math.min(2, Math.max(0, (dist - 10) / 12));
    return Math.max(0, Math.min(5, Math.round(era * 1.1 + distBonus) + DIFFICULTIES[this.difficulty].threat));
  }

  startBattle(context: 'defense' | 'expedition' | 'ruin', expeditionId: number | null = null, dist = 12): boolean {
    if (this.battle) return false;
    const size = this.squadSize;
    if (size <= 0) return false;
    const era = this.era;
    let threat = this.threatFor(era, dist);
    if (context === 'defense') threat = Math.max(0, Math.round(era * 1.0));
    const enemyCount = Math.max(1, Math.min(context === 'defense' ? 4 : 3, 1 + Math.floor(threat / 2) + (this.rand() < 0.3 ? 1 : 0)));
    const exp = expeditionId != null ? this.expeditions.find(e => e.id === expeditionId) : null;
    // v5: 载具 —— 远征随队 / 城防全部就绪载具参战
    const vehicles = exp ? { ...exp.vehicles } : { ...this.readyVehicles };
    const vehicleBldgs: Record<string, number> = {};
    const kinds: ('apc' | 'tank' | 'heli')[] = ['apc', 'tank', 'heli'];
    for (const kind of kinds) {
      const count = vehicles[kind];
      if (count <= 0) continue;
      const owners = [...this.buildings.values()].filter(b =>
        b.progress >= 1 && !b.damaged && (b.vehicleReadyDay ?? 0) <= this.day && this.def(b.defId).vehicle === kind);
      for (let i = 0; i < Math.min(count, owners.length); i++) vehicleBldgs['v_' + kind + '_' + i] = owners[i].id;
    }
    const players = makePlayerSquad(
      { size, weaponTier: this.weaponTier, armorTier: this.armorTier, vehicles }, this.battleRand);
    if (this.research.includes('military_drill')) {
      for (const p of players) { if (!p.uid.startsWith('v_')) { p.maxHp = Math.round(p.maxHp * 1.15); p.hp = p.maxHp; } }
    }
    const enemies = makeEnemySquad(threat, enemyCount, this.battleRand);
    const env = context === 'defense' ? (era >= 3 ? 'city' : era >= 1 ? 'village' : 'wild') : era >= 2 ? 'ruin' : 'wild';
    const title = context === 'defense'
      ? ['野兽袭击了城市!', '野人部落来犯!', '匪帮闯入城区!', '武装歹徒袭击!', '叛军装甲部队来袭!'][Math.min(4, era)]
      : '远征遭遇战!';
    // v5: 开战位置 —— 就在地图上 (远征队处 / 城郊来袭方向)
    let pos: { x: number; y: number };
    if (exp) {
      pos = { x: Math.round(exp.x), y: Math.round(exp.y) };
    } else {
      const cc = this.cityCenter();
      const ang = this.rand() * Math.PI * 2;
      const r = 5 + this.rand() * 3;
      pos = { x: Math.round(cc.x + Math.cos(ang) * r), y: Math.round(cc.y + Math.sin(ang) * r) };
    }
    // 只有探索相关战斗（如远征遭遇）能带来新视野；城市防御战不探索地图。
    if (context !== 'defense') this.terrain.reveal(pos.x, pos.y, 7);
    this.battle = createBattle(this.nextBattleId++, title, env, players, enemies, context, expeditionId, pos, vehicleBldgs);
    this.prevSpeedBeforeBattle = this.speed || 1;
    this.speed = 0;
    this.pendingFx.push({ kind: 'battle' });
    return true;
  }

  battleAction(moveId: string): boolean {
    const b = this.battle;
    if (!b) return false;
    if ((b.phase as string) !== 'select' || !b.activeUid) return false;
    const u = b.units.find(x => x.uid === b.activeUid);
    if (!u || u.side !== 'player') return false;
    b.floatTexts.length = 0;
    const ok = performMove(b, b.activeUid!, moveId, this.battleRand);
    if (ok && (b.phase as string) !== 'over') {
      this.battleAnimTimer = 0.72;
    }
    return ok;
  }

  battleFlee(): boolean {
    const b = this.battle;
    if (!b) return false;
    if ((b.phase as string) === 'over') return false;
    b.floatTexts.length = 0;
    fleeBattle(b, this.battleRand);
    return true;
  }

  private updateBattle(dtSec: number) {
    const b = this.battle;
    if (!b) return;
    const phase = b.phase as string;
    if (phase === 'over' || phase === 'select') return; // 等待玩家
    this.battleAnimTimer -= dtSec;
    if (this.battleAnimTimer > 0) return;
    this.battleAnimTimer = 0.72;
    if (b.activeUid) {
      const u = b.units.find(x => x.uid === b.activeUid);
      if (u && u.side === 'enemy' && u.alive) {
        const mv = enemyChooseMove(b, b.activeUid, this.battleRand);
        b.floatTexts.length = 0;
        performMove(b, b.activeUid, mv, this.battleRand);
      }
    }
  }

  private finishBattle() {
    const b = this.battle;
    if (!b) return;
    const exp = b.expeditionId != null ? this.expeditions.find(e => e.id === b.expeditionId) : null;
    if (b.result === 'win') {
      this.battleWins++;
      const exp2 = exp;
      const threat = this.threatFor(this.era, exp2 ? exp2.dist : 12);
      const rewards = b.rewards ?? battleRewards(threat, b.units.filter(u => u.side === 'enemy').length, this.era, this.battleRand);
      b.rewards = rewards;
      for (const k of RES_KEYS) if (rewards[k]) this.addRes(k, rewards[k]!);
      if (exp) for (const k of RES_KEYS) if (rewards[k]) exp.loot[k] = (exp.loot[k] ?? 0) + rewards[k]!;
      this.happiness = Math.min(100, this.happiness + (b.context === 'defense' ? 6 : 3));
      this.order = Math.min(100, this.order + 4);
      this.notify('battle', '战斗胜利!', `小队击退了敌人${b.casualties > 0 ? `, 但有 ${b.casualties} 名队员牺牲` : ''}。战利品已入账。`, 'good');
    } else if (b.result === 'lose') {
      this.battleLosses++;
      b.rewards = null;
      this.happiness = Math.max(0, this.happiness - 10);
      this.notify('battle', '战败……', '小队全军覆没, 城中人心惶惶。', 'bad');
      if (b.context === 'defense') {
        // 城市被劫掠
        const lostFood = Math.min(this.res.food * 0.25, 60);
        const lostMoney = Math.min(this.res.money * 0.15, 150);
        this.res.food -= lostFood; this.res.money = Math.max(0, this.res.money - lostMoney);
        this.notify('battle', '城市遭劫', `损失 ${Math.round(lostFood)} 食物与 ${Math.round(lostMoney)} 资金。`, 'bad');
      }
      if (exp) exp.state = 'returning';
    } else {
      // flee
      if (exp) exp.state = 'returning';
    }
    // 阵亡转化为人口损失
    if (b.casualties > 0) {
      this.pop = Math.max(0, this.pop - b.casualties);
      if (exp) exp.members = Math.max(0, exp.members - b.casualties);
      if (this.pop < 1) { this.pop = 0; this.endGame(false, '最后一位居民倒下了。城市的故事到此为止。'); }
    }
    // v5: 战损载具 → 车库重建 (3 日)
    for (const u of b.units) {
      if (u.side === 'player' && !u.alive && u.uid.startsWith('v_')) {
        const bldgId = b.vehicleBldgs[u.uid];
        const bldg = bldgId != null ? this.buildings.get(bldgId) : null;
        if (bldg) {
          bldg.vehicleReadyDay = this.day + 3;
          this.notify('battle', `${u.name} 被击毁`, `${this.def(bldg.defId).name} 开始重建载具 (预计第 ${this.day + 3} 日就绪)。`, 'bad');
        }
      }
    }
    this.battle = null;
    this.speed = this.prevSpeedBeforeBattle;
    this.pendingFx.push({ kind: 'battle' });
  }

  // ---------- 资源 ----------
  get cap(): Record<ResourceKey, number> {
    const cap = { ...BASE_CAP };
    RES_KEYS.forEach(k => { cap[k] += this.devCapBoost[k] ?? 0; });
    for (const b of this.buildings.values()) {
      if (b.progress < 1) continue;
      const s = this.def(b.defId).storage;
      if (s) RES_KEYS.forEach(k => { cap[k] += (s[k] ?? 0) * (b.damaged ? 0.4 : 1); });
    }
    return cap;
  }

  addRes(k: ResourceKey, v: number) {
    this.res[k] = Math.min(this.cap[k], this.res[k] + v);
  }

  get popCap(): number {
    let c = 0;
    for (const b of this.buildings.values()) {
      if (b.progress < 1) continue;
      const h = this.def(b.defId).housing;
      if (h) c += h * (b.damaged ? 0.5 : 1);
    }
    return Math.floor(c);
  }

  // ---------- 劳动参与率 (学校加成) ----------
  get workRatio(): number {
    let schools = 0;
    for (const b of this.buildings.values()) if (b.defId === 'school' && b.progress >= 1) schools++;
    return Math.min(0.74, WORK_RATIO + Math.min(0.08, schools * 0.025));
  }

  /** 可用劳动力 (扣除远征队员) */
  get availableWorkers(): number {
    let away = 0;
    for (const e of this.expeditions) away += e.members;
    return Math.max(0, Math.floor(this.pop * this.workRatio) - away);
  }

  // ---------- 主循环 ----------
  update(dtSec: number) {
    if (this.gameOver) return;
    // 战斗期间: 世界暂停, 只有战斗计时 (结算由 UI 确认)
    if (this.battle) {
      if ((this.battle.phase as string) !== 'over') {
        this.updateBattle(dtSec);
      } else if (this.battle.result === 'win' && this.battle.rewards === null) {
        // 胜利瞬间就算出战利品 —— 结算画面立即可展示奖励明细
        const bt = this.battle;
        const exp = bt.expeditionId != null ? this.expeditions.find(e => e.id === bt.expeditionId) : null;
        const threat = this.threatFor(this.era, exp ? exp.dist : 12);
        bt.rewards = battleRewards(threat, bt.units.filter(u => u.side === 'enemy').length, this.era, this.battleRand);
      }
      return;
    }
    if (this.speed === 0) return;
    const dtHours = (dtSec / HOUR_SEC) * this.speed;
    const dtDays = dtHours / DAY_HOURS;
    const prevHour = Math.floor(this.hour);
    this.hour += dtHours;
    while (this.hour >= DAY_HOURS) { this.hour -= DAY_HOURS; this.day++; this.dailyUpdate(); }
    if (Math.floor(this.hour) !== prevHour) this.hourlyUpdate();
    this.continuousUpdate(dtDays, dtSec);
    this.updateExpeditions(dtSec * this.speed);
    this.autoSaveTimer += dtSec;
    if (this.autoSaveTimer > 45) { this.autoSaveTimer = 0; this.save(); }
    this.slowTimer += dtSec;
    if (this.slowTimer > 1.2) { this.slowTimer = 0; this.slowTick(false); }
  }

  /** UI 结算确认 */
  confirmBattleEnd() {
    if (this.battle && this.battle.phase === 'over') this.finishBattle();
  }

  // 每帧: 连续生产/消耗
  private continuousUpdate(dtDays: number, dtSec: number) {
    if (dtDays <= 0) return;
    this.enforceWorkerCap();
    const powerRatio = this.powerDemand > 0 ? Math.min(1, this.powerSupply / this.powerDemand) : 1;
    // 供水: 蓄水池缓冲垫付
    let waterRatio = 1;
    if (this.waterDemand > this.waterSupply) {
      const deficit = (this.waterDemand - this.waterSupply) * dtDays * 6;
      if (this.waterBuffer >= deficit) {
        this.waterBuffer -= deficit;
      } else {
        this.waterBuffer = 0;
        waterRatio = this.waterDemand > 0 ? this.waterSupply / this.waterDemand : 1;
      }
    } else if (this.waterBufferCap > 0 && this.waterSupply > this.waterDemand) {
      this.waterBuffer = Math.min(this.waterBufferCap, this.waterBuffer + (this.waterSupply - this.waterDemand) * dtDays * 10);
    }
    const stats = emptyStats();

    // 施工推进
    for (const b of this.buildings.values()) {
      if (b.progress >= 1) continue;
      const def = this.def(b.defId);
      b.progress = Math.min(1, b.progress + dtDays / this.buildDaysOf(def));
      if (b.progress >= 1) {
        b.builtDay = this.day;
        this.pendingFx.push({ kind: 'complete', buildingId: b.id });
        if (def.size >= 2 || this.buildDaysOf(def) >= 0.9) {
          this.notify('info', `${def.name} 建成`, def.size >= 3 ? '宏伟的建筑落成了! 城市天际线再次改变。' : '建筑顺利竣工, 开始投入使用。', 'good');
        }
      }
    }

    for (const b of this.buildings.values()) {
      if (b.progress < 1) { b.efficiency = 0; continue; }
      const def = this.def(b.defId);
      if ((b.strike ?? 0) > 0) { b.efficiency = 0; continue; } // 罢工停产
      const eff = this.buildingEfficiency(b, powerRatio, waterRatio);
      b.efficiency = eff;
      if (def.produce) {
        let inputOk = true;
        if (def.consume) {
          for (const k of RES_KEYS) {
            const c = def.consume[k];
            if (!c) continue;
            if (this.res[k] < c * dtDays) { inputOk = false; break; }
          }
        }
        if (inputOk) {
          if (def.consume) {
            for (const k of RES_KEYS) {
              const c = def.consume[k];
              if (!c) continue;
              this.res[k] = Math.max(0, this.res[k] - c * eff * dtDays);
              stats[k].consume += c * eff;
            }
          }
          for (const k of RES_KEYS) {
            const p = def.produce[k];
            if (!p) continue;
            let v = p * eff * dtDays;
            if (k === 'food' && this.stormDays > 0 && (def.id === 'farm' || def.id === 'berry' || def.id === 'pasture')) v *= 0.45;
            this.addRes(k, v);
            stats[k].produce += p * eff;
          }
        }
      }
      if (def.upkeep) { this.res.money = Math.max(0, this.res.money - def.upkeep * eff * dtDays); stats.money.consume += def.upkeep * eff; }
    }

    // 人口消耗与税收 (食耗受难度影响) —— v5: 饥荒大幅加重 (9%/日)
    const foodNeed = this.pop * FOOD_PER_POP * DIFFICULTIES[this.difficulty].food;
    const foodEmpty = this.res.food <= 0.001;
    const foodTrade = this.tradeStep(stats, dtDays);
    if (this.res.food > 0) {
      const eaten = Math.min(this.res.food, foodNeed * dtDays);
      this.res.food -= eaten;
      stats.food.consume += foodNeed;
    } else if (foodEmpty && !foodTrade) {
      // 贸易也救不回来时才饥荒 (v5: 每日损失 9% 人口)
      this.pop = Math.max(0, this.pop - this.pop * 0.09 * dtDays - 0.02 * dtDays);
      if (this.day * 24 + this.hour - this.shortageNotified.food > 8) {
        this.shortageNotified.food = this.day * 24 + this.hour;
        this.notify('plague', '🌾 饥荒蔓延!', `粮仓已空, 居民每天饿死约 ${Math.max(1, Math.floor(this.pop * 0.09))} 人! 立即进口粮食、建农场或派人采集 —— 饥荒正在摧毁你的城市。`, 'bad');
      }
      if (this.pop < 1) { this.pop = 0; this.endGame(false, '最后一位居民也在饥荒中倒下了。下一次, 请优先保证食物供给。'); }
    }
    // v5: 缺水 —— 人口损失 (脱水中暑) 4%/日
    if (this.waterDemand > this.waterSupply && this.waterBuffer <= 0 && this.era >= 1) {
      const thirsty = this.pop * 0.04 * dtDays;
      this.pop = Math.max(0, this.pop - thirsty);
      if (this.day * 24 + this.hour - this.shortageNotified.water > 8) {
        this.shortageNotified.water = this.day * 24 + this.hour;
        this.notify('plague', '💧 城市断水!', `供水缺口 ${Math.round(this.waterDemand - this.waterSupply)}, 居民在干渴中倒下 (约 ${Math.max(1, Math.floor(this.pop * 0.04))} 人/日), 卫生状况恶化。多建水井/水塔或铺通水管!`, 'bad');
      }
      if (this.pop < 1) { this.pop = 0; this.endGame(false, '没有水, 就没有城市。'); }
    }
    // v5: 缺电 —— 现代城市症痪性损失 (设备烧毁 + 资金损失)
    if (this.powerDemand > this.powerSupply && this.era >= 3) {
      const gap = this.powerDemand - this.powerSupply;
      const spoil = Math.min(30, gap * 1.6) * dtDays;
      this.res.money = Math.max(0, this.res.money - spoil);
      stats.money.consume += Math.min(30, gap * 1.6);
      if (this.day * 24 + this.hour - this.shortageNotified.power > 8) {
        this.shortageNotified.power = this.day * 24 + this.hour;
        this.notify('accident', '⚡ 电力缺口!', `供电缺口 ${gap} —— 现代建筑大面积停转, 冷链与生产线每日报废大量货物。尽快增建电厂!`, 'bad');
      }
    }
    // 税收: 税率政策 × 秩序 × 地价 (城市越宜居税基越雄厚)
    const taxMult = this.taxPolicy === 0 ? 0.7 : this.taxPolicy === 2 ? 1.32 : 1;
    const lvMult = 0.85 + (this.avgLandValue / 100) * 0.4;
    const tax = this.pop * TAX_PER_POP * taxMult * lvMult * (1 + this.era * 0.22) * Math.min(1.25, Math.max(0.4, this.order / 65));
    this.addRes('money', tax * dtDays);
    stats.money.produce += tax;
    // 市政预算额外开支
    if (this.budgetCost > 0) {
      this.res.money = Math.max(0, this.res.money - this.budgetCost * dtDays);
      stats.money.consume += this.budgetCost;
    }

    // ---- 市政独立机制: 银行 ----
    const bankCount = this.countBuilt('bank');
    if (bankCount > 0) {
      // 存款利息
      if (this.res.money > 400) {
        const interest = Math.min(45 * bankCount, this.res.money * 0.003);
        this.addRes('money', interest * dtDays);
        stats.money.produce += interest;
      }
      // 贷款日息
      if (this.loan > 0) {
        const interest = this.loan * 0.008;
        this.res.money = Math.max(0, this.res.money - interest * dtDays);
        stats.money.consume += interest;
      }
    } else if (this.loan > 0) {
      // 无银行时利息更高
      const interest = this.loan * 0.012;
      this.res.money = Math.max(0, this.res.money - interest * dtDays);
    }
    // ---- 图书馆: 典籍 ----
    const libCount = this.countBuilt('library');
    if (libCount > 0) {
      this.scrolls = Math.min(30, this.scrolls + 0.4 * libCount * dtDays);
    }
    // ---- 体育场: 比赛日 ----
    if (this.hasBuilding('stadium') && this.day % 4 === 0 && this.hour > 12 && this.hour < 13 && !this.stadiumDayDone) {
      this.stadiumDayDone = true;
      this.happiness = Math.min(100, this.happiness + 8);
      const gate = Math.round(this.pop * 1.2 + 60);
      this.addRes('money', gate);
      this.notify('festival', '比赛日!', `体育场座无虚席, 全城幸福 +8, 门票收入 +${gate} 资金。`, 'good');
    }
    if (this.hour >= 13) this.stadiumDayDone = false;

    // ---- 生育机制 ----
    const cap = this.popCap;
    let hospitals = 0, schools = 0;
    for (const b of this.buildings.values()) {
      if (b.progress < 1) continue;
      if (b.defId === 'hospital') hospitals++;
      else if (b.defId === 'school') schools++;
    }
    if (this.res.food > 20 && this.happiness > 55 && this.pop < cap && this.pop >= 6) {
      this.birthRate = this.pop * (0.006 + hospitals * 0.0015 + schools * 0.0005);
      this.birthAcc += this.birthRate * dtDays;
      if (this.birthAcc >= 1) {
        this.birthAcc -= 1;
        this.pop += 1;
        this.notify('birth', '新生命诞生', '一个婴儿在祝福声中降生, 人口 +1。', 'good');
      }
    } else {
      this.birthRate = 0;
    }
    // ---- 移民吸引力 (幸福度越高人来得越多; 地价加成) ----
    const broadcast = this.hasBuilding('broadcast') ? 1.6 : 1;
    this.attraction = Math.max(0, (this.happiness - 52) / 11) * broadcast * Math.min(1.15, Math.max(0.3, this.order / 70)) * (0.8 + (this.avgLandValue / 100) * 0.5);
    if (this.attraction > 0 && this.pop < cap && this.res.food > 5) {
      this.immiAcc += this.attraction * dtDays;
      if (this.immiAcc >= 1) {
        this.immiAcc -= 1;
        this.pop += 1;
        this.notify('immigrant', '新居民迁入', '一位旅人被城市的繁荣与灯火吸引, 决定留下。', 'good');
      }
    }
    void dtSec;
    this.stats = stats;
  }

  private stadiumDayDone = false;

  private countBuilt(defId: string): number {
    let n = 0;
    for (const b of this.buildings.values()) if (b.defId === defId && b.progress >= 1) n++;
    return n;
  }

  // ---------- 贸易 (集市: 自动进出口) ----------
  /**
   * 自动贸易 (需集市): 资源见底时加价进口救急, 仓库爆满时折价出口过剩产能。
   * 返回 true 表示本次成功进口了食物 (饥荒判定用)。
   */
  private tradeStep(stats: Record<ResourceKey, ResourceStat>, dtDays: number): boolean {
    // 每日重置记账
    if (this._tradeDay !== this.day) { this._tradeDay = this.day; this.tradeSpent = 0; this.tradeEarned = 0; this.tradeNotified.clear(); }
    if (this.era < 2 || !this.hasBuilding('market')) return false;
    const priceMul = DIFFICULTIES[this.difficulty].trade;
    let foodImported = false;
    for (const k of ['food', 'wood', 'stone', 'metal', 'oil'] as ResourceKey[]) {
      const base = TRADE_PRICES[k] ?? 3;
      const price = base * priceMul;
      // 进口: 见底时买 14/日, 上限花掉可用资金的一半
      if (this.res[k] < 0.5) {
        const budget = Math.max(0, (this.res.money - 20) * 0.5);
        const buy = Math.min(14 * dtDays, budget / price);
        if (buy > 0.001) {
          this.res[k] += buy;
          this.res.money -= buy * price;
          this.tradeSpent += buy * price;
          stats.money.consume += buy * price;
          stats[k].produce += buy / Math.max(dtDays, 1e-9);
          if (k === 'food') foodImported = true;
          if (!this.tradeNotified.has('imp' + k) && buy > 1) {
            this.tradeNotified.add('imp' + k);
            this.notify('caravan', '商队急运', `本地${RES_META[k].name}告罄, 商队加价进口中 (当日已支出 ${Math.round(this.tradeSpent)} 资金)。`, 'info');
          }
        }
      }
      // 出口: 仓库爆满且仍在产出时, 折价倾销
      else if (this.res[k] >= this.cap[k] - 0.5 && stats[k].produce > stats[k].consume + 0.1) {
        const sell = Math.min(12 * dtDays, this.res[k] - this.cap[k] * 0.9);
        if (sell > 0.001) {
          this.res[k] -= sell;
          this.addRes('money', sell * price * 0.6);
          this.tradeEarned += sell * price * 0.6;
          stats.money.produce += sell * price * 0.6;
          if (!this.tradeNotified.has('exp' + k) && sell > 1) {
            this.tradeNotified.add('exp' + k);
            this.notify('caravan', `${RES_META[k].name}出口`, `仓库爆满, 商队折价收购过剩${RES_META[k].name} (当日已换回 ${Math.round(this.tradeEarned)} 资金)。`, 'good');
          }
        }
      }
    }
    return foodImported;
  }
  private _tradeDay = -1;

  /** 市政预算 (0.5~1.5) */
  setBudget(key: string, v: number) {
    if (!(key in this.budgets)) return;
    this.budgets[key] = Math.max(0.5, Math.min(1.5, v));
    this.slowTimer = 99;
  }

  // ---------- 贷款 (银行) ----------
  canBorrow(): boolean { return this.loan === 0 && this.hasBuilding('bank'); }
  borrowLoan(amount: number): boolean {
    if (!this.canBorrow()) return false;
    if (![300, 800, 2000].includes(amount)) return false;
    this.loan = amount;
    this.addRes('money', amount);
    this.notify('info', '贷款到账', `从银行借入 ${amount} 资金, 日息 0.8% (每日利息 ${Math.ceil(amount * 0.008)})。记得按时还款。`, 'info');
    return true;
  }
  repayLoan(): boolean {
    if (this.loan <= 0) return false;
    if (this.res.money < this.loan) return false;
    this.res.money -= this.loan;
    this.notify('info', '贷款结清', '债务清零, 银行经理向你举杯。', 'good');
    this.loan = 0;
    return true;
  }

  // ---------- 人力 (手动分配) ----------
  setWorkers(id: number, n: number): boolean {
    const b = this.buildings.get(id);
    if (!b) return false;
    const def = this.def(b.defId);
    const need = Math.ceil(def.workers * (this.research.includes('automation') ? 0.5 : 1));
    const target = Math.max(0, Math.min(need, Math.floor(n)));
    const others = this.workersEmployed - b.workers;
    const capped = Math.min(target, Math.max(0, this.availableWorkers - others) + b.workers);
    b.workers = capped;
    return true;
  }

  autoAssignLabor() {
    // 一键自动分配 (旧逻辑, 供不想手动的玩家)
    let remaining = this.availableWorkers;
    const cats: string[] = ['food', 'water', 'power', 'resource', 'civic', 'military'];
    for (const b of this.buildings.values()) b.workers = 0;
    for (const cat of cats) {
      const list = [...this.buildings.values()]
        .filter(b => b.progress >= 1 && this.def(b.defId).category === cat)
        .sort((a, c) => a.builtDay - c.builtDay);
      for (const b of list) {
        const need = Math.ceil(this.def(b.defId).workers * (this.research.includes('automation') ? 0.5 : 1));
        const give = Math.min(need, remaining);
        b.workers = give;
        remaining -= give;
        if (remaining <= 0) return;
      }
    }
  }

  /** 人口下降时防止超额用工 */
  private enforceWorkerCap() {
    let over = this.workersEmployed - this.availableWorkers;
    if (over <= 0) return;
    const list = [...this.buildings.values()].filter(b => b.workers > 0).sort((a, b) => b.workers - a.workers);
    for (const b of list) {
      if (over <= 0) break;
      const take = Math.min(b.workers, over);
      b.workers -= take;
      over -= take;
    }
  }

  get workersEmployed(): number {
    let n = 0;
    for (const b of this.buildings.values()) n += b.workers;
    return n;
  }

  // ---------- 水电 (自动接线网络) ----------
  private computeUtilities() {
    let ps = 0, pd = 0, ws = 0, wd = 0;
    for (const b of this.buildings.values()) {
      if (b.progress < 1) continue;
      const def = this.def(b.defId);
      if (def.powerOut) {
        let out = def.powerOut * (def.workers > 0 ? Math.min(1, b.workers / def.workers) : 1);
        if (this.research.includes('grid')) out *= 1.25;
        ps += out * (b.damaged ? 0.5 : 1);
      }
      if (def.powerNeed) pd += def.powerNeed;
      if (def.waterOut) {
        let out = def.waterOut * (def.workers > 0 ? Math.min(1, b.workers / def.workers) : 1) * (b.damaged ? 0.5 : 1);
        // 水质: 污染源附近的水源出水下降
        let polluters = 0;
        for (const o of this.buildings.values()) {
          if (o.progress < 1 || o.id === b.id) continue;
          const od = this.def(o.defId);
          if ((od.effects?.pollution ?? 0) >= 4 && chebyshev(o, b) <= 6) polluters++;
        }
        if (polluters > 0) out *= Math.max(0.4, 1 - polluters * 0.15);
        ws += out;
      }
      if (def.waterNeed) wd += def.waterNeed;
    }
    this.powerSupply = Math.round(ps); this.powerDemand = Math.round(pd);
    this.waterSupply = Math.round(ws); this.waterDemand = Math.round(wd);
    // 蓄水池容量
    this.waterBufferCap = 0;
    for (const b of this.buildings.values()) {
      if (b.defId === 'reservoir' && b.progress >= 1) this.waterBufferCap += 40 * (b.damaged ? 0.5 : 1);
    }
    this.waterBuffer = Math.min(this.waterBuffer, this.waterBufferCap);
  }

  isBuildingPowered(id: number): boolean {
    return this.pipePowered.has(id);
  }

  // ---------- 慢速缓存 ----------
  private slowTick(initial: boolean) {
    const arr = [...this.buildings.values()].filter(b => b.progress >= 1);
    // 0. 预算维护成本 (相对基准的额外开支)
    this.budgetCost = 0;
    const deptOf: Record<string, string> = {
      fire_station: 'fire', police: 'police', hospital: 'health', school: 'edu', library: 'edu',
    };
    for (const b of arr) {
      const dept = deptOf[b.defId];
      if (!dept) continue;
      this.budgetCost += (this.budgets[dept] - 1) * 6 * (1 + this.era * 0.8);
    }
    this.budgetCost += (this.budgets.road - 1) * Math.max(0, this.roadCount()) * 0.35;
    // 1. 教育网格 (受教育预算影响)
    this.eduGrid.clear();
    for (const src of arr) {
      const d = this.def(src.defId);
      const edu = d.effects?.education;
      if (!edu || !d.radius) continue;
      stampRadius(this.eduGrid, src.x, src.y, src.size, d.radius, edu * this.budgets.edu, Math.max);
    }
    // 2. 覆盖集合 (半径受对应部门预算影响)
    this.coveredFire.clear(); this.coveredPolice.clear(); this.coveredHealth.clear();
    for (const src of arr) {
      const d = this.def(src.defId);
      const fr = d.effects?.fireCover ? d.effects.fireCover * this.budgets.fire : 0;
      const pr = d.effects?.policeCover ? d.effects.policeCover * this.budgets.police : 0;
      const hr = d.effects?.healthCover ? d.effects.healthCover * this.budgets.health : 0;
      if (!fr && !pr && !hr) continue;
      for (const t of arr) {
        if (t.id === src.id) continue;
        const dd = chebyshev(src, t);
        if (fr && dd <= fr) this.coveredFire.add(t.id);
        if (pr && dd <= pr) this.coveredPolice.add(t.id);
        const hrr = hr ? (this.research.includes('medicine') ? hr * 1.6 : hr) : 0;
        if (hr && dd <= hrr) this.coveredHealth.add(t.id);
      }
    }
    // 3. 网络 (手动接线)
    this.computePipeNetworks(arr);
    // 4. 水电
    this.computeUtilities();
    // 4.5 地价
    this.computeLandValue(arr);
    // 5. 心情
    this.computeMood();
    // 5.5 警报
    this.computeAlerts();
    // 6. 数据视图
    if (this.viewMode !== 'none' || initial) this.computeOverlay();
  }

  /** 道路总数 */
  private roadCount(): number {
    let n = 0;
    for (const b of this.buildings.values()) if (this.def(b.defId).road) n++;
    return n;
  }

  /** 岗位总数 */
  get jobsTotal(): number {
    let n = 0;
    for (const b of this.buildings.values()) {
      if (b.progress < 1) continue;
      n += Math.ceil(this.def(b.defId).workers * (this.research.includes('automation') ? 0.5 : 1));
    }
    return n;
  }

  /** 地价 (0-100): 市政服务/教育/照明/水电拉动, 污染噪音拉低 */
  private computeLandValue(arr: Building[]) {
    this.landValues.clear();
    const housings = arr.filter(b => this.def(b.defId).housing);
    if (housings.length === 0) { this.avgLandValue = 0; return; }
    let sum = 0;
    for (const h of housings) {
      let lv = 30;
      if (this.coveredFire.has(h.id)) lv += 7;
      if (this.coveredPolice.has(h.id)) lv += 7;
      if (this.coveredHealth.has(h.id)) lv += 8;
      const edu = this.eduGrid.get(WorldT.key(h.x, h.y)) ?? 0;
      lv += Math.min(14, edu * 90);
      lv += Math.min(8, (this.landValuesSparkle(h, arr)));
      if (this.era >= 3) {
        lv += this.pipePowered.has(h.id) ? 6 : -10;
        lv += this.pipeWatered.has(h.id) ? 5 : -8;
      }
      // 环境暴露
      let poll = 0, noise = 0;
      for (const other of arr) {
        const d = this.def(other.defId);
        if (!d.effects || !d.radius) continue;
        if (chebyshev(h, other) > d.radius + 1) continue;
        poll += d.effects.pollution ?? 0;
        noise += d.effects.noise ?? 0;
      }
      if (this.research.includes('ecology')) poll *= 0.4;
      lv -= Math.min(22, poll * 1.4 + noise * 0.9);
      lv = Math.max(0, Math.min(100, Math.round(lv)));
      this.landValues.set(h.id, lv);
      sum += lv;
    }
    this.avgLandValue = Math.round(sum / housings.length);
  }

  /** 住房附近的公园/教堂/广场等魅力设施贡献 */
  private landValuesSparkle(h: Building, arr: Building[]): number {
    let charm = 0;
    for (const other of arr) {
      if (other.id === h.id) continue;
      const d = this.def(other.defId);
      if (!d.effects?.happiness || !d.radius) continue;
      if (chebyshev(h, other) <= d.radius + 1) charm += d.effects.happiness * 0.6;
    }
    return charm;
  }

  private computeAlerts() {
    const powerRatio = this.powerDemand > 0 ? this.powerSupply / this.powerDemand : 1;
    const waterRatio = this.waterDemand > 0 ? this.waterSupply / this.waterDemand : 1;
    const all = [...this.buildings.values()];
    for (const b of all) {
      if (b.progress < 1) { b.alerts = []; continue; }
      const def = this.def(b.defId);
      const a: string[] = [];
      if (b.fire > 0) a.push('火灾中! 急需消防局');
      if (b.damaged) a.push('建筑受损 效率-50%');
      if ((b.strike ?? 0) > 0) a.push(`工人罢工中 剩${b.strike}天`);
      if (def.powerNeed) {
        if (powerRatio < 0.985) a.push('供电不足 城市缺电');
        else if (!this.pipePowered.has(b.id)) a.push('未接入电网 (需电厂9格内或铺电缆牵引)');
        else {
          const v = this.buildingVolt.get(b.id) ?? 100;
          if (v < 92) a.push(`电压偏低 ${v}% (建变电站升压)`);
        }
      }
      if (def.waterNeed) {
        if (waterRatio < 0.985 && this.waterBuffer <= 0) a.push('供水不足 城市缺水');
        else if (!this.pipeWatered.has(b.id)) a.push('未接入水网 (需水厂7格内或铺水管)');
        else {
          const p = this.buildingPress.get(b.id) ?? 100;
          if (p < 92) a.push(`水压偏低 ${p}% (建泵站增压)`);
        }
      }
      const need = Math.ceil(def.workers * (this.research.includes('automation') ? 0.5 : 1));
      if (need > 0 && b.workers < need) a.push(`缺少工人 ${b.workers}/${need} (在人力面板分配)`);
      if (def.consume) {
        for (const k of RES_KEYS) {
          const c = def.consume[k];
          if (c && this.res[k] < c * 0.5) { a.push(`原料不足 (${RES_META[k].name})`); break; }
        }
      }
      if (def.roadBonus && def.roadBonus > 0 && this.adjacentRoadBonus(b) === 0) a.push('未邻路 无道路加成');
      if (def.waterOut) {
        let polluters = 0;
        for (const o of all) {
          if (o.progress < 1 || o.id === b.id) continue;
          const od = this.def(o.defId);
          if ((od.effects?.pollution ?? 0) >= 4 && chebyshev(o, b) <= 6) polluters++;
        }
        if (polluters > 0) a.push('水源被污染 出水下降');
      }
      if (def.housing) {
        let noise = 0, poll = 0;
        for (const other of all) {
          if (other.id === b.id || other.progress < 1) continue;
          const d = this.def(other.defId);
          if (!d.effects || !d.radius) continue;
          if (chebyshev(b, other) > d.radius + 1) continue;
          let nz = d.effects.noise ?? 0;
          let po = d.effects.pollution ?? 0;
          if (this.research.includes('ecology')) po *= 0.4;
          noise += nz; poll += po;
        }
        if (noise >= 3) a.push('噪音太大 居民不堪其扰');
        if (poll >= 3) a.push('污染严重 影响健康');
        if (this.era >= 1) {
          const lit = all.some(o => {
            if (o.id === b.id || o.progress < 1) return false;
            const dd = this.def(o.defId);
            return !!dd.light && (!dd.powerNeed || this.isBuildingPowered(o.id)) && chebyshev(b, o) <= dd.light + 1;
          });
          if (!lit) a.push('夜间无照明 安全感低');
        }
      }
      b.alerts = a;
    }
  }

  /** v5 SC4 式地下管网: 电缆/水管埋地下 (无模型), 资源自源点沿最短路径流向建筑接口;
   *  干线有容量, 一条线接太多建筑会过载 → 短路/爆管; 变电站/泵站升压增压并扩容。 */
  private computePipeNetworks(arr: Building[]) {
    this.pipePowered.clear(); this.pipeWatered.clear();
    this.pipePowerTotal = 0; this.pipeWaterTotal = 0;
    this.utilEdges = [];
    this.buildingVolt.clear(); this.buildingPress.clear();
    this.gridWarnings.power = 0; this.gridWarnings.water = 0;
    if (arr.length > 0) {
      this.buildUtilNet('power', arr);
      this.buildUtilNet('water', arr);
    }
    // 网络变化 → 渲染器重画视图线 (含增压设施数, 保证放置变电站/泵站后立即刷新)
    let boostN = 0, wireN = 0;
    for (const b of arr) {
      const d = this.def(b.defId);
      if (d.booster) boostN++;
      if (d.pipe) wireN++;
    }
    const hash = this.utilEdges.length + '|' + this.pipePowered.size + '|' + this.pipeWatered.size
      + '|' + this.blackouts.length + '|' + boostN + '|' + wireN;
    if (hash !== this.lastNetworkHash) {
      this.lastNetworkHash = hash;
      this.networkVersion++;
      this.pendingFx.push({ kind: 'network' });
    }
  }

  private get nowHour(): number { return this.day * 24 + this.hour; }

  /** 单一市政网络 (power 或 water) 的最短路径路由 */
  private buildUtilNet(u: 'power' | 'water', arr: Building[]) {
    const isPower = u === 'power';
    const served = isPower ? this.pipePowered : this.pipeWatered;
    const voltMap = isPower ? this.buildingVolt : this.buildingPress;
    const sources: Building[] = [], consumers: Building[] = [], wires: Building[] = [], boosters: Building[] = [];
    for (const b of arr) {
      const d = this.def(b.defId);
      if (isPower ? d.powerOut : d.waterOut) sources.push(b);
      if (isPower ? d.powerNeed : d.waterNeed) {
        consumers.push(b);
        if (isPower) this.pipePowerTotal++; else this.pipeWaterTotal++;
      }
      if (d.pipe === u || d.pipe === 'both') wires.push(b);
      if (d.booster === (isPower ? 'transformer' : 'pump')) boosters.push(b);
    }
    if (sources.length === 0) return;

    const srcRange = (isPower ? 9 : 7) + (isPower && this.research.includes('grid') ? 2 : 0);
    const nowH = this.nowHour;
    // 抢修中的干线 (短路/爆管): 从图中剔除
    const deadWire = new Set<number>();
    for (let i = this.blackouts.length - 1; i >= 0; i--) {
      const bi = this.blackouts[i];
      if (bi.utility !== u) continue;
      if (bi.endHour <= nowH) this.blackouts.splice(i, 1);
      else deadWire.add(WorldT.key(bi.x, bi.y));
    }

    // ---- 节点: 建筑 = 接口(入口)/输出口/变电站 ----
    interface UNode { b: Building; x: number; y: number; isSource: boolean; isWire: boolean; isBoost: boolean; range: number }
    const srcNodes: UNode[] = [], wireNodes: UNode[] = [], consNodes: UNode[] = [], boostNodes: UNode[] = [];
    const mk = (b: Building, kind: 'src' | 'wire' | 'cons' | 'boost'): UNode => {
      const d = this.def(b.defId);
      const n: UNode = {
        b, x: b.x + (b.size - 1) / 2, y: b.y + (b.size - 1) / 2,
        isSource: kind === 'src', isWire: kind === 'wire', isBoost: kind === 'boost',
        range: kind === 'src' ? srcRange : kind === 'wire' ? (d.wireRange ?? 6) : 99,
      };
      return n;
    };
    for (const b of sources) srcNodes.push(mk(b, 'src'));
    for (const b of wires) {
      if (deadWire.has(WorldT.key(b.x, b.y))) continue;
      wireNodes.push(mk(b, 'wire'));
    }
    for (const b of consumers) consNodes.push(mk(b, 'cons'));
    for (const b of boosters) boostNodes.push(mk(b, 'boost'));
    const allNodes = [...srcNodes, ...wireNodes, ...consNodes, ...boostNodes];
    if (allNodes.length === 0) return;

    // ---- 空间分桶 (近邻检索) ----
    const CELL = 10;
    const buckets = new Map<number, UNode[]>();
    const bkey = (cx: number, cy: number) => (cx + 4096) * 16384 + (cy + 4096);
    for (const n of allNodes) {
      const k = bkey(Math.floor(n.x / CELL), Math.floor(n.y / CELL));
      let list = buckets.get(k);
      if (!list) { list = []; buckets.set(k, list); }
      list.push(n);
    }
    const neighborCache = new Map<UNode, { m: UNode; w: number }[]>();
    const neighborsOf = (n: UNode): { m: UNode; w: number }[] => {
      const cached = neighborCache.get(n);
      if (cached) return cached;
      const out: { m: UNode; w: number }[] = [];
      const cx = Math.floor(n.x / CELL), cy = Math.floor(n.y / CELL);
      for (let dy = -1; dy <= 1; dy++)
        for (let dx = -1; dx <= 1; dx++) {
          const list = buckets.get(bkey(cx + dx, cy + dy));
          if (!list) continue;
          for (const m of list) {
            if (m === n) continue;
            // 连接规则: 源↔任意(srcRange) / 线↔线 / 线↔接口 (线距); 接口之间不互通
            if (!n.isWire && !m.isWire && !(n.isSource || m.isSource)) continue;
            const d = Math.hypot(n.x - m.x, n.y - m.y);
            const rng = (n.isSource || m.isSource)
              ? Math.max(srcRange, Math.min(n.isWire ? n.range : 99, m.isWire ? m.range : 99))
              : Math.min(n.isWire ? n.range : 99, m.isWire ? m.range : 99);
            if (d <= rng + 0.001) out.push({ m, w: Math.max(0.4, d) });
          }
        }
      neighborCache.set(n, out);
      return out;
    };

    // ---- Dijkstra: 多源 + 变电站/泵站重置电压/水压 ----
    const INF = 1e9;
    const dist = new Map<UNode, number>();
    const parent = new Map<UNode, UNode | null>();
    const heap: { d: number; n: UNode }[] = [];
    const hpush = (d: number, n: UNode) => {
      heap.push({ d, n });
      let i = heap.length - 1;
      while (i > 0) { const p = (i - 1) >> 1; if (heap[p].d <= heap[i].d) break; [heap[p], heap[i]] = [heap[i], heap[p]]; i = p; }
    };
    const hpop = () => {
      const top = heap[0];
      const last = heap.pop()!;
      if (heap.length > 0) {
        heap[0] = last;
        let i = 0;
        for (;;) {
          const l = i * 2 + 1, r = l + 1;
          let s = i;
          if (l < heap.length && heap[l].d < heap[s].d) s = l;
          if (r < heap.length && heap[r].d < heap[s].d) s = r;
          if (s === i) break;
          [heap[s], heap[i]] = [heap[i], heap[s]];
          i = s;
        }
      }
      return top;
    };
    for (const s of srcNodes) { dist.set(s, 0); parent.set(s, null); hpush(0, s); }
    const resetDone = new Set<UNode>();
    while (heap.length > 0) {
      const { d, n } = hpop();
      if ((dist.get(n) ?? INF) < d - 1e-9) continue;
      if (n.isBoost && !resetDone.has(n)) {
        resetDone.add(n);
        hpush(0, n);   // 升压/增压: 以此为零点重新辐射
        continue;
      }
      for (const { m, w } of neighborsOf(n)) {
        // 关键: 源/增压点是根节点, 永不作为路径中转 (否则 parent 链可能成环 → 回溯死循环)
        if (m.isSource || m.isBoost) continue;
        // 接口(消费者)不反向传导 —— 资源不会流经建筑接口再折回干线
        if (!n.isWire && !n.isSource && !n.isBoost) continue;
        const nd = d + w;
        if (nd < (dist.get(m) ?? INF) - 1e-9) { dist.set(m, nd); parent.set(m, n); hpush(nd, m); }
      }
    }

    // ---- 接入判定 + 电压/水压 (免费 12 格, 之后每格 -3.2%) ----
    const FREE = 12, DROP = 3.2;
    for (const s of srcNodes) voltMap.set(s.b.id, 100);
    for (const bo of boostNodes) {
      if ((dist.get(bo) ?? INF) < INF) voltMap.set(bo.b.id, 100);
    }
    for (const c of consNodes) {
      const d = dist.get(c);
      if (d == null || d >= INF) continue;
      served.add(c.b.id);
      voltMap.set(c.b.id, Math.max(25, Math.round(100 - Math.max(0, d - FREE) * DROP)));
    }

    // ---- 提取连线 (沿最短路径) 并累计干线负载 ----
    // 增压点连通判定: 邻接任一可达节点(干线/源)即视为接入 (它们自身不参与松弛)
    const connectedBoosters = boostNodes.filter(bo =>
      neighborsOf(bo).some(({ m }) => (dist.get(m) ?? INF) < INF));
    const edgeMap = new Map<number, UtiliEdge>();
    const capOfWire = (n: UNode) => this.def(n.b.defId).wireCap ?? 24;
    for (const c of consNodes) {
      if (!served.has(c.b.id)) continue;
      const need = (isPower ? this.def(c.b.defId).powerNeed : this.def(c.b.defId).waterNeed) ?? 0;
      let cur: UNode | undefined = c;
      let par = parent.get(cur) ?? null;
      while (cur && par) {
        const a = par, b2 = cur;
        const hasWire = a.isWire || b2.isWire;
        const key = Math.min(a.b.id, b2.b.id) * 100000 + Math.max(a.b.id, b2.b.id);
        let e = edgeMap.get(key);
        if (!e) {
          let cap = Infinity;
          if (a.isWire && b2.isWire) cap = Math.min(capOfWire(a), capOfWire(b2));
          else if (a.isWire) cap = capOfWire(a);
          else if (b2.isWire) cap = capOfWire(b2);
          e = {
            aId: a.b.id, bId: b2.b.id,
            ax: a.x, ay: a.y, bx: b2.x, by: b2.y,
            load: 0, cap, kind: hasWire ? 'trunk' : 'drop',
            boosted: false, dead: false, utility: u,
          };
          edgeMap.set(key, e);
        }
        e.load += need;
        cur = par;
        par = parent.get(cur) ?? null;
      }
    }
    // 变电站/泵站增容 (容量 ×2.2)
    for (const e of edgeMap.values()) {
      if (e.cap === Infinity) continue;
      for (const bo of connectedBoosters) {
        const r = this.def(bo.b.defId).boostRadius ?? 7;
        const nearA = Math.max(Math.abs(bo.x - e.ax), Math.abs(bo.y - e.ay)) <= r;
        const nearB = Math.max(Math.abs(bo.x - e.bx), Math.abs(bo.y - e.by)) <= r;
        if (nearA || nearB) { e.boosted = true; break; }
      }
      if (e.boosted) e.cap = Math.round(e.cap * 2.2);
      if (e.load > e.cap) {
        if (isPower) this.gridWarnings.power++; else this.gridWarnings.water++;
      }
    }
    for (const e of edgeMap.values()) this.utilEdges.push(e);

    if (isPower) this.pipePowerConnected = served.size;
    else this.pipeWaterConnected = served.size;
  }

  /** v5: 过载干线 → 短路/爆管 (每小时判定) */
  private utilityFailures() {
    for (const e of this.utilEdges) {
      if (e.kind !== 'trunk' || e.dead || e.cap === Infinity || e.load <= e.cap) continue;
      const overload = e.load / e.cap - 1;
      if (this.rand() > Math.min(0.5, 0.07 + overload * 0.4)) continue;
      // 找到干线所在的电缆/水管建筑 (短路点)
      const wa = this.buildings.get(e.aId), wb = this.buildings.get(e.bId);
      const wireB = wa && this.def(wa.defId).pipe ? wa : wb;
      if (!wireB) continue;
      this.blackouts.push({
        utility: e.utility,
        x: wireB.x, y: wireB.y,
        endHour: this.nowHour + 6,
        label: e.utility === 'power' ? '短路' : '爆管',
      });
      e.dead = true;
      this.slowTimer = 99;
      if (e.utility === 'power') {
        this.happiness = Math.max(0, this.happiness - 5);
        this.notify('accident', '⚡ 电网短路!', `过载 (${Math.round(e.load)}/${Math.round(e.cap)}) 的电缆在 (${wireB.x},${wireB.y}) 附近短路起弧, 抢修 6 小时 —— 下游建筑暂时断电。分流负载、升级高压电缆或建变电站可根治。`, 'bad');
      } else {
        this.happiness = Math.max(0, this.happiness - 4);
        this.notify('accident', '💧 水管爆裂!', `超压 (${Math.round(e.load)}/${Math.round(e.cap)}) 的水管在 (${wireB.x},${wireB.y}) 附近爆裂, 抢修 6 小时 —— 下游建筑暂时断水。铺设主干管或建增压泵站可根治。`, 'bad');
      }
      this.pendingFx.push({ kind: 'network' });
      return; // 每小时至多一起
    }
  }

  // ---------- 效率 ----------
  private buildingEfficiency(b: Building, powerRatio: number, waterRatio: number): number {
    const def = this.def(b.defId);
    let eff = 1;
    const need = Math.ceil(def.workers * (this.research.includes('automation') ? 0.5 : 1));
    if (need > 0) eff *= Math.min(1, b.workers / need);
    if (def.powerNeed) {
      eff *= powerRatio;
      if (!this.pipePowered.has(b.id)) eff *= 0.5;
      else eff *= (this.buildingVolt.get(b.id) ?? 100) / 100;   // v5: 电压衰减
    }
    if (def.waterNeed) {
      eff *= waterRatio;
      if (!this.pipeWatered.has(b.id)) eff *= 0.5;
      else eff *= (this.buildingPress.get(b.id) ?? 100) / 100;  // v5: 水压衰减
    }
    if (def.roadBonus && def.roadBonus > 0) {
      const rb = this.adjacentRoadBonus(b);
      if (rb > 0) eff *= 1 + rb * (this.research.includes('automotive') ? 1.5 : 1);
    }
    const edu = this.eduGrid.get(WorldT.key(b.x, b.y));
    if (edu) eff *= 1 + edu;
    if (b.damaged) eff *= 0.5;
    if (this.research.includes('crop_rotation') && (def.id === 'farm' || def.id === 'berry' || def.id === 'ifarm' || def.id === 'orchard')) eff *= 1.3;
    if (this.research.includes('husbandry') && def.id === 'pasture') eff *= 1.35;
    if (this.research.includes('steam_engine') && (def.category === 'resource')) eff *= 1.3;
    if (this.research.includes('carpentry') && def.id === 'workshop') eff *= 1.4;
    if (this.research.includes('assembly_line') && (def.id === 'market' || def.id === 'factory' || def.id === 'train_station')) eff *= 1.35;
    if (this.research.includes('telecom') && (def.id === 'bank' || def.id === 'office' || def.id === 'broadcast')) eff *= 1.3;
    if (this.research.includes('recycling') && (def.id === 'refinery' || def.id === 'factory')) eff *= 1.15;
    if (this.research.includes('automation')) eff *= 1.2;
    return eff;
  }

  private adjacentRoadBonus(b: Building): number {
    let best = 0;
    for (let dy = -1; dy <= 1; dy++)
      for (let dx = -1; dx <= 1; dx++) {
        if (dx === 0 && dy === 0) continue;
        const t = this.terrain.peek(b.x + dx, b.y + dy);
        if (t && t.buildingId >= 0) {
          const nb = this.buildings.get(t.buildingId);
          if (nb && this.def(nb.defId).road) best = Math.max(best, this.def(nb.defId).roadBonus ?? 0);
        }
      }
    return best;
  }

  coveredByCached(b: Building, key: 'fire' | 'police' | 'health'): boolean {
    const set = key === 'fire' ? this.coveredFire : key === 'police' ? this.coveredPolice : this.coveredHealth;
    return set.has(b.id);
  }

  // ---------- 幸福 / 秩序 ----------
  private computeMood() {
    const arr = [...this.buildings.values()].filter(b => b.progress >= 1);
    const housings = arr.filter(b => this.def(b.defId).housing);
    let hap = 54;
    const night = this.hour >= 19 || this.hour < 6;
    if (housings.length > 0) {
      let sum = 0;
      for (const h of housings) {
        let local = 0;
        let litVal = 0;
        for (const other of arr) {
          if (other.id === h.id) continue;
          const d = this.def(other.defId);
          if (d.light && (!d.powerNeed || this.pipePowered.has(other.id)) && chebyshev(h, other) <= d.light + 1) {
            litVal = Math.max(litVal, d.effects?.happiness ?? 2);
          }
          if (!d.effects || !d.radius) continue;
          if (chebyshev(h, other) > d.radius + 1) continue;
          if (d.effects.happiness) local += d.effects.happiness;
          if (d.effects.pollution) {
            let pol = d.effects.pollution;
            if (this.research.includes('ecology')) pol *= 0.4;
            if (this.research.includes('recycling') && (other.defId === 'refinery' || other.defId === 'factory')) pol *= 0.5;
            local -= pol;
          }
          if (d.effects.noise) local -= d.effects.noise * 0.55;
          if (d.id === 'park' && this.research.includes('ecology')) local += 5;
        }
        if (night) {
          local += litVal > 0 ? Math.min(5, litVal + 1) : (this.era === 0 ? -2 : -5);
        }
        sum += Math.max(-45, Math.min(45, local));
      }
      hap += sum / housings.length;
    }
    const foodDays = this.dailyFoodNet() < 0 ? this.res.food / Math.max(0.01, -this.dailyFoodNet()) : 99;
    if (this.res.food < 1) hap -= 34;
    else if (foodDays < 2) hap -= 13;
    if (this.powerDemand > this.powerSupply && this.era >= 2) hap -= Math.min(24, (this.powerDemand - this.powerSupply) * 0.9);
    if (this.waterDemand > this.waterSupply && this.era >= 1 && this.waterBuffer <= 0) hap -= Math.min(24, (this.waterDemand - this.waterSupply) * 0.9);
    if (this.popCap > 0 && this.pop / Math.max(1, this.popCap) > 0.96) hap -= 9;
    if (this.stormDays > 0) hap -= 4;
    if (this.riotDays > 0) hap -= 14;
    if (this.taxPolicy === 2) hap -= 7;
    else if (this.taxPolicy === 0) hap += 3;
    const idle = this.availableWorkers - this.workersEmployed;
    if (idle > 8 && this.era >= 1) hap -= Math.min(8, idle * 0.15);
    if (this.res.money <= 0 && this.stats.money.consume > 0) hap -= 6;
    if (this.loan > 0) hap -= 2; // 负债的心理压力
    if (this.battleLosses > 0) hap -= Math.min(6, this.battleLosses);
    this.happiness = Math.round(Math.max(0, Math.min(100, hap * 0.25 + this.happiness * 0.75)));

    let ord = 55;
    if (housings.length > 0) {
      let sum = 0;
      for (const h of housings) {
        let local = 0;
        for (const other of arr) {
          if (other.id === h.id) continue;
          const d = this.def(other.defId);
          if (!d.effects?.order || !d.radius) continue;
          if (chebyshev(h, other) <= d.radius + 1) local += d.effects.order;
        }
        sum += Math.min(30, local);
      }
      ord += sum / housings.length;
    }
    if (this.happiness < 40) ord -= (40 - this.happiness) * 0.5;
    if (this.riotDays > 0) ord -= 28;
    if (this.pop > this.workersEmployed * 2.5 + 20) ord -= 4;
    // 哨塔提升防御性秩序
    let towers = 0;
    for (const b of arr) if (b.defId === 'wall') towers++;
    ord += Math.min(10, towers * 4) * 0.25;
    this.order = Math.round(Math.max(0, Math.min(100, ord * 0.2 + this.order * 0.8)));
  }

  dailyFoodNet(): number {
    return this.stats.food.produce - this.stats.food.consume;
  }

  // ---------- 数据视图 (稀疏 Map) ----------
  private computeOverlay() {
    this.overlay.clear();
    for (const b of this.buildings.values()) {
      if (b.progress < 1) continue;
      const d = this.def(b.defId);
      const stamp = (fn: (c: OverlayCell) => void, radius?: number) => {
        if (radius == null) {
          for (let dy = 0; dy < b.size; dy++)
            for (let dx = 0; dx < b.size; dx++) {
              const c = this.cellAt(b.x + dx, b.y + dy);
              fn(c);
            }
        } else {
          const cx = b.x + (b.size - 1) / 2, cy = b.y + (b.size - 1) / 2;
          for (let yy = Math.floor(cy - radius); yy <= Math.ceil(cy + radius); yy++)
            for (let xx = Math.floor(cx - radius); xx <= Math.ceil(cx + radius); xx++) {
              if (!this.terrain.isExplored(xx, yy)) continue;
              fn(this.cellAt(xx, yy));
            }
        }
      };
      if (d.road) stamp(c => { c.road = 1; });
      if (d.light && (!d.powerNeed || this.isBuildingPowered(b.id))) {
        stamp(c => { c.light = Math.max(c.light, 1); }, d.light);
      }
      // 地价: 住房周边 2 格染上该住房的地价 (供地价视图)
      if (d.housing) {
        const lv = this.landValues.get(b.id);
        if (lv != null) stamp(c => { c.land = Math.max(c.land, lv); }, 2);
      }
      if (d.effects && d.radius) {
        const e = d.effects;
        if (e.happiness) stamp(c => { c.happiness += e.happiness!; }, d.radius);
        if (e.pollution) stamp(c => { c.pollution += e.pollution!; }, d.radius);
        if (e.noise) stamp(c => { c.noise += e.noise!; }, d.radius);
      }
    }
    // 电力/水网状态 + 电压/水压
    for (const b of this.buildings.values()) {
      if (b.progress < 1) continue;
      const d = this.def(b.defId);
      for (let dy = 0; dy < b.size; dy++)
        for (let dx = 0; dx < b.size; dx++) {
          const c = this.cellAt(b.x + dx, b.y + dy);
          if (d.powerOut) c.powerOk = 2;
          else if (d.powerNeed) c.powerOk = this.pipePowered.has(b.id) ? 1 : 0;
          if (d.waterOut) c.waterOk = 2;
          else if (d.waterNeed) c.waterOk = this.pipeWatered.has(b.id) ? 1 : 0;
          if (d.pipe === 'power' || d.pipe === 'both') { if (c.powerOk === -1) c.powerOk = 3; }
          if (d.pipe === 'water' || d.pipe === 'both') { if (c.waterOk === -1) c.waterOk = 3; }
          if (d.booster === 'transformer') { c.powerOk = 4; }
          if (d.booster === 'pump') { c.waterOk = 4; }
          if (d.powerNeed || d.powerOut || d.booster === 'transformer') c.volt = this.buildingVolt.get(b.id) ?? 100;
          if (d.waterNeed || d.waterOut || d.booster === 'pump') c.press = this.buildingPress.get(b.id) ?? 100;
        }
    }
  }

  private cellAt(x: number, y: number): OverlayCell {
    const k = WorldT.key(x, y);
    let c = this.overlay.get(k);
    if (!c) {
      c = { happiness: 0, noise: 0, pollution: 0, light: 0, land: 0, powerOk: -1, waterOk: -1, volt: 100, press: 100, road: 0 };
      this.overlay.set(k, c);
    }
    return c;
  }

  // ---------- 随机事件 ----------
  private randomEvents() {
    const r = this.rand;
    const evtScale = DIFFICULTIES[this.difficulty].evt;
    // 火灾
    if (r() < EVT.fire * (1 + this.era * 0.25) * evtScale) {
      const targets = [...this.buildings.values()].filter(b => !this.def(b.defId).road);
      if (targets.length > 0) {
        const industrial = targets.filter(b => ['resource', 'power', 'civic'].includes(this.def(b.defId).category));
        const pool = industrial.length > 0 && r() < 0.6 ? industrial : targets;
        const t = pool[Math.floor(r() * pool.length)];
        t.fire = this.coveredFire.has(t.id) ? 4 : 20;
        this.pendingFx.push({ kind: 'fire', buildingId: t.id });
        this.notify('fire', '火灾!', `${this.def(t.defId).name} 起火了!${this.coveredFire.has(t.id) ? ' 消防局正在扑救。' : ' 附近没有消防局, 火势恐将蔓延!'}`, 'bad');
        return;
      }
    }
    // 暴雨
    if (this.stormDays === 0 && r() < EVT.storm * evtScale && this.era >= 1) {
      this.stormDays = 2;
      this.pendingFx.push({ kind: 'stormOn' });
      this.notify('storm', '暴雨来袭', '连日暴雨淹没了农田, 收成大减。', 'bad');
      return;
    }
    // 地震
    if (r() < EVT.quake * evtScale) {
      const targets = [...this.buildings.values()];
      if (targets.length > 3) {
        const damaged = targets.filter(b => r() < 0.4);
        let n = 0;
        for (const t of damaged) { t.hp -= 22; t.damaged = t.hp < 70; if (t.hp <= 0) { this.removeBuilding(t.id, false); n++; } }
        this.happiness -= 8;
        this.notify('quake', '地震!', `大地颤抖了许久${n > 0 ? `, ${n} 座建筑倒塌` : ', 多座建筑受损'}。`, 'bad');
        return;
      }
    }
    // 疫病
    if (this.era >= 2 && r() < EVT.plague * evtScale * (this.research.includes('sanitation') ? 0.3 : 1)) {
      const hasHospital = this.coveredHealth.size > 0 || this.hasBuilding('hospital');
      if (hasHospital) {
        this.happiness -= 3;
        this.notify('plague', '疫情控制', '流感在城中流传, 医院迅速控制了疫情。', 'info');
      } else {
        const lost = Math.max(1, Math.floor(this.pop * 0.06));
        this.pop = Math.max(1, this.pop - lost);
        this.happiness -= 10;
        this.notify('plague', '疫病流行!', `没有医院, 疫病带走了 ${lost} 位居民。请尽快建设医院与研究卫生学。`, 'bad');
      }
      return;
    }
    // 车祸
    const roadCount = [...this.buildings.values()].filter(b => this.def(b.defId).road).length;
    if (this.era >= 3 && roadCount >= 8 && r() < EVT.accident * evtScale) {
      const hasHospital = this.hasBuilding('hospital');
      this.happiness -= hasHospital ? 1 : 4;
      this.res.money = Math.max(0, this.res.money - (hasHospital ? 10 : 40));
      this.notify('accident', '交通事故', hasHospital
        ? '路口发生追尾, 伤者被迅速送往医院。'
        : '路口发生严重车祸! 城市没有医院, 民怨沸腾。', hasHospital ? 'info' : 'bad');
      return;
    }
    // 暴乱
    if (this.riotDays === 0 && this.happiness < 30 && r() < EVT.riot * evtScale) {
      const policeRatio = this.policeCoverage();
      if (policeRatio > 0.5) {
        this.notify('riot', '未遂骚乱', '警察局及时控制了聚集的人群。', 'info');
      } else {
        this.riotDays = 2 + Math.floor(r() * 3);
        this.order = Math.max(5, this.order - 18);
        this.pendingFx.push({ kind: 'riotOn' });
        this.notify('riot', '暴乱爆发!', `幸福度长期过低(${Math.round(this.happiness)}), 人群走上街头打砸!`, 'bad');
      }
      return;
    }
    // 核事故
    if (this.hasBuilding('nuclear') && this.order < 50 && r() < EVT.nuclear * evtScale) {
      const nuke = [...this.buildings.values()].find(b => b.defId === 'nuclear')!;
      nuke.hp = 35; nuke.damaged = true;
      this.happiness -= 28; this.order = Math.max(5, this.order - 12);
      this.pendingFx.push({ kind: 'nuke', buildingId: nuke.id });
      this.notify('nuclear', '核事故!!', '核电厂发生放射性泄漏! 城市陷入恐慌, 请尽快修复并提升秩序。', 'bad');
      return;
    }

    // ===== 敌袭链: 野兽 → 野人 → 匪帮 → 坦克军队 =====
    const squad = this.squadSize;
    if (this.era === 0 && this.pop >= 6 && r() < 0.10 * evtScale) {
      if (squad > 0) {
        if (this.startBattle('defense')) { this.notify('beast', '野兽袭击!', '一群野兽逼近营地 —— 战队列阵迎敌! (战斗中城市时间暂停)', 'bad'); return; }
      }
      const lost = Math.round(Math.min(this.res.food * 0.2, 25));
      this.res.food = Math.max(0, this.res.food - lost);
      this.happiness -= 4;
      this.notify('beast', '野兽袭击!', `野兽夜袭粮仓${lost > 0 ? `, 掠走 ${lost} 食物` : ''}。建设训练场组建战队即可迎击。`, 'bad');
      return;
    }
    if (this.era === 1 && this.pop >= 12 && r() < 0.075 * evtScale) {
      if (squad > 0) {
        if (this.startBattle('defense')) { this.notify('raid', '野人来犯!', '野人部落盯上了你们的存粮 —— 战队出击!', 'bad'); return; }
      }
      const targets = [...this.buildings.values()].filter(b => !this.def(b.defId).road);
      if (targets.length > 2) {
        const t = targets[Math.floor(r() * targets.length)];
        t.hp -= 25; t.damaged = t.hp < 70;
        if (t.hp <= 0) this.removeBuilding(t.id, false);
      }
      const lost = Math.round(Math.min(this.res.food * 0.15, 30));
      this.res.food = Math.max(0, this.res.food - lost);
      this.happiness -= 6;
      this.notify('raid', '野人袭击!', `野人洗劫了村落${lost > 0 ? `, 抢走 ${lost} 食物` : ''}, 建筑受损。`, 'bad');
      return;
    }
    if (this.era === 2 && this.pop >= 20 && r() < 0.06 * evtScale) {
      if (squad > 0) {
        if (this.startBattle('defense')) { this.notify('bandit', '匪帮勒索', '匪帮要求"过路费" —— 战队拔刀相向!', 'bad'); return; }
      }
      const lost = Math.round(Math.min(this.res.money * 0.12, 160));
      this.res.money = Math.max(0, this.res.money - lost);
      this.happiness -= 5;
      this.notify('bandit', '匪帮勒索', `匪帮强行收走了 ${lost} 资金"保护费"。组建战队才能挺直腰杆。`, 'bad');
      return;
    }
    if (this.era >= 4 && this.pop >= 50 && r() < 0.045 * evtScale) {
      if (squad > 0) {
        if (this.startBattle('defense')) { this.notify('rebel', '叛军来袭!', '叛军装甲部队出现在城郊 —— 全体战斗员登城!', 'bad'); return; }
      }
      const targets = [...this.buildings.values()].filter(b => !this.def(b.defId).road);
      let destroyed = 0;
      for (const t of targets) {
        if (r() < 0.25) { t.hp -= 45; t.damaged = t.hp < 70; if (t.hp <= 0) { this.removeBuilding(t.id, false); destroyed++; } }
      }
      this.happiness -= 12; this.order = Math.max(5, this.order - 10);
      this.notify('rebel', '叛军劫掠!', `没有战队守城, 叛军坦克碾过街道, ${destroyed} 座建筑被毁。`, 'bad');
      return;
    }
    // 罢工 (幸福低 + 有工业)
    if (this.era >= 2 && this.happiness < 45 && r() < 0.09 * evtScale) {
      const industrial = [...this.buildings.values()].filter(b =>
        b.progress >= 1 && ['factory', 'mine', 'sawmill', 'deep_mine', 'refinery'].includes(b.defId));
      if (industrial.length > 0) {
        const t = industrial[Math.floor(r() * industrial.length)];
        t.strike = 1;
        this.notify('strike', '工人罢工', `${this.def(t.defId).name} 的工人放下工具抗议待遇, 停产 1 天。提升幸福度可避免。`, 'bad');
        return;
      }
    }

    // 好事件
    const roll = r();
    const marketBonus = 1 + 0.15 * this.countBuilt('market'); // 集市商路议价
    if (roll < EVT.harvest) {
      const bonus = (30 + this.pop * 0.6 + this.era * 28) * marketBonus;
      const before = this.res.food;
      this.addRes('food', bonus);
      this.notify('harvest', '风调雨顺', `今年收成极好, +${Math.round(this.res.food - before)} 食物。`, 'good');
    } else if (roll < EVT.harvest + EVT.caravan) {
      const bonus = Math.round((30 + this.era * 55 + Math.floor(this.pop * 0.5)) * marketBonus);
      this.addRes('money', bonus);
      this.notify('caravan', '商队来访', `远方的商队带来贸易收入 +${bonus} 资金。`, 'good');
    } else if (roll < EVT.harvest + EVT.caravan + EVT.immigrant) {
      if (this.happiness > 50 && this.pop < this.popCap) {
        const n = 2 + Math.floor(r() * (2 + this.era * 2));
        this.pop = Math.min(this.popCap, this.pop + n);
        this.notify('immigrant', '移民迁入', `${this.pop >= this.popCap ? '有人想迁入但住房已满。' : `${n} 名移民被城市的繁荣吸引而来。`}`, 'good');
      }
    } else if (roll < EVT.harvest + EVT.caravan + EVT.immigrant + EVT.festival && this.era >= 1) {
      this.happiness = Math.min(100, this.happiness + 9);
      this.addRes('food', -Math.min(this.res.food, 15));
      this.notify('festival', '节日庆典', '广场上篝火通明, 歌舞升平, 幸福 +9。', 'good');
    } else if (roll < EVT.harvest + EVT.caravan + EVT.immigrant + EVT.festival + EVT.deposit) {
      if (this.era >= 1) {
        const k: ResourceKey = this.era >= 2 && r() < 0.5 ? 'metal' : 'stone';
        const n = 15 + Math.floor(r() * 30) + this.era * 12;
        this.addRes(k, n);
        this.notify('deposit', k === 'metal' ? '发现富矿' : '发现优质石层', `勘探队立功了! +${n} ${k === 'metal' ? '金属' : '石料'}。`, 'good');
      }
    } else if (roll < EVT.harvest + EVT.caravan + EVT.immigrant + EVT.festival + EVT.deposit + 0.022 && this.era >= 1 && this.pop >= 12) {
      this.happiness = Math.min(100, this.happiness + 4);
      this.notify('wedding', '一场婚礼', '全城分享了新人的喜悦, 幸福 +4。', 'good');
    }
  }

  private policeCoverage(): number {
    const housings = [...this.buildings.values()].filter(b => this.def(b.defId).housing);
    if (housings.length === 0) return 1;
    let covered = 0;
    for (const h of housings) if (this.coveredPolice.has(h.id)) covered++;
    return covered / housings.length;
  }

  // ---------- 伐木消耗与森林再生 ----------
  private lumberAndRegrow() {
    for (const b of this.buildings.values()) {
      if (b.defId !== 'lumber' && b.defId !== 'sawmill') continue;
      const times = b.defId === 'sawmill' ? 2 : 1;
      for (let k = 0; k < times; k++) {
        if (this.rand() > 0.55) continue;
        outer: for (let r = 1; r <= 4; r++) {
          for (let dy = -r; dy <= r; dy++)
            for (let dx = -r; dx <= r; dx++) {
              if (Math.max(Math.abs(dx), Math.abs(dy)) !== r) continue;
              const x = b.x + dx, y = b.y + dy;
              const t = this.terrain.peek(x, y);
              if (t && t.tree >= 0 && !t.occupied) {
                this.removeTree(x, y, true);
                break outer;
              }
            }
        }
      }
    }
    // 再生: 在已知森林附近长新苗
    if (this.terrain.trees.length > 0 && this.rand() < 0.75) {
      for (let tries = 0; tries < 14; tries++) {
        const idx = Math.floor(this.rand() * this.terrain.trees.length);
        const base = this.terrain.trees[idx];
        if (!base || base.dead) continue;
        const bx = Math.floor(base.x), by = Math.floor(base.y);
        const dx = [1, -1, 0, 0][Math.floor(this.rand() * 4)];
        const dy = [0, 0, 1, -1][Math.floor(this.rand() * 4)];
        const x = bx + dx, y = by + dy;
        const t = this.terrain.peek(x, y);
        if (!t || t.occupied || t.tree >= 0 || t.terrain !== 'grass' || !t.explored) continue;
        const t2 = this.terrain.ensure(x, y);
        const ni = this.terrain.addTree(x, y, 0.55);
        void t2;
        this.pendingFx.push({ kind: 'place', buildingId: -100 - ni });
        break;
      }
    }
  }

  // ---------- 时代 / 研究 ----------
  eraProgress(): { ok: boolean; items: { label: string; done: boolean; value: string }[] } {
    const next = ERAS[this.era + 1];
    if (!next) return { ok: false, items: [] };
    const items: { label: string; done: boolean; value: string }[] = [];
    items.push({ label: '人口', done: this.pop >= next.require.pop, value: `${Math.floor(this.pop)} / ${next.require.pop}` });
    if (next.require.resources) {
      for (const k of RES_KEYS) {
        const need = next.require.resources[k];
        if (need) items.push({ label: ['食物', '木材', '石料', '金属', '石油', '资金'][RES_KEYS.indexOf(k)], done: this.res[k] >= need, value: `${Math.floor(this.res[k])} / ${need}` });
      }
    }
    if (next.require.powerNet) {
      const net = this.powerSupply - this.powerDemand;
      items.push({ label: '电力盈余', done: net >= next.require.powerNet, value: `${net} / ${next.require.powerNet}` });
    }
    if (next.require.hasBuilding) {
      for (const bid of next.require.hasBuilding) {
        const has = this.hasBuilding(bid);
        items.push({ label: `已建造 ${BUILDING_DEFS[bid].name}`, done: has, value: has ? '✓' : '未建' });
      }
    }
    for (const it of items) if (!it.done) { return { ok: false, items }; }
    return { ok: true, items };
  }

  advanceEra(): boolean {
    if (!this.devMode && !this.eraProgress().ok) return false;
    this.era++;
    const e = ERAS[this.era];
    this.notify('info', `进入「${e.name}」`, e.slogan, 'good');
    this.happiness += 6; this.order += 5;
    this.slowTimer = 99;
    return true;
  }

  canResearch(id: string): boolean {
    const r = RESEARCH_DEFS[id];
    if (!r || this.research.includes(id) || r.era > this.era) return false;
    if (this.freeBuild) return true;
    // 典籍抵扣: 每卷抵 15 资金
    const discount = Math.min(r.cost.money ?? 0, this.scrolls * 15);
    return RES_KEYS.every(k => {
      const need = k === 'money' ? (r.cost[k] ?? 0) - discount : (r.cost[k] ?? 0);
      return need <= this.res[k];
    });
  }

  doResearch(id: string): boolean {
    if (!this.canResearch(id)) return false;
    const r = RESEARCH_DEFS[id];
    if (!this.freeBuild) {
      // 典籍优先抵扣资金
      const moneyNeed = r.cost.money ?? 0;
      const use = Math.min(moneyNeed, this.scrolls * 15);
      const scrollsUse = Math.ceil(use / 15);
      this.scrolls -= Math.min(this.scrolls, scrollsUse);
      RES_KEYS.forEach(k => {
        const need = k === 'money' ? moneyNeed - use : (r.cost[k] ?? 0);
        this.res[k] -= need;
      });
    }
    this.research.push(id);
    this.notify('info', '研究完成', `「${r.name}」—— ${r.desc}`, 'good');
    return true;
  }

  hasBuilding(defId: string): boolean {
    for (const b of this.buildings.values()) if (b.defId === defId && b.progress >= 1) return true;
    return false;
  }

  // ---------- 开发者 API ----------
  devEnable() { this.devMode = true; }
  setTaxPolicy(p: number) {
    const v = Math.max(0, Math.min(2, Math.floor(p)));
    if (v === this.taxPolicy) return;
    this.taxPolicy = v;
    if (this.day !== this.lastTaxNotifyDay) {
      this.lastTaxNotifyDay = this.day;
      const msg = v === 0 ? '轻徭薄税, 民心所向 (税收 70%, 幸福 +)' : v === 1 ? '恢复正常税率 (税收 100%)' : '重税之下, 怨声渐起 (税收 132%, 幸福 -)';
      this.notify('info', '税率调整', msg, v === 2 ? 'bad' : 'info');
    }
  }
  devSetFreeBuild(v: boolean) { this.freeBuild = v; }
  devClearWeather() {
    this.riotDays = 0; this.stormDays = 0;
    this.pendingFx.push({ kind: 'riotOff' }, { kind: 'stormOff' });
    this.notify('info', '[开发] 天气清空', '暴乱与暴雨已解除。', 'info');
  }
  devAddRes(k: ResourceKey, n: number) { this.devSetRes(k, this.res[k] + n); }
  devSetRes(k: ResourceKey, n: number) {
    this.res[k] = Math.max(0, n);
    if (k !== 'money') {
      const over = Math.ceil(n) + 50 - BASE_CAP[k];
      if (over > (this.devCapBoost[k] ?? 0)) this.devCapBoost[k] = over;
    }
  }
  devAddAll(n: number) { RES_KEYS.forEach(k => this.devSetRes(k, this.res[k] + n)); }
  devSetPop(n: number) { this.pop = Math.max(0, Math.min(9999, n)); }
  devAddPop(n: number) { this.pop = Math.max(0, this.pop + n); }
  devSetHappiness(n: number) { this.happiness = Math.max(0, Math.min(100, n)); }
  devSetOrder(n: number) { this.order = Math.max(0, Math.min(100, n)); }
  devSetEra(n: number) {
    this.era = Math.max(0, Math.min(4, Math.floor(n)));
    this.notify('info', '[开发] 时代变更', `当前时代: 「${ERAS[this.era].name}」`, 'info');
    this.slowTimer = 99;
  }
  devUnlockAllResearch() {
    let n = 0;
    for (const id of Object.keys(RESEARCH_DEFS)) {
      if (!this.research.includes(id)) { this.research.push(id); n++; }
    }
    this.notify('info', '[开发] 科技全解', `已解锁 ${n} 项科技。`, 'info');
  }
  devSetDay(n: number) { this.day = Math.max(1, Math.floor(n)); }
  devSetHour(n: number) { this.hour = Math.max(0, Math.min(23.99, n)); }
  devRepairAll() {
    for (const b of this.buildings.values()) { b.hp = 100; b.damaged = false; b.fire = 0; b.strike = 0; }
    this.pendingFx.push({ kind: 'riotOff' });
    this.notify('info', '[开发] 万能维修', '所有建筑已修复, 火灾已扑灭。', 'info');
  }
  devClearTrees() {
    let n = 0;
    for (const t of this.terrain.trees) {
      if (!t.dead) { t.dead = true; n++; }
    }
    for (const c of this.terrain.chunks.values()) {
      for (const tile of c.tiles) {
        if (tile.tree >= 0) {
          this.terrain.treeAt.delete(WorldT.key(tile.x, tile.y));
          if (tile.terrain === 'forest') { this.terrain.stats.forest--; this.terrain.stats.grass++; tile.terrain = 'grass'; }
          tile.tree = -1;
        }
      }
    }
    this.pendingFx.push({ kind: 'remove', buildingId: -101 });
    this.notify('info', '[开发] 清空树木', `已清除 ${n} 棵树。`, 'info');
  }
  devPlantForest(cx: number, cy: number, r = 2) {
    let n = 0;
    for (let dy = -r; dy <= r; dy++)
      for (let dx = -r; dx <= r; dx++) {
        const x = cx + dx, y = cy + dy;
        const t = this.terrain.ensure(x, y);
        if (t.occupied || t.tree >= 0 || t.terrain === 'water' || t.terrain === 'mountain') continue;
        if (t.ruin >= 0) continue;
        this.terrain.addTree(x, y, 0.75 + this.rand() * 0.5);
        n++;
      }
    if (n > 0) this.pendingFx.push({ kind: 'place', buildingId: -100 });
    this.terrain.reveal(cx, cy, r + 1);
  }
  devSetTerrain(cx: number, cy: number, terrain: TileTerrain | 'clear') {
    const t = this.terrain.ensure(cx, cy);
    if (t.occupied) return;
    if (terrain === 'clear') {
      if (t.tree >= 0) this.removeTree(t.x, t.y, false);
      t.rock = false;
      this.pendingFx.push({ kind: 'place', buildingId: -101 });
      return;
    }
    if (t.tree >= 0) this.removeTree(t.x, t.y, false);
    if (t.ruin >= 0) {
      const ruin = this.terrain.ruins[t.ruin];
      if (ruin) ruin.scavenged = true;
      this.terrain.ruinAt.delete(WorldT.key(t.x, t.y));
      t.ruin = -1;
    }
    t.rock = false;
    this.terrain.stats[t.terrain]--;
    t.terrain = terrain;
    t.height = terrain === 'water' ? -0.18
      : terrain === 'mountain' ? 1.1
      : terrain === 'hill' ? 0.42
      : terrain === 'forest' ? 0.1
      : 0.06;
    if (terrain === 'forest') this.devPlantForest(t.x, t.y, 0);
    this.terrain.stats[terrain]++;
    this.pendingFx.push({ kind: 'place', buildingId: -101 });
  }
  devAddRock(cx: number, cy: number) {
    const t = this.terrain.ensure(cx, cy);
    if (t.occupied) return;
    t.rock = true;
    this.pendingFx.push({ kind: 'place', buildingId: -101 });
  }
  devRevealAll() {
    const cc = this.cityCenter();
    const t0 = performance.now();
    this.terrain.reveal(cc.x, cc.y, 90);
    this.notify('info', '[开发] 揭开迷雾', `已探索半径 90 格 (${Math.round(performance.now() - t0)}ms)。`, 'info');
  }
  devRevealAt(x: number, y: number, r = 12) { this.terrain.reveal(x, y, r); }
  devSetQuality(q: 'low' | 'med' | 'high') {
    this.quality = q;
    try { localStorage.setItem('wildcity_quality', q); } catch { /* */ }
  }
  devTriggerEvent(kind: string) {
    switch (kind) {
      case 'fire': {
        const targets = [...this.buildings.values()].filter(b => !this.def(b.defId).road);
        if (targets.length === 0) return;
        const t = targets[Math.floor(this.rand() * targets.length)];
        t.fire = 20;
        this.pendingFx.push({ kind: 'fire', buildingId: t.id });
        this.notify('fire', '[开发] 触发火灾', `${this.def(t.defId).name} 起火了!`, 'bad');
        break;
      }
      case 'storm':
        this.stormDays = 2;
        this.pendingFx.push({ kind: 'stormOn' });
        this.notify('storm', '[开发] 触发暴雨', '暴雨倾盆而下。', 'bad');
        break;
      case 'riot':
        this.riotDays = 3;
        this.order = Math.max(5, this.order - 18);
        this.pendingFx.push({ kind: 'riotOn' });
        this.notify('riot', '[开发] 触发暴乱', '人群走上街头! ', 'bad');
        break;
      case 'accident':
        this.res.money = Math.max(0, this.res.money - 40);
        this.happiness -= 4;
        this.notify('accident', '[开发] 触发车祸', '路口发生严重车祸!', 'bad');
        break;
      case 'beast': case 'raid': case 'bandit': case 'rebel': {
        if (!this.startBattle('defense')) {
          this.notify('info', '[开发] 触发战斗失败', '需要先建设训练场 (战队规模 > 0)。', 'bad');
        }
        break;
      }
      case 'harvest': {
        const bonus = 60 + this.pop * 0.6;
        this.addRes('food', bonus);
        this.notify('harvest', '[开发] 触发丰收', `+${Math.round(bonus)} 食物。`, 'good');
        break;
      }
      case 'caravan': {
        const bonus = 100 + this.era * 55;
        this.addRes('money', bonus);
        this.notify('caravan', '[开发] 触发商队', `+${Math.round(bonus)} 资金。`, 'good');
        break;
      }
      case 'immigrant': {
        const n = 5 + this.era * 3;
        this.pop = Math.min(Math.max(this.popCap, this.pop + n), 9999);
        this.notify('immigrant', '[开发] 移民潮', `+${n} 人口(超出住房上限也能入住)。`, 'good');
        break;
      }
      case 'deposit': {
        this.addRes('metal', 120); this.addRes('stone', 120);
        this.notify('deposit', '[开发] 触发矿藏', '+120 金属 +120 石料。', 'good');
        break;
      }
      case 'plague': {
        const lost = Math.max(1, Math.floor(this.pop * 0.06));
        this.pop = Math.max(1, this.pop - lost);
        this.happiness -= 10;
        this.notify('plague', '[开发] 触发疫病', `-${lost} 人口。`, 'bad');
        break;
      }
      case 'quake': {
        for (const t of [...this.buildings.values()]) { if (this.rand() < 0.4) { t.hp -= 22; t.damaged = t.hp < 70; } }
        this.notify('quake', '[开发] 触发地震', '多座建筑受损。', 'bad');
        break;
      }
      case 'win':
        this.winShown = true;
        this.gameOver = { win: true, reason: '[开发] 直接达成胜利条件。' };
        break;
    }
  }

  // ---------- 通知 ----------
  notify(kind: EventKind, title: string, detail: string, tone: 'good' | 'bad' | 'info' = 'info') {
    this.notifications.unshift({ id: this.notifId++, kind, title, detail, tone, ts: Date.now() });
    if (this.notifications.length > 40) this.notifications.pop();
  }

  private endGame(win: boolean, reason: string) {
    this.gameOver = { win, reason };
    this.speed = 0;
  }

  private hourlyUpdate() {
    const h = Math.floor(this.hour);
    if (h === 19 || h === 6) this.slowTimer = 99;
    // v5: 过载干线 → 短路/爆管判定
    this.utilityFailures();
    for (const b of [...this.buildings.values()]) {
      if (b.fire > 0) {
        b.fire -= 1;
        const covered = this.coveredFire.has(b.id);
        b.hp -= covered ? 3.2 : 9;
        if (!covered && b.fire > 8 && this.rand() < 0.16) {
          const victim = this.adjacentBuilding(b);
          if (victim && victim.fire <= 0) {
            victim.fire = 14;
            this.pendingFx.push({ kind: 'fire', buildingId: victim.id });
            this.notify('fire', '火势蔓延!', `火星溅到了旁边的 ${this.def(victim.defId).name}, 火势正在扩散! 建设消防局可大幅降低损失。`, 'bad');
          }
        }
        if (b.hp <= 0) {
          const def = this.def(b.defId);
          this.removeBuilding(b.id, false);
          this.notify('fire', '建筑焚毁', `${def.name} 在大火中化为灰烬。`, 'bad');
          this.happiness -= 4;
        } else if (b.fire <= 0) {
          b.damaged = b.hp < 55;
          this.notify('fire', '火灾扑灭', `${this.def(b.defId).name} 的火被扑灭了${b.damaged ? ', 但已受损, 效率下降' : ''}。`, 'bad');
          this.pendingFx.push({ kind: 'extinguish', buildingId: b.id });
        }
      }
    }
  }

  private adjacentBuilding(b: Building): Building | null {
    const cands: Building[] = [];
    for (const o of this.buildings.values()) {
      if (o.id === b.id || o.fire > 0 || o.progress < 1) continue;
      if (this.def(o.defId).road || this.def(o.defId).pipe) continue;
      if (chebyshev(b, o) <= (b.size + o.size) / 2 + 0.5) cands.push(o);
    }
    if (cands.length === 0) return null;
    return cands[Math.floor(this.rand() * cands.length)];
  }

  private dailyUpdate() {
    if (this.gameOver) return;
    this.randomEvents();
    // 罢工倒计时
    for (const b of this.buildings.values()) {
      if ((b.strike ?? 0) > 0) {
        b.strike = (b.strike ?? 0) - 1;
        if ((b.strike ?? 0) === 0) this.notify('strike', '罢工结束', `${this.def(b.defId).name} 恢复了生产。`, 'info');
      }
    }
    if (this.riotDays > 0) {
      this.riotDays--;
      if (this.riotDays === 0) {
        this.pendingFx.push({ kind: 'riotOff' });
        this.notify('riot', '暴乱平息', '秩序重回街道, 但伤痕需要时间愈合。', 'info');
      } else {
        const targets = [...this.buildings.values()].filter(b => !this.def(b.defId).road);
        if (targets.length > 2) {
          const t = targets[Math.floor(this.rand() * targets.length)];
          t.hp -= 18; t.damaged = t.hp < 70;
          if (t.hp <= 0) {
            this.notify('riot', '暴乱破坏', `${this.def(t.defId).name} 被愤怒的人群摧毁了。`, 'bad');
            this.removeBuilding(t.id, false);
          } else {
            this.notify('riot', '暴乱持续', `人群冲击了 ${this.def(t.defId).name}, 建筑受损。`, 'bad');
          }
        }
      }
    }
    if (this.stormDays > 0) {
      this.stormDays--;
      if (this.stormDays === 0) {
        this.pendingFx.push({ kind: 'stormOff' });
        this.notify('info', '雨过天晴', '暴雨结束, 农田逐步恢复。', 'info');
      }
    }
    this.lumberAndRegrow();
    if (!this.winShown && this.era === 4 && this.pop >= 150 && this.hasBuilding('airport')) {
      this.winShown = true;
      this.gameOver = { win: true, reason: '从几个人的荒野营地, 到摩天大楼与国际航班川流不息的大都会 —— 你做到了!' };
    }
  }

  // ---------- 存档 ----------
  save() {
    try {
      const chunks: { cx: number; cy: number; t: number[] }[] = [];
      for (const c of this.terrain.chunks.values()) {
        if (!c.generated) continue;
        const t: number[] = [];
        for (let i = 0; i < CHUNK_SQ; i++) {
          const tile = c.tiles[i];
          t.push(TERRAIN_LIST.indexOf(tile.terrain), tile.tree, tile.rock ? 1 : 0, tile.buildingId, tile.ruin, tile.explored ? 1 : 0);
        }
        chunks.push({ cx: c.cx, cy: c.cy, t });
      }
      const data = {
        v: 5,
        seed: this.seed, res: this.res, era: this.era, research: this.research,
        buildings: [...this.buildings.values()].map(b => ({ ...b, alerts: undefined })),
        nextId: this.nextId, day: this.day, hour: this.hour, pop: this.pop,
        happiness: this.happiness, order: this.order, winShown: this.winShown,
        taxPolicy: this.taxPolicy,
        scrolls: this.scrolls, loan: this.loan, weaponTier: this.weaponTier, armorTier: this.armorTier,
        battleWins: this.battleWins, battleLosses: this.battleLosses,
        laborManual: this.laborManual, quality: this.quality,
        budgets: this.budgets, difficulty: this.difficulty,
        expeditions: this.expeditions, nextExpId: this.nextExpId,
        chunks,
        trees: this.terrain.trees.map(t => [t.x, t.y, t.type, t.scale, t.rot, t.dead ? 1 : 0]),
        ruins: this.terrain.ruins.map(r => [r.type, r.scavenged ? 1 : 0]),
      };
      localStorage.setItem(SAVE_KEY, JSON.stringify(data));
    } catch { /* 忽略 */ }
  }

  static hasSave(): boolean {
    try { return !!localStorage.getItem(SAVE_KEY); } catch { return false; }
  }

  static clearSave() {
    try { localStorage.removeItem(SAVE_KEY); } catch { /* */ }
  }

  static load(): GameEngine | null {
    try {
      const raw = localStorage.getItem(SAVE_KEY);
      if (!raw) return null;
      const data = JSON.parse(raw);
      if (data.v !== 4 && data.v !== 5) return null;
      const e = new GameEngine(data.seed);
      e.res = data.res; e.era = data.era; e.research = data.research ?? [];
      e.nextId = data.nextId; e.day = data.day; e.hour = data.hour;
      e.pop = data.pop; e.happiness = data.happiness; e.order = data.order;
      e.winShown = data.winShown ?? false;
      e.taxPolicy = data.taxPolicy ?? 1;
      e.scrolls = data.scrolls ?? 0; e.loan = data.loan ?? 0;
      e.weaponTier = data.weaponTier ?? 0; e.armorTier = data.armorTier ?? 0;
      e.battleWins = data.battleWins ?? 0; e.battleLosses = data.battleLosses ?? 0;
      e.laborManual = data.laborManual ?? true;
      e.quality = data.quality ?? 'med';
      e.budgets = { fire: 1, police: 1, health: 1, edu: 1, road: 1, ...(data.budgets ?? {}) };
      e.difficulty = data.difficulty ?? 1;
      e.expeditions = (data.expeditions ?? []).map((ex: Expedition) => ({ ...ex, vehicles: ex.vehicles ?? { apc: 0, tank: 0, heli: 0 } }));
      e.nextExpId = data.nextExpId ?? 1;
      e.buildings = new Map(data.buildings.map((b: Building) => {
        b.rot = b.rot ?? 0;
        b.progress = b.progress ?? 1;
        b.alerts = [];
        b.strike = b.strike ?? 0;
        return [b.id, b];
      }));
      // 恢复区块
      for (const ch of data.chunks as { cx: number; cy: number; t: number[] }[]) {
        e.terrain.ensureChunk(ch.cx, ch.cy);
        const c = e.terrain.chunks.get(WorldT.chunkKey(ch.cx, ch.cy))!;
        c.revealed = 0;
        for (let i = 0; i < CHUNK_SQ; i++) {
          const tile = c.tiles[i];
          const terrain = TERRAIN_LIST[ch.t[i * 6]] ?? 'grass';
          // 修正统计
          if (tile.terrain !== terrain) {
            e.terrain.stats[tile.terrain]--; e.terrain.stats[terrain]++;
          }
          tile.terrain = terrain;
          tile.tree = ch.t[i * 6 + 1];
          tile.rock = !!ch.t[i * 6 + 2];
          tile.buildingId = ch.t[i * 6 + 3];
          tile.ruin = ch.t[i * 6 + 4];
          tile.explored = !!ch.t[i * 6 + 5];
          tile.occupied = tile.buildingId >= 0;
          if (tile.explored) c.revealed++;
        }
        c.dirty = true;
      }
      // 恢复树/遗迹实例
      e.terrain.trees = data.trees.map((t: number[]) => ({ x: t[0], y: t[1], type: t[2], scale: t[3], rot: t[4], hp: 3, dead: !!t[5] }));
      e.terrain.treeAt = new Map();
      e.terrain.ruins = data.ruins.map((r: number[]) => ({ x: 0, y: 0, type: r[0], scavenged: !!r[1] }));
      // ruinAt 与 ruins 坐标从 tile 恢复
      e.terrain.ruinAt = new Map();
      for (const c of e.terrain.chunks.values()) {
        for (const tile of c.tiles) {
          if (tile.tree >= 0) e.terrain.treeAt.set(WorldT.key(tile.x, tile.y), tile.tree);
          if (tile.ruin >= 0) {
            const ruin = e.terrain.ruins[tile.ruin];
            if (ruin) { ruin.x = tile.x; ruin.y = tile.y; }
            e.terrain.ruinAt.set(WorldT.key(tile.x, tile.y), tile.ruin);
          }
        }
      }
      e.notifications = [];
      e.notify('info', '载入存档', `欢迎回来, 第 ${e.day} 天的「${ERAS[e.era].name}」。`);
      return e;
    } catch {
      return null;
    }
  }

  snapshot(): UISnapshot {
    const stats = emptyStats();
    RES_KEYS.forEach(k => { stats[k] = this.stats[k]; });
    const net = this.dailyFoodNet();
    let away = 0;
    for (const ex of this.expeditions) away += ex.members;
    return {
      day: this.day, hour: Math.floor(this.hour), minute: Math.floor((this.hour % 1) * 60), speed: this.speed, era: this.era,
      res: { ...this.res } as Record<ResourceKey, number>,
      resCap: this.cap,
      pop: Math.floor(this.pop), popCap: this.popCap,
      workersEmployed: this.workersEmployed,
      workersTotal: Math.floor(this.pop * this.workRatio) - away,
      happiness: this.happiness, order: this.order,
      powerSupply: this.powerSupply, powerDemand: this.powerDemand,
      waterSupply: this.waterSupply, waterDemand: this.waterDemand,
      stats,
      foodDaysLeft: net < 0 ? Math.max(0, this.res.food / -net) : -1,
      research: [...this.research],
      buildings: this.buildings.size,
      treeCount: this.terrain.stats.forest,
      eventActive: { storm: this.stormDays, riot: this.riotDays },
      gameOver: this.gameOver,
      pipePowerConnected: this.pipePowerConnected, pipePowerTotal: this.pipePowerTotal,
      pipeWaterConnected: this.pipeWaterConnected, pipeWaterTotal: this.pipeWaterTotal,
      taxPolicy: this.taxPolicy,
      scrolls: Math.floor(this.scrolls),
      loan: this.loan,
      attraction: this.attraction,
      birthRate: this.birthRate,
      waterBuffer: Math.round(this.waterBuffer),
      waterBufferCap: this.waterBufferCap,
      budgets: { ...this.budgets },
      budgetCost: Math.round(this.budgetCost * 10) / 10,
      landValue: this.avgLandValue,
      jobsTotal: this.jobsTotal,
      weaponTier: this.weaponTier,
      armorTier: this.armorTier,
      squadSize: this.squadSize,
      battleWins: this.battleWins,
      vehicles: this.readyVehicles,
      gridWarnings: { ...this.gridWarnings },
      expeditions: this.expeditions.map(e => {
        const scoutMul = this.research.includes('scouting') ? 1.3 : 1;
        const target = e.state === 'outbound' ? { x: e.tx, y: e.ty } : { x: e.sx, y: e.sy };
        const remain = Math.hypot(target.x - e.x, target.y - e.y);
        return {
          id: e.id, members: e.members, dist: e.dist,
          vehicles: { ...e.vehicles },
          traveled: Math.round(Math.hypot(e.x - e.sx, e.y - e.sy)),
          state: e.state, tx: e.tx, ty: e.ty,
          foodUsed: 0,
          etaSec: Math.round(remain / (EXP_SPEED * scoutMul * GameEngine.vehicleSpeedMul(e.vehicles))),
          foodPerSec: Math.round(EXP_FOOD_PER_SEC * e.members * (this.research.includes('scouting') ? 0.8 : 1) * 100) / 100,
        };
      }),
      battleActive: !!this.battle,
      laborManual: this.laborManual,
      idleWorkers: Math.max(0, this.availableWorkers - this.workersEmployed),
      difficulty: this.difficulty,
      tradeSpent: Math.round(this.tradeSpent),
      tradeEarned: Math.round(this.tradeEarned),
      devMode: this.devMode, freeBuild: this.freeBuild, devSpeed: 0,
      quality: this.quality,
    };
  }
}

const CHUNK_SQ = 16 * 16;

// ---------- 工具 ----------
function chebyshev(a: Building, b: Building): number {
  const acx = a.x + (a.size - 1) / 2, acy = a.y + (a.size - 1) / 2;
  const bcx = b.x + (b.size - 1) / 2, bcy = b.y + (b.size - 1) / 2;
  return Math.max(Math.abs(acx - bcx), Math.abs(acy - bcy));
}

type StampOp = (a: number, b: number) => number;
const max: StampOp = (a, b) => Math.max(a, b);

function stampRadius(grid: Map<number, number>, x: number, y: number, size: number, radius: number, value: number, op: StampOp) {
  const cx = x + (size - 1) / 2, cy = y + (size - 1) / 2;
  for (let yy = Math.floor(cy - radius); yy <= Math.ceil(cy + radius); yy++)
    for (let xx = Math.floor(cx - radius); xx <= Math.ceil(cx + radius); xx++) {
      const k = WorldT.key(xx, yy);
      grid.set(k, op(grid.get(k) ?? 0, value));
    }
}

function emptyStats(): Record<ResourceKey, ResourceStat> {
  return {
    food: { produce: 0, consume: 0, net: 0 },
    wood: { produce: 0, consume: 0, net: 0 },
    stone: { produce: 0, consume: 0, net: 0 },
    metal: { produce: 0, consume: 0, net: 0 },
    oil: { produce: 0, consume: 0, net: 0 },
    money: { produce: 0, consume: 0, net: 0 },
  };
}
