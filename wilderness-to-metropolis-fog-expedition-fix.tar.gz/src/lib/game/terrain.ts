// ===== 荒野筑城 · 无限世界 (按需生成的区块地形 + 战争迷雾 + 遗迹) =====
import type { Tile, TileTerrain } from './types';

// --- 可复现随机 ---
export function mulberry32(seed: number) {
  let a = seed >>> 0;
  return function () {
    a |= 0; a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/** 整数坐标哈希 → [0,1) (用于逐格确定性判定) */
export function hash2(x: number, y: number, seed = 0): number {
  let h = Math.imul(x | 0, 0x27d4eb2d) ^ Math.imul(y | 0, 0x165667b1) ^ Math.imul(seed | 0, 0x9e3779b9);
  h ^= h >>> 15; h = Math.imul(h, 0x85ebca6b);
  h ^= h >>> 13; h = Math.imul(h, 0xc2b2ae35);
  h ^= h >>> 16;
  return (h >>> 0) / 4294967296;
}

// --- 平滑值噪声 (全域连续, 供无限地形使用) ---
class ValueNoise {
  private perm: Uint8Array;
  constructor(rand: () => number, size = 256) {
    this.perm = new Uint8Array(size * 2);
    const p = new Uint8Array(size);
    for (let i = 0; i < size; i++) p[i] = i;
    for (let i = size - 1; i > 0; i--) {
      const j = Math.floor(rand() * (i + 1));
      const t = p[i]; p[i] = p[j]; p[j] = t;
    }
    for (let i = 0; i < size * 2; i++) this.perm[i] = p[i & (size - 1)];
  }
  private hash(x: number, y: number) {
    return this.perm[(this.perm[x & 255] + (y & 255)) & 511];
  }
  private static fade(t: number) { return t * t * (3 - 2 * t); }
  noise2(x: number, y: number) {
    const xi = Math.floor(x), yi = Math.floor(y);
    const xf = x - xi, yf = y - yi;
    const u = ValueNoise.fade(xf), v = ValueNoise.fade(yf);
    const a = this.hash(xi, yi) / 255, b = this.hash(xi + 1, yi) / 255;
    const c = this.hash(xi, yi + 1) / 255, d = this.hash(xi + 1, yi + 1) / 255;
    return a + (b - a) * u + (c - a) * v + (a - b - c + d) * u * v;
  }
  fbm(x: number, y: number, oct = 4, lac = 2, gain = 0.5) {
    let amp = 1, freq = 1, sum = 0, norm = 0;
    for (let i = 0; i < oct; i++) {
      sum += amp * this.noise2(x * freq, y * freq);
      norm += amp;
      amp *= gain; freq *= lac;
    }
    return sum / norm;
  }
}

export interface TreeIns { x: number; y: number; type: number; scale: number; rot: number; hp: number; dead?: boolean; }
export interface RuinIns { x: number; y: number; type: number; scavenged: boolean; }

/** 区块: 16×16 格, 首次进入视野/被探索时才生成 */
export interface Chunk {
  cx: number; cy: number;
  tiles: Tile[];
  revealed: number;   // 已揭开格数 (0=全迷雾)
  dirty: boolean;     // 渲染器需要重建网格
  generated: boolean;
}

export const CHUNK = 16;

const WATER = 0.335, SAND = 0.375, HILL = 0.60, MOUNT = 0.82;

/** 遗迹类型 */
export const RUIN_TYPES = [
  { id: 0, name: '巨石阵',   model: 'ruin_circle',  desc: '环形的古老立石, 石缝间藏着先民的储物' },
  { id: 1, name: '残破石塔', model: 'ruin_tower',   desc: '不知何人修建的塔楼废墟, 断壁中或有遗物' },
  { id: 2, name: '远古营地', model: 'ruin_camp',    desc: '废弃的营地, 篝火灰烬下埋着补给' },
  { id: 3, name: '神秘石碑', model: 'ruin_obelisk', desc: '刻满未知文字的石碑, 触碰时隐有低语' },
  { id: 4, name: '搁浅沉船', model: 'ruin_ship',    desc: '深陷荒野的搁浅货船, 货舱里或许还有完好的木料与货物' },
  { id: 5, name: '废弃加油站', model: 'ruin_gas',   desc: '锈蚀的加油泵与便利店, 地下储罐里可能还残存油料' },
  { id: 6, name: '坠毁无人机', model: 'ruin_drone', desc: '老战争遗留的军用无人机残骸, 精密合金与数据核心价值不菲' },
  { id: 7, name: '掩埋地窖', model: 'ruin_cellar',  desc: '半塌的地下储藏室, 泥土之下封存着前人的口粮' },
  // ---- v5 新增 ----
  { id: 8, name: '废弃哨塔', model: 'ruin_watchpost', desc: '边防哨所的锈蚀残骸, 军械库或许还未被洗劫一空' },
  { id: 9, name: '沉没码头', model: 'ruin_dock',      desc: '河水改道后留下的木质码头, 淤泥下压着当年的货箱' },
  { id: 10, name: '巨型残骸', model: 'ruin_mech',     desc: '一台倒伏的巨型机械, 精密部件在荒野中依然闪闪发光' },
  { id: 11, name: '神秘古井', model: 'ruin_well',     desc: '井壁刻满祈祷文, 井底沉淀着历代旅人的供奉' },
] as const;

export const RUIN_MODEL_OF = (type: number, scavenged: boolean) =>
  scavenged ? 'rubble' : (RUIN_TYPES[type]?.model ?? 'ruin_circle');

export interface WorldStats { water: number; grass: number; forest: number; hill: number; mountain: number; }

export class World {
  seed: number;
  private n1: ValueNoise; // 基础高度
  private n2: ValueNoise; // 森林遮罩
  private n3: ValueNoise; // 山脉
  chunks = new Map<number, Chunk>();
  trees: TreeIns[] = [];
  treeAt = new Map<number, number>();
  ruins: RuinIns[] = [];
  ruinAt = new Map<number, number>();
  spawn: { x: number; y: number };
  stats: WorldStats = { water: 0, grass: 0, forest: 0, hill: 0, mountain: 0 };
  /** 迷雾揭开时递增, 渲染器据此刷新 */
  revealVersion = 0;

  constructor(seed: number) {
    this.seed = seed;
    const rand = mulberry32(seed);
    this.n1 = new ValueNoise(rand);
    this.n2 = new ValueNoise(rand);
    this.n3 = new ValueNoise(rand);
    this.spawn = this.findSpawn();
    // 开局视野: 以出生点为圆心半径 7 格
    this.reveal(this.spawn.x, this.spawn.y, 7);
  }

  // ---------- 坐标 ----------
  static key(x: number, y: number): number {
    return (x + 65536) * 131072 + (y + 65536);
  }
  static chunkKey(cx: number, cy: number): number {
    return (cx + 4096) * 8192 + (cy + 4096);
  }

  chunkOf(x: number, y: number): Chunk | undefined {
    return this.chunks.get(World.chunkKey(Math.floor(x / CHUNK), Math.floor(y / CHUNK)));
  }

  /** 查询格子 (不生成) */
  peek(x: number, y: number): Tile | undefined {
    const c = this.chunkOf(x, y);
    if (!c || !c.generated) return undefined;
    return c.tiles[((y - c.cy * CHUNK) + CHUNK) % CHUNK * CHUNK + ((x - c.cx * CHUNK) + CHUNK) % CHUNK];
  }

  /** 取格子, 必要时生成所在区块 */
  ensure(x: number, y: number): Tile {
    const cx = Math.floor(x / CHUNK), cy = Math.floor(y / CHUNK);
    const c = this.ensureChunk(cx, cy);
    const lx = x - cx * CHUNK, ly = y - cy * CHUNK;
    return c.tiles[ly * CHUNK + lx];
  }

  ensureChunk(cx: number, cy: number): Chunk {
    const k = World.chunkKey(cx, cy);
    let c = this.chunks.get(k);
    if (c && c.generated) return c;
    if (!c) {
      c = { cx, cy, tiles: new Array(CHUNK * CHUNK), revealed: 0, dirty: false, generated: false };
      this.chunks.set(k, c);
    }
    this.generateChunk(c);
    return c;
  }

  // ---------- 地形生成 (全域连续噪声) ----------
  rawHeight(x: number, y: number): number {
    let v = this.n1.fbm(x * 0.045, y * 0.045, 4);
    const mount = this.n3.fbm(x * 0.028 + 5.3, y * 0.028 - 1.7, 3);
    v = v * 0.66 + mount * 0.34;
    v = (v - 0.5) * 1.75 + 0.5; // 对比度
    return Math.max(0, Math.min(1, v));
  }

  private static classify(v: number): TileTerrain {
    if (v < WATER) return 'water';
    if (v < SAND) return 'sand';
    if (v > MOUNT) return 'mountain';
    if (v > HILL) return 'hill';
    return 'grass';
  }

  static heightOf(terrain: TileTerrain, v: number): number {
    const h = terrain === 'water' ? Math.max(-0.22, (v - WATER) * 2.2)
      : terrain === 'mountain' ? 0.9 + (v - MOUNT) * 3.2
      : terrain === 'hill' ? 0.28 + (v - HILL) * 2.2
      : (v - SAND) * 0.5;
    return Math.max(terrain === 'water' ? -0.22 : 0.02, h);
  }

  private generateChunk(c: Chunk) {
    c.generated = true;
    for (let ly = 0; ly < CHUNK; ly++) {
      for (let lx = 0; lx < CHUNK; lx++) {
        const x = c.cx * CHUNK + lx, y = c.cy * CHUNK + ly;
        const v = this.rawHeight(x, y);
        const terrain = World.classify(v);
        const t: Tile = {
          x, y, height: World.heightOf(terrain, v), terrain,
          tree: -1, rock: false, occupied: false, buildingId: -1,
          ruin: -1, explored: false,
        };
        // 森林遮罩 (草地上撒树)
        if (terrain === 'grass') {
          const m = this.n2.fbm(x * 0.085 + 11.7, y * 0.085 - 3.1, 3);
          if (m > 0.46 && hash2(x, y, this.seed) < 0.85) {
            const type = hash2(x, y, this.seed + 7) < 0.55 ? 0 : hash2(x, y, this.seed + 13) < 0.65 ? 1 : 2;
            const idx = this.trees.length;
            this.trees.push({
              x: x + (hash2(x, y, this.seed + 21) - 0.5) * 0.5,
              y: y + (hash2(x, y, this.seed + 22) - 0.5) * 0.5,
              type, scale: 0.75 + hash2(x, y, this.seed + 23) * 0.55,
              rot: hash2(x, y, this.seed + 24) * Math.PI * 2, hp: 3,
            });
            this.treeAt.set(World.key(x, y), idx);
            t.tree = idx;
            t.terrain = 'forest';
          }
        } else if (terrain === 'mountain' && hash2(x, y, this.seed + 31) < 0.22) {
          t.rock = true;
        }
        c.tiles[ly * CHUNK + lx] = t;
        this.stats[t.terrain]++;
      }
    }
    // 遗迹: 每区块约 34% 概率生成 1~2 处 (远离出生点, 避免营地重叠)
    const cr = hash2(c.cx, c.cy, this.seed + 991);
    if (cr < 0.34) {
      const nRuins = cr < 0.10 ? 2 : 1;
      for (let ri = 0; ri < nRuins; ri++) {
      const lx = 1 + Math.floor(hash2(c.cx, c.cy, this.seed + 992 + ri * 77) * (CHUNK - 2));
      const ly = 1 + Math.floor(hash2(c.cx, c.cy, this.seed + 993 + ri * 131) * (CHUNK - 2));
      const t = c.tiles[ly * CHUNK + lx];
      // 距出生点太近 (营地范围) 则跳过
      if (Math.max(Math.abs(t.x - this.spawn.x), Math.abs(t.y - this.spawn.y)) < 6) {
        // 不生成
      } else if (t.terrain === 'grass' || t.terrain === 'forest' || t.terrain === 'hill') {
        if (t.tree >= 0) { // 清掉树
          const tr = this.trees[t.tree]; if (tr) tr.dead = true;
          this.treeAt.delete(World.key(t.x, t.y));
          if (t.terrain === 'forest') { this.stats.forest--; this.stats.grass++; }
          t.terrain = 'grass';
          t.tree = -1;
        }
        if (t.ruin < 0) {
          const type = Math.floor(hash2(c.cx, c.cy, this.seed + 994 + ri * 17) * RUIN_TYPES.length) % RUIN_TYPES.length;
          const idx = this.ruins.length;
          this.ruins.push({ x: t.x, y: t.y, type, scavenged: false });
          this.ruinAt.set(World.key(t.x, t.y), idx);
          t.ruin = idx;
        }
      }
      }
    }
  }

  // ---------- 迷雾 ----------
  /** 揭开圆形视野, 返回新揭开的格数 */
  reveal(cx: number, cy: number, r: number): number {
    let n = 0;
    const r2 = r * r;
    for (let dy = -r; dy <= r; dy++) {
      for (let dx = -r; dx <= r; dx++) {
        if (dx * dx + dy * dy > r2) continue;
        const x = cx + dx, y = cy + dy;
        const t = this.ensure(x, y); // 生成区块
        if (!t.explored) {
          t.explored = true;
          const ch = this.chunkOf(x, y)!;
          ch.revealed++;
          ch.dirty = true;
          n++;
        }
      }
    }
    if (n > 0) this.revealVersion++;
    return n;
  }

  isExplored(x: number, y: number): boolean {
    const t = this.peek(x, y);
    return !!t && t.explored;
  }

  /** 该区块是否有任何已探索格 */
  chunkExplored(cx: number, cy: number): boolean {
    const c = this.chunks.get(World.chunkKey(cx, cy));
    return !!c && c.revealed > 0;
  }

  // ---------- 出生点: 纯噪声搜索 (不生成区块) ----------
  private findSpawn(): { x: number; y: number } {
    let best: { x: number; y: number } | null = null;
    let bestScore = -1;
    for (let r = 0; r <= 56 && !best; r += 1) {
      // 沿螺旋采样
      const pts: [number, number][] = [];
      if (r === 0) pts.push([0, 0]);
      else {
        for (let i = -r; i <= r; i++) {
          pts.push([i, -r], [i, r], [-r, i], [r, i]);
        }
      }
      for (const [x, y] of pts) {
        const v = this.rawHeight(x, y);
        const t = World.classify(v);
        if (t !== 'grass' && t !== 'forest') continue;
        // 3×3 平坦可建
        let ok = true;
        for (let dy = -1; dy <= 1 && ok; dy++)
          for (let dx = -1; dx <= 1 && ok; dx++) {
            const tt = World.classify(this.rawHeight(x + dx, y + dy));
            if (tt === 'water' || tt === 'mountain') ok = false;
          }
        if (!ok) continue;
        // 10 格内有水
        let nearWater = false;
        for (let dy = -10; dy <= 10 && !nearWater; dy += 2)
          for (let dx = -10; dx <= 10 && !nearWater; dx += 2) {
            if (World.classify(this.rawHeight(x + dx, y + dy)) === 'water') nearWater = true;
          }
        if (!nearWater) continue;
        let grass = 0;
        for (let dy = -6; dy <= 6; dy += 2)
          for (let dx = -6; dx <= 6; dx += 2) {
            const tt = World.classify(this.rawHeight(x + dx, y + dy));
            if (tt === 'grass' || tt === 'forest') grass++;
          }
        const score = grass - r * 0.6 + hash2(x, y, this.seed) * 6;
        if (score > bestScore) { bestScore = score; best = { x, y }; }
      }
    }
    if (best) return best;
    // 兜底: 原点强制平原 (生成后改造)
    this.ensureChunk(0, 0);
    for (let dy = -3; dy <= 3; dy++)
      for (let dx = -3; dx <= 3; dx++) {
        const t = this.ensure(dx, dy);
        if (t.terrain === 'water' || t.terrain === 'mountain') {
          if (t.tree >= 0) this.killTree(t.x, t.y);
          this.stats[t.terrain]--;
          t.terrain = 'grass'; t.height = 0.06; this.stats.grass++;
        }
      }
    // 旁边挖一个保底小湖
    for (let dy = -2; dy <= 2; dy++)
      for (let dx = -2; dx <= 2; dx++) {
        if (dx * dx + dy * dy > 5) continue;
        const t = this.ensure(6 + dx, 0 + dy);
        if (t.tree >= 0) this.killTree(t.x, t.y);
        if (!t.occupied && t.terrain !== 'water') { this.stats[t.terrain]--; t.terrain = 'water'; t.height = -0.16; this.stats.water++; }
      }
    return { x: 0, y: 0 };
  }

  /** 标记树死亡 (不发放资源) */
  killTree(x: number, y: number) {
    const t = this.peek(x, y);
    if (!t || t.tree < 0) return;
    const tr = this.trees[t.tree];
    if (tr) tr.dead = true;
    this.treeAt.delete(World.key(x, y));
    t.tree = -1;
    if (t.terrain === 'forest') { this.stats.forest--; this.stats.grass++; t.terrain = 'grass'; }
  }

  /** 新增一棵树 (再生) */
  addTree(x: number, y: number, scale = 0.55) {
    const t = this.ensure(x, y);
    const idx = this.trees.length;
    this.trees.push({
      x: x + (hash2(x, y, 77) - 0.5) * 0.5, y: y + (hash2(x, y, 78) - 0.5) * 0.5,
      type: Math.floor(hash2(x, y, 79) * 3), scale, rot: hash2(x, y, 80) * Math.PI * 2, hp: 3,
    });
    this.treeAt.set(World.key(x, y), idx);
    if (t.terrain === 'grass') { this.stats.grass--; this.stats.forest++; }
    t.tree = idx;
    t.terrain = 'forest';
    return idx;
  }
}

// ---------- 兼容旧接口 (供渐进迁移) ----------
export type TerrainResult = World;
export function tileIndex(x: number, y: number) { return World.key(x, y); }
