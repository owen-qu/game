// ===== 荒野筑城 · 电影化主菜单演示场景 =====
// 主菜单背后的实时 3D"序章": 同一片土地上, 城市从部落篝火一路生长为摩天都市。
// 五幕轮转 (每幕约 14 秒), 电影运镜 + 昼夜流转 + 黑场转场, 全程序化生成。
import * as THREE from 'three';
import { GRID } from './constants';
import { World, mulberry32 } from './terrain';
import type { Tile } from './types';
import { buildModel, treeGeometries, citizenBodyGeometry, citizenHeadGeometry, carGeometry, cartGeometry, mat } from './models';

/** 菜单场景地形: 从无限世界中截取出生点周围 80×80 的有界窗口 (保持旧坐标系) */
interface MenuTerrain {
  tiles: Tile[];
  trees: { x: number; y: number; type: number; scale: number; rot: number; hp: number; dead?: boolean }[];
  spawn: { x: number; y: number };
}
function menuTerrain(seed: number): MenuTerrain {
  const world = new World(seed);
  const s = world.spawn;
  world.reveal(s.x, s.y, 30);
  const ox = s.x - GRID / 2, oy = s.y - GRID / 2;
  const tiles: Tile[] = [];
  for (let y = 0; y < GRID; y++)
    for (let x = 0; x < GRID; x++) {
      const wt = world.ensure(ox + x, oy + y);
      tiles.push({ ...wt, x, y });
    }
  const trees = world.trees
    .filter(t => !t.dead && t.x >= ox && t.x < ox + GRID && t.y >= oy && t.y < oy + GRID)
    .map(t => ({ ...t, x: t.x - ox, y: t.y - oy }));
  return { tiles, trees, spawn: { x: Math.floor(GRID / 2), y: Math.floor(GRID / 2) } };
}
const tileIdx = (x: number, y: number) => y * GRID + x;

// ---------- 幕次编排 ----------
export interface MenuEraInfo { index: number; name: string; slogan: string; hour: number; dist: number; phi: number; lookY: number; }
export const MENU_ERAS: MenuEraInfo[] = [
  { index: 0, name: '荒野部落', slogan: '几个人, 一片荒野, 篝火与星空', hour: 6.4, dist: 13, phi: 1.0, lookY: 0.8 },
  { index: 1, name: '农耕村落', slogan: '春种秋收, 鸡犬相闻', hour: 10.5, dist: 18, phi: 0.97, lookY: 1.2 },
  { index: 2, name: '工业城镇', slogan: '机器轰鸣, 烟囱林立', hour: 16.9, dist: 26, phi: 0.92, lookY: 9.5 },
  { index: 3, name: '电气都市', slogan: '灯火通明, 车水马龙', hour: 19.4, dist: 34, phi: 1.1, lookY: 9 },
  { index: 4, name: '现代都会', slogan: '摩天大楼刺破天际, 你的城市与世界相连', hour: 21.6, dist: 46, phi: 1.0, lookY: 15 },
];;
const ACT_HOLD = 12.5;   // 每幕停留
const FADE_TIME = 1.7;   // 黑场时长

interface CarAgent { x: number; z: number; dir: 0 | 1 | 2 | 3; speed: number; kind: 0 | 1; }
interface Walker { x: number; z: number; tx: number; tz: number; speed: number; phase: number; hue: number; }

function softDot(): THREE.Texture {
  const c = document.createElement('canvas'); c.width = c.height = 64;
  const ctx = c.getContext('2d')!;
  const g = ctx.createRadialGradient(32, 32, 2, 32, 32, 30);
  g.addColorStop(0, 'rgba(255,255,255,1)');
  g.addColorStop(0.4, 'rgba(255,255,255,0.55)');
  g.addColorStop(1, 'rgba(255,255,255,0)');
  ctx.fillStyle = g; ctx.fillRect(0, 0, 64, 64);
  return new THREE.CanvasTexture(c);
}

const TERRAIN_COLORS: Record<string, [number, number]> = {
  water: [0x2e6396, 0x27537f],
  sand: [0xd9c489, 0xcbb87c],
  grass: [0x5da24a, 0x549643],
  forest: [0x4a8a3c, 0x447e37],
  hill: [0x7fa35c, 0x71934f],
  mountain: [0x9aa1a8, 0x868d94],
};

export class MenuScene {
  private renderer: THREE.WebGLRenderer;
  private scene = new THREE.Scene();
  private camera: THREE.PerspectiveCamera;
  private canvas: HTMLCanvasElement;
  private raf = 0;
  private lastTime = performance.now();
  private time = 0;
  private disposed = false;
  private terrain: MenuTerrain;
  private occupied = new Set<number>();
  private terrainMesh!: THREE.Mesh;
  private ocean!: THREE.Mesh;
  private treeMeshes: THREE.InstancedMesh[] = [];
  private eraGroup = new THREE.Group();
  private sun!: THREE.DirectionalLight;
  private hemi!: THREE.HemisphereLight;
  private clouds: THREE.Group[] = [];
  private cloudMat!: THREE.MeshStandardMaterial;
  private stars!: THREE.Points;
  private moon!: THREE.Sprite;
  private dotTex = softDot();
  private particles: { spr: THREE.Sprite; life: number; maxLife: number; vx: number; vy: number; vz: number; grow: number; base: number }[] = [];
  private fadePlane!: THREE.Mesh;
  private windowMeshes: THREE.Mesh[] = [];
  private lampGlows: THREE.Sprite[] = [];
  private walkers: Walker[] = [];
  private bodyMesh!: THREE.InstancedMesh;
  private headMesh!: THREE.InstancedMesh;
  private cars: CarAgent[] = [];
  private carMesh!: THREE.InstancedMesh;
  private cartMesh!: THREE.InstancedMesh;
  private roadLines: { x: number; y: number; horizontal: boolean }[] = [];

  // 幕次状态
  private act = 0;               // 当前幕 0..4
  private actT = 0;              // 幕内计时
  private hour = MENU_ERAS[0].hour;
  // 运镜目标 (缓动)
  private camTheta = Math.PI * 0.8;
  private camDist = MENU_ERAS[0].dist;
  private camPhi = MENU_ERAS[0].phi;
  private tTheta = Math.PI * 0.8;
  private tDist = MENU_ERAS[0].dist;
  private tPhi = MENU_ERAS[0].phi;
  private tLookY = MENU_ERAS[0].lookY;
  private camLookY = MENU_ERAS[0].lookY;
  private camTarget = new THREE.Vector3();
  private rand: () => number;
  onEraChange: (era: number) => void = () => { };
  onAudioState: (era: number, hour: number) => void = () => { };

  constructor(canvas: HTMLCanvasElement, seed: number) {
    this.canvas = canvas;
    this.rand = mulberry32(seed ^ 0x51ab7f3a);
    this.terrain = menuTerrain(seed);

    this.renderer = new THREE.WebGLRenderer({ canvas, antialias: true, powerPreference: 'high-performance' });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 1.6));
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFShadowMap;
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;

    this.camera = new THREE.PerspectiveCamera(46, 1, 0.1, 900);
    this.scene.fog = new THREE.Fog(0x87b5d4, 32, 175);

    const s = this.terrain.spawn;
    this.camTarget.set(s.x - GRID / 2 + 0.5, 0, s.y - GRID / 2 + 0.5);

    this.setupLights();
    this.buildTerrainMesh();
    this.buildOcean();
    this.buildTrees();
    this.buildSky();
    this.buildClouds();
    this.buildAgents();
    this.buildFade();
    this.scene.add(this.eraGroup);
    this.buildAct(0);
    this.resize();
    window.addEventListener('resize', this.resize);
    document.addEventListener('visibilitychange', this.onVisible);
    this.loop();
  }

  // ---------- 光照 ----------
  private setupLights() {
    this.hemi = new THREE.HemisphereLight(0xcfe8ff, 0x6b7c5a, 0.75);
    this.scene.add(this.hemi);
    this.sun = new THREE.DirectionalLight(0xfff2d9, 1.6);
    this.sun.castShadow = true;
    this.sun.shadow.mapSize.set(1536, 1536);
    const sc = this.sun.shadow.camera as THREE.OrthographicCamera;
    sc.left = -46; sc.right = 46; sc.top = 46; sc.bottom = -46; sc.near = 1; sc.far = 260;
    this.sun.shadow.bias = -0.0006;
    this.scene.add(this.sun, this.sun.target);
    this.scene.add(new THREE.AmbientLight(0xffffff, 0.1));
  }

  private dispH(t: { terrain: string; height: number }): number {
    if (t.terrain === 'water') return Math.min(-0.08, t.height);
    if (t.terrain === 'grass' || t.terrain === 'forest') return 0.04 + (t.height - 0.04) * 0.5;
    return t.height;
  }
  private heightAt(x: number, y: number): number {
    const t = this.terrain.tiles[tileIdx(x, y)];
    return t ? this.dispH(t) : 0.05;
  }

  // ---------- 地表 ----------
  private buildTerrainMesh() {
    const { tiles } = this.terrain;
    const positions: number[] = [];
    const colors: number[] = [];
    const col = new THREE.Color();
    const tileColor = (t: { terrain: string; height: number; x: number; y: number }) => {
      const pair = TERRAIN_COLORS[t.terrain] ?? TERRAIN_COLORS.grass;
      const n = ((t.x * 7 + t.y * 13) % 5) / 5;
      col.setHex(pair[0]).lerp(new THREE.Color(pair[1]), n);
      if (t.terrain === 'mountain' && t.height > 1.6) col.lerp(new THREE.Color(0xe8eef2), Math.min(0.8, (t.height - 1.6) / 1.2));
      return col.clone();
    };
    const push = (x: number, y: number, z: number, c: THREE.Color) => { positions.push(x, y, z); colors.push(c.r, c.g, c.b); };
    for (const t of tiles) {
      const c = tileColor(t);
      const h = this.dispH(t);
      const x0 = t.x - GRID / 2, z0 = t.y - GRID / 2;
      push(x0, h, z0, c); push(x0, h, z0 + 1, c); push(x0 + 1, h, z0 + 1, c);
      push(x0, h, z0, c); push(x0 + 1, h, z0 + 1, c); push(x0 + 1, h, z0, c);
    }
    // 悬崖侧壁
    const wall = (ax: number, az: number, bx: number, bz: number, hTop: number, hBot: number, c: THREE.Color) => {
      push(ax, hTop, az, c); push(bx, hBot, bz, c); push(bx, hTop, bz, c);
      push(ax, hTop, az, c); push(ax, hBot, az, c); push(bx, hBot, bz, c);
    };
    for (const t of tiles) {
      const h = this.dispH(t);
      const x0 = t.x - GRID / 2, z0 = t.y - GRID / 2;
      const cDark = tileColor(t).multiplyScalar(0.68);
      for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]] as const) {
        const nx = t.x + dx, ny = t.y + dy;
        let nh: number;
        if (nx < 0 || ny < 0 || nx >= GRID || ny >= GRID) nh = -0.5;
        else nh = this.dispH(tiles[tileIdx(nx, ny)]);
        if (h - nh <= 0.07) continue;
        if (dx === 1) wall(x0 + 1, z0, x0 + 1, z0 + 1, h, nh, cDark);
        else if (dx === -1) wall(x0, z0 + 1, x0, z0, h, nh, cDark);
        else if (dy === 1) wall(x0 + 1, z0 + 1, x0, z0 + 1, h, nh, cDark);
        else wall(x0, z0, x0 + 1, z0, h, nh, cDark);
      }
    }
    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
    geo.setAttribute('color', new THREE.Float32BufferAttribute(colors, 3));
    geo.computeVertexNormals();
    this.terrainMesh = new THREE.Mesh(geo, new THREE.MeshStandardMaterial({ vertexColors: true, flatShading: true, roughness: 0.95, side: THREE.DoubleSide }));
    this.terrainMesh.receiveShadow = true;
    this.scene.add(this.terrainMesh);
  }

  private buildOcean() {
    const geo = new THREE.PlaneGeometry(800, 800, 56, 56);
    geo.rotateX(-Math.PI / 2);
    const m = new THREE.MeshStandardMaterial({ color: 0x3a86b8, transparent: true, opacity: 0.88, roughness: 0.22, metalness: 0.05 });
    this.ocean = new THREE.Mesh(geo, m);
    this.ocean.position.set(GRID / 2 - 0.5, -0.06, GRID / 2 - 0.5);
    this.scene.add(this.ocean);
  }

  private buildTrees() {
    const geos = treeGeometries();
    const trees = this.terrain.trees;
    const cap = trees.length + 64;
    const trunkMat = mat(0x6b4423, { roughness: 1 });
    const mats = [mat(0x2f6b3a, { roughness: 1 }), mat(0x4c8c3f, { roughness: 1 }), mat(0x9db06a, { roughness: 1 })];
    this.treeMeshes = [
      new THREE.InstancedMesh(geos.trunk, trunkMat, cap),
      new THREE.InstancedMesh(geos.pine, mats[0], cap),
      new THREE.InstancedMesh(geos.oak, mats[1], cap),
      new THREE.InstancedMesh(geos.birch, mats[2], cap),
    ];
    const counts = [0, 0, 0, 0];
    const mtx = new THREE.Matrix4();
    const q = new THREE.Quaternion();
    for (const t of trees) {
      if (t.dead) continue;
      const h = this.heightAt(Math.floor(t.x), Math.floor(t.y));
      q.setFromAxisAngle(new THREE.Vector3(0, 1, 0), t.rot);
      mtx.compose(new THREE.Vector3(t.x - GRID / 2 + 0.5, h, t.y - GRID / 2 + 0.5), q, new THREE.Vector3(t.scale, t.scale, t.scale));
      this.treeMeshes[0].setMatrixAt(counts[0]++, mtx);
      const ti = Math.max(0, Math.min(2, t.type));
      this.treeMeshes[ti + 1].setMatrixAt(counts[ti + 1]++, mtx);
    }
    for (let i = 0; i < 4; i++) {
      this.treeMeshes[i].count = counts[i];
      this.treeMeshes[i].instanceMatrix.needsUpdate = true;
      this.treeMeshes[i].castShadow = true; this.treeMeshes[i].receiveShadow = true;
      this.scene.add(this.treeMeshes[i]);
    }
  }

  private buildSky() {
    // 星空穹顶
    const N = 700;
    const geo = new THREE.BufferGeometry();
    const pos = new Float32Array(N * 3);
    for (let i = 0; i < N; i++) {
      const a = Math.random() * Math.PI * 2;
      // 幂次偏置: 星星向低空集中, 更容易被电影构图捕捉
      const e = Math.pow(Math.random(), 1.6) * Math.PI * 0.48;
      const r = 420;
      pos[i * 3] = Math.cos(a) * Math.cos(e) * r;
      pos[i * 3 + 1] = Math.sin(e) * r + 40;
      pos[i * 3 + 2] = Math.sin(a) * Math.cos(e) * r;
    }
    geo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
    const m = new THREE.PointsMaterial({ color: 0xe8efff, size: 4.0, map: this.dotTex, transparent: true, opacity: 0, depthWrite: false, sizeAttenuation: true, blending: THREE.AdditiveBlending });
    (m as any).fog = false;
    this.stars = new THREE.Points(geo, m);
    this.stars.position.set(GRID / 2 - 0.5, 0, GRID / 2 - 0.5);
    this.scene.add(this.stars);
    // 月亮
    const cv = document.createElement('canvas'); cv.width = cv.height = 128;
    const ctx = cv.getContext('2d')!;
    const g = ctx.createRadialGradient(64, 64, 20, 64, 64, 62);
    g.addColorStop(0, 'rgba(255,252,240,1)');
    g.addColorStop(0.55, 'rgba(250,246,228,0.96)');
    g.addColorStop(0.66, 'rgba(244,240,224,0.55)');
    g.addColorStop(0.8, 'rgba(240,236,220,0.16)');
    g.addColorStop(1, 'rgba(240,236,220,0)');
    ctx.fillStyle = g; ctx.beginPath(); ctx.arc(64, 64, 62, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = 'rgba(215,210,195,0.5)';
    ctx.beginPath(); ctx.arc(50, 52, 9, 0, Math.PI * 2); ctx.fill();
    ctx.beginPath(); ctx.arc(74, 70, 6, 0, Math.PI * 2); ctx.fill();
    const tex = new THREE.CanvasTexture(cv);
    const mm = new THREE.SpriteMaterial({ map: tex, transparent: true, opacity: 0, depthWrite: false });
    (mm as any).fog = false;
    this.moon = new THREE.Sprite(mm);
    this.moon.scale.set(46, 46, 1);
    this.moon.position.set(0, 150, 0);
    this.scene.add(this.moon);
  }

  private buildClouds() {
    this.cloudMat = new THREE.MeshStandardMaterial({ color: 0xffffff, transparent: true, opacity: 0.7, roughness: 1, flatShading: true });
    for (let i = 0; i < 9; i++) {
      const g = new THREE.Group();
      for (let j = 0; j < 3; j++) {
        const s = new THREE.Mesh(new THREE.SphereGeometry(1.6 + Math.random() * 2.0, 6, 5), this.cloudMat);
        s.position.set((Math.random() - 0.5) * 5, (Math.random() - 0.5) * 0.7, (Math.random() - 0.5) * 3.4);
        s.scale.y = 0.42;
        g.add(s);
      }
      // 高空云层: 避免低机位时在地平线处形成突兀的灰白块
      g.position.set((Math.random() - 0.5) * 150, 38 + Math.random() * 12, (Math.random() - 0.5) * 150);
      this.clouds.push(g);
      this.scene.add(g);
    }
  }

  private buildAgents() {
    this.bodyMesh = new THREE.InstancedMesh(citizenBodyGeometry(),
      new THREE.MeshStandardMaterial({ flatShading: true, roughness: 0.9, vertexColors: true }), 12);
    this.headMesh = new THREE.InstancedMesh(citizenHeadGeometry(),
      new THREE.MeshStandardMaterial({ flatShading: true, roughness: 0.85, vertexColors: true }), 12);
    this.bodyMesh.castShadow = this.headMesh.castShadow = true;
    this.bodyMesh.count = this.headMesh.count = 0;
    this.bodyMesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
    this.headMesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
    this.scene.add(this.bodyMesh, this.headMesh);
    this.carMesh = new THREE.InstancedMesh(carGeometry(),
      new THREE.MeshStandardMaterial({ flatShading: true, roughness: 0.4, metalness: 0.3, vertexColors: true }), 14);
    this.cartMesh = new THREE.InstancedMesh(cartGeometry(),
      new THREE.MeshStandardMaterial({ flatShading: true, roughness: 0.9, vertexColors: true }), 8);
    this.carMesh.castShadow = this.cartMesh.castShadow = true;
    this.carMesh.count = this.cartMesh.count = 0;
    this.carMesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
    this.cartMesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
    this.scene.add(this.carMesh, this.cartMesh);
  }

  private buildFade() {
    const geo = new THREE.PlaneGeometry(30, 30);
    const m = new THREE.MeshBasicMaterial({ color: 0x000000, transparent: true, opacity: 0, depthTest: false, depthWrite: false, fog: false });
    this.fadePlane = new THREE.Mesh(geo, m);
    this.fadePlane.position.set(0, 0, -1);
    this.fadePlane.renderOrder = 999;
    this.camera.add(this.fadePlane);
    this.scene.add(this.camera);
  }

  // ---------- 建筑摆放 ----------
  private clearGroup(g: THREE.Group) {
    for (const child of [...g.children]) {
      g.remove(child);
      child.traverse((o) => {
        const m = o as THREE.Mesh;
        if (m.isMesh && m.geometry) m.geometry.dispose();
      });
    }
  }

  /** 在 (cx,cy) 附近找空草地 (螺旋搜索) */
  private findSpot(cx: number, cy: number, r = 10): { x: number; y: number } | null {
    for (let rad = 0; rad <= r; rad++) {
      for (let dy = -rad; dy <= rad; dy++)
        for (let dx = -rad; dx <= rad; dx++) {
          if (Math.max(Math.abs(dx), Math.abs(dy)) !== rad) continue;
          const x = cx + dx, y = cy + dy;
          if (x < 1 || y < 1 || x >= GRID - 1 || y >= GRID - 1) continue;
          const i = tileIdx(x, y);
          if (this.occupied.has(i)) continue;
          const t = this.terrain.tiles[i];
          if (t.terrain === 'water' || t.terrain === 'mountain' || t.tree >= 0) continue;
          return { x, y };
        }
    }
    return null;
  }

  private place(defId: string, x: number, y: number, rot = 0): THREE.Group | null {
    const i = tileIdx(x, y);
    if (this.occupied.has(i)) return null;
    const g = buildModel(defId);
    g.position.set(x - GRID / 2 + 0.5, this.heightAt(x, y), y - GRID / 2 + 0.5);
    g.rotation.y = rot * Math.PI / 2;
    g.traverse(o => {
      const m = o as THREE.Mesh;
      if (m.isMesh) {
        m.castShadow = true; m.receiveShadow = true;
        if ((m as any).isWindowMesh) this.windowMeshes.push(m);
      }
    });
    this.eraGroup.add(g);
    this.occupied.add(i);
    return g;
  }

  private placeNear(defId: string, cx: number, cy: number, rot = 0): THREE.Group | null {
    const spot = this.findSpot(cx, cy);
    return spot ? this.place(defId, spot.x, spot.y, rot) : null;
  }

  /** 直线道路 */
  private layRoad(defId: string, x0: number, y0: number, len: number, horizontal: boolean) {
    for (let k = 0; k < len; k++) {
      const x = horizontal ? x0 + k : x0;
      const y = horizontal ? y0 : y0 + k;
      if (x < 1 || y < 1 || x >= GRID - 1 || y >= GRID - 1) break;
      const i = tileIdx(x, y);
      if (this.occupied.has(i)) continue;
      const t = this.terrain.tiles[i];
      if (t.terrain === 'water' || t.terrain === 'mountain') continue;
      const g = buildModel(defId);
      g.position.set(x - GRID / 2 + 0.5, this.heightAt(x, y), y - GRID / 2 + 0.5);
      if (!horizontal) g.rotation.y = Math.PI / 2;
      this.eraGroup.add(g);
      this.occupied.add(i);
      this.roadLines.push({ x, y, horizontal });
      // 路灯夜光
      if (k % 2 === 0) {
        const spr = new THREE.Sprite(new THREE.SpriteMaterial({ map: this.dotTex, color: 0xffc46b, transparent: true, opacity: 0, blending: THREE.AdditiveBlending, depthWrite: false }));
        spr.scale.setScalar(0.9);
        spr.position.set(g.position.x, this.heightAt(x, y) + 0.55, g.position.z);
        this.eraGroup.add(spr);
        this.lampGlows.push(spr);
      }
    }
  }

  // ---------- 各幕布景 ----------
  private buildAct(era: number) {
    this.clearGroup(this.eraGroup);
    this.occupied.clear();
    this.windowMeshes = [];
    this.lampGlows = [];
    this.roadLines = [];
    this.walkers = [];
    this.cars = [];
    const s = this.terrain.spawn;
    const cx = s.x, cy = s.y;

    if (era === 0) {
      // 第一幕: 篝火营地
      this.place('campfire', cx, cy);
      const ring: [number, number][] = [[-2, -1], [2, -1], [-2, 2], [2, 2], [0, -2], [0, 3], [-3, 0], [3, 1]];
      for (const [dx, dy] of ring) this.placeNear('tent', cx + dx, cy + dy, (dx + dy + 4) % 4);
      this.placeNear('totem', cx + 4, cy - 3);
      this.placeNear('berry', cx - 4, cy + 3);
      this.placeNear('berry', cx - 5, cy + 1);
      this.placeNear('lumber', cx + 5, cy + 4);
      for (let i = 0; i < 5; i++) this.spawnWalker(cx, cy, 5);
    } else if (era === 1) {
      // 第二幕: 农耕村落
      this.placeNear('well', cx, cy);
      const homes: [number, number][] = [[-3, -2], [-2, -3], [2, -3], [3, -2], [-3, 2], [3, 3], [0, -4], [-1, 4]];
      for (const [dx, dy] of homes) this.placeNear('hut', cx + dx, cy + dy);
      this.placeNear('longhouse', cx + 5, cy - 4);
      for (const [dx, dy] of [[-5, 0], [-5, 2], [5, 1], [5, 3]]) this.placeNear('farm', cx + dx, cy + dy);
      this.placeNear('orchard', cx - 5, cy - 3);
      this.placeNear('pasture', cx + 6, cy + 5);
      this.placeNear('church', cx + 1, cy - 6);
      this.placeNear('granary', cx - 6, cy + 5);
      for (const [dx, dy] of [[1, 3], [-1, -5]]) this.placeNear('wood_house', cx + dx, cy + dy);
      for (let i = 0; i < 7; i++) this.spawnWalker(cx, cy, 7);
    } else if (era === 2) {
      // 第三幕: 工业城镇
      this.layRoad('gravel', cx - 6, cy, 13, true);
      for (const [dx, dy] of [[-5, -2], [-3, -2], [-1, -2], [1, -2], [3, -2], [-4, 1], [-2, 1], [0, 1], [2, 1]]) this.placeNear('stone_house', cx + dx, cy + dy);
      this.placeNear('townhouse', cx + 5, cy - 3);
      this.placeNear('market', cx - 4, cy + 3);
      this.placeNear('factory', cx + 7, cy + 3);
      this.placeNear('coal_plant', cx + 10, cy + 6);
      this.placeNear('workshop', cx - 6, cy - 4);
      this.placeNear('train_station', cx - 8, cy - 1);
      for (let i = 0; i < 4; i++) this.spawnWalker(cx, cy, 8);
    } else if (era === 3) {
      // 第四幕: 电气都市
      this.layRoad('paved', cx - 8, cy, 17, true);
      this.layRoad('paved', cx, cy - 6, 13, false);
      for (const [dx, dy] of [[-6, -2], [-4, -2], [4, -2], [6, -2], [-6, 2], [6, 2]]) this.placeNear('apartment', cx + dx, cy + dy);
      this.placeNear('school', cx - 2, cy + 3);
      this.placeNear('hospital', cx + 2, cy + 3);
      this.placeNear('bank', cx - 2, cy - 3);
      this.placeNear('water_tower', cx + 8, cy - 5);
      this.placeNear('solar', cx - 9, cy + 5);
      this.placeNear('wind', cx + 10, cy + 4);
      this.placeNear('broadcast', cx - 10, cy - 6);
      for (let i = 0; i < 7; i++) this.spawnCar(1);
      for (let i = 0; i < 2; i++) this.spawnWalker(cx, cy, 9);
    } else {
      // 第五幕: 现代都会之夜
      this.layRoad('highway', cx - 11, cy, 23, true);
      this.layRoad('highway', cx, cy - 8, 17, false);
      this.layRoad('highway', cx - 11, cy + 6, 23, true);
      this.placeNear('skyscraper', cx, cy + 2);
      this.placeNear('skyscraper', cx - 4, cy - 2);
      this.placeNear('skyscraper', cx + 4, cy - 2);
      this.placeNear('condo', cx - 7, cy + 2);
      this.placeNear('condo', cx + 7, cy + 2);
      this.placeNear('office', cx - 2, cy - 5);
      this.placeNear('office', cx + 3, cy - 5);
      this.placeNear('mall', cx - 7, cy - 5);
      this.placeNear('park', cx + 8, cy - 4);
      this.placeNear('nuclear', cx + 13, cy + 8);
      this.placeNear('stadium', cx - 12, cy + 9);
      for (let i = 0; i < 10; i++) this.spawnCar(1);
    }
  }

  private spawnWalker(cx: number, cy: number, r: number) {
    const a = Math.random() * Math.PI * 2;
    const d = Math.random() * r;
    this.walkers.push({
      x: cx - GRID / 2 + 0.5 + Math.cos(a) * d,
      z: cy - GRID / 2 + 0.5 + Math.sin(a) * d,
      tx: 0, tz: 0, speed: 0.34 + Math.random() * 0.22,
      phase: Math.random() * 10, hue: (Math.random() * 0.95 + 0.03) % 1,
    });
    const w = this.walkers[this.walkers.length - 1];
    const p = this.pickWalkerPoint();
    w.tx = p[0]; w.tz = p[1];
  }

  private pickWalkerPoint(): [number, number] {
    // 在演示建筑附近游荡
    const children = this.eraGroup.children;
    if (children.length > 0) {
      const c = children[Math.floor(Math.random() * Math.min(children.length, 24))];
      return [c.position.x + (Math.random() - 0.5) * 2.2, c.position.z + (Math.random() - 0.5) * 2.2];
    }
    const s = this.terrain.spawn;
    return [s.x - GRID / 2 + 0.5 + (Math.random() - 0.5) * 6, s.y - GRID / 2 + 0.5 + (Math.random() - 0.5) * 6];
  }

  private spawnCar(kind: 0 | 1) {
    if (this.roadLines.length === 0) return;
    const line = this.roadLines[Math.floor(Math.random() * this.roadLines.length)];
    this.cars.push({
      x: line.x - GRID / 2 + 0.5, z: line.y - GRID / 2 + 0.5,
      dir: (line.horizontal ? (Math.random() < 0.5 ? 0 : 1) : (Math.random() < 0.5 ? 2 : 3)) as 0 | 1 | 2 | 3,
      speed: (kind === 1 ? 1.6 : 0.7) + Math.random() * 0.5, kind,
    });
  }

  // ---------- 昼夜 / 天气 ----------
  private updateDayNight(dt: number) {
    const info = MENU_ERAS[this.act];
    // 小时平滑趋向该幕设定
    let target = info.hour;
    const diff = ((target - this.hour + 36) % 24) - 12;
    this.hour = (this.hour + Math.sign(diff) * Math.min(Math.abs(diff), dt * 2.2) + 24) % 24;
    const dayT = (this.hour - 5.5) / 13;
    const isDay = dayT >= 0 && dayT <= 1;
    const angle = isDay ? dayT * Math.PI : Math.PI;
    const sunH = isDay ? Math.sin(angle) : -0.2;
    const cx = this.camTarget.x, cz = this.camTarget.z;
    this.sun.position.set(cx + Math.cos(angle) * 60, 12 + Math.max(0, sunH) * 60, cz - 24);
    this.sun.target.position.set(cx, 0, cz);
    const nightFactor = isDay ? Math.max(0, Math.min(1, sunH * 1.8)) : 0;
    const duskGlow = isDay ? Math.max(0, 1 - Math.abs(sunH) * 4) : 0;
    this.sun.intensity = 0.34 + nightFactor * 1.4;
    this.sun.color.setHSL(0.09 + nightFactor * 0.04, 0.5 - nightFactor * 0.3 + duskGlow * 0.35, 0.55 + nightFactor * 0.3);
    this.hemi.intensity = 0.4 + nightFactor * 0.4;
    this.hemi.color.setHex(nightFactor > 0.15 ? 0xcfe8ff : 0x2c3a58);

    const skyDay = new THREE.Color(0x87b5d4);
    const skyNight = new THREE.Color(0x151f38);
    const skyDusk = new THREE.Color(0xe8946a);
    const sky = skyNight.clone().lerp(skyDay, nightFactor);
    if (duskGlow > 0) sky.lerp(skyDusk, duskGlow * 0.55);
    // 城市光污染: 夜晚地平线泛起暖光
    if (nightFactor < 0.3) sky.lerp(new THREE.Color(0x32344a), (0.3 - nightFactor) * 0.55);
    if (this.scene.background instanceof THREE.Color) (this.scene.background as THREE.Color).copy(sky);
    else this.scene.background = sky.clone();
    (this.scene.fog as THREE.Fog).color.copy(sky);
    // 夜晚云层变暗变淡, 避免灰白突兀
    this.cloudMat.opacity = 0.18 + nightFactor * 0.5;
    this.cloudMat.color.setHex(nightFactor > 0.35 ? 0xffffff : 0x2e3a54);

    // 窗户灯光
    const lit = 1 - nightFactor;
    for (const m of this.windowMeshes) (m.material as THREE.MeshStandardMaterial).emissiveIntensity = lit * 3.0;
    // 路灯
    for (const s of this.lampGlows) (s.material as THREE.SpriteMaterial).opacity = lit * 0.95;
    // 星空与月亮
    const starO = Math.max(0, 1 - nightFactor * 1.6);
    (this.stars.material as THREE.PointsMaterial).opacity = Math.min(1, starO * 1.05);
    (this.stars as any).rotation.y = this.time * 0.004;
    this.stars.visible = starO > 0.02;
    const mo = Math.max(0, 1 - nightFactor * 1.4);
    (this.moon.material as THREE.SpriteMaterial).opacity = mo * 0.75;
    this.moon.visible = mo > 0.02;
    this.moon.scale.set(26, 26, 1);
    // 月亮挂在镜头前方天际线上 (跟随环绕方向, 避开标题居中区)
    const vdx = -Math.cos(this.camTheta), vdz = -Math.sin(this.camTheta);
    this.moon.position.set(
      this.camTarget.x + vdx * 205 - vdz * 78,
      20 + Math.sin(this.time * 0.02) * 2.5,
      this.camTarget.z + vdz * 205 + vdx * 78,
    );
    return nightFactor;
  }

  // ---------- 粒子 ----------
  private spawnParticle(x: number, y: number, z: number, opts: { color: number; life: number; vx: number; vy: number; vz: number; size: number; grow: number; opacity?: number; additive?: boolean }) {
    if (this.particles.length > 120) return;
    const spr = new THREE.Sprite(new THREE.SpriteMaterial({ map: this.dotTex, transparent: true, depthWrite: false }));
    spr.material.color.setHex(opts.color);
    (spr.material as THREE.SpriteMaterial).blending = opts.additive ? THREE.AdditiveBlending : THREE.NormalBlending;
    (spr.material as THREE.SpriteMaterial).opacity = opts.opacity ?? 0.8;
    spr.position.set(x, y, z);
    spr.scale.setScalar(opts.size);
    this.scene.add(spr);
    this.particles.push({ spr, life: opts.life, maxLife: opts.life, vx: opts.vx, vy: opts.vy, vz: opts.vz, grow: opts.grow, base: opts.opacity ?? 0.8 });
  }

  private updateParticles(dt: number) {
    for (let i = this.particles.length - 1; i >= 0; i--) {
      const p = this.particles[i];
      p.life -= dt;
      if (p.life <= 0) {
        this.scene.remove(p.spr);
        p.spr.material.dispose();
        this.particles.splice(i, 1);
        continue;
      }
      p.spr.position.x += p.vx * dt; p.spr.position.y += p.vy * dt; p.spr.position.z += p.vz * dt;
      const t = p.life / p.maxLife;
      (p.spr.material as THREE.SpriteMaterial).opacity = Math.min(1, t * 3) * p.base;
      p.spr.scale.addScalar(p.grow * dt);
    }
  }

  // ---------- 居民 / 车辆 ----------
  private updateWalkers(dt: number) {
    const mtx = new THREE.Matrix4();
    const q = new THREE.Quaternion();
    const col = new THREE.Color();
    this.bodyMesh.count = this.walkers.length;
    this.headMesh.count = this.walkers.length;
    for (let i = 0; i < this.walkers.length; i++) {
      const c = this.walkers[i];
      const dx = c.tx - c.x, dz = c.tz - c.z;
      const d = Math.hypot(dx, dz);
      if (d < 0.15) {
        const p = this.pickWalkerPoint();
        c.tx = p[0]; c.tz = p[1];
      } else {
        c.x += (dx / d) * c.speed * dt;
        c.z += (dz / d) * c.speed * dt;
      }
      const tx = Math.floor(c.x + GRID / 2), ty = Math.floor(c.z + GRID / 2);
      const h = (tx >= 0 && ty >= 0 && tx < GRID && ty < GRID) ? this.heightAt(tx, ty) : 0.05;
      const bob = Math.abs(Math.sin(this.time * 9 * c.speed + c.phase)) * 0.035;
      q.setFromAxisAngle(new THREE.Vector3(0, 1, 0), Math.atan2(dx, dz));
      mtx.compose(new THREE.Vector3(c.x, h + bob, c.z), q, new THREE.Vector3(1, 1, 1));
      this.bodyMesh.setMatrixAt(i, mtx);
      this.headMesh.setMatrixAt(i, mtx);
      col.setHSL(c.hue, 0.55, 0.5);
      this.bodyMesh.setColorAt(i, col);
    }
    this.bodyMesh.instanceMatrix.needsUpdate = true;
    this.headMesh.instanceMatrix.needsUpdate = true;
    if (this.bodyMesh.instanceColor) this.bodyMesh.instanceColor.needsUpdate = true;
  }

  private updateCars(dt: number) {
    const mtx = new THREE.Matrix4();
    const q = new THREE.Quaternion();
    let ci = 0, ki = 0;
    for (const c of this.cars) {
      const dx = c.dir === 0 ? 1 : c.dir === 1 ? -1 : 0;
      const dz = c.dir === 2 ? 1 : c.dir === 3 ? -1 : 0;
      c.x += dx * c.speed * dt; c.z += dz * c.speed * dt;
      // 出界或离路太远: 重新上路
      const tx = Math.floor(c.x + GRID / 2), ty = Math.floor(c.z + GRID / 2);
      const onRoad = this.roadLines.some(r => r.x === tx && r.y === ty);
      if (!onRoad && !this.roadLines.some(r => Math.abs(r.x - tx) <= 1 && Math.abs(r.y - ty) <= 1 && ((r.horizontal && dz === 0) || (!r.horizontal && dx === 0)))) {
        if (tx < 2 || ty < 2 || tx > GRID - 3 || ty > GRID - 3 || Math.random() < 0.2) {
          const line = this.roadLines[Math.floor(Math.random() * this.roadLines.length)];
          c.x = line.x - GRID / 2 + 0.5; c.z = line.y - GRID / 2 + 0.5;
          c.dir = (line.horizontal ? (Math.random() < 0.5 ? 0 : 1) : (Math.random() < 0.5 ? 2 : 3)) as 0 | 1 | 2 | 3;
        } else {
          // 尝试拐弯
          const cand = this.roadLines.filter(r => Math.abs(r.x - tx) <= 2 && Math.abs(r.y - ty) <= 2);
          if (cand.length > 0) {
            const nl = cand[Math.floor(Math.random() * cand.length)];
            c.x = nl.x - GRID / 2 + 0.5; c.z = nl.y - GRID / 2 + 0.5;
            c.dir = (nl.horizontal ? (Math.random() < 0.5 ? 0 : 1) : (Math.random() < 0.5 ? 2 : 3)) as 0 | 1 | 2 | 3;
          }
        }
      }
      // 靠右行驶偏移
      const lane = c.kind === 1 ? 0.17 : 0.14;
      const ox = -dz * lane, oz = dx * lane;
      const tx2 = Math.max(0, Math.min(GRID - 1, Math.floor(c.x + GRID / 2)));
      const ty2 = Math.max(0, Math.min(GRID - 1, Math.floor(c.z + GRID / 2)));
      const h = this.heightAt(tx2, ty2);
      q.setFromAxisAngle(new THREE.Vector3(0, 1, 0), Math.atan2(dx, dz));
      mtx.compose(new THREE.Vector3(c.x + ox, h + 0.02, c.z + oz), q, new THREE.Vector3(1, 1, 1));
      if (c.kind === 1) { if (ci < 14) this.carMesh.setMatrixAt(ci++, mtx); }
      else { if (ki < 8) this.cartMesh.setMatrixAt(ki++, mtx); }
    }
    this.carMesh.count = ci;
    this.cartMesh.count = ki;
    this.carMesh.instanceMatrix.needsUpdate = true;
    this.cartMesh.instanceMatrix.needsUpdate = true;
  }

  // ---------- 烟雾 / 火焰氛围 ----------
  private ambientFx(dt: number) {
    // 篝火 (第 1-2 幕)
    if (this.act <= 1 && this.rand() < dt * 26) {
      const s = this.terrain.spawn;
      this.spawnParticle(s.x - GRID / 2 + 0.5 + (Math.random() - 0.5) * 0.3, this.heightAt(s.x, s.y) + 0.25, s.y - GRID / 2 + 0.5 + (Math.random() - 0.5) * 0.3, {
        color: Math.random() < 0.5 ? 0xe8590c : 0xfab005, life: 0.7, vx: (Math.random() - 0.5) * 0.3, vy: 1.1 + Math.random() * 0.5, vz: (Math.random() - 0.5) * 0.3, size: 0.4, grow: 0.25, additive: true, opacity: 0.9,
      });
    }
    // 烟囱烟 (第 3 幕起)
    if (this.act >= 2 && this.rand() < dt * 4) {
      const children = this.eraGroup.children;
      if (children.length > 0) {
        const c = children[Math.floor(Math.random() * children.length)];
        if (c.position.length() < 200) {
          this.spawnParticle(c.position.x + (Math.random() - 0.5) * 0.6, c.position.y + 1.1, c.position.z + (Math.random() - 0.5) * 0.6, {
            color: 0x9aa0a6, life: 2.6, vx: 0.12 + (Math.random() - 0.5) * 0.1, vy: 0.5, vz: (Math.random() - 0.5) * 0.1, size: 0.18, grow: 0.3, opacity: 0.3,
          });
        }
      }
    }
  }

  // ---------- 相机 ----------
  private updateCamera(dt: number) {
    // 缓慢环绕 + 参数缓动
    this.tTheta += dt * 0.045;
    const k = 1 - Math.pow(0.0018, dt); // 平滑追踪系数
    this.camTheta += (this.tTheta - this.camTheta) * k;
    this.camDist += (this.tDist - this.camDist) * k;
    this.camPhi += (this.tPhi - this.camPhi) * k;
    this.camLookY += (this.tLookY - this.camLookY) * k;
    // 轻微呼吸起伏
    const breathe = Math.sin(this.time * 0.3) * 0.35;
    const sinPhi = Math.sin(this.camPhi);
    this.camera.position.set(
      this.camTarget.x + (this.camDist + breathe) * sinPhi * Math.cos(this.camTheta),
      this.camTarget.y + (this.camDist + breathe) * Math.cos(this.camPhi) + 1.2,
      this.camTarget.z + (this.camDist + breathe) * sinPhi * Math.sin(this.camTheta),
    );
    this.camera.lookAt(this.camTarget.x, this.camTarget.y + this.camLookY, this.camTarget.z);
  }

  // ---------- 主循环 ----------
  private loop = () => {
    if (this.disposed) return;
    this.raf = requestAnimationFrame(this.loop);
    const now = performance.now();
    const dt = Math.min(0.1, (now - this.lastTime) / 1000);
    this.lastTime = now;
    this.time += dt;
    this.actT += dt;

    // 幕次推进
    if (this.actT > ACT_HOLD + FADE_TIME) {
      this.actT = 0;
      this.act = (this.act + 1) % MENU_ERAS.length;
      this.buildAct(this.act);
      const info = MENU_ERAS[this.act];
      this.tDist = info.dist;
      this.tPhi = info.phi;
      this.tLookY = info.lookY;
      this.onEraChange(this.act);
      this.onAudioState(this.act, info.hour);
    }

    // 黑场 (幕末)。fadePlane 是摄像机子节点, 默认朝向镜头, 无需旋转。
    let fade = 0;
    if (this.actT > ACT_HOLD) fade = Math.sin(Math.min(1, (this.actT - ACT_HOLD) / FADE_TIME) * Math.PI);
    (this.fadePlane.material as THREE.MeshBasicMaterial).opacity = fade;

    const nightFactor = this.updateDayNight(dt);
    this.updateCamera(dt);
    this.updateWalkers(dt);
    this.updateCars(dt);
    this.ambientFx(dt);
    this.updateParticles(dt);
    // 海浪
    const pos = this.ocean.geometry.attributes.position as THREE.BufferAttribute;
    const arr = pos.array as Float32Array;
    for (let i = 0; i < arr.length; i += 3) {
      arr[i + 1] = -0.06 + Math.sin(this.time * 0.8 + arr[i] * 0.08) * 0.045 + Math.cos(this.time * 0.6 + arr[i + 2] * 0.1) * 0.04;
    }
    pos.needsUpdate = true;
    // 云
    for (const c of this.clouds) {
      c.position.x += dt * 0.35;
      if (c.position.x > 100) c.position.x = -100;
    }
    // 装饰动画 (风机旋转等)
    this.eraGroup.traverse(o => {
      const m = o as any;
      if (m.isWindRotor) m.rotation.z += dt * 2.2;
      else if (m.isRotor) m.rotation.y += dt * 6;
      else if (m.isBeacon) (m.material as THREE.MeshStandardMaterial).emissiveIntensity = 0.4 + (Math.sin(this.time * 5) > 0 ? 1.2 : 0.1);
      else if (m.isFlame) m.scale.setScalar(1 + Math.sin(this.time * 12) * 0.18);
    });
    void nightFactor;
    this.renderer.render(this.scene, this.camera);
  };

  private onVisible = () => {
    if (document.hidden) {
      cancelAnimationFrame(this.raf);
      this.raf = 0;
    } else if (!this.disposed && this.raf === 0) {
      this.lastTime = performance.now();
      this.loop();
    }
  };

  resize = () => {
    const w = this.canvas.clientWidth || window.innerWidth;
    const h = this.canvas.clientHeight || window.innerHeight;
    this.renderer.setSize(w, h, false);
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
  };

  dispose() {
    this.disposed = true;
    cancelAnimationFrame(this.raf);
    window.removeEventListener('resize', this.resize);
    document.removeEventListener('visibilitychange', this.onVisible);
    this.clearGroup(this.eraGroup);
    this.renderer.dispose();
  }
}
