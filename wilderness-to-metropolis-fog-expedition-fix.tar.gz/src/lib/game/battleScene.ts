// ===== 荒野筑城 · 3D 战斗舞台 (回合制的立体演出层) =====
// 只负责视觉: 阵型站位 / 攻击冲撞 / 投射物 / 受击震颤 / 倒地 / 镜头运镜。
// 逻辑全部在 battle.ts, 通过 BattleEvent 驱动演出。
import * as THREE from 'three';
import type { BattleUnit, BattleEvent, BattleState } from './types';
import { mat } from './models';

const B = {
  w: (g: THREE.Group, w: number, h: number, d: number, m: THREE.Material, x = 0, y = 0, z = 0) => {
    const mesh = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), m);
    mesh.position.set(x, y, z);
    mesh.castShadow = true;
    g.add(mesh);
    return mesh;
  },
  c: (g: THREE.Group, rt: number, rb: number, h: number, m: THREE.Material, x = 0, y = 0, z = 0, seg = 8) => {
    const mesh = new THREE.Mesh(new THREE.CylinderGeometry(rt, rb, h, seg), m);
    mesh.position.set(x, y, z);
    mesh.castShadow = true;
    g.add(mesh);
    return mesh;
  },
  s: (g: THREE.Group, r: number, m: THREE.Material, x = 0, y = 0, z = 0, seg = 8) => {
    const mesh = new THREE.Mesh(new THREE.SphereGeometry(r, seg, seg), m);
    mesh.position.set(x, y, z);
    mesh.castShadow = true;
    g.add(mesh);
    return mesh;
  },
  k: (g: THREE.Group, r: number, h: number, m: THREE.Material, x = 0, y = 0, z = 0, seg = 6) => {
    const mesh = new THREE.Mesh(new THREE.ConeGeometry(r, h, seg), m);
    mesh.position.set(x, y, z);
    mesh.castShadow = true;
    g.add(mesh);
    return mesh;
  },
};

// ---------- 单位模型 (更形象: 一眼认出兵种) ----------
const SKIN = 0xe8c39a;

/** 人形骨架 (腿/躯干/头), 返回组; 头顶高度 */
function humanoid(color: number, opts: { helmet?: number; dark?: number; height?: number } = {}): { g: THREE.Group; headY: number } {
  const g = new THREE.Group();
  const h = opts.height ?? 1;
  const dark = opts.dark ?? 0x4a4038;
  const body = mat(color, { roughness: 0.85 });
  const legM = mat(dark, { roughness: 0.9 });
  const skin = mat(SKIN, { roughness: 0.8 });
  // 腿
  for (const dx of [-0.07, 0.07]) B.w(g, 0.075, 0.26 * h, 0.075, legM, dx, 0.13 * h, 0);
  // 躯干
  B.w(g, 0.24, 0.3 * h, 0.15, body, 0, 0.41 * h, 0);
  // 腰带
  B.w(g, 0.25, 0.05 * h, 0.16, mat(dark), 0, 0.28 * h, 0);
  // 头
  B.s(g, 0.085, skin, 0, 0.62 * h, 0, 8);
  if (opts.helmet != null) {
    B.s(g, 0.092, mat(opts.helmet, { metalness: 0.4, roughness: 0.5 }), 0, 0.645 * h, 0, 8);
    B.w(g, 0.19, 0.02, 0.16, mat(opts.helmet, { metalness: 0.4, roughness: 0.5 }), 0, 0.615 * h, 0);
  }
  return { g, headY: 0.74 * h };
}

function addWeapon(g: THREE.Group, kind: 'club' | 'spear' | 'axe' | 'sword' | 'rifle', y = 0.45, right = true) {
  const dx = right ? 0.17 : -0.17;
  const wood = mat(0x6b4423, { roughness: 1 });
  const metal = mat(0xb8bec4, { metalness: 0.6, roughness: 0.35 });
  const armM = mat(SKIN, { roughness: 0.8 });
  // 手臂
  B.w(g, 0.05, 0.22, 0.05, armM, dx, y, 0.05);
  switch (kind) {
    case 'club':
      B.c(g, 0.02, 0.035, 0.42, wood, dx, y + 0.16, 0.14, 5);
      break;
    case 'spear':
      B.c(g, 0.014, 0.014, 0.62, wood, dx, y + 0.22, 0.14, 5);
      B.k(g, 0.026, 0.1, metal, dx, y + 0.55, 0.14, 5);
      break;
    case 'axe':
      B.c(g, 0.016, 0.016, 0.5, wood, dx, y + 0.18, 0.14, 5);
      B.w(g, 0.05, 0.14, 0.02, metal, dx, y + 0.4, 0.14);
      break;
    case 'sword':
      B.c(g, 0.012, 0.012, 0.1, mat(0x8a6a3c), dx, y + 0.06, 0.14, 5);
      B.w(g, 0.026, 0.36, 0.014, metal, dx, y + 0.28, 0.14);
      break;
    case 'rifle':
      B.c(g, 0.02, 0.02, 0.5, mat(0x3d3a36, { metalness: 0.5, roughness: 0.5 }), dx, y + 0.1, 0.16, 5);
      B.w(g, 0.03, 0.06, 0.09, mat(0x2b2b2b), dx, y + 0.05, 0.16);
      break;
  }
}

/** 四足兽 (bodyLen 沿 z, 面朝 +z) */
function quadruped(color: number, opts: { len?: number; tall?: number; ears?: boolean; tusks?: boolean; tail?: boolean; stripes?: number; mane?: number } = {}): { g: THREE.Group; headY: number } {
  const g = new THREE.Group();
  const len = opts.len ?? 0.5, tall = opts.tall ?? 0.32;
  const fur = mat(color, { roughness: 0.95 });
  const legM = mat(color, { roughness: 0.95 });
  const dark = mat(0x2b2620, { roughness: 0.9 });
  // 躯干
  B.w(g, 0.22, tall * 0.62, len, fur, 0, tall * 0.78, 0);
  // 头 + 吻部
  B.w(g, 0.15, 0.14, 0.16, fur, 0, tall * 0.98, len / 2 + 0.05);
  B.w(g, 0.09, 0.08, 0.1, dark, 0, tall * 0.92, len / 2 + 0.14);
  // 眼
  for (const dx of [-0.06, 0.06]) B.s(g, 0.016, mat(0xfbbf24, { emissive: 0xf59e0b, emissiveIntensity: 0.8 }), dx, tall * 1.02, len / 2 + 0.1, 4);
  if (opts.ears) for (const dx of [-0.055, 0.055]) B.k(g, 0.03, 0.07, fur, dx, tall * 1.1, len / 2 + 0.02, 4);
  if (opts.tusks) for (const dx of [-0.045, 0.045]) B.c(g, 0.008, 0.018, 0.07, mat(0xe8e3da), dx, tall * 0.88, len / 2 + 0.13, 4);
  if (opts.mane != null) B.w(g, 0.24, 0.16, 0.2, mat(opts.mane, { roughness: 1 }), 0, tall * 1.06, len / 2 - 0.1);
  // 腿 ×4
  for (const dx of [-0.08, 0.08])
    for (const dz of [len / 2 - 0.08, -len / 2 + 0.08])
      B.w(g, 0.055, tall * 0.55, 0.055, legM, dx, tall * 0.27, dz);
  // 尾巴
  if (opts.tail !== false) {
    const tail = B.c(g, 0.02, 0.035, 0.24, fur, 0, tall * 0.9, -len / 2 - 0.08, 5);
    tail.rotation.x = 0.6;
  }
  // 条纹 (虎)
  if (opts.stripes) {
    for (let i = 0; i < opts.stripes; i++) {
      B.w(g, 0.225, tall * 0.64, 0.025, mat(0x3d2b1f, { roughness: 0.95 }), 0, tall * 0.78, -len / 2 + 0.09 + i * (len - 0.18) / (opts.stripes - 1));
    }
  }
  return { g, headY: tall * 1.25 };
}

/** 车辆 (面朝 +z) */
function vehicle(kind: 'apc' | 'tank' | 'heli'): { g: THREE.Group; headY: number } {
  const g = new THREE.Group();
  if (kind === 'apc') {
    const hull = mat(0x4d5d41, { roughness: 0.8, metalness: 0.3 });
    B.w(g, 0.34, 0.2, 0.62, hull, 0, 0.24, 0);
    B.w(g, 0.3, 0.14, 0.3, hull, 0, 0.4, -0.08);           // 指挥塔
    B.w(g, 0.2, 0.04, 0.16, mat(0x2f3a2a, { roughness: 0.4 }), 0, 0.48, -0.08);
    B.c(g, 0.03, 0.03, 0.28, mat(0x2b2b2b, { metalness: 0.5 }), 0.05, 0.5, 0.0, 5); // 机枪
    for (const dz of [0.22, -0.22])
      for (const dx of [-0.19, 0.19])
        B.c(g, 0.085, 0.085, 0.07, mat(0x1e1e1e, { roughness: 0.95 }), dx, 0.085, dz, 8);
    return { g, headY: 0.72 };
  }
  if (kind === 'heli') {
    // 武装直升机: 机身 + 短翼挂架 + 旋翼 + 尾梁
    const body = mat(0x2f4a5a, { roughness: 0.6, metalness: 0.4 });
    const dark = mat(0x22323d, { roughness: 0.7, metalness: 0.3 });
    const glass = mat(0x9fd4e8, { roughness: 0.15, metalness: 0.2, transparent: true, opacity: 0.75 });
    B.w(g, 0.22, 0.18, 0.6, body, 0, 0.34, 0.02);            // 机身
    B.w(g, 0.16, 0.12, 0.18, body, 0, 0.36, 0.32);           // 机鼻
    B.w(g, 0.1, 0.09, 0.1, glass, 0, 0.42, 0.28);            // 座舱玻璃
    B.w(g, 0.5, 0.035, 0.1, dark, 0, 0.3, 0.02);             // 短翼
    B.c(g, 0.022, 0.022, 0.34, mat(0x2b2b2b, { metalness: 0.5 }), 0.2, 0.3, 0.02, 5); // 火箭巢
    B.c(g, 0.022, 0.022, 0.34, mat(0x2b2b2b, { metalness: 0.5 }), -0.2, 0.3, 0.02, 5);
    B.w(g, 0.07, 0.07, 0.42, body, 0, 0.38, -0.42);          // 尾梁
    B.w(g, 0.02, 0.16, 0.1, dark, 0, 0.46, -0.6);            // 垂尾
    B.w(g, 0.2, 0.02, 0.05, dark, 0, 0.38, -0.6);            // 平尾
    B.c(g, 0.015, 0.015, 0.24, dark, 0.06, 0.42, -0.44, 5);  // 尾传动轴
    // 起落稿 ×2
    for (const dx of [-0.13, 0.13]) {
      B.c(g, 0.014, 0.014, 0.2, mat(0x3a3a3a), dx, 0.16, 0.1, 4);
      B.w(g, 0.03, 0.04, 0.1, mat(0x1e1e1e, { roughness: 1 }), dx, 0.13, 0.16);
    }
    // 主旋翼 (两片 + 桨毂)
    const rotor = new THREE.Group();
    B.w(rotor, 1.5, 0.012, 0.07, dark, 0, 0, 0);
    B.w(rotor, 0.07, 0.012, 1.5, dark, 0, 0, 0);
    rotor.position.set(0, 0.52, 0.02);
    rotor.name = 'rotor';
    g.add(rotor);
    B.c(g, 0.03, 0.04, 0.12, dark, 0, 0.46, 0.02, 6);
    return { g, headY: 0.72 };
  }
  const hull = mat(0x3a4a37, { roughness: 0.75, metalness: 0.35 });
  // 履带
  for (const dx of [-0.21, 0.21]) {
    B.w(g, 0.12, 0.15, 0.72, mat(0x2a2a2a, { roughness: 0.95 }), dx, 0.1, 0);
    for (let i = 0; i < 4; i++) B.c(g, 0.055, 0.055, 0.03, mat(0x444), dx, 0.1, -0.27 + i * 0.18, 8);
  }
  // 车体
  B.w(g, 0.34, 0.14, 0.66, hull, 0, 0.24, 0);
  B.w(g, 0.3, 0.08, 0.44, mat(0x33422f, { roughness: 0.75, metalness: 0.35 }), 0, 0.33, -0.04);
  // 炮塔 + 主炮
  B.c(g, 0.12, 0.14, 0.1, hull, 0, 0.4, -0.02, 10);
  const barrel = B.c(g, 0.032, 0.032, 0.42, mat(0x2f3a2c, { metalness: 0.5, roughness: 0.4 }), 0, 0.41, 0.2, 8);
  barrel.rotation.x = Math.PI / 2;
  return { g, headY: 0.66 };
}

/** 按 BattleUnit.kind 生成战斗模型 */
export function battleUnitModel(kind: string): { g: THREE.Group; headY: number } {
  switch (kind) {
    case 'warrior': {
      const { g, headY } = humanoid(0xb98a4a, { dark: 0x5a4632 });
      addWeapon(g, 'club');
      B.w(g, 0.26, 0.06, 0.17, mat(0x8a5a33), 0, 0.3, 0); // 腰布
      return { g, headY };
    }
    case 'soldier': {
      const { g, headY } = humanoid(0x4a6b5a, { helmet: 0x4a5548, dark: 0x37423a });
      addWeapon(g, 'rifle');
      B.w(g, 0.26, 0.08, 0.09, mat(0x37423a), 0, 0.3, -0.09); // 背包
      return { g, headY };
    }
    case 'wolf': return quadruped(0x9ca3af, { len: 0.52, tall: 0.34, ears: true });
    case 'boar': return quadruped(0x7c5c3e, { len: 0.5, tall: 0.36, tusks: true, tail: false });
    case 'bear': return quadruped(0x4b3621, { len: 0.6, tall: 0.46, ears: true, tail: false });
    case 'tiger': return quadruped(0xd97706, { len: 0.58, tall: 0.4, ears: true, stripes: 4 });
    case 'slinger': {
      const { g, headY } = humanoid(0xa3743a, { dark: 0x6e5236 });
      B.w(g, 0.27, 0.05, 0.27, mat(0xb8944f), 0, 0.65, 0); // 头带
      B.s(g, 0.05, mat(0x8d8d8d, { roughness: 1 }), 0.19, 0.5, 0.12, 5); // 石头
      return { g, headY };
    }
    case 'berserk': {
      const { g, headY } = humanoid(0x9a3412, { dark: 0x4a2a18 });
      addWeapon(g, 'axe');
      B.k(g, 0.06, 0.1, mat(0xe8dcc5), 0, 0.72, 0.03, 4); // 顶髻
      return { g, headY };
    }
    case 'chief': {
      const { g, headY } = humanoid(0xb91c1c, { dark: 0x5a2018, height: 1.12 });
      addWeapon(g, 'club');
      for (const dx of [-0.07, 0, 0.07]) B.k(g, 0.022, 0.16, mat(0xe8590c), dx, 0.76, -0.03, 4); // 羽冠
      B.w(g, 0.3, 0.05, 0.2, mat(0xd9a536, { metalness: 0.4 }), 0, 0.31, 0); // 金腰带
      return { g, headY: headY + 0.06 };
    }
    case 'thug': {
      const { g, headY } = humanoid(0x57534e, { dark: 0x2f2b28 });
      addWeapon(g, 'sword');
      B.w(g, 0.27, 0.08, 0.18, mat(0x2f2b28), 0, 0.62, -0.02); // 兜帽
      return { g, headY };
    }
    case 'gunner': {
      const { g, headY } = humanoid(0x44403c, { dark: 0x2b2724 });
      addWeapon(g, 'rifle');
      B.c(g, 0.1, 0.1, 0.03, mat(0x2b2724), 0, 0.68, 0, 8); // 帽
      return { g, headY };
    }
    case 'boss': {
      const { g, headY } = humanoid(0x7f1d1d, { dark: 0x3a1414, height: 1.15 });
      addWeapon(g, 'sword', 0.45, true);
      addWeapon(g, 'sword', 0.45, false);
      B.s(g, 0.06, mat(0xd9a536, { metalness: 0.5 }), 0, 0.76, 0.04, 6); // 单眼罩饰
      return { g, headY: headY + 0.05 };
    }
    case 'rebel': {
      const { g, headY } = humanoid(0x3f4b5b, { helmet: 0x364152, dark: 0x2b3340 });
      addWeapon(g, 'rifle');
      return { g, headY };
    }
    case 'apc': return vehicle('apc');
    case 'tank': return vehicle('tank');
    case 'heli': return vehicle('heli');
    default: return humanoid(0x8a8a8a, {});
  }
}

/** v5: 远征队员个体模型 —— 每人不同的武器/头盔/配色 (i = 队内序号) */
export function squadMemberModel(i: number, weaponTier: number): { g: THREE.Group; headY: number } {
  const palettes = [0xb98a4a, 0x6b8a72, 0x8a6b7a, 0x5a7a9a, 0x9a8a5a, 0x7a9a6b, 0x8a5a5a, 0x5a8a8a];
  const color = palettes[i % palettes.length];
  const darks = [0x5a4632, 0x3a4a3a, 0x4a3a4a, 0x2f3f4f, 0x5a5030, 0x3f5a35, 0x5a3030, 0x2f4a4a];
  const dark = darks[i % darks.length];
  const weapon: 'club' | 'spear' | 'sword' | 'rifle' =
    weaponTier >= 3 ? 'rifle' : weaponTier === 2 ? 'sword' : weaponTier === 1 ? 'spear' : 'club';
  const isLeader = i === 0;
  const { g, headY } = humanoid(color, {
    dark,
    helmet: weaponTier >= 2 ? (isLeader ? 0xd9a536 : dark) : undefined,
    height: isLeader ? 1.08 : 0.94 + (i % 3) * 0.04,
  });
  addWeapon(g, weapon, 0.42, i % 2 === 0);
  // 背包 + 水壶
  B.w(g, 0.16, 0.14, 0.07, mat(dark), 0, 0.42, -0.1);
  if (i % 2 === 1) B.c(g, 0.035, 0.035, 0.09, mat(0x607a8a, { metalness: 0.3 }), -0.15, 0.34, -0.02, 6);
  if (isLeader) { // 队长披风
    B.w(g, 0.22, 0.3, 0.015, mat(0xa3452e, { roughness: 1 }), 0, 0.4, -0.13);
  }
  return { g, headY };
}

// ---------- 环境布景 ----------
const ENV_STYLE: Record<BattleState['env'], { bg: number; ground: number; ground2: number; fogNear: number; fogFar: number; sun: number; amb: number }> = {
  wild:   { bg: 0x1a2b1e, ground: 0x4a7a3c, ground2: 0x3d6a32, fogNear: 11, fogFar: 24, sun: 0xffe9c4, amb: 0x8aa88a },
  village:{ bg: 0x2b2419, ground: 0x8a7a48, ground2: 0x7a6c40, fogNear: 11, fogFar: 24, sun: 0xffd9a0, amb: 0xa89a80 },
  city:   { bg: 0x1c2026, ground: 0x3d4045, ground2: 0x33363b, fogNear: 10, fogFar: 22, sun: 0xdfe8ff, amb: 0x7a8494 },
  ruin:   { bg: 0x1e1830, ground: 0x4a4258, ground2: 0x3e3850, fogNear: 9,  fogFar: 20, sun: 0xcdd6ff, amb: 0x8a7ab8 },
};

function dressStage(scene: THREE.Scene, env: BattleState['env']) {
  const st = ENV_STYLE[env];
  const props = new THREE.Group();
  // 地面圆台
  const ground = new THREE.Mesh(new THREE.CircleGeometry(9, 40), mat(st.ground, { roughness: 1 }));
  ground.rotation.x = -Math.PI / 2;
  ground.receiveShadow = true;
  props.add(ground);
  // 交战带 (浅色带标记阵线)
  const band = new THREE.Mesh(new THREE.RingGeometry(0.4, 1.6, 40), mat(st.ground2, { roughness: 1 }));
  band.rotation.x = -Math.PI / 2;
  band.position.y = 0.012;
  band.receiveShadow = true;
  props.add(band);
  const rand = mulberry(env.length * 7919 + 13);
  if (env === 'wild') {
    for (let i = 0; i < 7; i++) {
      const a = rand() * Math.PI * 2, r = 4.6 + rand() * 2.6;
      const tuft = new THREE.Group();
      for (let j = 0; j < 3; j++) B.k(tuft, 0.03, 0.14 + rand() * 0.08, mat(0x5d9a4a, { roughness: 1 }), (rand() - 0.5) * 0.16, 0.07, (rand() - 0.5) * 0.16, 4);
      tuft.position.set(Math.cos(a) * r, 0, Math.sin(a) * r);
      props.add(tuft);
    }
    for (const [x, z] of [[-5.4, -3.2], [5.6, 3.6], [-4.8, 4.4]] as const) {
      const tree = new THREE.Group();
      B.c(tree, 0.1, 0.14, 0.8, mat(0x5a4430, { roughness: 1 }), 0, 0.4, 0, 6);
      B.s(tree, 0.55, mat(0x2f6b3a, { roughness: 1 }), 0, 1.05, 0, 7);
      B.s(tree, 0.38, mat(0x3d7a48, { roughness: 1 }), 0.18, 1.35, 0.1, 7);
      tree.position.set(x, 0, z);
      props.add(tree);
    }
  } else if (env === 'village') {
    for (const [x, z, r] of [[-5.6, -2.8, 0.5], [5.8, -3.4, -0.7], [0.4, 6.2, 0.2]] as const) {
      const hut = new THREE.Group();
      B.w(hut, 1.1, 0.7, 0.9, mat(0x8a5a33, { roughness: 1 }), 0, 0.35, 0);
      const roof = new THREE.Mesh(new THREE.ConeGeometry(0.85, 0.5, 4), mat(0xd9b36a, { roughness: 1 }));
      roof.rotation.y = Math.PI / 4;
      roof.position.y = 0.95;
      roof.castShadow = true;
      hut.add(roof);
      hut.position.set(x, 0, z);
      hut.rotation.y = r;
      props.add(hut);
    }
    for (let i = 0; i < 6; i++) {
      const a = 1.2 + i * 0.35;
      B.w(props, 0.05, 0.3, 0.05, mat(0x6b4423, { roughness: 1 }), Math.cos(a) * 4.2, 0.15, Math.sin(a) * 4.2);
    }
  } else if (env === 'city') {
    for (const [x, z, h] of [[-5.8, -3, 2.4], [5.4, -3.6, 1.8], [-4.6, 4.8, 1.2], [6, 3, 2.8], [0, 7, 2]] as const) {
      const bld = new THREE.Group();
      B.w(bld, 1 + rand() * 0.6, h, 1 + rand() * 0.6, mat(0x4a5058, { roughness: 0.95 }), 0, h / 2, 0);
      B.w(bld, 0.2, 0.25, 0.2, mat(0x3a3f46, { roughness: 0.95 }), 0.2, h + 0.1, 0);
      bld.position.set(x, 0, z);
      props.add(bld);
    }
    for (let i = 0; i < 5; i++) {
      const a = rand() * Math.PI * 2, r = 4.4 + rand() * 2.4;
      B.s(props, 0.16 + rand() * 0.14, mat(0x565a60, { roughness: 1 }), Math.cos(a) * r, 0.1, Math.sin(a) * r, 5);
    }
  } else {
    // ruin: 断柱 + 发光符文
    for (const [x, z, h] of [[-5.2, -3, 1.3], [5.4, -2.6, 1.7], [-4.6, 4.2, 0.9], [5.8, 4.4, 1.5], [-2.2, 6.4, 1.1]] as const) {
      const pillar = new THREE.Group();
      B.c(pillar, 0.18, 0.22, h, mat(0x7d7a8a, { roughness: 1 }), 0, h / 2, 0, 8);
      pillar.rotation.z = (rand() - 0.5) * 0.16;
      pillar.position.set(x, 0, z);
      props.add(pillar);
    }
    for (let i = 0; i < 5; i++) {
      const a = rand() * Math.PI * 2, r = 3.6 + rand() * 3;
      const rune = new THREE.Mesh(
        new THREE.BoxGeometry(0.05, 0.05, 0.01),
        new THREE.MeshBasicMaterial({ color: 0x67e8f9, transparent: true, opacity: 0.75 }),
      );
      rune.position.set(Math.cos(a) * r, 0.03, Math.sin(a) * r);
      rune.rotation.y = -Math.PI / 2 + rand() * 0.4;
      props.add(rune);
    }
  }
  scene.add(props);
}

function mulberry(seed: number) {
  let a = seed >>> 0;
  return () => {
    a |= 0; a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

// ---------- 舞台 ----------
interface AnimJob {
  type: 'lunge' | 'dodge' | 'flash' | 'death' | 'guard' | 'projectile' | 'shake';
  uid: string;              // 作用对象
  to?: THREE.Vector3;       // 冲撞目标点
  t: number;                // 已进行时间
  dur: number;
  crit?: boolean;
  hit?: boolean;
}

interface UnitView {
  uid: string;
  side: 'player' | 'enemy';
  group: THREE.Group;
  base: THREE.Vector3;
  headY: number;
  ring: THREE.Mesh;         // 行动光环
  shield: THREE.Group;      // 格挡盾
  alive: boolean;
  fallen: boolean;
}

export class BattleStage {
  readonly scene = new THREE.Scene();
  readonly camera: THREE.PerspectiveCamera;
  private renderer: THREE.WebGLRenderer;
  private units = new Map<string, UnitView>();
  private jobs: AnimJob[] = [];
  private projectiles: { mesh: THREE.Mesh; from: THREE.Vector3; to: THREE.Vector3; t: number; dur: number; targetUid: string; crit: boolean }[] = [];
  private flashSprites: { spr: THREE.Sprite; t: number; dur: number }[] = [];
  private raf = 0;
  private clock = new THREE.Clock();
  private time = 0;
  private camShake = 0;
  private disposed = false;
  private flashTex: THREE.Texture;
  onFloat?: (uid: string, text: string, tone: 'good' | 'bad' | 'info') => void;
  onSfx?: (name: 'slash' | 'hit' | 'crit' | 'guard' | 'miss' | 'death') => void;

  constructor(private canvas: HTMLCanvasElement, env: BattleState['env']) {
    const st = ENV_STYLE[env];
    this.scene.background = new THREE.Color(st.bg);
    this.scene.fog = new THREE.Fog(st.bg, st.fogNear, st.fogFar);
    this.camera = new THREE.PerspectiveCamera(40, 16 / 9, 0.1, 60);
    this.camera.position.set(0, 3.3, 7.6);
    this.camera.lookAt(0, 0.85, 0);

    this.renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: false });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    const hemi = new THREE.HemisphereLight(st.amb, st.ground2, 0.85);
    this.scene.add(hemi);
    const sun = new THREE.DirectionalLight(st.sun, 1.5);
    sun.position.set(4, 8, 5);
    sun.castShadow = true;
    sun.shadow.mapSize.set(1024, 1024);
    sun.shadow.camera.left = -6; sun.shadow.camera.right = 6;
    sun.shadow.camera.top = 6; sun.shadow.camera.bottom = -6;
    this.scene.add(sun);

    dressStage(this.scene, env);

    // 受击闪光贴图 (径向渐变)
    const cv = document.createElement('canvas');
    cv.width = cv.height = 64;
    const ctx = cv.getContext('2d')!;
    const grad = ctx.createRadialGradient(32, 32, 2, 32, 32, 30);
    grad.addColorStop(0, 'rgba(255,255,255,1)');
    grad.addColorStop(0.5, 'rgba(255,230,180,0.55)');
    grad.addColorStop(1, 'rgba(255,255,255,0)');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, 64, 64);
    this.flashTex = new THREE.CanvasTexture(cv);

    this.loop();
  }

  /** 按 BattleUnit[] 重建阵型 */
  buildUnits(units: BattleUnit[]) {
    for (const [, v] of this.units) {
      this.scene.remove(v.group);
      this.scene.remove(v.ring);
      this.scene.remove(v.shield);
    }
    this.units.clear();
    const players = units.filter(u => u.side === 'player');
    const enemies = units.filter(u => u.side === 'enemy');
    const place = (arr: BattleUnit[], side: 'player' | 'enemy') => {
      const n = arr.length;
      arr.forEach((u, i) => {
        const { g, headY } = battleUnitModel(u.kind);
        const z = n === 1 ? 0 : (i - (n - 1) / 2) * 1.18;
        const x = (side === 'player' ? -1 : 1) * (2.15 + (i % 2) * 0.5);
        g.position.set(x, 0, z);
        g.rotation.y = side === 'player' ? Math.PI / 2 : -Math.PI / 2;
        this.scene.add(g);
        // 行动光环
        const ring = new THREE.Mesh(
          new THREE.RingGeometry(0.3, 0.4, 26),
          new THREE.MeshBasicMaterial({ color: side === 'player' ? 0xfbbf24 : 0xef4444, transparent: true, opacity: 0.85, side: THREE.DoubleSide, depthWrite: false }),
        );
        ring.rotation.x = -Math.PI / 2;
        ring.position.set(x, 0.03, z);
        ring.visible = false;
        this.scene.add(ring);
        // 格挡盾 (平时隐藏)
        const shield = new THREE.Group();
        const plate = new THREE.Mesh(
          new THREE.CircleGeometry(0.3, 18),
          new THREE.MeshBasicMaterial({ color: 0x38bdf8, transparent: true, opacity: 0.4, side: THREE.DoubleSide, depthWrite: false }),
        );
        plate.position.y = 0.42;
        shield.add(plate);
        shield.position.set(x, 0, z);
        shield.rotation.y = side === 'player' ? Math.PI / 2 : -Math.PI / 2;
        shield.position.x += side === 'player' ? 0.28 : -0.28;
        shield.visible = false;
        this.scene.add(shield);
        this.units.set(u.uid, {
          uid: u.uid, side, group: g, headY,
          base: new THREE.Vector3(x, 0, z),
          ring, shield, alive: u.alive, fallen: false,
        });
      });
    };
    place(players, 'player');
    place(enemies, 'enemy');
  }

  /** 每帧同步: 血量/行动者/格挡/阵亡 */
  syncUnits(units: BattleUnit[], activeUid: string | null) {
    for (const u of units) {
      const v = this.units.get(u.uid);
      if (!v) continue;
      if (!u.alive && !v.fallen) {
        // 倒地演出 (若尚未由事件触发)
        v.fallen = true;
        this.jobs.push({ type: 'death', uid: u.uid, t: 0, dur: 0.55 });
      }
      v.ring.visible = u.alive && u.uid === activeUid;
      v.shield.visible = u.guarding && u.alive;
      v.alive = u.alive;
    }
  }

  /** 事件驱动演出 */
  fireEvent(ev: BattleEvent) {
    const actor = this.units.get(ev.actorUid);
    const target = ev.targetUid ? this.units.get(ev.targetUid) : null;
    switch (ev.type) {
      case 'attack': {
        if (actor && target) {
          const ranged = ['spear', 'rock', 'volley', 'shell'].includes(ev.moveId);
          if (ranged) {
            this.spawnProjectile(actor, target, ev.crit ?? false, ev.moveId === 'shell');
          } else {
            this.jobs.push({ type: 'lunge', uid: ev.actorUid, to: target.base.clone(), t: 0, dur: 0.5, crit: ev.crit });
          }
        }
        break;
      }
      case 'miss':
        if (target) this.jobs.push({ type: 'dodge', uid: ev.targetUid!, t: 0, dur: 0.4 });
        break;
      case 'guard':
        if (actor) {
          actor.shield.visible = true;
          this.jobs.push({ type: 'guard', uid: ev.actorUid, t: 0, dur: 0.5 });
        }
        break;
      case 'death':
        if (target && !target.fallen) {
          target.fallen = true;
          this.jobs.push({ type: 'death', uid: ev.targetUid!, t: 0, dur: 0.55 });
        }
        break;
      case 'flee':
        break;
    }
  }

  private spawnProjectile(actor: UnitView, target: UnitView, crit: boolean, big: boolean) {
    const geo = big ? new THREE.SphereGeometry(0.09, 8, 8) : new THREE.SphereGeometry(0.05, 8, 8);
    const mesh = new THREE.Mesh(geo, new THREE.MeshBasicMaterial({ color: big ? 0xffa94d : 0xd8dce0 }));
    const from = actor.base.clone();
    from.y = actor.headY * 0.8;
    const to = target.base.clone();
    to.y = target.headY * 0.7;
    mesh.position.copy(from);
    this.scene.add(mesh);
    this.projectiles.push({ mesh, from, to, t: 0, dur: 0.32, targetUid: target.uid, crit });
  }

  private impact(target: UnitView, crit: boolean) {
    // 闪光
    const spr = new THREE.Sprite(new THREE.SpriteMaterial({
      map: this.flashTex, transparent: true, opacity: 0.95, blending: THREE.AdditiveBlending, depthWrite: false,
    }));
    spr.position.copy(target.base).setY(target.headY * 0.72);
    spr.scale.setScalar(crit ? 1.5 : 0.95);
    this.scene.add(spr);
    this.flashSprites.push({ spr, t: 0, dur: 0.3 });
    // 震颤
    this.jobs.push({ type: 'shake', uid: target.uid, t: 0, dur: crit ? 0.42 : 0.28, crit });
    if (crit) this.camShake = 0.35;
    this.onSfx?.(crit ? 'crit' : 'hit');
  }

  private loop = () => {
    if (this.disposed) return;
    this.raf = requestAnimationFrame(this.loop);
    const dt = Math.min(0.05, this.clock.getDelta());
    this.time += dt;
    this.tick(dt);
    this.renderer.render(this.scene, this.camera);
  };

  private tick(dt: number) {
    // 动画任务
    for (let i = this.jobs.length - 1; i >= 0; i--) {
      const j = this.jobs[i];
      const v = this.units.get(j.uid);
      j.t += dt;
      const p = Math.min(1, j.t / j.dur);
      if (v) {
        switch (j.type) {
          case 'lunge': {
            // 冲向目标再折返, 命中在半程
            const dir = (j.to as THREE.Vector3).clone().sub(v.base);
            const reach = Math.max(0.1, dir.length() - 0.95);
            dir.normalize();
            const k = Math.sin(Math.PI * p);
            v.group.position.copy(v.base).addScaledVector(dir, reach * k * 0.95);
            v.group.position.y = Math.abs(Math.sin(p * Math.PI * 2)) * 0.12;
            v.group.rotation.z = -0.22 * k * (v.side === 'player' ? 1 : -1);
            if (p >= 0.5 && !j.hit) {
              j.hit = true;
              this.impact(v, !!j.crit);
            }
            break;
          }
          case 'dodge': {
            const k = Math.sin(Math.PI * p);
            v.group.position.copy(v.base);
            v.group.position.z += k * 0.55;
            break;
          }
          case 'shake': {
            const decay = (1 - p);
            v.group.position.copy(v.base);
            v.group.position.x += (Math.random() - 0.5) * 0.09 * decay * 2;
            v.group.position.z += (Math.random() - 0.5) * 0.09 * decay * 2;
            break;
          }
          case 'death': {
            const fall = -Math.PI / 2 * Math.min(1, p * 1.6);
            v.group.rotation.z = v.side === 'player' ? -fall : fall;
            v.group.position.y = -0.1 * Math.min(1, p * 1.6);
            if (p >= 1) v.group.visible = true;
            break;
          }
          case 'guard': {
            const k = Math.sin(Math.PI * p);
            v.group.position.copy(v.base);
            v.group.position.y = k * 0.06;
            v.shield.scale.setScalar(1 + k * 0.25);
            break;
          }
        }
        if (j.type === 'lunge' && p >= 1) {
          v.group.position.copy(v.base);
          v.group.rotation.z = 0;
        }
        if (j.type === 'dodge' && p >= 1) v.group.position.copy(v.base);
        if (j.type === 'shake' && p >= 1) v.group.position.copy(v.base);
        if (j.type === 'guard' && p >= 1) { v.group.position.copy(v.base); v.shield.scale.setScalar(1); }
      }
      if (p >= 1) this.jobs.splice(i, 1);
    }
    // 投射物
    for (let i = this.projectiles.length - 1; i >= 0; i--) {
      const pr = this.projectiles[i];
      pr.t += dt;
      const p = Math.min(1, pr.t / pr.dur);
      pr.mesh.position.lerpVectors(pr.from, pr.to, p);
      pr.mesh.position.y += Math.sin(p * Math.PI) * 0.55;
      if (p >= 1) {
        this.scene.remove(pr.mesh);
        (pr.mesh.material as THREE.Material).dispose();
        pr.mesh.geometry.dispose();
        const target = this.units.get(pr.targetUid);
        if (target) this.impact(target, pr.crit);
        this.projectiles.splice(i, 1);
      }
    }
    // 闪光
    for (let i = this.flashSprites.length - 1; i >= 0; i--) {
      const f = this.flashSprites[i];
      f.t += dt;
      const p = f.t / f.dur;
      (f.spr.material as THREE.SpriteMaterial).opacity = Math.max(0, 0.95 * (1 - p));
      f.spr.scale.setScalar(f.spr.scale.x * (1 + dt * 1.6));
      if (p >= 1) {
        this.scene.remove(f.spr);
        (f.spr.material as THREE.SpriteMaterial).dispose();
        this.flashSprites.splice(i, 1);
      }
    }
    // 镜头呼吸 + 震屏
    this.camShake = Math.max(0, this.camShake - dt * 1.4);
    const shake = this.camShake * this.camShake;
    this.camera.position.x = Math.sin(this.time * 0.22) * 0.42 + (Math.random() - 0.5) * shake;
    this.camera.position.y = 3.3 + Math.sin(this.time * 0.15) * 0.14 + (Math.random() - 0.5) * shake * 0.6;
    this.camera.position.z = 7.6;
    this.camera.lookAt(0, 0.85, 0);
    // 行动者呼吸浮动
    for (const v of this.units.values()) {
      if (v.ring.visible) {
        v.ring.scale.setScalar(1 + Math.sin(this.time * 5) * 0.1);
        if (v.alive && !this.jobs.some(j => j.uid === v.uid)) {
          v.group.position.y = Math.sin(this.time * 3.2) * 0.035;
        }
      }
      if (v.shield.visible && !v.fallen) {
        (v.shield.children[0] as THREE.Mesh).rotation.z = this.time * 1.2;
      }
    }
  }

  /** 单位头顶世界坐标 → 画布像素 (供 DOM 血条/飘字) */
  project(uid: string): { x: number; y: number; visible: boolean } {
    const v = this.units.get(uid);
    if (!v) return { x: 0, y: 0, visible: false };
    const p = new THREE.Vector3(v.base.x, v.headY + 0.15, v.base.z).project(this.camera);
    const w = this.canvas.clientWidth, h = this.canvas.clientHeight;
    return { x: (p.x * 0.5 + 0.5) * w, y: (-p.y * 0.5 + 0.5) * h, visible: p.z < 1 };
  }

  resize() {
    const w = this.canvas.clientWidth || 640;
    const h = this.canvas.clientHeight || 360;
    this.renderer.setSize(w, h, false);
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
  }

  dispose() {
    this.disposed = true;
    cancelAnimationFrame(this.raf);
    this.scene.traverse(o => {
      const m = o as THREE.Mesh;
      if (m.geometry) m.geometry.dispose();
    });
    this.renderer.dispose();
  }
}
