// ===== 荒野筑城 · 类型定义 =====

export type ResourceKey = 'food' | 'wood' | 'stone' | 'metal' | 'oil' | 'money';
export type UtilityKey = 'power' | 'water';

export type TileTerrain = 'water' | 'sand' | 'grass' | 'forest' | 'hill' | 'mountain';

export interface Tile {
  x: number;
  y: number;
  height: number;
  terrain: TileTerrain;
  tree: number;      // -1 无树, 否则树实例编号(用于砍伐)
  rock: boolean;
  occupied: boolean; // 被建筑占用
  buildingId: number;
  ruin: number;      // -1 无遗迹, 否则遗迹实例编号
  explored: boolean; // 战争迷雾: 是否已探索
}

export type BuildingCategory = 'road' | 'housing' | 'food' | 'resource' | 'power' | 'water' | 'civic' | 'pipe' | 'light' | 'military';

/** 管线类型: 输水管 / 电线杆 (手动接线) */
export type PipeKind = 'water' | 'power';

export interface BuildingEffects {
  happiness?: number;   // 半径内幸福加成
  order?: number;       // 半径内秩序加成
  pollution?: number;   // 半径内污染(幸福减益), 工业建筑对住房
  noise?: number;       // 半径内噪音(幸福减益)
  education?: number;   // 半径内生产效率加成(0~1)
  fireCover?: number;   // 消防覆盖半径
  policeCover?: number; // 警察覆盖半径
  healthCover?: number; // 医疗覆盖半径(减少事件伤害)
}

export interface BuildingDef {
  id: string;
  name: string;
  category: BuildingCategory;
  era: number;
  desc: string;
  size: number;                // 占地 size×size
  cost: Partial<Record<ResourceKey, number>>;
  upkeep?: number;             // 每日资金维护
  workers: number;             // 所需工人
  buildDays?: number;          // 建造工期(游戏日), 缺省按造价估算
  housing?: number;            // 提供住房容量
  produce?: Partial<Record<ResourceKey, number>>; // 每日产出
  consume?: Partial<Record<ResourceKey, number>>; // 每日原料消耗
  powerOut?: number;           // 供电输出
  powerNeed?: number;          // 耗电
  waterOut?: number;           // 供水输出
  waterNeed?: number;          // 耗水
  radius?: number;             // 影响半径
  light?: number;              // 夜间照明半径(格), 住房在范围内获得安全感
  effects?: BuildingEffects;
  storage?: Partial<Record<ResourceKey, number>>; // 增加仓储上限
  needsWater?: boolean;        // 须邻水
  needsForest?: number;        // 周围 N 格内需树林
  needsRock?: number;          // 周围 N 格内需山地
  needsRoad?: boolean;         // 须邻路
  research?: string;           // 需先研究的科技
  road?: boolean;              // 是道路
  roadBonus?: number;          // 邻路生产加成(0~1)
  pipe?: PipeKind | 'both';    // 管线建筑类型
  onWater?: boolean;           // 可以建在水上(栈道/水下管道)
  /** v5 地下管网: 电缆/水管的输送容量 (超出会短路/爆管) */
  wireCap?: number;
  /** v5 地下管网: 自动连接半径 (格) */
  wireRange?: number;
  /** v5 变电站(升压) / 泵站(增压): 重置周边电压/水压并倍增容量 */
  booster?: 'transformer' | 'pump';
  boostRadius?: number;
  /** v5 载具库: 每座建筑常备一辆载具 (战损后 3 日重建) */
  vehicle?: 'apc' | 'tank' | 'heli';
  /** 独立机制标记 */
  mechanic?: 'barracks' | 'armory' | 'armor' | 'bank' | 'library' | 'school' | 'hospital' | 'broadcast' | 'market' | 'stadium' | 'reservoir';
  model: string;               // 模型工厂键
  icon: string;                // lucide 图标名
}

export interface ResearchDef {
  id: string;
  name: string;
  era: number;
  desc: string;
  cost: Partial<Record<ResourceKey, number>>;
}

export interface EraDef {
  index: number;
  name: string;
  slogan: string;
  require: {
    pop: number;
    resources?: Partial<Record<ResourceKey, number>>;
    powerNet?: number;   // 电力净输出需求
    hasBuilding?: string[]; // 需已建造某建筑
  };
}

export interface Building {
  id: number;
  defId: string;
  x: number;
  y: number;
  size: number;
  rot: number;          // 朝向 0-3 (×90°)
  hp: number;
  fire: number;       // >0 燃烧中(剩余时间/秒)
  workers: number;    // 当前分配工人 (手动分配制)
  efficiency: number; // 最近一次效率
  builtDay: number;
  progress: number;   // 建造进度 0-1 (<1 为施工中)
  alerts: string[];   // 感叹号警报 (由引擎自动识别)
  damaged?: boolean;  // 受损(暴乱/事故后)
  powered?: boolean;  // 已接入电网
  watered?: boolean;  // 已接入水网
  strike?: number;    // 罢工剩余天数 (>0 停产)
  vehicleReadyDay?: number; // 载具重建完成日 (战损后 3 日)
}

export type EventKind = 'fire' | 'storm' | 'riot' | 'accident' | 'nuclear' |
  'harvest' | 'caravan' | 'immigrant' | 'deposit' | 'festival' | 'plague' | 'quake' | 'info' |
  'beast' | 'raid' | 'bandit' | 'rebel' | 'wedding' | 'strike' | 'birth' | 'expedition' | 'ruin' | 'battle';

export interface GameEvent {
  id: number;
  kind: EventKind;
  title: string;
  detail: string;
  day: number;
}

export interface NotificationItem {
  id: number;
  kind: EventKind;
  title: string;
  detail: string;
  tone: 'good' | 'bad' | 'info';
  ts: number;
}

export type GameSpeed = number;

export interface ResourceStat {
  produce: number;
  consume: number;
  net: number;
}

/** 数据视图叠加层格子数据 */
export interface OverlayCell {
  happiness: number;  // -45..45
  noise: number;      // 0..30
  pollution: number;  // 0..30
  light: number;      // 0..1 夜间照明覆盖率
  land: number;       // 0..100 地价 (住房周边)
  powerOk: -1 | 0 | 1 | 2 | 3 | 4;  // -1无需求 1接入 0断电 2源 3管线 4变电站
  waterOk: -1 | 0 | 1 | 2 | 3 | 4;  // -1无需求 1接入 0断水 2源 3管线 4泵站
  volt: number;       // 0..100 电压百分比 (v5)
  press: number;      // 0..100 水压百分比 (v5)
  road: number;       // 0 无 1 有路
}

// ================= 地下管网 (v5: SC4 式) =================
/** 一条已建成的电网/水网连线 (地下, 视图中可视化) */
export interface UtiliEdge {
  aId: number; bId: number;      // 两端建筑 id
  ax: number; ay: number; bx: number; by: number; // 锚点 (格中心)
  load: number;                  // 当前流经负载 (需求合计)
  cap: number;                   // 容量 (超限即过载)
  kind: 'trunk' | 'drop';        // 干线 / 建筑接入线(接口)
  boosted: boolean;              // 受变电站/泵站增容
  dead: boolean;                 // 短路/爆管抢修中
  utility: 'power' | 'water';
}
/** 一次短路/爆管事故 */
export interface BlackoutIncident {
  utility: 'power' | 'water';
  x: number; y: number;
  endHour: number;   // 绝对游戏小时 (day*24+hour)
  label: string;
}

// ================= 战斗系统 (回合制) =================
export type BattleMoveKind = 'strike' | 'heavy' | 'guard' | 'special';

export interface BattleMove {
  id: string;
  name: string;
  kind: BattleMoveKind;
  power: number;      // 伤害倍率 (相对攻击力)
  accuracy: number;   // 0~1
  desc: string;
}

export interface BattleUnit {
  uid: string;
  name: string;
  side: 'player' | 'enemy';
  kind: string;         // 模型/图标种类
  hp: number;
  maxHp: number;
  atk: number;
  def: number;
  spd: number;
  guarding: boolean;
  alive: boolean;
  moves: BattleMove[];
  /** 视觉: 图标与配色 */
  icon: string;
  color: string;
}

export interface BattleLogLine { text: string; tone: 'good' | 'bad' | 'info'; }

/** 战斗动画事件 (3D 场景据此播放攻击/受击/倒地等演出) */
export interface BattleEvent {
  key: number;
  type: 'attack' | 'guard' | 'miss' | 'death' | 'flee';
  actorUid: string;
  targetUid: string | null;
  moveId: string;
  moveKind: BattleMoveKind | '';
  moveName: string;
  dmg: number;
  crit: boolean;
}

export interface BattleState {
  id: number;
  title: string;
  env: 'wild' | 'village' | 'city' | 'ruin';
  units: BattleUnit[];
  pos: { x: number; y: number };        // v5: 地图内开战位置
  vehicleBldgs: Record<string, number>; // v5: 载具单位 → 所属车库建筑 id (战损重建)
  turnOrder: string[];
  turnIdx: number;
  round: number;
  phase: 'select' | 'anim' | 'enemy' | 'over';
  activeUid: string | null;
  log: BattleLogLine[];
  result: null | 'win' | 'lose' | 'flee';
  rewards: Partial<Record<ResourceKey, number>> | null;
  casualties: number;      // 阵亡队员数
  context: 'defense' | 'expedition' | 'ruin';
  expeditionId: number | null; // 若因远征触发
  floatTexts: { uid: string; text: string; tone: 'good' | 'bad' | 'info'; key: number }[];
  events: BattleEvent[];
}

// ================= 远征系统 =================
export type ExpeditionState = 'outbound' | 'scavenge' | 'returning';

export interface Expedition {
  id: number;
  members: number;
  vehicles: { apc: number; tank: number; heli: number }; // v5: 随队载具
  x: number; y: number;         // 当前位置 (浮点格)
  sx: number; sy: number;       // 出发点 (城市边缘)
  tx: number; ty: number;       // 目标
  dist: number;                 // 总距离 (格)
  state: ExpeditionState;
  timer: number;                // 状态计时 (搜刮等)
  encounterDone: boolean;       // 是否已判定遭遇
  loot: Partial<Record<ResourceKey, number>>;
  revealAcc: number;            // 揭雾累积步长
  speedMul: number;             // 地形减速
}

export interface ExpeditionPreview {
  dist: number;
  members: number;
  foodCost: number;      // 预计总耗粮
  oilCost: number;       // v5: 载具油耗
  etaSec: number;        // 1× 下单程耗时 (秒)
  ruin: string | null;   // 若目标点已知遗迹
  inFog: boolean;
}

export interface UISnapshot {
  day: number;
  hour: number;
  minute: number;          // 分钟 0-59 (精细时钟)
  speed: GameSpeed;
  era: number;
  res: Record<ResourceKey, number>;
  resCap: Record<ResourceKey, number>;
  pop: number;
  popCap: number;
  workersEmployed: number;
  workersTotal: number;
  happiness: number;
  order: number;
  powerSupply: number;
  powerDemand: number;
  waterSupply: number;
  waterDemand: number;
  stats: Record<ResourceKey, ResourceStat>;
  foodDaysLeft: number; // 存粮可支撑天数, -1 为无限
  research: string[];
  buildings: number;
  treeCount: number;
  eventActive: { storm: number; riot: number }; // 剩余天数
  gameOver: null | { win: boolean; reason: string };
  // 管网
  pipePowerConnected: number; // 接入电网建筑数
  pipePowerTotal: number;     // 需接入建筑数
  pipeWaterConnected: number;
  pipeWaterTotal: number;
  // 政策
  taxPolicy: number;         // 税率 0低 1中 2高
  // 市政独立机制
  scrolls: number;           // 典籍 (图书馆产出, 抵扣研究)
  loan: number;              // 未偿贷款
  attraction: number;        // 移民吸引力 (人/日)
  birthRate: number;         // 生育率 (人/日)
  // 水电
  waterBuffer: number;       // 蓄水池缓冲
  waterBufferCap: number;
  // 市政预算 (0.5~1.5)
  budgets: Record<string, number>;
  budgetCost: number;         // 预算额外每日开支
  // 地价
  landValue: number;          // 全城平均地价 0-100
  // 就业
  jobsTotal: number;          // 岗位总数
  // 军备
  weaponTier: number;
  armorTier: number;
  squadSize: number;
  battleWins: number;
  // v5 载具与管网
  vehicles: { apc: number; tank: number; heli: number };
  gridWarnings: { power: number; water: number };
  // 远征
  expeditions: {
    id: number; members: number; dist: number; traveled: number;
    vehicles: { apc: number; tank: number; heli: number };
    state: ExpeditionState; tx: number; ty: number; foodUsed: number;
    etaSec: number;          // 预计剩余秒 (1×)
    foodPerSec: number;      // 每秒耗粮 (1×)
  }[];
  // 战斗
  battleActive: boolean;
  // 人力
  laborManual: boolean;
  idleWorkers: number;
  // 难度 (0平和/1标准/2严酷)
  difficulty: number;
  // 贸易 (当日本)
  tradeSpent: number;
  tradeEarned: number;
  // 开发者
  devMode: boolean;
  freeBuild: boolean;
  devSpeed: number; // 0=正常档位
  // 画质
  quality: 'low' | 'med' | 'high';
}
