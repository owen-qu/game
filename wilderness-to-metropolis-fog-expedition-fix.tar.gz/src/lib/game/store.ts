// ===== 荒野筑城 · UI 状态桥 =====
'use client';
import { create } from 'zustand';
import type { UISnapshot, NotificationItem } from './types';
import type { GameEngine } from './engine';
import type { GameRenderer, Mode } from './renderer';
import { BUILDING_DEFS } from './buildings';
import { ERAS } from './constants';

export interface SelectedInfo {
  id: number;
  defId: string;
  hp: number;
  fire: number;
  workers: number;
  efficiency: number;
  damaged: boolean;
  progress: number;
  alerts: string[];
  rot: number;
  strike: number;
}

interface GameStore {
  engine: GameEngine | null;
  renderer: GameRenderer | null;
  snap: UISnapshot | null;
  notifications: NotificationItem[];
  selected: SelectedInfo | null;
  mode: Mode;
  activeCategory: string;
  showTech: boolean;
  showHelp: boolean;
  showStats: boolean;
  showStart: boolean;
  showDev: boolean;
  showSquad: boolean;
  showLabor: boolean;
  /** 远征目标 (点击探索模式选点后) */
  expeditionTarget: { x: number; y: number } | null;
  viewMode: string;
  lastPlaced: string | null;
  /** 道路/管线连线预览 (格数与总造价) */
  linePreview: { count: number; cost: Record<string, number> } | null;
  /** 悬停格坐标 (顶栏/远征信息用) */
  hoverTile: { x: number; y: number } | null;
  setEngine: (e: GameEngine, r: GameRenderer) => void;
  setSnap: (s: UISnapshot, notifications: NotificationItem[]) => void;
  setSelected: (s: SelectedInfo | null) => void;
  setMode: (m: Mode) => void;
  setCategory: (c: string) => void;
  setPanel: (k: 'showTech' | 'showHelp' | 'showStats' | 'showStart' | 'showDev' | 'showSquad' | 'showLabor', v: boolean) => void;
  setViewMode: (v: string) => void;
  setLastPlaced: (id: string | null) => void;
  setExpeditionTarget: (t: { x: number; y: number } | null) => void;
  setHoverTile: (t: { x: number; y: number } | null) => void;
}

export const useGame = create<GameStore>((set, get) => ({
  engine: null,
  renderer: null,
  snap: null,
  notifications: [],
  selected: null,
  mode: { type: 'none' },
  activeCategory: 'housing',
  showTech: false,
  showHelp: false,
  showStats: false,
  showStart: true,
  showDev: false,
  showSquad: false,
  showLabor: false,
  expeditionTarget: null,
  viewMode: 'none',
  lastPlaced: null,
  linePreview: null,
  hoverTile: null,
  setEngine: (e, r) => set({ engine: e, renderer: r }),
  setSnap: (s, notifications) => set({ snap: s, notifications }),
  setSelected: (s) => set({ selected: s }),
  setMode: (m) => set({ mode: m }),
  setCategory: (c) => set({ activeCategory: c }),
  setPanel: (k, v) => set({ [k]: v } as any),
  setViewMode: (v) => set({ viewMode: v }),
  setLastPlaced: (id) => set({ lastPlaced: id }),
  setExpeditionTarget: (t) => set({ expeditionTarget: t }),
  setHoverTile: (t) => set({ hoverTile: t }),
}));

// ---- 供 UI 调用的动作 ----
export function makeActions(get: () => () => GameStore) {
  const g = () => (get as any)() as GameStore;
  return {
    place: (defId: string, x: number, y: number) => {
      const st = g();
      if (!st.engine) return false;
      return st.engine.place(defId, x, y);
    },
    chop: (x: number, y: number) => {
      const st = g();
      if (!st.engine) return;
      const got = st.engine.chopAt(x, y);
      if (got.wood > 0) st.engine.notify('info', '砍伐树木', '+4 木材', 'good');
      if (got.stone > 0) st.engine.notify('info', '开采石块', '+3 石料', 'good');
    },
    demolish: (id: number) => {
      const st = g();
      if (!st.engine) return;
      st.engine.removeBuilding(id, true);
      st.renderer?.selectBuilding(null);
    },
    setSpeed: (s: 0 | 1 | 2 | 3) => {
      const st = g();
      if (st.engine) st.engine.speed = s;
    },
  };
}
