// ===== 荒野筑城 · 原创配乐与音效引擎 (Web Audio 程序化实时作曲) =====
// 五个时代各有一首风格迥异的原创配乐, 随昼夜/天灾动态变化, 全部由振荡器与噪声实时合成。

'use client';

// ---------- 音阶/音高工具 ----------
const mtof = (m: number) => 440 * Math.pow(2, (m - 69) / 12);

/** 简易可复现随机 (旋律生成用, 保证每次听起来是"同一首曲子") */
function mulberry32(seed: number) {
  let a = seed >>> 0;
  return () => {
    a |= 0; a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

interface EraTrack {
  bpm: number;
  root: number;                 // 根音 midi
  chords: number[][];           // 每小节和弦 (相对根音的半音)
  scale: number[];              // 旋律可用音 (相对根音半音)
  swing: number;                // 16分音符摇摆 0~0.25
  drums: { kick: string; snare?: string; hat?: string; tom?: string; shaker?: string; timpani?: string };
  bass: { pattern: string; wave: OscillatorType; oct: number };
  arp?: { pattern: string; wave: OscillatorType; gain: number; oct: number };
  pad: { wave: OscillatorType; cutoff: number; gain: number };
  lead: 'flute' | 'harp' | 'organ' | 'synth' | 'epic';
  leadGain: number;
  melodyDensity: number;        // 0~1 八分音符出音概率
  crash: boolean;
}

// 鼓组 pattern: 16 字符, 'x' 强 'o' 弱 '.' 无
const TRACKS: EraTrack[] = [
  // ===== 时代0 荒野部落: D 小调 · i-VI-III-VII 部落鼓与木笛 =====
  {
    bpm: 76, root: 50, scale: [0, 3, 5, 7, 10, 12, 15],
    chords: [[0, 3, 7], [-4, 0, 3], [3, 7, 10], [-2, 2, 5]],
    swing: 0.12,
    drums: { kick: 'x.......x...o...', tom: '....o.......o..o', shaker: '..o...o...o...o.' },
    bass: { pattern: 'x.......x.......', wave: 'triangle', oct: -12 },
    arp: { pattern: 'x.....x.....x...', wave: 'sine', gain: 0.055, oct: 12 },
    pad: { wave: 'triangle', cutoff: 620, gain: 0.16 },
    lead: 'flute', leadGain: 0.30, melodyDensity: 0.42, crash: false,
  },
  // ===== 时代1 农耕村落: F 大调 · I-V-vi-IV 竖琴与牧歌 =====
  {
    bpm: 88, root: 53, scale: [0, 2, 4, 7, 9, 12, 14],
    chords: [[0, 4, 7], [-5, -1, 2], [-3, 0, 4], [5, 9, 12]],
    swing: 0.08,
    drums: { kick: 'x.......o.......', shaker: '..o.o.o...o.o.o.', tom: '........x.......' },
    bass: { pattern: 'x...o...x...o...', wave: 'triangle', oct: -12 },
    arp: { pattern: 'x..x..x.x..x..x.', wave: 'sine', gain: 0.075, oct: 12 },
    pad: { wave: 'sine', cutoff: 900, gain: 0.2 },
    lead: 'harp', leadGain: 0.26, melodyDensity: 0.55, crash: false,
  },
  // ===== 时代2 工业城镇: A 自然小调 · i-VI-III-VII 蒸汽进行曲 =====
  {
    bpm: 102, root: 45, scale: [0, 2, 3, 5, 7, 8, 10, 12],
    chords: [[0, 3, 7], [-4, 0, 3], [3, 7, 10], [-2, 2, 5]],
    swing: 0,
    drums: { kick: 'x...x...x...x...', snare: '....x.......x...', hat: '..x...x...x...x.' },
    bass: { pattern: 'x.x.x.x.x.x.x.x.', wave: 'sawtooth', oct: -12 },
    arp: { pattern: 'x.x.x.x.x.x.x.x.', wave: 'triangle', gain: 0.09, oct: 12 },
    pad: { wave: 'square', cutoff: 520, gain: 0.11 },
    lead: 'organ', leadGain: 0.20, melodyDensity: 0.6, crash: false,
  },
  // ===== 时代3 电气都市: C# 小调 · i7-VI△7-III△7-VII7 合成器浪潮 =====
  {
    bpm: 114, root: 49, scale: [0, 2, 3, 5, 7, 8, 10, 12, 14],
    chords: [[0, 3, 7, 10], [-4, 0, 3, 7], [-5, -1, 2, 6], [-2, 2, 5, 9]],
    swing: 0,
    drums: { kick: 'x...x...x...x...', snare: '....x.......x..x', hat: 'x.x.x.x.x.x.x.x.' },
    bass: { pattern: 'x.xxx.x.x.xxx.xx', wave: 'sawtooth', oct: -12 },
    arp: { pattern: 'x.xxx.x.xx.xx.x.', wave: 'square', gain: 0.06, oct: 12 },
    pad: { wave: 'sawtooth', cutoff: 850, gain: 0.10 },
    lead: 'synth', leadGain: 0.22, melodyDensity: 0.7, crash: true,
  },
  // ===== 时代4 现代都会: D 大调 · I△7-V-vi7-IV△7 史诗颂歌 =====
  {
    bpm: 122, root: 50, scale: [0, 2, 4, 5, 7, 9, 11, 12, 14, 16],
    chords: [[0, 4, 7, 11], [7, 11, 14, 18], [-3, 0, 2, 7], [5, 9, 12, 16]],
    swing: 0,
    drums: { kick: 'x..x..x.x..x..x.', snare: '....x.......x...', hat: '..x...x...x...x.', timpani: 'x.......x...x..x' },
    bass: { pattern: 'x.x..x.xx.x..x.x', wave: 'sawtooth', oct: -12 },
    arp: { pattern: 'x..x..x.x..x..x.', wave: 'triangle', gain: 0.10, oct: 12 },
    pad: { wave: 'sawtooth', cutoff: 1100, gain: 0.15 },
    lead: 'epic', leadGain: 0.32, melodyDensity: 0.66, crash: true,
  },
];

/** B 面曲目: 每个时代两首轮换, 大幅扩充音乐量 */
const TRACKS_ALT: EraTrack[] = [
  // ===== 时代0-B 荒野夜歌: A 小调 · i-iv-VII-III 安静篝火 =====
  {
    bpm: 68, root: 45, scale: [0, 2, 3, 5, 7, 8, 10, 12],
    chords: [[0, 3, 7], [5, 8, 12], [-2, 2, 5], [3, 7, 10]],
    swing: 0.16,
    drums: { kick: 'x.......o.......', shaker: '....o.......o...', tom: '........x.....o.' },
    bass: { pattern: 'x.......o...o...', wave: 'sine', oct: -12 },
    arp: { pattern: 'x...x.....x...x.', wave: 'sine', gain: 0.05, oct: 12 },
    pad: { wave: 'sine', cutoff: 480, gain: 0.17 },
    lead: 'harp', leadGain: 0.24, melodyDensity: 0.4, crash: false,
  },
  // ===== 时代1-B 田园夜曲: G 大调 · I-vi-ii-V 摇篮曲风 =====
  {
    bpm: 80, root: 55, scale: [0, 2, 4, 7, 9, 11, 12],
    chords: [[0, 4, 7], [-3, 0, 4], [2, 5, 9], [-5, -1, 2]],
    swing: 0.1,
    drums: { kick: 'x.......o.......', shaker: '..o...o...o...o.' },
    bass: { pattern: 'x.....o.x.....o.', wave: 'sine', oct: -12 },
    arp: { pattern: 'x..x..x..x..x..x', wave: 'sine', gain: 0.07, oct: 12 },
    pad: { wave: 'triangle', cutoff: 760, gain: 0.19 },
    lead: 'flute', leadGain: 0.26, melodyDensity: 0.5, crash: false,
  },
  // ===== 时代2-B 烟囱圆舞曲: E 小调 · i-VII-VI-V 圆舞曲 =====
  {
    bpm: 96, root: 52, scale: [0, 2, 3, 5, 7, 8, 10, 12],
    chords: [[0, 3, 7], [-2, 2, 5], [-4, 0, 3], [-5, -1, 2]],
    swing: 0,
    drums: { kick: 'x..o..x..o..x..o', snare: '....o.......o...', hat: '..x...x...x...x.' },
    bass: { pattern: 'x..x..x.x..x..x.', wave: 'triangle', oct: -12 },
    arp: { pattern: 'x..x..x..x..x..x', wave: 'triangle', gain: 0.08, oct: 12 },
    pad: { wave: 'square', cutoff: 600, gain: 0.09 },
    lead: 'harp', leadGain: 0.24, melodyDensity: 0.58, crash: false,
  },
  // ===== 时代3-B 靓虹漫步: E 大调 · I-IV-vii-V 慢电波 =====
  {
    bpm: 100, root: 52, scale: [0, 2, 4, 6, 7, 9, 11, 12],
    chords: [[0, 4, 7], [5, 9, 12], [7, 11, 14], [-1, 2, 6]],
    swing: 0,
    drums: { kick: 'x.....x.x.....x.', snare: '....x.......x...', hat: 'x.x.x.x.x.x.x.x.' },
    bass: { pattern: 'x.....x.x...x...', wave: 'sawtooth', oct: -12 },
    arp: { pattern: 'x..x..x..x..x..x', wave: 'sine', gain: 0.07, oct: 12 },
    pad: { wave: 'sawtooth', cutoff: 720, gain: 0.11 },
    lead: 'synth', leadGain: 0.2, melodyDensity: 0.62, crash: false,
  },
  // ===== 时代4-B 天际线协奏: ♭B 大调 · I-vii-IV-V 颂歌变奏 =====
  {
    bpm: 116, root: 58, scale: [0, 2, 4, 5, 7, 9, 11, 12, 14],
    chords: [[0, 4, 7, 11], [7, 11, 14], [5, 9, 12, 16], [-1, 2, 6, 9]],
    swing: 0,
    drums: { kick: 'x...x..xx...x...', snare: '....x.......x..x', hat: '..x...x...x...x.', timpani: 'x...............' },
    bass: { pattern: 'x...x..x.x..x...', wave: 'sawtooth', oct: -12 },
    arp: { pattern: 'x.x..x.x.x..x.x.', wave: 'triangle', gain: 0.09, oct: 12 },
    pad: { wave: 'sawtooth', cutoff: 980, gain: 0.14 },
    lead: 'epic', leadGain: 0.3, melodyDensity: 0.6, crash: true,
  },
];

/** v5 战斗主题曲: 「荒野战歌」 D 小调 i-VI-III-VII · iv-V 终止 —— 手写英雄主题 */
const BATTLE_TRACK: EraTrack = {
  bpm: 138, root: 50,
  scale: [0, 2, 3, 5, 7, 8, 10, 12, 14],
  chords: [[0, 3, 7], [-4, 0, 3], [3, 7, 10], [-2, 2, 5], [0, 3, 7], [-5, -1, 2], [7, 11, 14], [0, 3, 7]],
  swing: 0,
  drums: {
    kick: 'x...x..xx...x...',
    snare: '....x..x....x.xo',
    hat: 'x.x.x.x.x.x.x.x.',
    timpani: 'x.......x.......',
  },
  bass: { pattern: 'x..x..x.x..x..x.', wave: 'sawtooth', oct: -12 },
  arp: { pattern: 'x.xxx.x.x.xxx.x.', wave: 'square', gain: 0.05, oct: 12 },
  pad: { wave: 'sawtooth', cutoff: 720, gain: 0.12 },
  lead: 'epic', leadGain: 0.34, melodyDensity: 0.85, crash: true,
};

/** 手写战斗主旋律 (64 个八分音符槽, 值为音级索引, -1 休止)
 *  乐句结构: A(0-1) D-Bb 起; A'(2-3) F-C 承; B(4-5) Dm-Gm 转; 高潮(6) A 大三; 终止(7) Dm 合 */
const BATTLE_MELODY = [
  0, -1, 2, -1, 4, -1, 4, 3,   // D  F  A  A G
  2, -1, 2, -1, 1, -1, 0, -1,  // F  F  E  D—
  5, -1, 5, -1, 4, -1, 3, 2,   // Bb Bb A  G F
  4, -1, 3, -1, 2, -1, 3, -1,  // A  G  F  G—
  0, -1, 2, -1, 4, -1, 6, -1,  // D  F  A  C—
  7, -1, 6, -1, 5, -1, 4, -1,  // D' C  Bb A—
  8, -1, 7, -1, 5, -1, 4, -1,  // E' D' Bb A—(高潮)
  4, -1, 3, -1, 2, -1, 0, -1,  // A  G  F  D—(终止)
];

type SfxName =
  | 'build' | 'chop' | 'mine' | 'fire' | 'extinguish' | 'storm' | 'riot'
  | 'nuke' | 'order' | 'morning' | 'night' | 'era' | 'win' | 'lose' | 'click'
  | 'hammer' | 'saw' | 'drill' | 'treefall' | 'road' | 'demolish' | 'error'
  | 'complete' | 'coin' | 'horn' | 'select' | 'research' | 'place'
  // v3: 战斗 / 远征 / 迷雾 / 市政
  | 'slash' | 'hit' | 'crit' | 'guard' | 'miss' | 'victory' | 'defeat' | 'flee'
  | 'dig' | 'discover' | 'baby' | 'loan' | 'repay' | 'march' | 'battle' | 'scout';

interface SfxDef {
  urls: string[];        // 分层采样 (可叠加以加厚音色)
  gain?: number;         // 音量
  maxSec?: number;       // 截断 (环境类采样只播前几秒)
  delays?: number[];     // 每层延迟 (秒)
  rates?: number[];      // 每层速率
  reverb?: number;       // 混响发送量
}

// Kenney CC0 音频包 (jsDelivr 镜像) 与 Google 免费音效库
const KEN = 'https://cdn.jsdelivr.net/gh/receptron/mulmocast-media@main/soundeffects/kenney';
const GGL = 'https://actions.google.com/sounds/v1';

const SFX_LIB: Record<SfxName, SfxDef> = {
  // ---- 建造 / 施工 ----
  build:     { urls: [`${GGL}/tools/hammering_into_wood.ogg`], gain: 0.8, maxSec: 1.6 },
  hammer:    { urls: [`${GGL}/tools/hammer_on_cement.ogg`], gain: 0.7, maxSec: 1.2 },
  saw:       { urls: [`${GGL}/tools/small_reciprocating_saw_burst.ogg`], gain: 0.65, maxSec: 1.6 },
  drill:     { urls: [`${GGL}/tools/small_drill.ogg`], gain: 0.65, maxSec: 1.4 },
  road:      { urls: [`${GGL}/tools/shovel_digging_dirt.ogg`], gain: 0.75, maxSec: 1.8 },
  dig:       { urls: [`${GGL}/tools/digging_with_trowel.ogg`], gain: 0.75, maxSec: 1.6 },
  place:     { urls: [`${KEN}/interface-sounds/drop_002.ogg`], gain: 0.9 },
  complete:  { urls: [`${KEN}/interface-sounds/confirmation_001.ogg`], gain: 0.9 },
  demolish:  { urls: [`${GGL}/impacts/rubble_crash.ogg`], gain: 0.9, maxSec: 2.2 },
  chop:      { urls: [`${KEN}/rpg-audio/chop.ogg`, `${KEN}/rpg-audio/chop.ogg`], delays: [0, 0.22], gain: 0.85 },
  mine:      { urls: [`${KEN}/impact-sounds/impactMining_000.ogg`, `${KEN}/impact-sounds/impactMining_003.ogg`], delays: [0, 0.2], gain: 0.85 },
  treefall:  { urls: [`${GGL}/impacts/taking_down_a_dead_tree.ogg`], gain: 0.95, maxSec: 2.6 },
  // ---- 界面 ----
  click:     { urls: [`${KEN}/ui-audio/click4.ogg`], gain: 0.8 },
  select:    { urls: [`${KEN}/interface-sounds/select_001.ogg`], gain: 0.8 },
  order:     { urls: [`${KEN}/interface-sounds/confirmation_002.ogg`], gain: 0.8 },
  error:     { urls: [`${KEN}/interface-sounds/error_001.ogg`], gain: 0.85 },
  coin:      { urls: [`${KEN}/casino-audio/chips-collide-2.ogg`, `${KEN}/casino-audio/chips-collide-4.ogg`], delays: [0, 0.07], gain: 0.8 },
  research:  { urls: [`${KEN}/rpg-audio/bookFlip1.ogg`], gain: 0.9 },
  loan:      { urls: [`${KEN}/casino-audio/chips-handle-3.ogg`], gain: 0.85, maxSec: 1.4 },
  repay:     { urls: [`${KEN}/casino-audio/chips-stack-5.ogg`], gain: 0.85, maxSec: 1.4 },
  // ---- 昼夜 / 时代 ----
  morning:   { urls: [`${GGL}/animals/june_songbirds.ogg`], gain: 0.5, maxSec: 2.6, reverb: 0.25 },
  night:     { urls: [`${GGL}/animals/owl_hooting.ogg`], gain: 0.45, maxSec: 2.4, reverb: 0.3 },
  era:       { urls: [`${KEN}/digital-audio/powerUp4.ogg`], gain: 0.9 },
  win:       { urls: [`${GGL}/crowds/team_cheer.ogg`], gain: 0.85, maxSec: 3, reverb: 0.3 },
  lose:      { urls: [`${KEN}/digital-audio/phaserDown2.ogg`], gain: 0.85 },
  // ---- 灾害 / 事件 ----
  fire:      { urls: [`${GGL}/ambiences/fire.ogg`], gain: 0.7, maxSec: 3.4, reverb: 0.2 },
  extinguish:{ urls: [`${GGL}/water/water_spray_into_bucket.ogg`], gain: 0.8, maxSec: 2 },
  storm:     { urls: [`${GGL}/weather/thunder_crack.ogg`], gain: 1.0, reverb: 0.3 },
  riot:      { urls: [`${GGL}/crowds/voices_angry.ogg`], gain: 0.7, maxSec: 2.4 },
  nuke:      { urls: [`${GGL}/weapons/big_explosion_sweeping_in.ogg`], gain: 1.0, reverb: 0.35 },
  horn:      { urls: [`${GGL}/transportation/car_horn.ogg`], gain: 0.8, maxSec: 1.5 },
  baby:      { urls: [`${GGL}/human_sounds/baby_cry_long.ogg`], gain: 0.5, maxSec: 1.8 },
  discover:  { urls: [`${GGL}/cartoon/wind_chimes.ogg`], gain: 0.6, maxSec: 2.6, reverb: 0.35 },
  march:     { urls: [`${GGL}/crowds/wild_battle_crowd_approach.ogg`], gain: 0.6, maxSec: 3, reverb: 0.25 },
  scout:     { urls: [`${GGL}/cartoon/wooden_train_whistle.ogg`], gain: 0.5, maxSec: 1.6, reverb: 0.3 },
  // ---- 战斗 ----
  battle:    { urls: [`${GGL}/alarms/bugle_tune.ogg`], gain: 0.75, maxSec: 2.4, reverb: 0.25 },
  slash:     { urls: [`${KEN}/rpg-audio/knifeSlice.ogg`, `${KEN}/rpg-audio/knifeSlice2.ogg`], delays: [0, 0.08], gain: 0.85 },
  hit:       { urls: [`${KEN}/impact-sounds/impactPunch_heavy_000.ogg`], gain: 0.95 },
  crit:      { urls: [`${KEN}/impact-sounds/impactPunch_heavy_003.ogg`, `${KEN}/impact-sounds/impactMetal_light_002.ogg`], gain: 1.0 },
  guard:     { urls: [`${KEN}/impact-sounds/impactMetal_heavy_001.ogg`], gain: 0.75 },
  miss:      { urls: [`${GGL}/ambiences/swoosh.ogg`], gain: 0.75 },
  victory:   { urls: [`${GGL}/crowds/battle_crowd_celebration.ogg`], gain: 0.85, maxSec: 3, reverb: 0.3 },
  defeat:    { urls: [`${GGL}/cartoon/falling_whistle.ogg`], gain: 0.8, maxSec: 2 },
  flee:      { urls: [`${KEN}/impact-sounds/footstep_grass_000.ogg`, `${KEN}/impact-sounds/footstep_grass_002.ogg`, `${KEN}/impact-sounds/footstep_grass_004.ogg`], delays: [0, 0.2, 0.4], gain: 0.8 },
};

export class GameAudio {
  private ctx: AudioContext | null = null;
  private master: GainNode | null = null;
  private musicBus: GainNode | null = null;     // 时代配乐总线
  private musicFilter: BiquadFilterNode | null = null;
  private sfxBus: GainNode | null = null;
  private reverb: ConvolverNode | null = null;
  private reverbSend: GainNode | null = null;
  private noiseBuf: AudioBuffer | null = null;

  // 状态
  private era = 0;
  private night = false;
  private stormy = false;
  private targetEra = 0;
  private fading = false;
  private step = 0;
  private nextTime = 0;
  private timer: ReturnType<typeof setInterval> | null = null;
  private melody: number[] = [];       // 8 小节 × 8 个八分音符, 值为 scale 索引或 -1 休止
  private melodySeed = 1;
  private variant: 0 | 1 = 0;          // A/B 面曲目轮换
  private loopCount = 0;               // 每 2 个完整乐章换一面
  private battleMode = false;          // 战斗音乐模式
  private musicVol = 0.55;
  private sfxVol = 0.8;
  private muted = false;
  started = false;

  /** 战斗开始/结束: 切换战斗音乐 */
  setBattle(active: boolean) {
    if (this.battleMode === active) return;
    this.battleMode = active;
    if (!this.ctx || !this.musicBus) return;
    const t = this.ctx.currentTime;
    this.musicBus.gain.cancelScheduledValues(t);
    this.musicBus.gain.setTargetAtTime(0.0001, t, 0.3);
    window.setTimeout(() => {
      if (!this.ctx || !this.musicBus) return;
      this.step = 0;
      this.melodySeed = (this.battleMode ? 77713 : this.targetEra * 977 + 13) + this.loopCount;
      this.generateMelody();
      this.musicBus.gain.cancelScheduledValues(this.ctx.currentTime);
      this.musicBus.gain.setTargetAtTime(
        this.musicVol * (this.night ? 0.72 : 1) * (this.stormy ? 0.6 : 1),
        this.ctx.currentTime, 0.7);
    }, 900);
  }

  /** 必须在用户手势中调用 (浏览器自动播放策略) */
  ensure() {
    if (this.ctx) { void this.ctx.resume(); return; }
    try {
      const AC = window.AudioContext || (window as any).webkitAudioContext;
      const ctx: AudioContext = new AC();
      this.ctx = ctx;

      this.master = ctx.createGain();
      this.master.gain.value = this.muted ? 0 : 1;
      const comp = ctx.createDynamicsCompressor();
      comp.threshold.value = -20; comp.knee.value = 18; comp.ratio.value = 3.5;
      comp.attack.value = 0.004; comp.release.value = 0.24;
      this.master.connect(comp); comp.connect(ctx.destination);

      // 音乐总线 (昼夜低通)
      this.musicFilter = ctx.createBiquadFilter();
      this.musicFilter.type = 'lowpass';
      this.musicFilter.frequency.value = 18000;
      this.musicBus = ctx.createGain();
      this.musicBus.gain.value = this.musicVol;
      this.musicFilter.connect(this.musicBus);
      this.musicBus.connect(this.master);

      // 音效总线
      this.sfxBus = ctx.createGain();
      this.sfxBus.gain.value = this.sfxVol;
      this.sfxBus.connect(this.master);

      // 混响 (生成脉冲响应)
      this.reverb = ctx.createConvolver();
      this.reverb.buffer = this.makeImpulse(2.6, 2.4);
      this.reverbSend = ctx.createGain();
      this.reverbSend.gain.value = 0.30;
      this.reverbSend.connect(this.reverb);
      this.reverb.connect(this.master);

      // 白噪声缓冲
      const len = ctx.sampleRate * 2;
      const buf = ctx.createBuffer(1, len, ctx.sampleRate);
      const d = buf.getChannelData(0);
      for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
      this.noiseBuf = buf;

      this.started = true;
      this.nextTime = ctx.currentTime + 0.15;
      this.generateMelody();
      this.timer = setInterval(() => this.scheduler(), 80);
      this.preloadSfx(); // 后台预热高频音效采样
    } catch {
      this.ctx = null;
    }
  }

  dispose() {
    if (this.timer) clearInterval(this.timer);
    this.timer = null;
    try { this.ctx?.close(); } catch { /* */ }
    this.ctx = null;
    this.started = false;
  }

  // ---------- 公共控制 ----------
  setVolumes(music: number, sfx: number) {
    this.musicVol = music; this.sfxVol = sfx;
    this.persist();
    if (this.musicBus) this.musicBus.gain.value = music * (this.night ? 0.8 : 1) * (this.stormy ? 0.62 : 1);
    if (this.sfxBus) this.sfxBus.gain.value = sfx;
  }
  toggleMute(): boolean {
    this.muted = !this.muted;
    if (this.master) this.master.gain.value = this.muted ? 0 : 1;
    this.persist();
    return this.muted;
  }
  get isMuted() { return this.muted; }
  get volumes() { return { music: this.musicVol, sfx: this.sfxVol }; }

  private persist() {
    try { localStorage.setItem('wildcity_audio', JSON.stringify({ m: this.musicVol, s: this.sfxVol, muted: this.muted })); } catch { /* */ }
  }
  restore() {
    try {
      const raw = localStorage.getItem('wildcity_audio');
      if (raw) {
        const v = JSON.parse(raw);
        if (typeof v.m === 'number') this.musicVol = v.m;
        if (typeof v.s === 'number') this.sfxVol = v.s;
        if (typeof v.muted === 'boolean') this.muted = v.muted;
        this.setVolumes(this.musicVol, this.sfxVol);
        if (this.master) this.master.gain.value = this.muted ? 0 : 1;
      }
    } catch { /* */ }
  }

  /** 游戏状态同步 (每次 UI 刷新调用, 极轻量) */
  setGameState(era: number, hour: number, stormDays: number, _riotDays: number) {
    const night = hour < 5.5 || hour >= 19.5;
    if (night !== this.night) {
      this.night = night;
      this.applyMood();
    }
    const stormy = stormDays > 0;
    if (stormy !== this.stormy) {
      this.stormy = stormy;
      this.applyMood();
    }
    if (era !== this.targetEra) {
      this.targetEra = era;
      this.crossfadeTo(era);
    }
  }

  private applyMood() {
    if (!this.ctx || !this.musicBus || !this.musicFilter) return;
    const t = this.ctx.currentTime;
    this.musicBus.gain.cancelScheduledValues(t);
    this.musicBus.gain.setTargetAtTime(
      this.musicVol * (this.night ? 0.72 : 1) * (this.stormy ? 0.6 : 1), t, 0.8);
    this.musicFilter.frequency.cancelScheduledValues(t);
    this.musicFilter.frequency.setTargetAtTime(this.night ? 1500 : 18000, t, 1.2);
  }

  private crossfadeTo(era: number) {
    if (!this.ctx || !this.musicBus) return;
    const t = this.ctx.currentTime;
    if (this.fading) { this.era = Math.max(0, Math.min(4, era)); return; }
    this.fading = true;
    this.musicBus.gain.cancelScheduledValues(t);
    this.musicBus.gain.setTargetAtTime(0.0001, t, 0.45);
    const target = Math.max(0, Math.min(4, era));
    window.setTimeout(() => {
      this.era = target;
      this.step = 0;
      this.melodySeed = target * 977 + 13;
      this.generateMelody();
      if (this.ctx && this.musicBus) {
        this.musicBus.gain.cancelScheduledValues(this.ctx.currentTime);
        this.musicBus.gain.setTargetAtTime(
          this.musicVol * (this.night ? 0.72 : 1) * (this.stormy ? 0.6 : 1),
          this.ctx.currentTime, 0.8);
      }
      this.fading = false;
    }, 1400);
  }

  // ---------- 音序器 ----------
  private currentTrack(): EraTrack {
    if (this.battleMode) return BATTLE_TRACK;
    return this.variant === 0 ? TRACKS[this.era] : TRACKS_ALT[this.era];
  }

  private scheduler() {
    const ctx = this.ctx;
    if (!ctx) return;
    const tr = this.currentTrack();
    const stepDur = 60 / tr.bpm / 4;
    while (this.nextTime < ctx.currentTime + 0.28) {
      // 完整乐章结束 → B 面轮换
      if (this.step > 0 && this.step % 256 === 0 && !this.battleMode) {
        this.loopCount++;
        if (this.loopCount % 2 === 0) {
          this.variant = this.variant === 0 ? 1 : 0;
          this.melodySeed = (this.targetEra * 977 + 13) + this.loopCount + this.variant * 500;
          this.generateMelody();
        }
      }
      const trNow = this.currentTrack();
      const durNow = 60 / trNow.bpm / 4;
      this.scheduleStep(trNow, this.step, this.nextTime, durNow);
      this.nextTime += durNow;
      this.step++;
    }
  }

  private scheduleStep(tr: EraTrack, step: number, t: number, stepDur: number) {
    const s16 = step % 16;
    const barIdx = Math.floor(step / 16);
    const bar = barIdx % 8;                       // 8 小节循环
    const chord = tr.chords[barIdx % tr.chords.length];
    const swing = s16 % 2 === 1 ? stepDur * tr.swing : 0;
    const tt = t + swing;

    // --- 鼓组 ---
    const d = tr.drums;
    if (d.kick[s16] === 'x') this.kick(tt, 0.9);
    else if (d.kick[s16] === 'o') this.kick(tt, 0.5);
    if (d.snare) {
      if (d.snare[s16] === 'x') this.snare(tt, this.era >= 3 ? 0.5 : 0.42);
    }
    if (d.hat) {
      if (d.hat[s16] === 'x') this.hat(tt, this.night ? 0.10 : 0.18);
    }
    if (d.tom) {
      if (d.tom[s16] === 'x') this.tom(tt, 0.5, 150);
      else if (d.tom[s16] === 'o') this.tom(tt, 0.34, 118);
    }
    if (d.shaker) {
      if (d.shaker[s16] === 'x' || d.shaker[s16] === 'o') this.shaker(tt, d.shaker[s16] === 'x' ? 0.2 : 0.13);
    }
    if (d.timpani && d.timpani[s16] === 'x' && !this.night) this.timpani(tt, 0.5);
    if (tr.crash && s16 === 0 && bar % 4 === 0 && !this.night) this.crash(tt, 0.16);

    // --- 贝斯 ---
    if (tr.bass.pattern[s16] === 'x' || tr.bass.pattern[s16] === 'o') {
      const strong = tr.bass.pattern[s16] === 'x';
      const bassNote = tr.root + chord[0] + tr.bass.oct;
      this.bass(tt, bassNote, stepDur * (strong ? 1.7 : 1.1), tr.bass.wave, strong ? 0.30 : 0.2);
    }

    // --- 琶音层 (16 分音符流转的和弦分解, 增添流动感) ---
    if (tr.arp && tr.arp.pattern[s16] === 'x') {
      const tones = chord.length;
      const tone = chord[(step + Math.floor(step / 16)) % tones];
      this.arpNote(tt, tr.root + tone + tr.arp.oct, stepDur * 1.9, tr.arp.wave, tr.arp.gain * (this.night ? 0.6 : 1));
    }

    // --- 和声垫 (每小节头) ---
    if (s16 === 0) {
      const notes = chord.map(c => tr.root + c);
      this.pad(t, notes, stepDur * 16 * 0.98, tr.pad);
    }

    // --- 旋律 (八分音符栅格) ---
    if (s16 % 2 === 0) {
      const slot = bar * 8 + s16 / 2;
      const deg = this.melody[slot] ?? -1;
      if (deg >= 0) {
        const oct = this.melodyOctave(bar);
        const midi = tr.root + tr.scale[deg % tr.scale.length] + 12 * (Math.floor(deg / tr.scale.length) + oct);
        const dur = stepDur * 2 * (1 + (Math.random() < 0.18 ? 1 : 0));
        this.lead(tt, midi, dur, tr.lead, tr.leadGain * (this.night ? 0.65 : 1));
      }
    }
  }

  /** 乐段结构: 前 4 小节主旋律, 中间呼吸, 后段推向高八度 */
  private melodyOctave(bar: number): number {
    if (this.battleMode) return 0;  // 战斗主题自带高潮设计
    if (bar >= 6) return 1;
    if (bar <= 1) return 0;
    return 0;
  }

  private generateMelody() {
    // v5: 战斗模式使用手写英雄主题 (不再随机生成)
    if (this.battleMode) {
      this.melody = [...BATTLE_MELODY];
      return;
    }
    const tr = this.currentTrack();
    const rand = mulberry32(this.melodySeed * 2654435761 % 4294967291);
    const N = 64;
    const out: number[] = new Array(N).fill(-1);
    let deg = 0;
    // AABA 乐段: 0-1 生成动机, 2-3 重复动机(贴合和弦), 4-5 留白呼吸, 6-7 动机高八度再现 (高潮)
    for (let bar = 0; bar < 8; bar++) {
      const chord = tr.chords[bar % tr.chords.length];
      const isMotifBar = bar <= 1;
      const isRepeatBar = bar === 2 || bar === 3;
      const isClimaxBar = bar >= 6;
      if (isRepeatBar || isClimaxBar) {
        // 复读动机小节 (2←0, 3←1, 6←0, 7←1)
        for (let e = 0; e < 8; e++) {
          const from = out[(bar % 2 === 0 ? 0 : 1) * 8 + e];
          if (from === undefined || from < 0) continue;
          let d = from;
          // 强拍贴合当前和弦
          if (e === 0 || e === 4) d = this.nearestChordDegree(tr, d, chord);
          out[bar * 8 + e] = d;
        }
        // 更新 deg
        const last = out[bar * 8 + 7];
        if (last >= 0) deg = last;
        continue;
      }
      const active = isMotifBar; // 4-5 留白
      for (let e = 0; e < 8; e++) {
        const slot = bar * 8 + e;
        if (!active) { continue; }
        // 夜间更稀疏
        const dens = tr.melodyDensity;
        if (rand() > dens) continue;
        // 强拍落在和弦音上
        if (e === 0 || e === 4) {
          deg = this.nearestChordDegree(tr, deg, chord);
        } else {
          const r = rand();
          if (r < 0.5) deg += rand() < 0.5 ? 1 : -1;        // 级进 (更歌唱性)
          else if (r < 0.68) deg += rand() < 0.5 ? 2 : -2;    // 跳进
          else if (r < 0.88) { /* 同音反复 */ }
          else deg += rand() < 0.5 ? 4 : -3;                  // 大跳
        }
        // 音域限制
        if (deg < 0) deg += 3;
        if (deg >= tr.scale.length * 2) deg -= 4;
        out[slot] = deg;
      }
      // 乐句收尾解决到和弦音
      const last = bar * 8 + 7;
      if (out[last] === undefined || out[last] >= 0) out[last] = this.nearestChordDegree(tr, out[last] < 0 ? deg : out[last], chord);
    }
    this.melody = out;
  }

  private nearestChordDegree(tr: EraTrack, deg: number, chord: number[]): number {
    // 找到与给定级数最近的"和弦音级数"
    let best = deg, bestDist = Infinity;
    for (let oct = 0; oct <= 2; oct++) {
      for (const semi of chord) {
        // 和弦音在音阶中的级数
        let d = -1;
        for (let i = 0; i < tr.scale.length; i++) {
          if (tr.scale[i] === semi % 12 || tr.scale[i] % 12 === semi % 12) { d = i + oct * tr.scale.length; break; }
        }
        if (d < 0) continue;
        const dist = Math.abs(d - deg);
        if (dist < bestDist) { bestDist = dist; best = d; }
      }
    }
    return best;
  }

  // ---------- 乐器 ----------
  /** 将乐器增益接入音乐总线 (含可选混响发送) */
  private wireOut(gain: GainNode, reverbAmt = 0.12) {
    gain.connect(this.musicFilter!);
    if (reverbAmt > 0 && this.reverbSend) {
      const send = this.ctx!.createGain();
      send.gain.value = reverbAmt;
      gain.connect(send); send.connect(this.reverbSend);
    }
  }

  private kick(t: number, vol: number) {
    const ctx = this.ctx!;
    const o = ctx.createOscillator(); const g = ctx.createGain();
    o.type = 'sine';
    o.frequency.setValueAtTime(130, t);
    o.frequency.exponentialRampToValueAtTime(44, t + 0.11);
    g.gain.setValueAtTime(vol * 0.9, t);
    g.gain.exponentialRampToValueAtTime(0.001, t + 0.24);
    o.connect(g);
    this.wireOut(g, 0.02);
    o.start(t); o.stop(t + 0.26);
  }

  private tom(t: number, vol: number, freq: number) {
    const ctx = this.ctx!;
    const o = ctx.createOscillator(); const g = ctx.createGain();
    o.type = 'sine';
    o.frequency.setValueAtTime(freq, t);
    o.frequency.exponentialRampToValueAtTime(freq * 0.55, t + 0.18);
    g.gain.setValueAtTime(vol * 0.7, t);
    g.gain.exponentialRampToValueAtTime(0.001, t + 0.3);
    o.connect(g);
    this.wireOut(g, 0.25);
    o.start(t); o.stop(t + 0.32);
  }

  private snare(t: number, vol: number) {
    const ctx = this.ctx!;
    const n = ctx.createBufferSource(); n.buffer = this.noiseBuf!;
    const f = ctx.createBiquadFilter(); f.type = 'bandpass'; f.frequency.value = 1900; f.Q.value = 0.9;
    const g = ctx.createGain();
    g.gain.setValueAtTime(vol, t);
    g.gain.exponentialRampToValueAtTime(0.001, t + 0.16);
    n.connect(f); f.connect(g);
    this.wireOut(g, 0.12);
    n.start(t, Math.random()); n.stop(t + 0.18);
    // 鼓身
    const o = ctx.createOscillator(); const og = ctx.createGain();
    o.type = 'triangle'; o.frequency.setValueAtTime(210, t);
    o.frequency.exponentialRampToValueAtTime(140, t + 0.09);
    og.gain.setValueAtTime(vol * 0.5, t);
    og.gain.exponentialRampToValueAtTime(0.001, t + 0.11);
    o.connect(og);
    this.wireOut(og, 0.02);
    o.start(t); o.stop(t + 0.12);
  }

  private hat(t: number, vol: number) {
    const ctx = this.ctx!;
    const n = ctx.createBufferSource(); n.buffer = this.noiseBuf!;
    const f = ctx.createBiquadFilter(); f.type = 'highpass'; f.frequency.value = 8200;
    const g = ctx.createGain();
    g.gain.setValueAtTime(vol, t);
    g.gain.exponentialRampToValueAtTime(0.001, t + 0.045);
    n.connect(f); f.connect(g);
    this.wireOut(g, 0.03);
    n.start(t, Math.random()); n.stop(t + 0.06);
  }

  private shaker(t: number, vol: number) {
    const ctx = this.ctx!;
    const n = ctx.createBufferSource(); n.buffer = this.noiseBuf!;
    const f = ctx.createBiquadFilter(); f.type = 'bandpass'; f.frequency.value = 5200; f.Q.value = 1.4;
    const g = ctx.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.linearRampToValueAtTime(vol, t + 0.014);
    g.gain.exponentialRampToValueAtTime(0.001, t + 0.07);
    n.connect(f); f.connect(g);
    this.wireOut(g, 0.06);
    n.start(t, Math.random()); n.stop(t + 0.09);
  }

  private timpani(t: number, vol: number) {
    const ctx = this.ctx!;
    const o = ctx.createOscillator(); const g = ctx.createGain();
    o.type = 'sine';
    o.frequency.setValueAtTime(96, t);
    o.frequency.exponentialRampToValueAtTime(72, t + 0.3);
    g.gain.setValueAtTime(vol, t);
    g.gain.exponentialRampToValueAtTime(0.001, t + 0.9);
    o.connect(g);
    this.wireOut(g, 0.4);
    o.start(t); o.stop(t + 0.95);
  }

  private crash(t: number, vol: number) {
    const ctx = this.ctx!;
    const n = ctx.createBufferSource(); n.buffer = this.noiseBuf!;
    const f = ctx.createBiquadFilter(); f.type = 'highpass'; f.frequency.value = 4800;
    const g = ctx.createGain();
    g.gain.setValueAtTime(vol, t);
    g.gain.exponentialRampToValueAtTime(0.0008, t + 1.4);
    n.connect(f); f.connect(g);
    this.wireOut(g, 0.5);
    n.start(t, Math.random()); n.stop(t + 1.5);
  }

  /** 琶音: 短促明亮的拨弦式音符, 让和声流动起来 */
  private arpNote(t: number, midi: number, dur: number, wave: OscillatorType, vol: number) {
    const ctx = this.ctx!;
    const o = ctx.createOscillator(); const g = ctx.createGain();
    const f = ctx.createBiquadFilter(); f.type = 'lowpass'; f.frequency.value = 2400; f.Q.value = 0.6;
    o.type = wave; o.frequency.value = mtof(midi);
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(Math.max(0.001, vol), t + 0.014);
    g.gain.exponentialRampToValueAtTime(0.0008, t + dur);
    o.connect(f); f.connect(g);
    this.wireOut(g, 0.2);
    o.start(t); o.stop(t + dur + 0.02);
  }

  private bass(t: number, midi: number, dur: number, wave: OscillatorType, vol: number) {
    const ctx = this.ctx!;
    const o = ctx.createOscillator(); const g = ctx.createGain();
    const f = ctx.createBiquadFilter(); f.type = 'lowpass'; f.frequency.value = 420; f.Q.value = 0.8;
    o.type = wave; o.frequency.value = mtof(midi);
    g.gain.setValueAtTime(0.0001, t);
    g.gain.linearRampToValueAtTime(vol, t + 0.012);
    g.gain.setTargetAtTime(0.0001, t + dur * 0.72, dur * 0.16);
    o.connect(f); f.connect(g);
    this.wireOut(g, 0.02);
    o.start(t); o.stop(t + dur + 0.1);
  }

  private pad(t: number, midis: number[], dur: number, cfg: EraTrack['pad']) {
    const ctx = this.ctx!;
    const f = ctx.createBiquadFilter(); f.type = 'lowpass'; f.frequency.value = cfg.cutoff; f.Q.value = 0.6;
    const g = ctx.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.linearRampToValueAtTime(cfg.gain, t + dur * 0.24);
    g.gain.setTargetAtTime(0.0001, t + dur * 0.8, dur * 0.14);
    f.connect(g);
    this.wireOut(g, 0.3);
    // LFO 轻微调制滤波
    const lfo = ctx.createOscillator(); const lg = ctx.createGain();
    lfo.frequency.value = 0.16; lg.gain.value = cfg.cutoff * 0.24;
    lfo.connect(lg); lg.connect(f.frequency);
    lfo.start(t); lfo.stop(t + dur + 0.4);
    for (const m of midis) {
      for (const det of [-4, 4]) {
        const o = ctx.createOscillator();
        o.type = cfg.wave; o.frequency.value = mtof(m); o.detune.value = det;
        o.connect(f);
        o.start(t); o.stop(t + dur + 0.4);
      }
    }
  }

  private lead(t: number, midi: number, dur: number, kind: EraTrack['lead'], vol: number) {
    const ctx = this.ctx!;
    const g = ctx.createGain();
    const humanize = (Math.random() - 0.5) * 0.012;
    const t0 = t + humanize;
    if (kind === 'flute') {
      // 木笛: 正弦 + 颤音 + 气声
      const o = ctx.createOscillator(); o.type = 'sine'; o.frequency.value = mtof(midi);
      const vib = ctx.createOscillator(); const vg = ctx.createGain();
      vib.frequency.value = 5.2; vg.gain.value = mtof(midi) * 0.006;
      vib.connect(vg); vg.connect(o.frequency);
      g.gain.setValueAtTime(0.0001, t0);
      g.gain.linearRampToValueAtTime(vol, t0 + 0.05);
      g.gain.setTargetAtTime(vol * 0.75, t0 + 0.08, 0.1);
      g.gain.setTargetAtTime(0.0001, t0 + dur * 0.8, 0.09);
      o.connect(g);
      this.wireOut(g, 0.35);
      // 气声
      const n = ctx.createBufferSource(); n.buffer = this.noiseBuf!;
      const nf = ctx.createBiquadFilter(); nf.type = 'bandpass'; nf.frequency.value = mtof(midi) * 2; nf.Q.value = 2;
      const ng = ctx.createGain(); ng.gain.value = vol * 0.06;
      n.connect(nf); nf.connect(ng);
      this.wireOut(ng, 0.2);
      o.start(t0); o.stop(t0 + dur + 0.15); vib.start(t0); vib.stop(t0 + dur + 0.15);
      n.start(t0, Math.random()); n.stop(t0 + dur + 0.1);
    } else if (kind === 'harp') {
      // 竖琴: 快速衰减 + 高音区明亮
      const o = ctx.createOscillator(); o.type = 'triangle'; o.frequency.value = mtof(midi);
      const o2 = ctx.createOscillator(); o2.type = 'sine'; o2.frequency.value = mtof(midi + 12);
      g.gain.setValueAtTime(0.0001, t0);
      g.gain.linearRampToValueAtTime(vol, t0 + 0.008);
      g.gain.exponentialRampToValueAtTime(0.0008, t0 + Math.min(dur * 1.4, 1.1));
      o.connect(g); o2.connect(g);
      this.wireOut(g, 0.4);
      o.start(t0); o.stop(t0 + 1.3); o2.start(t0); o2.stop(t0 + 1.3);
    } else if (kind === 'organ') {
      const o = ctx.createOscillator(); o.type = 'square'; o.frequency.value = mtof(midi);
      const o2 = ctx.createOscillator(); o2.type = 'square'; o2.frequency.value = mtof(midi + 7);
      const f = ctx.createBiquadFilter(); f.type = 'lowpass'; f.frequency.value = 1600;
      g.gain.setValueAtTime(0.0001, t0);
      g.gain.linearRampToValueAtTime(vol, t0 + 0.03);
      g.gain.setTargetAtTime(0.0001, t0 + dur * 0.85, 0.06);
      o.connect(f); o2.connect(f); f.connect(g);
      this.wireOut(g, 0.28);
      o.start(t0); o.stop(t0 + dur + 0.1); o2.start(t0); o2.stop(t0 + dur + 0.1);
    } else if (kind === 'synth') {
      // 合成器: 锯齿 + 滤波扫频
      const o = ctx.createOscillator(); o.type = 'sawtooth'; o.frequency.value = mtof(midi);
      const f = ctx.createBiquadFilter(); f.type = 'lowpass'; f.Q.value = 7;
      f.frequency.setValueAtTime(500, t0);
      f.frequency.exponentialRampToValueAtTime(3400, t0 + 0.06);
      f.frequency.exponentialRampToValueAtTime(900, t0 + dur);
      g.gain.setValueAtTime(0.0001, t0);
      g.gain.linearRampToValueAtTime(vol, t0 + 0.014);
      g.gain.setTargetAtTime(0.0001, t0 + dur * 0.75, 0.07);
      o.connect(f); f.connect(g);
      this.wireOut(g, 0.3);
      o.start(t0); o.stop(t0 + dur + 0.2);
    } else {
      // epic: 双八度锯齿 + 力度渐强
      const o = ctx.createOscillator(); o.type = 'sawtooth'; o.frequency.value = mtof(midi);
      const o2 = ctx.createOscillator(); o2.type = 'sawtooth'; o2.frequency.value = mtof(midi + 12); o2.detune.value = 6;
      const f = ctx.createBiquadFilter(); f.type = 'lowpass'; f.frequency.value = 2600; f.Q.value = 1.2;
      g.gain.setValueAtTime(0.0001, t0);
      g.gain.linearRampToValueAtTime(vol, t0 + dur * 0.18);
      g.gain.setTargetAtTime(0.0001, t0 + dur * 0.82, 0.1);
      o.connect(f); o2.connect(f); f.connect(g);
      this.wireOut(g, 0.42);
      o.start(t0); o.stop(t0 + dur + 0.3); o2.start(t0); o2.stop(t0 + dur + 0.3);
    }
  }

  // ---------- 混响脉冲 ----------
  private makeImpulse(seconds: number, decay: number): AudioBuffer {
    const ctx = this.ctx!;
    const rate = ctx.sampleRate;
    const len = Math.floor(rate * seconds);
    const buf = ctx.createBuffer(2, len, rate);
    for (let ch = 0; ch < 2; ch++) {
      const d = buf.getChannelData(ch);
      for (let i = 0; i < len; i++) {
        const t = i / len;
        d[i] = (Math.random() * 2 - 1) * Math.pow(1 - t, decay) * (1 - t * 0.2);
      }
    }
    return buf;
  }

  // ---------- 音效 (网络采样库: Kenney CC0 + Google 免费音效库) ----------
  // BGM 保持本地合成不变; 所有 SFX 改为 CDN 在线采样。
  private sfxCache = new Map<SfxName, AudioBuffer[] | 'loading' | 'failed'>();

  /** 用户手势后预热高频音效 (后台静默加载) */
  private preloadSfx() {
    const priority: SfxName[] = ['click', 'select', 'error', 'place', 'complete', 'build', 'coin', 'hit', 'slash'];
    for (const n of priority) void this.loadSfxSet(n);
  }

  private async loadSfxSet(name: SfxName): Promise<AudioBuffer[] | null> {
    const def = SFX_LIB[name];
    if (!def) return null;
    try {
      const bufs = await Promise.all(def.urls.map(async u => {
        const resp = await fetch(u, { mode: 'cors' });
        if (!resp.ok) throw new Error(`sfx ${name}: HTTP ${resp.status}`);
        const ab = await resp.arrayBuffer();
        return await this.ctx!.decodeAudioData(ab);
      }));
      this.sfxCache.set(name, bufs);
      return bufs;
    } catch {
      this.sfxCache.set(name, 'failed');
      return null;
    }
  }

  /** 极简合成兜底: 离线 / CDN 失败时仍有可辨反馈 */
  private sfxFallback(name: SfxName) {
    const ctx = this.ctx!;
    const t = ctx.currentTime + 0.005;
    const o = ctx.createOscillator();
    const g = ctx.createGain();
    const bad = name === 'error' || name === 'lose' || name === 'defeat' || name === 'nuke';
    o.type = bad ? 'square' : 'triangle';
    o.frequency.setValueAtTime(bad ? 220 : 620, t);
    o.frequency.exponentialRampToValueAtTime(bad ? 110 : 300, t + 0.09);
    g.gain.setValueAtTime(0.07, t);
    g.gain.exponentialRampToValueAtTime(0.0008, t + 0.12);
    o.connect(g); g.connect(this.sfxBus!);
    o.start(t); o.stop(t + 0.14);
  }

  playSfx(name: SfxName) {
    const ctx = this.ctx;
    if (!ctx || this.sfxVol <= 0.001) return;
    const def = SFX_LIB[name];
    if (!def) { this.sfxFallback(name); return; }
    const cached = this.sfxCache.get(name);
    if (cached === 'failed') { this.sfxFallback(name); return; }
    if (Array.isArray(cached)) { this.fireSfx(cached, def); return; }
    if (!cached) {
      // 首次触发: 后台加载; 若加载够快 (800ms 内) 补播一次
      this.sfxCache.set(name, 'loading');
      const wantAt = performance.now();
      void this.loadSfxSet(name).then(bufs => {
        if (bufs && performance.now() - wantAt < 800) this.fireSfx(bufs, def);
      });
    }
  }

  private fireSfx(bufs: AudioBuffer[], def: SfxDef) {
    const ctx = this.ctx!;
    const base = ctx.currentTime + 0.005;
    bufs.forEach((buf, i) => {
      const src = ctx.createBufferSource();
      src.buffer = buf;
      // 轻微随机变调, 避免同一采样连续播放的机械感
      src.playbackRate.value = def.rates?.[i] ?? 1 + (Math.random() - 0.5) * 0.07;
      const vol = def.gain ?? 0.85;
      const t0 = base + (def.delays?.[i] ?? 0);
      const g = ctx.createGain();
      g.gain.setValueAtTime(0.0001, t0);
      g.gain.linearRampToValueAtTime(vol, t0 + 0.012);
      let dur = Math.max(0.05, buf.duration / src.playbackRate.value);
      if (def.maxSec) dur = Math.min(dur, def.maxSec);
      g.gain.setValueAtTime(vol, Math.max(t0 + 0.02, t0 + dur - 0.1));
      g.gain.linearRampToValueAtTime(0.0001, t0 + dur);
      src.connect(g); g.connect(this.sfxBus!);
      const rev = def.reverb ?? 0.1;
      if (this.reverbSend && rev > 0) {
        const send = ctx.createGain(); send.gain.value = rev;
        g.connect(send); send.connect(this.reverbSend);
      }
      src.start(t0); src.stop(t0 + dur + 0.03);
    });
  }
}

/** 全局唯一音频实例 (UI 与渲染器共用) */
export const gameAudio = new GameAudio();
