// ===== 荒野筑城 · Three.js 渲染器 (v3: 无限世界/迷雾/接线/远征) =====
import * as THREE from 'three';
import { BUILDING_DEFS } from './buildings';
import {
  buildModel, treeGeometries, citizenBodyGeometry, citizenHeadGeometry,
  carGeometry, cartGeometry, rockGeometry, mat, constructionSite,
} from './models';
import { battleUnitModel, squadMemberModel } from './battleScene';
import type { UtiliEdge } from './types';
import type { GameEngine } from './engine';
import type { Building, BattleState, BattleUnit, BattleEvent } from './types';
import { World, CHUNK, RUIN_MODEL_OF } from './terrain';
import type { ViewModeId } from './constants';

export type Mode =
  | { type: 'none' }
  | { type: 'build'; defId: string }
  | { type: 'chop' }
  | { type: 'demolish' }
  | { type: 'explore' }
  | { type: 'terrain'; terrain: string; brush: number };

export interface RendererCallbacks {
  onTileClick: (x: number, y: number) => void;
  onBuildingClick: (id: number) => void;
  onHover: (x: number, y: number) => void;
  syncUI: () => void;
  onSfx?: (name: string) => void;
  onLinePreview?: (count: number, cost: Record<string, number>) => void;
}

// 柔和圆点贴图(粒子)
function softDot(): THREE.Texture {
  const c = document.createElement('canvas'); c.width = c.height = 64;
  const ctx = c.getContext('2d')!;
  const g = ctx.createRadialGradient(32, 32, 2, 32, 32, 30);
  g.addColorStop(0, 'rgba(255,255,255,1)');
  g.addColorStop(0.4, 'rgba(255,255,255,0.55)');
  g.addColorStop(1, 'rgba(255,255,255,0)');
  ctx.fillStyle = g; ctx.fillRect(0, 0, 64, 64);
  return new THREE.CanvasTexture(c);
}

const TERRAIN_COLORS: Record<string, [number, number]> = {
  water: [0x2e6396, 0x27537f],
  sand: [0xd9c489, 0xcbb87c],
  grass: [0x5da24a, 0x549643],
  forest: [0x4a8a3c, 0x447e37],
  hill: [0x7fa35c, 0x71934f],
  mountain: [0x9aa1a8, 0x868d94],
};
// 迷雾色 (未探索区域)
const FOG_COLOR = new THREE.Color(0x232c3a);
const FOG_COLOR2 = new THREE.Color(0x1d2531);

// 居民(客户端模拟)
interface CitizenPathPoint { x: number; z: number; }
interface CitizenWorkTask {
  tileX: number; tileY: number; wx: number; wz: number;
  workX: number; workZ: number;
  isRock: boolean; isRuin: boolean;
}
interface ChopOrder {
  tileX: number; tileY: number; wx: number; wz: number;
  isRock: boolean; isRuin: boolean;
  retryIn: number;
}
interface CitizenPathResult {
  path: CitizenPathPoint[];
  goalX: number; goalY: number;
  cost: number;
}
interface CitizenAgent {
  x: number; z: number; tx: number; tz: number;
  speed: number; phase: number; hue: number;
  path: CitizenPathPoint[]; pathIndex: number; stuckTime: number;
  task: CitizenWorkTask | null;
  working: boolean;
}
interface CarAgent { x: number; z: number; tx: number; tz: number; speed: number; kind: 0 | 1; }

/** 远征队行军小队 (客户端视觉) */
interface ExpeditionParty {
  group: THREE.Group;
  members: THREE.Group[];      // v5: 每人独立模型
  vehicles: THREE.Group[];     // v5: 随队载具
  lastX: number; lastZ: number;
}

export class GameRenderer {
  engine: GameEngine;
  cb: RendererCallbacks;
  renderer: THREE.WebGLRenderer;
  scene: THREE.Scene;
  camera: THREE.PerspectiveCamera;
  private canvas: HTMLCanvasElement;
  private raf = 0;
  private lastTime = performance.now();
  // 地形区块
  private chunkMeshes = new Map<number, THREE.Mesh>();
  private chunkMeshList: THREE.Mesh[] = [];
  private fogPlanes = new Map<number, THREE.Mesh>();
  private exploredChunkKeys: number[] = [];
  private lastRevealVersion = -1;
  private treeMeshes: THREE.InstancedMesh[] = [];
  private rockMesh!: THREE.InstancedMesh;
  private buildingGroups = new Map<number, THREE.Group>();
  private bodyMesh!: THREE.InstancedMesh;
  private headMesh!: THREE.InstancedMesh;
  private citizens: CitizenAgent[] = [];
  private carMesh!: THREE.InstancedMesh;
  private cartMesh!: THREE.InstancedMesh;
  private cars: CarAgent[] = [];
  private roadTiles: { x: number; y: number }[] = [];
  private particles: { spr: THREE.Sprite; life: number; maxLife: number; vx: number; vy: number; vz: number; grow: number; baseOpacity: number }[] = [];
  private particlePool: THREE.Sprite[] = [];
  private rainPoints!: THREE.Points;
  private clouds: THREE.Group[] = [];
  private cloudMat!: THREE.MeshStandardMaterial;
  private sun!: THREE.DirectionalLight;
  private hemi!: THREE.HemisphereLight;
  private windowMeshes: THREE.Mesh[] = [];
  private ghostGroup: THREE.Group | null = null;
  private hoverQuad!: THREE.Mesh;
  private selectRing!: THREE.Mesh;
  private radiusRing!: THREE.Mesh;
  private progressBars = new Map<number, { bg: THREE.Mesh; fill: THREE.Mesh; size: number }>();
  private buildingTops = new Map<number, number>();
  private alertSprites: THREE.Sprite[] = [];
  private alertTex: THREE.Texture | null = null;
  private lineStart: { x: number; y: number } | null = null;
  private linePreviewMesh: THREE.InstancedMesh | null = null;
  private lineTiles: { x: number; y: number }[] = [];
  buildRot = 0;
  // 数据视图 (按区块)
  private overlayMeshes = new Map<number, THREE.InstancedMesh>();
  private overlayTimer = 0;
  viewMode: ViewModeId = 'none';
  // 电线接线
  private wireGroup = new THREE.Group();
  private wireVersion = -1;
  // v5: 地下管网视图 (线 + 流点 + 增压环 + 过载闪)
  private utilGroup = new THREE.Group();
  private utilVersion = -1;
  private utilLines: { edge: UtiliEdge; line: THREE.Mesh }[] = [];
  private utilFlow!: THREE.Points;
  private utilFlowData: { ax: number; az: number; bx: number; bz: number; y: number; speed: number; off: number }[] = [];
  private boostRings: THREE.Mesh[] = [];
  // v5: 地图内战斗层
  private battleLayer = new THREE.Group();
  private battleFxLayer = new THREE.Group();
  private battleId = -1;
  private battleUnits = new Map<string, {
    uid: string;
    group: THREE.Group; base: THREE.Vector3; headY: number;
    side: 'player' | 'enemy'; ring: THREE.Mesh; shield: THREE.Mesh;
    alive: boolean; fallen: boolean; kind: string;
  }>();
  private battleJobs: { type: 'lunge' | 'dodge' | 'shake' | 'death' | 'guard'; uid: string; to?: THREE.Vector3; t: number; dur: number; crit?: boolean; hit?: boolean }[] = [];
  private battleProjectiles: { mesh: THREE.Mesh; from: THREE.Vector3; to: THREE.Vector3; t: number; dur: number; targetUid: string; crit: boolean }[] = [];
  private battleSeenEvents = new Set<number>();
  private battleCam: { t: number; dur: number; fromX: number; fromZ: number; toX: number; toZ: number; fromDist: number; toDist: number } | null = null;
  private battleReturnCam: { x: number; z: number; dist: number } | null = null;
  private camShake = 0;
  // 遗迹
  private ruinGroups = new Map<number, THREE.Group>();
  // 远征队
  private parties = new Map<number, ExpeditionParty>();
  private expMarkers = new Map<number, THREE.Group>();
  // 探索模式路径预览
  private exploreLine!: THREE.Line;
  private exploreFlag!: THREE.Group;
  // 砍伐任务标记
  private taskMarkers: THREE.Mesh[] = [];
  private chopTasks: ChopOrder[] = [];
  private mode: Mode = { type: 'none' };
  private mouse = { x: 0, y: 0, inside: false };
  private hoverTile = { x: -999, y: -999 };
  private isLeftDown = false;
  selectedBuildingId: number | null = null;
  // 相机
  private camTarget = new THREE.Vector3(0, 0, 0);
  private camDist = 26;
  private camTheta = Math.PI * 0.75;
  private camPhi = 0.95;
  private keys = new Set<string>();
  private dragging: null | 'orbit' | 'pan' = null;
  private lastPointer = { x: 0, y: 0 };
  private movedDistance = 0;
  private touchMode: null | 'one' | 'two' = null;
  private touchDist = 0;
  private time = 0;
  private uiTimer = 0;
  private dotTex = softDot();
  private disposed = false;
  private wasNight = false;
  // 电影化与氛围
  private oceanMesh: THREE.Mesh | null = null;
  private stars!: THREE.Points;
  private moon!: THREE.Sprite;
  private lampSprites: THREE.Sprite[] = [];
  private lightGlows = new Map<number, THREE.Sprite>();
  private workGlows = new Map<number, THREE.Sprite>();
  private lightPool: THREE.PointLight[] = [];
  private fireflies: { spr: THREE.Sprite; cx: number; cz: number; phase: number; r: number }[] = [];
  private floatTexts: { spr: THREE.Sprite; life: number; maxLife: number }[] = [];
  private alertBadgeCache = new Map<number, THREE.Texture>();
  private intro = { t: 0, dur: 3.6, fromDist: 78, toDist: 18, fromPhi: 0.32, toPhi: 0.95, fromTheta: 0 };
  private cine: { t: number; dur: number; fd: number; td: number; fth: number; tth: number; fph: number; tph: number } | null = null;
  // 画质
  quality: 'low' | 'med' | 'high' = 'med';

  constructor(canvas: HTMLCanvasElement, engine: GameEngine, cb: RendererCallbacks) {
    this.canvas = canvas;
    this.engine = engine;
    this.cb = cb;
    this.quality = engine.quality;

    this.renderer = new THREE.WebGLRenderer({ canvas, antialias: true, powerPreference: 'high-performance' });
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;

    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x87b5d4);
    this.scene.fog = new THREE.Fog(0x87b5d4, 90, 260);

    this.camera = new THREE.PerspectiveCamera(50, 1, 0.1, 900);

    this.setupLights();
    this.buildOcean();
    this.buildTrees();
    this.rebuildRocks();
    this.buildCitizens();
    this.buildCars();
    this.buildRain();
    this.buildClouds();
    this.buildSkyDecor();
    this.buildFireflies();
    this.buildHelpers();
    this.buildLinePreview();
    this.buildAlertSprites();
    this.buildLightPool();
    this.scene.add(this.wireGroup);
    this.scene.add(this.utilGroup);
    this.scene.add(this.battleLayer);
    this.scene.add(this.battleFxLayer);
    this.buildUtilFlow();
    this.buildExploreHelpers();
    this.updateTerrainChunks(true);
    this.syncBuildings();
    this.applyQuality(this.quality);
    this.bindEvents();
    this.resize();
    this.applyCamera();
    // 开场镜头: 从高空俯瞰缓缓降落至营地
    const s = this.engine.terrain.spawn;
    const [swx, swz] = this.tileToWorld(s.x, s.y);
    this.camTarget.set(swx, 0, swz);
    this.intro.fromTheta = this.camTheta - 0.85;
    this.camTheta = this.intro.fromTheta;
    this.camDist = this.intro.fromDist;
    this.camPhi = this.intro.fromPhi;
    this.loop();
  }

  // ---------- 场景构建 ----------
  private setupLights() {
    this.hemi = new THREE.HemisphereLight(0xcfe8ff, 0x6b7c5a, 0.75);
    this.scene.add(this.hemi);
    this.sun = new THREE.DirectionalLight(0xfff2d9, 1.6);
    this.sun.castShadow = true;
    this.sun.shadow.mapSize.set(2048, 2048);
    const sc = this.sun.shadow.camera as THREE.OrthographicCamera;
    sc.left = -58; sc.right = 58; sc.top = 58; sc.bottom = -58; sc.near = 1; sc.far = 320;
    this.sun.shadow.bias = -0.0005;
    this.scene.add(this.sun);
    this.scene.add(this.sun.target);
    this.scene.add(new THREE.AmbientLight(0xffffff, 0.12));
  }

  /** 地表显示高度: 草地压平 / 水面压至海面之下 */
  static dispH(t: { terrain: string; height: number }): number {
    if (t.terrain === 'water') return Math.min(-0.08, t.height);
    if (t.terrain === 'grass' || t.terrain === 'forest') return 0.04 + (t.height - 0.04) * 0.5;
    return t.height;
  }

  /** 迷雾中的平坦高度 (不泄露地形) */
  static fogH(): number { return 0.03; }

  private buildOcean() {
    const geo = new THREE.PlaneGeometry(3000, 3000, 40, 40);
    geo.rotateX(-Math.PI / 2);
    const m = new THREE.MeshStandardMaterial({
      color: 0x3a86b8, transparent: true, opacity: 0.88, roughness: 0.25, metalness: 0.05,
    });
    const mesh = new THREE.Mesh(geo, m);
    mesh.position.set(0, -0.06, 0);
    (mesh as any).isOcean = true;
    this.oceanMesh = mesh;
    this.scene.add(mesh);
  }

  // ---------- 区块地形 ----------
  private buildChunkMesh(cx: number, cy: number): THREE.Mesh | null {
    const world = this.engine.terrain;
    const chunk = world.chunks.get(World.chunkKey(cx, cy));
    if (!chunk || !chunk.generated) return null;
    const positions: number[] = [];
    const colors: number[] = [];
    const col = new THREE.Color();
    const tileColor = (t: { terrain: string; height: number; x: number; y: number; explored: boolean }) => {
      if (!t.explored) return (t.x + t.y) % 2 === 0 ? FOG_COLOR.clone() : FOG_COLOR2.clone();
      const pair = TERRAIN_COLORS[t.terrain];
      const n = ((t.x * 7 + t.y * 13) % 5) / 5;
      col.setHex(pair[0]).lerp(new THREE.Color(pair[1]), n);
      if (t.terrain === 'mountain' && t.height > 1.6) col.lerp(new THREE.Color(0xe8eef2), Math.min(0.8, (t.height - 1.6) / 1.2)); // 雪顶
      return col.clone();
    };
    const tileH = (t: { terrain: string; height: number; explored: boolean }) =>
      t.explored ? GameRenderer.dispH(t) : GameRenderer.fogH();
    const push = (x: number, y: number, z: number, c: THREE.Color) => {
      positions.push(x, y, z);
      colors.push(c.r, c.g, c.b);
    };
    for (const t of chunk.tiles) {
      const c = tileColor(t);
      const h = tileH(t);
      const x0 = t.x, z0 = t.y; // 世界原点 = 格 (0,0)
      push(x0, h, z0, c); push(x0, h, z0 + 1, c); push(x0 + 1, h, z0 + 1, c);
      push(x0, h, z0, c); push(x0 + 1, h, z0 + 1, c); push(x0 + 1, h, z0, c);
    }
    // 悬崖侧壁 (已探索边缘)
    const wall = (ax: number, az: number, bx: number, bz: number, hTop: number, hBot: number, c: THREE.Color) => {
      push(ax, hTop, az, c); push(bx, hBot, bz, c); push(bx, hTop, bz, c);
      push(ax, hTop, az, c); push(ax, hBot, az, c); push(bx, hBot, bz, c);
    };
    for (const t of chunk.tiles) {
      if (!t.explored) continue;
      const h = GameRenderer.dispH(t);
      const x0 = t.x, z0 = t.y;
      const cDark = tileColor(t).multiplyScalar(0.68);
      const dirs: [number, number][] = [[1, 0], [-1, 0], [0, 1], [0, -1]];
      for (const [dx, dy] of dirs) {
        const nt = world.peek(t.x + dx, t.y + dy);
        const nh = nt ? tileH(nt) : GameRenderer.fogH();
        if (h - nh <= 0.07) continue;
        if (dx === 1) wall(x0 + 1, z0, x0 + 1, z0 + 1, h, nh, cDark);
        else if (dx === -1) wall(x0, z0 + 1, x0, z0, h, nh, cDark);
        else if (dy === 1) wall(x0 + 1, z0 + 1, x0, z0 + 1, h, nh, cDark);
        else wall(x0, z0, x0 + 1, z0, h, nh, cDark);
      }
    }
    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
    geo.setAttribute('color', new THREE.Float32BufferAttribute(colors, 3));
    geo.computeVertexNormals();
    const m = new THREE.MeshStandardMaterial({ vertexColors: true, flatShading: true, roughness: 0.95, side: THREE.DoubleSide });
    const mesh = new THREE.Mesh(geo, m);
    mesh.receiveShadow = true;
    mesh.castShadow = true;
    (mesh as any).isTerrain = true;
    return mesh;
  }

  /** 每帧检查: 新探索区块建网格 / 脏区块重建 / 迷雾边界 */
  private updateTerrainChunks(initial = false) {
    const world = this.engine.terrain;
    let changed = false;
    for (const [k, c] of world.chunks) {
      if (!c.generated || c.revealed === 0) continue;
      const existing = this.chunkMeshes.get(k);
      if (!existing || c.dirty) {
        if (existing) {
          this.scene.remove(existing);
          existing.geometry.dispose();
          (existing.material as THREE.Material).dispose();
          this.chunkMeshes.delete(k);
        }
        const mesh = this.buildChunkMesh(c.cx, c.cy);
        if (mesh) {
          this.scene.add(mesh);
          this.chunkMeshes.set(k, mesh);
        }
        c.dirty = false;
        changed = true;
      }
    }
    if (changed || initial) this.chunkMeshList = [...this.chunkMeshes.values()];
    // 迷雾揭开 → 更新树/石/遗迹/迷雾边界
    if (world.revealVersion !== this.lastRevealVersion || initial) {
      this.lastRevealVersion = world.revealVersion;
      this.updateFogBorders();
      this.updateTreeInstances();
      this.rebuildRocks();
      this.updateRuins();
      if (this.viewMode !== 'none') this.rebuildOverlayChunks();
    }
  }

  /** 未探索区块的暗色迷雾面 (探索边界外 3 圈) + 边界飘雾 */
  private fogSprites: THREE.Sprite[] = [];
  private updateFogBorders() {
    const world = this.engine.terrain;
    const explored: number[] = [];
    for (const [k, c] of world.chunks) {
      if (c.generated && c.revealed > 0) explored.push(k);
    }
    this.exploredChunkKeys = explored;
    const need = new Set<number>();
    for (const k of explored) {
      const c = world.chunks.get(k)!;
      for (let dy = -3; dy <= 3; dy++)
        for (let dx = -3; dx <= 3; dx++) {
          if (Math.abs(dx) + Math.abs(dy) > 4) continue;
          const nk = World.chunkKey(c.cx + dx, c.cy + dy);
          const nc = world.chunks.get(nk);
          if (!nc || nc.revealed === 0) need.add(nk);
        }
    }
    // 删除不再需要的
    for (const [k, mesh] of this.fogPlanes) {
      if (!need.has(k)) {
        this.scene.remove(mesh);
        mesh.geometry.dispose();
        (mesh.material as THREE.Material).dispose();
        this.fogPlanes.delete(k);
      }
    }
    let budget = 480 - this.fogPlanes.size;
    for (const k of need) {
      if (this.fogPlanes.has(k)) continue;
      if (budget-- <= 0) break;
      const cx = Math.floor(k / 8192) - 4096;
      const cy = (k % 8192) - 4096;
      const geo = new THREE.PlaneGeometry(CHUNK, CHUNK);
      geo.rotateX(-Math.PI / 2);
      const m = new THREE.MeshStandardMaterial({
        color: ((cx + cy) % 2 === 0) ? FOG_COLOR : FOG_COLOR2, roughness: 1,
      });
      const mesh = new THREE.Mesh(geo, m);
      mesh.position.set(cx * CHUNK + CHUNK / 2, 0.031, cy * CHUNK + CHUNK / 2);
      mesh.receiveShadow = false;
      this.scene.add(mesh);
      this.fogPlanes.set(k, mesh);
    }
    // 边界飘雾: 在迷雾面上放置柔和雾气精灵, 软化探索边界
    this.syncFogSprites();
  }

  /** 雾气精灵跟随迷雾边界重新分布 */
  private syncFogSprites() {
    if (this.quality === 'low') {
      this.fogSprites.forEach(s => { s.visible = false; });
      return;
    }
    const planes = [...this.fogPlanes.values()];
    for (let i = 0; i < this.fogSprites.length; i++) {
      const spr = this.fogSprites[i];
      if (planes.length === 0) { spr.visible = false; continue; }
      const p = planes[(i * 7 + Math.floor(this.time)) % planes.length];
      const a = (i * 2.399) % (Math.PI * 2); // 黄金角分布
      spr.position.set(
        p.position.x + Math.cos(a) * 5.5,
        0.4 + (i % 3) * 0.35,
        p.position.z + Math.sin(a) * 5.5,
      );
      spr.visible = true;
    }
  }

  private buildTrees() {
    this.rebuildTreeMeshes(3000);
  }

  private rebuildTreeMeshes(cap: number) {
    for (const m of this.treeMeshes) {
      this.scene.remove(m);
      m.dispose();
    }
    this.treeMeshes = [];
    const geos = treeGeometries();
    const trunkMat = mat(0x6b4423, { roughness: 1 });
    const mats = [mat(0x2f6b3a, { roughness: 1 }), mat(0x4c8c3f, { roughness: 1 }), mat(0x9db06a, { roughness: 1 })];
    this.treeMeshes = [
      new THREE.InstancedMesh(geos.trunk, trunkMat, cap),
      new THREE.InstancedMesh(geos.pine, mats[0], cap),
      new THREE.InstancedMesh(geos.oak, mats[1], cap),
      new THREE.InstancedMesh(geos.birch, mats[2], cap),
    ];
    this.treeMeshes.forEach(m => { m.castShadow = true; m.receiveShadow = true; this.scene.add(m); });
    this.updateTreeInstances();
  }

  updateTreeInstances() {
    const world = this.engine.terrain;
    // 已探索区域内的活树
    const visible: typeof world.trees = [];
    for (const t of world.trees) {
      if (t.dead) continue;
      const tile = world.peek(Math.floor(t.x), Math.floor(t.y));
      if (tile && tile.explored) visible.push(t);
    }
    if (this.treeMeshes.length > 0 && visible.length > this.treeMeshes[0].instanceMatrix.count) {
      this.rebuildTreeMeshes(Math.ceil(visible.length * 1.4) + 256);
      return;
    }
    const counts = [0, 0, 0, 0];
    const mtx = new THREE.Matrix4();
    const q = new THREE.Quaternion();
    const pos = new THREE.Vector3();
    const scl = new THREE.Vector3();
    for (const t of visible) {
      pos.set(t.x, this.heightAt(Math.floor(t.x), Math.floor(t.y)), t.y);
      q.setFromAxisAngle(new THREE.Vector3(0, 1, 0), t.rot);
      const s = Math.max(0.5, t.scale);
      scl.set(s, s, s);
      mtx.compose(pos, q, scl);
      this.treeMeshes[0].setMatrixAt(counts[0]++, mtx);
      const ti = Math.max(0, Math.min(2, t.type));
      this.treeMeshes[ti + 1].setMatrixAt(counts[ti + 1]++, mtx);
    }
    for (let i = 0; i < 4; i++) {
      this.treeMeshes[i].count = counts[i];
      this.treeMeshes[i].instanceMatrix.needsUpdate = true;
      this.treeMeshes[i].computeBoundingSphere();
    }
  }

  private rebuildRocks() {
    const world = this.engine.terrain;
    const rocks: { x: number; y: number }[] = [];
    for (const c of world.chunks.values()) {
      if (!c.generated || c.revealed === 0) continue;
      for (const t of c.tiles) if (t.rock && t.explored) rocks.push({ x: t.x, y: t.y });
    }
    if (!this.rockMesh) {
      this.rockMesh = new THREE.InstancedMesh(rockGeometry(), mat(0x7c8085, { roughness: 1 }), Math.max(1, rocks.length));
      this.rockMesh.castShadow = true;
      this.scene.add(this.rockMesh);
    } else if (rocks.length > this.rockMesh.instanceMatrix.count) {
      this.scene.remove(this.rockMesh);
      this.rockMesh.dispose();
      this.rockMesh = new THREE.InstancedMesh(rockGeometry(), mat(0x7c8085, { roughness: 1 }), Math.ceil(rocks.length * 1.3));
      this.rockMesh.castShadow = true;
      this.scene.add(this.rockMesh);
    }
    const mtx = new THREE.Matrix4();
    const q = new THREE.Quaternion();
    const pos = new THREE.Vector3();
    const scl = new THREE.Vector3();
    rocks.forEach((t, i) => {
      pos.set(t.x, this.heightAt(t.x, t.y) + 0.02, t.y);
      q.setFromAxisAngle(new THREE.Vector3(0, 1, 0), (t.x * 3.1 + t.y * 7.7) % 6.28);
      const s = 0.8 + ((t.x * 13 + t.y * 7) % 5) / 10;
      scl.set(s, s, s);
      mtx.compose(pos, q, scl);
      this.rockMesh.setMatrixAt(i, mtx);
    });
    this.rockMesh.count = rocks.length;
    this.rockMesh.instanceMatrix.needsUpdate = true;
  }

  /** 遗迹模型 (已探索才显示; 搜刮后换成小废墟) + 未搜刮遗迹的发现光标 */
  private ruinGlows = new Map<number, THREE.Sprite>();
  private updateRuins() {
    const world = this.engine.terrain;
    for (const [idx, ruin] of world.ruins.entries()) {
      const tile = world.peek(ruin.x, ruin.y);
      if (!tile || !tile.explored) continue;
      const modelName = RUIN_MODEL_OF(ruin.type, ruin.scavenged);
      const existing = this.ruinGroups.get(idx);
      if (existing && (existing.userData.modelName === modelName)) continue;
      if (existing) {
        this.scene.remove(existing);
        this.disposeGroup(existing);
        this.ruinGroups.delete(idx);
      }
      const g = buildModel(modelName);
      g.userData.modelName = modelName;
      if (ruin.scavenged) g.scale.setScalar(0.55);
      g.position.set(ruin.x + 0.5, this.heightAt(ruin.x, ruin.y), ruin.y + 0.5);
      this.scene.add(g);
      this.ruinGroups.set(idx, g);
      // 未搜刮 → 顶部金色微光 (发现标记); 已搜刮 → 移除
      const glow = this.ruinGlows.get(idx);
      if (!ruin.scavenged && !glow) {
        const spr = new THREE.Sprite(new THREE.SpriteMaterial({
          map: this.dotTex, color: 0xfde68a, transparent: true, opacity: 0.5,
          blending: THREE.AdditiveBlending, depthWrite: false,
        }));
        spr.position.set(ruin.x + 0.5, this.heightAt(ruin.x, ruin.y) + 1.55, ruin.y + 0.5);
        spr.scale.setScalar(0.75);
        spr.renderOrder = 9;
        spr.userData.seed = Math.random() * 10;
        this.scene.add(spr);
        this.ruinGlows.set(idx, spr);
      } else if (ruin.scavenged && glow) {
        this.scene.remove(glow);
        (glow.material as THREE.SpriteMaterial).dispose();
        this.ruinGlows.delete(idx);
      }
    }
  }

  /** 遗迹光标呼吸动画 */
  private animateRuinGlows(t: number) {
    for (const spr of this.ruinGlows.values()) {
      const s = spr.userData.seed as number;
      (spr.material as THREE.SpriteMaterial).opacity = 0.32 + Math.sin(t * 2.1 + s) * 0.2;
      spr.position.y += Math.sin(t * 1.6 + s) * 0.0016;
    }
  }

  private removeRuinVisual(idx: number) {
    const g = this.ruinGroups.get(idx);
    if (g) {
      this.scene.remove(g);
      this.disposeGroup(g);
      this.ruinGroups.delete(idx);
    }
  }

  private buildCitizens() {
    const bodyGeo = citizenBodyGeometry();
    this.bodyMesh = new THREE.InstancedMesh(bodyGeo,
      new THREE.MeshStandardMaterial({ flatShading: true, roughness: 0.9, vertexColors: true }), 80);
    this.bodyMesh.castShadow = true;
    this.bodyMesh.count = 0;
    this.bodyMesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
    // v5 比例修复: 居民整体缩小 (0.37 → 0.27), 建筑尺度感回归真实
    this.bodyMesh.scale.setScalar(0.72);
    this.scene.add(this.bodyMesh);
    const headGeo = citizenHeadGeometry();
    this.headMesh = new THREE.InstancedMesh(headGeo,
      new THREE.MeshStandardMaterial({ flatShading: true, roughness: 0.85, vertexColors: true }), 80);
    this.headMesh.castShadow = true;
    this.headMesh.count = 0;
    this.headMesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
    this.headMesh.scale.setScalar(0.72);
    this.scene.add(this.headMesh);
  }

  private buildCars() {
    this.carMesh = new THREE.InstancedMesh(carGeometry(),
      new THREE.MeshStandardMaterial({ flatShading: true, roughness: 0.45, metalness: 0.25, vertexColors: true }), 40);
    this.carMesh.castShadow = true;
    this.carMesh.count = 0;
    this.carMesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
    this.scene.add(this.carMesh);
    this.cartMesh = new THREE.InstancedMesh(cartGeometry(),
      new THREE.MeshStandardMaterial({ flatShading: true, roughness: 0.9, vertexColors: true }), 24);
    this.cartMesh.castShadow = true;
    this.cartMesh.count = 0;
    this.cartMesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
    this.scene.add(this.cartMesh);
  }

  private buildRain() {
    const N = 2200;
    const geo = new THREE.BufferGeometry();
    const pos = new Float32Array(N * 3);
    for (let i = 0; i < N; i++) {
      pos[i * 3] = (Math.random() - 0.5) * 80;
      pos[i * 3 + 1] = Math.random() * 18;
      pos[i * 3 + 2] = (Math.random() - 0.5) * 80;
    }
    geo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
    const m = new THREE.PointsMaterial({
      color: 0xc8def0, size: 0.32, map: this.dotTex, transparent: true, opacity: 0.8,
      depthWrite: false, sizeAttenuation: true,
    });
    this.rainPoints = new THREE.Points(geo, m);
    this.rainPoints.visible = false;
    this.scene.add(this.rainPoints);
  }

  private buildClouds() {
    this.cloudMat = new THREE.MeshStandardMaterial({ color: 0xffffff, transparent: true, opacity: 0.85, roughness: 1, flatShading: true });
    for (let i = 0; i < 16; i++) {
      const g = new THREE.Group();
      for (let j = 0; j < 3; j++) {
        const s = new THREE.Mesh(new THREE.SphereGeometry(1.4 + Math.random() * 1.8, 6, 5), this.cloudMat);
        s.position.set((Math.random() - 0.5) * 4.4, (Math.random() - 0.5) * 0.6, (Math.random() - 0.5) * 3);
        s.scale.y = 0.45;
        g.add(s);
      }
      g.position.set((Math.random() - 0.5) * 150, 26 + Math.random() * 8, (Math.random() - 0.5) * 150);
      this.clouds.push(g);
      this.scene.add(g);
    }
  }

  private buildHelpers() {
    const hoverGeo = new THREE.PlaneGeometry(1, 1);
    hoverGeo.rotateX(-Math.PI / 2);
    this.hoverQuad = new THREE.Mesh(hoverGeo, new THREE.MeshBasicMaterial({ color: 0x4ade80, transparent: true, opacity: 0.35, depthWrite: false }));
    this.hoverQuad.visible = false;
    this.scene.add(this.hoverQuad);

    const ringGeo = new THREE.RingGeometry(0.55, 0.68, 28);
    ringGeo.rotateX(-Math.PI / 2);
    this.selectRing = new THREE.Mesh(ringGeo, new THREE.MeshBasicMaterial({ color: 0xfbbf24, transparent: true, opacity: 0.9, depthWrite: false }));
    this.selectRing.visible = false;
    this.scene.add(this.selectRing);

    const rGeo = new THREE.RingGeometry(0.96, 1, 48);
    rGeo.rotateX(-Math.PI / 2);
    this.radiusRing = new THREE.Mesh(rGeo, new THREE.MeshBasicMaterial({ color: 0x60a5fa, transparent: true, opacity: 0.5, depthWrite: false, side: THREE.DoubleSide }));
    this.radiusRing.visible = false;
    this.scene.add(this.radiusRing);

    const mkGeo = new THREE.RingGeometry(0.3, 0.42, 20);
    mkGeo.rotateX(-Math.PI / 2);
    for (let i = 0; i < 10; i++) {
      const mk = new THREE.Mesh(mkGeo, new THREE.MeshBasicMaterial({ color: 0xfbbf24, transparent: true, opacity: 0.85, depthWrite: false }));
      mk.visible = false;
      this.taskMarkers.push(mk);
      this.scene.add(mk);
    }
  }

  /** 探索模式: 城市中心→目标的虚线预览 + 目标旗 */
  private buildExploreHelpers() {
    const geo = new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(), new THREE.Vector3(0, 0, 1)]);
    this.exploreLine = new THREE.Line(geo, new THREE.LineDashedMaterial({ color: 0x67e8f9, dashSize: 0.5, gapSize: 0.35, transparent: true, opacity: 0.75 }));
    this.exploreLine.visible = false;
    this.scene.add(this.exploreLine);
    const flag = new THREE.Group();
    const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.02, 0.025, 0.9, 5), mat(0x8a5a33));
    pole.position.y = 0.45;
    flag.add(pole);
    const cloth = new THREE.Mesh(new THREE.PlaneGeometry(0.42, 0.26), new THREE.MeshBasicMaterial({ color: 0x22d3ee, side: THREE.DoubleSide }));
    cloth.position.set(0.21, 0.72, 0);
    flag.add(cloth);
    flag.visible = false;
    this.exploreFlag = flag;
    this.scene.add(flag);
  }

  // ---------- 画质 ----------
  applyQuality(q: 'low' | 'med' | 'high') {
    this.quality = q;
    this.engine.devSetQuality(q);
    const r = this.renderer;
    if (q === 'low') {
      r.setPixelRatio(1);
      r.shadowMap.enabled = false;
      r.toneMapping = THREE.NoToneMapping;
      (this.rainPoints.geometry as THREE.BufferGeometry).setDrawRange(0, 900);
      this.clouds.forEach((c, i) => { c.visible = i < 5; });
      this.fireflies.forEach(f => { f.spr.visible = false; });
    } else if (q === 'med') {
      r.setPixelRatio(Math.min(window.devicePixelRatio, 2));
      r.shadowMap.enabled = true;
      r.shadowMap.type = THREE.PCFShadowMap;
      r.toneMapping = THREE.NoToneMapping;
      (this.rainPoints.geometry as THREE.BufferGeometry).setDrawRange(0, Infinity);
      this.clouds.forEach(c => { c.visible = true; });
    } else {
      r.setPixelRatio(Math.min(window.devicePixelRatio, 2.5));
      r.shadowMap.enabled = true;
      r.shadowMap.type = THREE.PCFSoftShadowMap;
      r.toneMapping = THREE.ACESFilmicToneMapping;
      r.toneMappingExposure = 1.06;
      (this.rainPoints.geometry as THREE.BufferGeometry).setDrawRange(0, Infinity);
      this.clouds.forEach(c => { c.visible = true; });
    }
    // 阴影贴图尺寸
    const size = q === 'high' ? 4096 : 2048;
    if (this.sun.shadow.mapSize.x !== size) {
      this.sun.shadow.map?.dispose();
      this.sun.shadow.map = null;
      this.sun.shadow.mapSize.set(size, size);
    }
    this.sun.castShadow = q !== 'low';
    this.hemi.intensity = q === 'low' ? 0.85 : 0.75;
  }

  // ---------- 数据视图 (按区块实例化) ----------
  setViewMode(mode: ViewModeId) {
    this.viewMode = mode;
    this.engine.viewMode = mode;
    if (mode === 'none') {
      for (const m of this.overlayMeshes.values()) m.visible = false;
      // v5: 清空管网视图
      for (const obj of this.utilLines) { this.utilGroup.remove(obj.line); obj.line.geometry.dispose(); (obj.line.material as THREE.Material).dispose(); }
      this.utilLines = [];
      for (const r of this.boostRings) this.utilGroup.remove(r);
      this.boostRings = [];
      this.utilFlowData = [];
      this.utilFlow.count = 0;
    } else {
      this.rebuildOverlayChunks();
      this.updateOverlayColors();
      if (mode === 'power' || mode === 'water') this.rebuildUtilView();
    }
  }

  private rebuildOverlayChunks() {
    const world = this.engine.terrain;
    // 只在镜头附近 ~9×9 区块
    const cCol = Math.floor(this.camTarget.x / CHUNK);
    const cRow = Math.floor(this.camTarget.z / CHUNK);
    const need = new Set<number>();
    for (let dy = -4; dy <= 4; dy++)
      for (let dx = -4; dx <= 4; dx++) {
        const k = World.chunkKey(cCol + dx, cRow + dy);
        const c = world.chunks.get(k);
        if (c && c.revealed > 0) need.add(k);
      }
    for (const [k, m] of this.overlayMeshes) {
      if (!need.has(k)) {
        this.scene.remove(m);
        m.dispose();
        this.overlayMeshes.delete(k);
      }
    }
    for (const k of need) {
      if (this.overlayMeshes.has(k)) {
        this.overlayMeshes.get(k)!.visible = true;
        continue;
      }
      const c = world.chunks.get(k)!;
      const geo = new THREE.PlaneGeometry(1, 1);
      geo.rotateX(-Math.PI / 2);
      const m = new THREE.MeshBasicMaterial({ transparent: true, opacity: 0.5, depthWrite: false });
      const mesh = new THREE.InstancedMesh(geo, m, CHUNK * CHUNK);
      mesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
      const mtx = new THREE.Matrix4();
      let n = 0;
      for (const t of c.tiles) {
        if (!t.explored) continue;
        // 跟随地形高度 (修复: 山丘上视图色块被埋进地里)
        mtx.makeTranslation(t.x, GameRenderer.dispH(t) + 0.16, t.y);
        mesh.setMatrixAt(n++, mtx);
      }
      mesh.count = n;
      mesh.visible = this.viewMode !== 'none';
      mesh.renderOrder = 5;
      this.overlayMeshes.set(k, mesh);
      this.scene.add(mesh);
    }
  }

  /** 视图标记: 电力/供水视图下, 在问题建筑顶部显示脉冲警示环 */
  private viewMarkerPool: THREE.Mesh[] = [];
  private updateViewMarkers() {
    const mode = this.viewMode;
    if (mode !== 'power' && mode !== 'water') {
      this.viewMarkerPool.forEach(m => { m.visible = false; });
      return;
    }
    let used = 0;
    const isPower = mode === 'power';
    for (const b of this.engine.buildings.values()) {
      if (b.progress < 1) continue;
      const def = BUILDING_DEFS[b.defId];
      if (isPower ? !def.powerNeed : !def.waterNeed) continue;
      const bad = (b.alerts ?? []).some(a =>
        isPower ? (a.includes('电网') || a.includes('缺电')) : (a.includes('水网') || a.includes('缺水')));
      if (!bad) continue;
      let m = this.viewMarkerPool[used];
      if (!m) {
        const geo = new THREE.TorusGeometry(0.4, 0.05, 6, 22);
        geo.rotateX(Math.PI / 2);
        m = new THREE.Mesh(geo, new THREE.MeshBasicMaterial({
          color: isPower ? 0xff3d3d : 0x38bdf8, transparent: true, opacity: 0.9, depthWrite: false,
        }));
        m.renderOrder = 8;
        this.scene.add(m);
        this.viewMarkerPool.push(m);
      }
      (m.material as THREE.MeshBasicMaterial).color.setHex(isPower ? 0xff3d3d : 0x38bdf8);
      const size = Math.max(1, def.size);
      const g = this.buildingGroups.get(b.id);
      const wx = g ? g.position.x : b.x + 0.5;
      const wz = g ? g.position.z : b.y + 0.5;
      const top = this.buildingTops.get(b.id) ?? 0.8;
      const h = g ? g.position.y : this.heightAt(b.x, b.y);
      m.position.set(wx, h + top + 0.42, wz);
      m.userData.baseScale = size * 0.62;
      m.scale.setScalar(size * 0.62);
      m.visible = true;
      used++;
    }
    for (let i = used; i < this.viewMarkerPool.length; i++) this.viewMarkerPool[i].visible = false;
  }

  private animateViewMarkers(t: number) {
    const pulse = 1 + Math.sin(t * 5) * 0.14;
    for (const m of this.viewMarkerPool) {
      if (!m.visible) continue;
      m.scale.setScalar((m.userData.baseScale ?? 0.62) * pulse);
      m.rotation.y = t * 0.8;
      (m.material as THREE.MeshBasicMaterial).opacity = 0.62 + Math.sin(t * 5) * 0.28;
    }
  }

  private updateOverlayColors() {
    const ov = this.engine.overlay;
    if (!ov || ov.size === 0) return;
    const col = new THREE.Color();
    const mode = this.viewMode;
    const world = this.engine.terrain;
    for (const [k, mesh] of this.overlayMeshes) {
      const c = world.chunks.get(k);
      if (!c) continue;
      let n = 0;
      for (const t of c.tiles) {
        if (!t.explored) continue;
        const cell = ov.get(World.key(t.x, t.y));
        let set = true;
        if (!cell) {
          col.setHex(0x3a3a3a);
        } else {
          switch (mode) {
            case 'happiness': {
              const v = cell.happiness;
              if (v > 0.5) col.setHSL(0.33, 0.75, Math.min(0.55, 0.22 + v / 90));
              else if (v < -0.5) col.setHSL(0.0, 0.8, Math.min(0.55, 0.24 + -v / 90));
              else col.setHex(0x3a3a3a);
              break;
            }
            case 'power': {
              // v5: 电压梯度绿→黄→橙; 断电红; 变电站紫; 电缆黄
              if (cell.powerOk === 0) col.setHex(0xff4d4d);
              else if (cell.powerOk === 2) col.setHex(0x3b82f6);
              else if (cell.powerOk === 4) col.setHex(0xa78bfa);
              else if (cell.powerOk === 3) col.setHex(0xfacc15);
              else if (cell.powerOk === 1) {
                const v = cell.volt;
                if (v >= 95) col.setHex(0x2fdd6e);
                else if (v >= 80) col.setHex(0xa3e635);
                else if (v >= 60) col.setHex(0xfacc15);
                else col.setHex(0xfb923c);
              }
              else col.setHex(0x3a3a3a);
              break;
            }
            case 'water': {
              // v5: 水压梯度; 断水红; 泵站青; 水管黄
              if (cell.waterOk === 0) col.setHex(0xff4d4d);
              else if (cell.waterOk === 2) col.setHex(0x0ea5e9);
              else if (cell.waterOk === 4) col.setHex(0x22d3ee);
              else if (cell.waterOk === 3) col.setHex(0xfacc15);
              else if (cell.waterOk === 1) {
                const v = cell.press;
                if (v >= 95) col.setHex(0x2fdd6e);
                else if (v >= 80) col.setHex(0xa3e635);
                else if (v >= 60) col.setHex(0xfacc15);
                else col.setHex(0xfb923c);
              }
              else col.setHex(0x3a3a3a);
              break;
            }
            case 'light': {
              if (cell.light > 0) col.setHSL(0.13, 1, 0.5);
              else col.setHex(0x141e33);
              break;
            }
            case 'landvalue': {
              // 地价: 深蓝(贫瘠) → 青绿 → 金(黄金地段)
              if (cell.land > 1) col.setHSL(0.12 - Math.min(0.12, (cell.land / 100) * 0.12), 0.85, Math.min(0.56, 0.18 + (cell.land / 100) * 0.4));
              else col.setHex(0x232c3a);
              break;
            }
            case 'noise': {
              if (cell.noise > 0.5) col.setHSL(0.08 - Math.min(0.08, cell.noise / 240), 0.9, Math.min(0.55, 0.2 + cell.noise / 50));
              else col.setHex(0x2f3a2f);
              break;
            }
            case 'pollution': {
              if (cell.pollution > 0.5) col.setHSL(0.02, 0.85, Math.min(0.55, 0.2 + cell.pollution / 50));
              else col.setHex(0x2f3a2f);
              break;
            }
            case 'road': {
              if (cell.road === 1) col.setHex(0x60a5fa);
              else if (cell.powerOk !== -1 || cell.waterOk !== -1) col.setHex(0x64748b);
              else col.setHex(0x27303f);
              break;
            }
            default: set = false;
          }
        }
        if (set) mesh.setColorAt(n, col);
        n++;
      }
      if (mesh.instanceColor) mesh.instanceColor.needsUpdate = true;
    }
  }

  // ---------- 高度 / 坐标 ----------
  heightAt(x: number, y: number): number {
    const t = this.engine.terrain.peek(x, y);
    if (!t) return 0.05;
    if (!t.explored) return GameRenderer.fogH();
    return GameRenderer.dispH(t);
  }

  tileToWorld(x: number, y: number): [number, number] {
    return [x + 0.5, y + 0.5];
  }
  worldToTile(wx: number, wz: number): [number, number] {
    return [Math.floor(wx), Math.floor(wz)];
  }
  private tileAtWorld(wx: number, wz: number) {
    const [x, y] = this.worldToTile(wx, wz);
    return this.engine.terrain.peek(x, y);
  }

  // ---------- 建筑同步 ----------
  syncBuildings() {
    for (const [id, g] of this.buildingGroups) {
      this.scene.remove(g);
      this.disposeGroup(g);
    }
    this.buildingGroups.clear();
    this.windowMeshes = [];
    this.roadTiles = [];
    this.progressBars.clear();
    this.buildingTops.clear();
    for (const b of this.engine.buildings.values()) {
      this.addBuildingMesh(b.id);
    }
    this.refreshRoadTiles();
    this.refreshRoadOrientations();
    this.rebuildWires();
  }

  private addBuildingMesh(id: number) {
    const b = this.engine.buildings.get(id);
    if (!b) return;
    const def = BUILDING_DEFS[b.defId];
    const underConstruction = b.progress < 1;
    const g = underConstruction ? constructionSite(def.size) : buildModel(b.defId);
    g.userData.buildingId = id;
    const [wx, wz] = this.tileToWorld(b.x + (b.size - 1) / 2, b.y + (b.size - 1) / 2);
    // 坡地修正: 取占地内最高地形高度作为基底, 避免下坡侧悬空/上坡侧穿土
    // (下坡缝隙由模型的埋地裙边遮挡)
    let baseY = this.heightAt(b.x, b.y);
    for (let dy = 0; dy < b.size; dy++)
      for (let dx = 0; dx < b.size; dx++) {
        const h = this.heightAt(b.x + dx, b.y + dy);
        if (h > baseY) baseY = h;
      }
    g.position.set(wx, baseY, wz);
    if (!def.road && def.category !== 'road' && def.category !== 'pipe') {
      g.rotation.y = (b.rot * Math.PI) / 2;
    }
    g.traverse(o => {
      if ((o as THREE.Mesh).isMesh) {
        const mesh = o as THREE.Mesh;
        if ((mesh as any).isWindowMesh) this.windowMeshes.push(mesh);
        mesh.userData.buildingId = id;
      }
    });
    if (def.road) this.roadTiles.push({ x: b.x, y: b.y });
    this.scene.add(g);
    this.buildingGroups.set(id, g);
    g.updateMatrixWorld(true);
    const bbox = new THREE.Box3().setFromObject(g);
    this.buildingTops.set(id, Math.max(0.6, bbox.max.y - g.position.y));
    if (underConstruction) {
      const barY = this.heightAt(b.x, b.y) + 1.15 + def.size * 0.45;
      const bg = new THREE.Mesh(
        new THREE.PlaneGeometry(def.size * 0.72, 0.14),
        new THREE.MeshBasicMaterial({ color: 0x1c1917, transparent: true, opacity: 0.85, depthWrite: false, side: THREE.DoubleSide }),
      );
      bg.position.set(wx, barY, wz);
      bg.renderOrder = 20;
      const fill = new THREE.Mesh(
        new THREE.PlaneGeometry(def.size * 0.72 - 0.03, 0.09),
        new THREE.MeshBasicMaterial({ color: 0x4ade80, depthWrite: false, side: THREE.DoubleSide }),
      );
      fill.position.set(wx, barY, wz);
      fill.position.z += 0.005;
      fill.renderOrder = 21;
      this.scene.add(bg, fill);
      this.progressBars.set(id, { bg, fill, size: def.size });
    }
    if (b.fire > 0) this.setFireVisual(id, true);
    this.removeLightGlow(id);
    if (def.light && !underConstruction) this.addLightGlow(id, b, b.defId, def.light);
    else if (underConstruction) this.addWorkGlow(id, b);
  }

  private removeBuildingMesh(id: number) {
    const g = this.buildingGroups.get(id);
    if (g) {
      this.scene.remove(g);
      this.disposeGroup(g);
      this.buildingGroups.delete(id);
      this.windowMeshes = this.windowMeshes.filter(m => m.userData.buildingId !== id);
    }
    const bar = this.progressBars.get(id);
    if (bar) {
      this.scene.remove(bar.bg, bar.fill);
      bar.bg.geometry.dispose(); bar.fill.geometry.dispose();
      this.progressBars.delete(id);
    }
    this.buildingTops.delete(id);
    this.removeLightGlow(id);
    this.refreshRoadTiles();
    this.refreshRoadOrientations();
  }

  private refreshRoadTiles() {
    this.roadTiles = [];
    for (const b of this.engine.buildings.values()) {
      if (BUILDING_DEFS[b.defId].road) this.roadTiles.push({ x: b.x, y: b.y });
    }
    this.refreshLampSprites();
  }

  refreshLampSprites() {
    for (const s of this.lampSprites) {
      this.scene.remove(s);
      (s.material as THREE.SpriteMaterial).dispose();
    }
    this.lampSprites = [];
    if (this.engine.era < 3) return;
    let n = 0;
    for (const r of this.roadTiles) {
      if (n >= 160) break;
      const b = this.engine.buildingAt(r.x, r.y);
      if (!b) continue;
      const d = BUILDING_DEFS[b.defId];
      if (d.id !== 'paved' && d.id !== 'highway') continue;
      if ((r.x + r.y) % 2 !== 0) continue;
      const spr = new THREE.Sprite(new THREE.SpriteMaterial({
        map: this.dotTex, color: 0xffc46b, transparent: true, opacity: 0,
        blending: THREE.AdditiveBlending, depthWrite: false,
      }));
      spr.scale.setScalar(d.id === 'highway' ? 1.15 : 0.85);
      const [wx, wz] = this.tileToWorld(r.x, r.y);
      spr.position.set(wx, this.heightAt(r.x, r.y) + 0.62, wz);
      spr.renderOrder = 8;
      this.scene.add(spr);
      this.lampSprites.push(spr);
      n++;
    }
  }

  private disposeGroup(g: THREE.Group) {
    g.traverse(o => {
      const m = o as THREE.Mesh;
      if (m.isMesh) {
        m.geometry.dispose();
      }
    });
  }

  // ---------- 光源机制 ----------
  private buildLightPool() {
    for (let i = 0; i < 10; i++) {
      const pl = new THREE.PointLight(0xffd9a0, 0, 9, 2);
      pl.visible = false;
      this.scene.add(pl);
      this.lightPool.push(pl);
    }
  }

  private lightGlowStyle(defId: string): { color: number; y: number; scale: number; flicker: boolean } {
    switch (defId) {
      case 'torch':     return { color: 0xff9a3c, y: 0.95, scale: 1.5, flicker: true };
      case 'campfire':  return { color: 0xffa94d, y: 0.55, scale: 1.7, flicker: true };
      case 'oil_lamp':  return { color: 0xffc46b, y: 1.2,  scale: 2.0, flicker: true };
      case 'street_lamp': return { color: 0xdfe8ff, y: 1.62, scale: 2.3, flicker: false };
      case 'floodlight': return { color: 0xbfdcff, y: 2.25, scale: 3.4, flicker: false };
      default:          return { color: 0xffc46b, y: 0.8,  scale: 1.6, flicker: true };
    }
  }

  private addLightGlow(id: number, b: { x: number; y: number; size: number }, defId: string, defLight: number) {
    const st = this.lightGlowStyle(defId);
    const spr = new THREE.Sprite(new THREE.SpriteMaterial({
      map: this.dotTex, color: st.color, transparent: true, opacity: 0,
      blending: THREE.AdditiveBlending, depthWrite: false,
    }));
    const [wx, wz] = this.tileToWorld(b.x + (b.size - 1) / 2, b.y + (b.size - 1) / 2);
    spr.position.set(wx, this.heightAt(b.x, b.y) + st.y, wz);
    spr.scale.setScalar(Math.max(1.2, defLight * 0.32) + st.scale * 0.12);
    spr.renderOrder = 9;
    spr.userData.flicker = st.flicker;
    spr.userData.seed = Math.random() * 10;
    this.scene.add(spr);
    this.lightGlows.set(id, spr);
  }

  private addWorkGlow(id: number, b: { x: number; y: number; size: number }) {
    const spr = new THREE.Sprite(new THREE.SpriteMaterial({
      map: this.dotTex, color: 0xffe6a8, transparent: true, opacity: 0,
      blending: THREE.AdditiveBlending, depthWrite: false,
    }));
    const [wx, wz] = this.tileToWorld(b.x + (b.size - 1) / 2, b.y + (b.size - 1) / 2);
    spr.position.set(wx, this.heightAt(b.x, b.y) + 1.35 + b.size * 0.35, wz);
    spr.scale.setScalar(1.1 + b.size * 0.2);
    spr.renderOrder = 9;
    spr.userData.flicker = true;
    spr.userData.seed = Math.random() * 10;
    this.scene.add(spr);
    this.workGlows.set(id, spr);
  }

  private removeLightGlow(id: number) {
    const lg = this.lightGlows.get(id);
    if (lg) {
      this.scene.remove(lg);
      (lg.material as THREE.SpriteMaterial).dispose();
      this.lightGlows.delete(id);
    }
    const wg = this.workGlows.get(id);
    if (wg) {
      this.scene.remove(wg);
      (wg.material as THREE.SpriteMaterial).dispose();
      this.workGlows.delete(id);
    }
  }

  // ---------- 电力接线 (v5: 地下化 —— 普通视图不再显示悬垂导线) ----------
  rebuildWires() {
    // v5: 电缆全部埋入地下, 普通视图无任何导线; 管网视图由 rebuildUtilView 负责
    while (this.wireGroup.children.length > 0) {
      const c = this.wireGroup.children[0];
      this.wireGroup.remove(c);
      if ((c as THREE.Line).geometry) (c as THREE.Line).geometry.dispose();
    }
    this.wireVersion = this.engine.networkVersion;
  }

  // ---------- v5: 地下管网视图 (SC4 式) ----------
  private buildUtilFlow() {
    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.BufferAttribute(new Float32Array(600 * 3), 3));
    const m = new THREE.PointsMaterial({
      color: 0xffffff, size: 0.34, map: this.dotTex, transparent: true, opacity: 1,
      depthWrite: false, sizeAttenuation: true, blending: THREE.AdditiveBlending,
    });
    this.utilFlow = new THREE.Points(geo, m);
    this.utilFlow.count = 0;
    this.utilFlow.renderOrder = 9;
    this.utilGroup.add(this.utilFlow);
  }

  /** 管网视图: 干线/接口线 + 变电站环 + 流向粒子 */
  rebuildUtilView() {
    // 清理旧线
    for (const obj of this.utilLines) {
      this.utilGroup.remove(obj.line);
      obj.line.geometry.dispose();
      (obj.line.material as THREE.Material).dispose();
    }
    this.utilLines = [];
    for (const r of this.boostRings) this.utilGroup.remove(r);
    this.boostRings = [];
    this.utilVersion = this.engine.networkVersion;

    const isPower = this.viewMode === 'power';
    const isWater = this.viewMode === 'water';
    if (!isPower && !isWater) { this.utilFlowData = []; this.utilFlow.count = 0; return; }
    const edges = this.engine.utilEdges.filter(e => e.utility === (isPower ? 'power' : 'water'));
    if (edges.length === 0) { this.utilFlowData = []; this.utilFlow.count = 0; return; }

    const colorOf = (e: UtiliEdge): number => {
      if (e.dead) return 0x64748b;
      if (e.cap === Infinity) return isPower ? 0x93c5fd : 0x7dd3fc; // 接口线: 浅色
      const ratio = e.load / e.cap;
      if (ratio > 1) return 0xff2222;      // 过载: 闪红
      if (ratio > 0.85) return 0xfb923c;   // 高负载: 橙
      if (ratio > 0.55) return 0xfacc15;   // 中负载: 黄
      return e.boosted ? 0xa78bfa : 0x22c55e; // 健康: 绿 (增压后紫)
    };

    const flow: typeof this.utilFlowData = [];
    let flowBudget = 600;
    const YAXIS = new THREE.Vector3(0, 1, 0);
    for (const e of edges) {
      // 跟随地形高度: 管体画在地表之上, 呈"地下管线透视"效果 (v5: 圆柱管体, 粗细=等级)
      const ha = this.heightAt(Math.floor(e.ax), Math.floor(e.ay)) + 0.22;
      const hb = this.heightAt(Math.floor(e.bx), Math.floor(e.by)) + 0.22;
      const a = new THREE.Vector3(e.ax, ha, e.ay);
      const b = new THREE.Vector3(e.bx, hb, e.by);
      const dir = new THREE.Vector3().subVectors(b, a);
      const len = Math.max(0.05, dir.length());
      const radius = e.kind === 'trunk' ? 0.062 : 0.03;
      const mesh = new THREE.Mesh(
        new THREE.CylinderGeometry(radius, radius, len, 6, 1),
        new THREE.MeshBasicMaterial({
          color: colorOf(e), transparent: true, opacity: e.kind === 'drop' ? 0.6 : 0.92, depthWrite: false,
        }),
      );
      mesh.position.copy(a).addScaledVector(dir, 0.5);
      mesh.quaternion.setFromUnitVectors(YAXIS, dir.clone().normalize());
      mesh.renderOrder = 8;
      this.utilGroup.add(mesh);
      this.utilLines.push({ edge: e, line: mesh });
      // 干线: 附着流向粒子 (源→接口方向)
      if (e.kind === 'trunk' && flowBudget > 0 && !e.dead) {
        const n = Math.max(1, Math.min(4, Math.floor(len / 2.2)));
        for (let i = 0; i < n && flowBudget > 0; i++) {
          flow.push({ ax: e.ax, az: e.ay, bx: e.bx, bz: e.by, y: (ha + hb) / 2, speed: 1.6, off: i / n });
          flowBudget--;
        }
      }
    }
    // 变电站/泵站: 增压范围环
    for (const b of this.engine.buildings.values()) {
      if (b.progress < 1) continue;
      const d = BUILDING_DEFS[b.defId];
      if (d.booster !== (isPower ? 'transformer' : 'pump')) continue;
      const ring = new THREE.Mesh(
        new THREE.RingGeometry(d.boostRadius ?? 7, (d.boostRadius ?? 7) + 0.5, 42),
        new THREE.MeshBasicMaterial({
          color: isPower ? 0xa78bfa : 0x38bdf8, transparent: true, opacity: 0.4, side: THREE.DoubleSide, depthWrite: false,
        }),
      );
      ring.rotation.x = -Math.PI / 2;
      ring.renderOrder = 8;
      const [wx, wz] = this.tileToWorld(b.x + (b.size - 1) / 2, b.y + (b.size - 1) / 2);
      ring.position.set(wx, this.heightAt(b.x, b.y) + 0.2, wz);
      this.utilGroup.add(ring);
      this.boostRings.push(ring);
    }
    this.utilFlowData = flow;
    // 流点颜色: 电=暖黄, 水=青蓝
    (this.utilFlow.material as THREE.PointsMaterial).color.setHex(isPower ? 0xffe066 : 0x7dd3fc);
  }

  /** 每帧: 流向粒子滑动 + 过载闪 + 增压环呼吸 */
  private updateUtilFlow(dt: number) {
    if (this.viewMode !== 'power' && this.viewMode !== 'water') return;
    // 过载干线闪红
    const pulse = 0.5 + Math.abs(Math.sin(this.time * 6)) * 0.5;
    for (const { edge, line } of this.utilLines) {
      if (edge.cap === Infinity) continue;
      const m = line.material as THREE.MeshBasicMaterial;
      const ratio = edge.load / edge.cap;
      if (edge.dead) { m.opacity = 0.25 + Math.sin(this.time * 3) * 0.1; continue; }
      if (ratio > 1) {
        m.color.setHex(0xff2222);
        m.opacity = 0.4 + pulse * 0.6;
      } else if (ratio > 0.85) {
        m.color.setHex(0xfb923c);
        m.opacity = 0.85;
      }
    }
    for (const r of this.boostRings) {
      (r.material as THREE.MeshBasicMaterial).opacity = 0.28 + Math.sin(this.time * 2.2) * 0.14;
      r.rotation.z = this.time * 0.15;
    }
    // 流点沿 a→b 滑动 (资源自源点流向接口, 悬在管体上方半格)
    const pos = this.utilFlow.geometry.attributes.position as THREE.BufferAttribute;
    const n = Math.min(this.utilFlowData.length, 600);
    for (let i = 0; i < n; i++) {
      const f = this.utilFlowData[i];
      f.off = (f.off + dt * f.speed * 0.45) % 1;
      const ha = this.heightAt(Math.floor(f.ax), Math.floor(f.az)) + 0.38;
      const hb = this.heightAt(Math.floor(f.bx), Math.floor(f.bz)) + 0.38;
      pos.setXYZ(i, f.ax + (f.bx - f.ax) * f.off, ha + (hb - ha) * f.off, f.az + (f.bz - f.az) * f.off);
    }
    this.utilFlow.count = n;
    pos.needsUpdate = true;
  }

  // ---------- 道路/管线两点连线 ----------
  private buildLinePreview() {
    const geo = new THREE.PlaneGeometry(0.92, 0.92);
    geo.rotateX(-Math.PI / 2);
    const m = new THREE.MeshBasicMaterial({ transparent: true, opacity: 0.42, depthWrite: false });
    const mesh = new THREE.InstancedMesh(geo, m, 320);
    mesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
    mesh.count = 0;
    mesh.visible = false;
    mesh.renderOrder = 6;
    this.linePreviewMesh = mesh;
    this.scene.add(mesh);
  }

  private linePath(a: { x: number; y: number }, b: { x: number; y: number }): { x: number; y: number }[] {
    const out: { x: number; y: number }[] = [];
    const dx = b.x - a.x, dy = b.y - a.y;
    if (dx === 0 && dy === 0) return [a];
    const xFirst = Math.abs(dx) >= Math.abs(dy);
    const stepX = xFirst ? Math.sign(dx) : 0;
    const stepY = xFirst ? 0 : Math.sign(dy);
    let cx = a.x, cy = a.y;
    out.push({ x: cx, y: cy });
    while (cx !== a.x + (xFirst ? dx : 0) || cy !== a.y + (xFirst ? 0 : dy)) {
      cx += stepX; cy += stepY;
      out.push({ x: cx, y: cy });
    }
    const stepX2 = xFirst ? 0 : Math.sign(dx);
    const stepY2 = xFirst ? Math.sign(dy) : 0;
    while (cx !== b.x || cy !== b.y) {
      cx += stepX2; cy += stepY2;
      out.push({ x: cx, y: cy });
    }
    return out;
  }

  buildLineClick(x: number, y: number) {
    if (this.mode.type !== 'build') return;
    if (!this.lineStart) {
      this.lineStart = { x, y };
      this.cb.onSfx?.('order');
      return;
    }
    const path = this.linePath(this.lineStart, { x, y });
    this.lineStart = null;
    this.applyLinePreview([], this.mode.defId);
    const res = this.engine.placeLine(this.mode.defId, path);
    if (res.built > 0) {
      this.cb.onSfx?.('build');
      const def = BUILDING_DEFS[this.mode.defId];
      this.engine.notify('info', `${def.name}铺设完成`, `共建 ${res.built} 格${res.failed > 0 ? `, ${res.failed} 格因受阻或资源不足跳过` : ''}。`, 'good');
    } else {
      this.engine.notify('info', '无法铺设', '路径上没有可建造的格子 (受阻/无资源/已有建筑/未探索)。', 'bad');
    }
  }

  cancelLine() {
    this.lineStart = null;
    this.lineTiles = [];
    if (this.linePreviewMesh) this.linePreviewMesh.visible = false;
    this.cb.onLinePreview?.(0, {});
  }

  private applyLinePreview(tiles: { x: number; y: number }[], defId: string) {
    const mesh = this.linePreviewMesh;
    if (!mesh) return;
    this.lineTiles = tiles;
    mesh.visible = tiles.length > 0;
    const mtx = new THREE.Matrix4();
    const col = new THREE.Color();
    let n = 0;
    const cost: Record<string, number> = {};
    for (const t of tiles) {
      if (n >= 320) break;
      const ok = this.engine.canPlace(defId, t.x, t.y).ok;
      const [wx, wz] = this.tileToWorld(t.x, t.y);
      const h = this.heightAt(t.x, t.y);
      mtx.makeTranslation(wx, h + 0.12, wz);
      mesh.setMatrixAt(n, mtx);
      col.setHex(ok ? 0x4ade80 : 0xef4444);
      mesh.setColorAt(n, col);
      if (ok) {
        const def = BUILDING_DEFS[defId];
        for (const [k, v] of Object.entries(def.cost)) cost[k] = (cost[k] ?? 0) + (v ?? 0);
      }
      n++;
    }
    mesh.count = n;
    mesh.instanceMatrix.needsUpdate = true;
    if (mesh.instanceColor) mesh.instanceColor.needsUpdate = true;
    this.cb.onLinePreview?.(tiles.length, cost);
  }

  // ---------- 感叹号警报 ----------
  private buildAlertSprites() {
    const cv = document.createElement('canvas');
    cv.width = 96; cv.height = 128;
    const ctx = cv.getContext('2d')!;
    const grad = ctx.createRadialGradient(48, 52, 8, 48, 52, 46);
    grad.addColorStop(0, '#ff6b5e');
    grad.addColorStop(1, '#d92318');
    ctx.beginPath(); ctx.arc(48, 52, 46, 0, Math.PI * 2);
    ctx.fillStyle = grad; ctx.fill();
    ctx.lineWidth = 6; ctx.strokeStyle = '#7f100a'; ctx.stroke();
    ctx.fillStyle = '#fff';
    ctx.beginPath();
    ctx.roundRect(41, 22, 14, 44, 7); ctx.fill();
    ctx.beginPath(); ctx.arc(48, 82, 8, 0, Math.PI * 2); ctx.fill();
    ctx.beginPath(); ctx.moveTo(38, 96); ctx.lineTo(58, 96); ctx.lineTo(48, 112); ctx.closePath();
    ctx.fillStyle = '#d92318'; ctx.fill();
    const tex = new THREE.CanvasTexture(cv);
    tex.colorSpace = THREE.SRGBColorSpace;
    this.alertTex = tex;
    for (let i = 0; i < 90; i++) {
      const spr = new THREE.Sprite(new THREE.SpriteMaterial({ map: tex, transparent: true, depthWrite: false, depthTest: false }));
      spr.scale.set(0.52, 0.7, 1);
      spr.visible = false;
      spr.renderOrder = 30;
      this.alertSprites.push(spr);
      this.scene.add(spr);
    }
  }

  private updateAlertsAndBars() {
    for (const [id, bar] of this.progressBars) {
      const b = this.engine.buildings.get(id);
      if (!b) continue;
      bar.fill.scale.x = Math.max(0.02, b.progress);
      bar.fill.position.x = bar.bg.position.x - (bar.size * 0.72 - 0.03) * (1 - b.progress) / 2;
    }
    let si = 0;
    const t = this.time;
    for (const b of this.engine.buildings.values()) {
      if (si >= this.alertSprites.length) break;
      if (!b.alerts || b.alerts.length === 0 || b.progress < 1) continue;
      const spr = this.alertSprites[si++];
      const g = this.buildingGroups.get(b.id);
      if (!g) continue;
      const top = this.buildingTops.get(b.id) ?? 0.8;
      const bob = Math.sin(t * 3.2 + b.id * 1.7) * 0.06;
      spr.position.set(g.position.x, g.position.y + top + 0.55 + bob, g.position.z);
      const mat = spr.material as THREE.SpriteMaterial;
      mat.opacity = 0.82 + Math.sin(t * 4 + b.id) * 0.15;
      if (b.alerts.length > 1) {
        mat.map = this.alertBadgeTexture(Math.min(9, b.alerts.length));
        spr.scale.set(0.62, 0.84, 1);
      } else {
        mat.map = this.alertTex;
        spr.scale.set(0.52, 0.7, 1);
      }
      spr.visible = true;
    }
    for (let i = si; i < this.alertSprites.length; i++) this.alertSprites[i].visible = false;
  }

  private alertBadgeTexture(n: number): THREE.Texture {
    const cached = this.alertBadgeCache.get(n);
    if (cached) return cached;
    const cv = document.createElement('canvas');
    cv.width = 96; cv.height = 128;
    const ctx = cv.getContext('2d')!;
    const grad = ctx.createRadialGradient(48, 52, 8, 48, 52, 46);
    grad.addColorStop(0, '#ff6b5e');
    grad.addColorStop(1, '#d92318');
    ctx.beginPath(); ctx.arc(48, 52, 46, 0, Math.PI * 2);
    ctx.fillStyle = grad; ctx.fill();
    ctx.lineWidth = 6; ctx.strokeStyle = '#7f100a'; ctx.stroke();
    ctx.fillStyle = '#fff';
    ctx.beginPath();
    ctx.roundRect(41, 18, 14, 40, 7); ctx.fill();
    ctx.beginPath(); ctx.arc(48, 74, 7, 0, Math.PI * 2); ctx.fill();
    ctx.beginPath(); ctx.arc(74, 92, 22, 0, Math.PI * 2);
    ctx.fillStyle = '#1c1917'; ctx.fill();
    ctx.lineWidth = 4; ctx.strokeStyle = '#fbbf24'; ctx.stroke();
    ctx.fillStyle = '#fde68a';
    ctx.font = 'bold 28px sans-serif';
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.fillText(String(n), 74, 93);
    ctx.beginPath(); ctx.moveTo(38, 96); ctx.lineTo(58, 96); ctx.lineTo(48, 112); ctx.closePath();
    ctx.fillStyle = '#d92318'; ctx.fill();
    const tex = new THREE.CanvasTexture(cv);
    tex.colorSpace = THREE.SRGBColorSpace;
    this.alertBadgeCache.set(n, tex);
    return tex;
  }

  // ---------- 道路自动朝向 ----------
  refreshRoadOrientations() {
    for (const b of this.engine.buildings.values()) {
      const def = BUILDING_DEFS[b.defId];
      if (!def.road && !def.pipe) continue;
      const g = this.buildingGroups.get(b.id);
      if (!g) continue;
      if (b.progress < 1) continue;
      let mask = 0;
      for (const [dx, dy, bit] of [[1, 0, 1], [-1, 0, 2], [0, 1, 4], [0, -1, 8]] as const) {
        const t = this.engine.terrain.peek(b.x + dx, b.y + dy);
        if (!t || t.buildingId < 0) continue;
        const nb = this.engine.buildings.get(t.buildingId);
        if (!nb || nb.progress < 1) continue;
        const nd = BUILDING_DEFS[nb.defId];
        if ((def.road && nd.road) || (def.pipe && nd.pipe)) mask |= bit;
      }
      if ((g.userData.roadMask ?? -1) === mask) continue;
      g.userData.roadMask = mask;
      const xAxis = (mask & 3) !== 0 && (mask & 12) === 0;
      const zAxis = (mask & 12) !== 0 && (mask & 3) === 0;
      const flip = def.id === 'water_pipe';
      let rotY = 0;
      if (flip ? zAxis : xAxis) rotY = Math.PI / 2;
      g.rotation.y = rotY;
      const plain = !xAxis && !zAxis;
      if (def.id === 'paved' || def.id === 'highway') {
        const plainColor = def.id === 'paved' ? 0x3d4045 : 0x33363b;
        g.traverse(o => {
          const mesh = o as THREE.Mesh;
          if (!mesh.isMesh) return;
          const mtl = mesh.material as THREE.MeshStandardMaterial;
          if (plain && mtl.map) {
            mesh.material = mat(plainColor, { roughness: 0.92 });
          }
        });
        if (!plain) {
          const fresh = buildModel(def.id);
          const textured = fresh.children.find(c => (c as THREE.Mesh).isMesh && ((c as THREE.Mesh).material as THREE.MeshStandardMaterial).map);
          if (textured) {
            const texMat = (textured as THREE.Mesh).material;
            g.traverse(o => {
              const mesh = o as THREE.Mesh;
              if (mesh.isMesh && !(mesh.material as THREE.MeshStandardMaterial).map) mesh.material = texMat;
            });
          }
          this.disposeGroup(fresh);
        }
      }
    }
  }

  // ---------- 粒子 ----------
  private spawnParticle(x: number, y: number, z: number, opts: {
    color: number; life: number; vx: number; vy: number; vz: number; size: number; grow: number; additive?: boolean; opacity?: number; noDepth?: boolean;
  }) {
    let spr = this.particlePool.pop();
    if (!spr) {
      if (this.particles.length > 160) return;
      spr = new THREE.Sprite(new THREE.SpriteMaterial({ map: this.dotTex, transparent: true, depthWrite: false }));
      this.scene.add(spr);
    }
    spr.material.color.setHex(opts.color);
    (spr.material as THREE.SpriteMaterial).blending = opts.additive ? THREE.AdditiveBlending : THREE.NormalBlending;
    (spr.material as THREE.SpriteMaterial).opacity = opts.opacity ?? 0.8;
    (spr.material as THREE.SpriteMaterial).depthTest = !(opts.noDepth ?? false);
    spr.renderOrder = opts.noDepth ? 999 : 0;
    spr.position.set(x, y, z);
    spr.scale.setScalar(opts.size);
    spr.visible = true;
    this.particles.push({ spr, life: opts.life, maxLife: opts.life, vx: opts.vx, vy: opts.vy, vz: opts.vz, grow: opts.grow, baseOpacity: opts.opacity ?? 0.8 });
  }

  private updateParticles(dt: number) {
    for (let i = this.particles.length - 1; i >= 0; i--) {
      const p = this.particles[i];
      p.life -= dt;
      if (p.life <= 0) {
        p.spr.visible = false;
        this.particlePool.push(p.spr);
        this.particles.splice(i, 1);
        continue;
      }
      p.spr.position.x += p.vx * dt;
      p.spr.position.y += p.vy * dt;
      p.spr.position.z += p.vz * dt;
      const t = p.life / p.maxLife;
      (p.spr.material as THREE.SpriteMaterial).opacity = Math.min(1, t * 3) * p.baseOpacity;
      p.spr.scale.addScalar(p.grow * dt);
    }
  }

  private setFireVisual(id: number, on: boolean) {
    void on; void id;
  }

  // ---------- 浮动文字 ----------
  spawnFloatText(wx: number, wy: number, wz: number, text: string, color = '#ffe9b0') {
    if (this.floatTexts.length > 14) return;
    const cv = document.createElement('canvas');
    cv.width = 256; cv.height = 72;
    const ctx = cv.getContext('2d')!;
    ctx.font = 'bold 38px "Noto Sans SC", sans-serif';
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.lineWidth = 7; ctx.strokeStyle = 'rgba(20,14,6,0.9)';
    ctx.strokeText(text, 128, 36);
    ctx.fillStyle = color;
    ctx.fillText(text, 128, 36);
    const tex = new THREE.CanvasTexture(cv);
    tex.colorSpace = THREE.SRGBColorSpace;
    const spr = new THREE.Sprite(new THREE.SpriteMaterial({ map: tex, transparent: true, depthWrite: false, depthTest: false }));
    spr.scale.set(1.5, 0.42, 1);
    spr.position.set(wx, wy, wz);
    spr.renderOrder = 40;
    this.scene.add(spr);
    this.floatTexts.push({ spr, life: 1.5, maxLife: 1.5 });
  }

  private updateFloatTexts(dt: number) {
    for (let i = this.floatTexts.length - 1; i >= 0; i--) {
      const f = this.floatTexts[i];
      f.life -= dt;
      if (f.life <= 0) {
        this.scene.remove(f.spr);
        f.spr.material.map?.dispose();
        (f.spr.material as THREE.SpriteMaterial).dispose();
        this.floatTexts.splice(i, 1);
        continue;
      }
      const t = f.life / f.maxLife;
      f.spr.position.y += dt * 0.55;
      (f.spr.material as THREE.SpriteMaterial).opacity = t < 0.35 ? t / 0.35 : 1;
      const s = t > 0.82 ? 1 + (1 - (t - 0.82) / 0.18) * 0.25 : 1;
      f.spr.scale.set(1.5 * s, 0.42 * s, 1);
    }
  }

  eraCinematic() {
    this.cine = {
      t: 0, dur: 3.0,
      fd: this.camDist, td: Math.min(110, this.camDist + 15),
      fth: this.camTheta, tth: this.camTheta + 0.42,
      fph: this.camPhi, tph: Math.max(0.42, Math.min(this.camPhi, 0.95) - 0.14),
    };
  }

  // ---------- 交互 ----------
  setMode(m: Mode) {
    const prevDefId = this.mode.type === 'build' ? this.mode.defId : null;
    this.mode = m;
    if (m.type !== 'build') {
      this.cancelLine();
      this.buildRot = 0;
    } else if (m.defId !== prevDefId) {
      this.cancelLine();
    }
    if (this.ghostGroup) {
      this.scene.remove(this.ghostGroup);
      this.disposeGroup(this.ghostGroup);
      this.ghostGroup = null;
    }
    if (m.type === 'build') {
      const g = buildModel(m.defId);
      const ghostMat = new THREE.MeshStandardMaterial({ color: 0x4ade80, transparent: true, opacity: 0.55, depthWrite: false });
      g.traverse(o => {
        const mesh = o as THREE.Mesh;
        if (mesh.isMesh) mesh.material = ghostMat;
      });
      g.rotation.y = (this.buildRot * Math.PI) / 2;
      this.ghostGroup = g;
      this.scene.add(g);
    }
    // 探索模式辅助线
    const explore = m.type === 'explore';
    this.exploreLine.visible = explore;
    this.exploreFlag.visible = false;
    this.updateHoverVisual();
  }

  selectBuilding(id: number | null) {
    this.selectedBuildingId = id;
    if (id == null) {
      this.selectRing.visible = false;
      this.radiusRing.visible = false;
      return;
    }
    const b = this.engine.buildings.get(id);
    if (!b) { this.selectRing.visible = false; this.radiusRing.visible = false; return; }
    const def = BUILDING_DEFS[b.defId];
    const [wx, wz] = this.tileToWorld(b.x + (b.size - 1) / 2, b.y + (b.size - 1) / 2);
    this.selectRing.position.set(wx, this.heightAt(b.x, b.y) + 0.08, wz);
    const base = b.size * 1.4;
    this.selectRing.userData.baseScale = base;
    this.selectRing.scale.setScalar(base);
    this.selectRing.visible = true;
    if (def.radius && def.radius > 0) {
      this.radiusRing.position.copy(this.selectRing.position);
      this.radiusRing.scale.setScalar(def.radius);
      this.radiusRing.visible = true;
    } else {
      this.radiusRing.visible = false;
    }
  }

  private bindEvents() {
    const c = this.canvas;
    c.addEventListener('pointerdown', this.onPointerDown);
    c.addEventListener('pointermove', this.onPointerMove);
    c.addEventListener('pointerup', this.onPointerUp);
    c.addEventListener('pointerleave', this.onPointerLeave);
    c.addEventListener('wheel', this.onWheel, { passive: false });
    c.addEventListener('contextmenu', e => e.preventDefault());
    window.addEventListener('keydown', this.onKeyDown);
    window.addEventListener('keyup', this.onKeyUp);
    window.addEventListener('resize', this.resize);
  }

  private onPointerDown = (e: PointerEvent) => {
    this.canvas.setPointerCapture(e.pointerId);
    this.lastPointer = { x: e.clientX, y: e.clientY };
    this.movedDistance = 0;
    if (e.button === 2 || (e.button === 0 && e.shiftKey && this.mode.type === 'none')) {
      this.dragging = 'orbit';
    } else if (e.button === 1 || (e.button === 0 && e.altKey)) {
      this.dragging = 'pan';
    } else if (e.button === 0) {
      this.dragging = null;
      this.isLeftDown = true;
    }
  };

  private onPointerMove = (e: PointerEvent) => {
    const rect = this.canvas.getBoundingClientRect();
    this.mouse.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
    this.mouse.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;
    this.mouse.inside = true;
    const dx = e.clientX - this.lastPointer.x;
    const dy = e.clientY - this.lastPointer.y;
    this.movedDistance += Math.abs(dx) + Math.abs(dy);
    if (this.touchMode === 'two' && e.pointerType === 'touch') return;
    if (this.dragging === 'orbit') {
      this.camTheta -= dx * 0.005;
      this.camPhi = Math.max(0.18, Math.min(1.4, this.camPhi - dy * 0.004));
      this.lastPointer = { x: e.clientX, y: e.clientY };
    } else if (this.dragging === 'pan') {
      this.panCamera(dx, dy);
      this.lastPointer = { x: e.clientX, y: e.clientY };
    } else {
      this.lastPointer = { x: e.clientX, y: e.clientY };
      if (this.isLeftDown && this.mode.type === 'terrain' && this.movedDistance > 4) {
        const pt = this.pickTerrain();
        if (pt) {
          const [x, y] = this.worldToTile(pt.x, pt.z);
          this.cb.onTileClick(x, y);
        }
      }
    }
    this.updateHoverVisual();
  };

  private onPointerUp = (e: PointerEvent) => {
    this.isLeftDown = false;
    if (e.button === 0 && this.movedDistance < 6 && this.mode.type !== 'none') {
      this.handleClick();
    } else if (e.button === 0 && this.movedDistance < 6 && this.mode.type === 'none') {
      this.handleClickSelect();
    }
    this.dragging = null;
  };

  private onPointerLeave = () => { this.mouse.inside = false; this.hoverQuad.visible = false; };

  private onWheel = (e: WheelEvent) => {
    e.preventDefault();
    this.camDist = Math.max(6, Math.min(150, this.camDist * (1 + Math.sign(e.deltaY) * 0.09)));
  };

  private onKeyDown = (e: KeyboardEvent) => {
    this.keys.add(e.key.toLowerCase());
    if (e.key.toLowerCase() === 'r' && this.mode.type === 'build') {
      const def = BUILDING_DEFS[this.mode.defId];
      if (!def.road && !def.pipe) {
        this.buildRot = (this.buildRot + 1) % 4;
        if (this.ghostGroup) this.ghostGroup.rotation.y = (this.buildRot * Math.PI) / 2;
        this.cb.onSfx?.('click');
      }
    }
  };
  private onKeyUp = (e: KeyboardEvent) => {
    this.keys.delete(e.key.toLowerCase());
  };

  private panCamera(dx: number, dy: number) {
    this.battleCam = null;   // v5: 玩家接管镜头, 取消战斗飞行动画
    const forward = new THREE.Vector3();
    this.camera.getWorldDirection(forward);
    forward.y = 0; forward.normalize();
    const right = new THREE.Vector3().crossVectors(new THREE.Vector3(0, 1, 0), forward).normalize();
    const speed = this.camDist * 0.0016;
    this.camTarget.addScaledVector(right, dx * speed);
    this.camTarget.addScaledVector(forward, -dy * speed * -1);
    const lim = 400; // 无限世界: 只为浮点安全设远界
    this.camTarget.x = Math.max(-lim, Math.min(lim, this.camTarget.x));
    this.camTarget.z = Math.max(-lim, Math.min(lim, this.camTarget.z));
  }

  private raycaster = new THREE.Raycaster();
  private pickTerrain(): THREE.Vector3 | null {
    this.raycaster.setFromCamera(new THREE.Vector2(this.mouse.x, this.mouse.y), this.camera);
    if (this.chunkMeshList.length > 0) {
      const hits = this.raycaster.intersectObjects(this.chunkMeshList, false);
      if (hits.length > 0) return hits[0].point;
    }
    const plane = new THREE.Plane(new THREE.Vector3(0, 1, 0), 0.05);
    const pt = new THREE.Vector3();
    if (this.raycaster.ray.intersectPlane(plane, pt)) return pt;
    return null;
  }

  private pickBuilding(): number | null {
    this.raycaster.setFromCamera(new THREE.Vector2(this.mouse.x, this.mouse.y), this.camera);
    const groups = [...this.buildingGroups.values()];
    const hits = this.raycaster.intersectObjects(groups, true);
    for (const h of hits) {
      let o: THREE.Object3D | null = h.object;
      while (o) {
        if (o.userData.buildingId != null && o.userData.buildingId !== undefined) return o.userData.buildingId as number;
        o = o.parent;
      }
    }
    return null;
  }

  private handleClick() {
    const pt = this.pickTerrain();
    if (!pt) return;
    const [x, y] = this.worldToTile(pt.x, pt.z);
    this.cb.onTileClick(x, y);
  }

  private handleClickSelect() {
    const id = this.pickBuilding();
    if (id != null) {
      this.cb.onBuildingClick(id);
    } else {
      const pt = this.pickTerrain();
      if (pt) {
        const [x, y] = this.worldToTile(pt.x, pt.z);
        const t = this.engine.terrain.peek(x, y);
        if (t && t.explored) {
          this.cb.onTileClick(x, y);
          return;
        }
      }
      this.cb.onBuildingClick(-1);
    }
  }

  private updateHoverVisual() {
    if (!this.mouse.inside) return;
    const pt = this.pickTerrain();
    if (!pt) { this.hoverQuad.visible = false; return; }
    const [x, y] = this.worldToTile(pt.x, pt.z);
    this.hoverTile = { x, y };
    this.cb.onHover(x, y);
    if (this.mode.type === 'build') {
      const def = BUILDING_DEFS[this.mode.defId];
      const isLine = !!(def.road || def.pipe);
      if (isLine && this.lineStart) {
        this.hoverQuad.visible = false;
        if (this.ghostGroup) this.ghostGroup.visible = false;
        const path = this.linePath(this.lineStart, { x, y });
        this.applyLinePreview(path, this.mode.defId);
        return;
      }
      if (isLine) {
        if (this.linePreviewMesh) this.linePreviewMesh.visible = false;
      }
      const check = this.engine.canPlace(this.mode.defId, x, y);
      const size = def.size;
      const [wx, wz] = this.tileToWorld(x + (size - 1) / 2, y + (size - 1) / 2);
      const hh = this.heightAt(x, y);
      this.hoverQuad.position.set(wx, hh + 0.1, wz);
      this.hoverQuad.scale.setScalar(size);
      (this.hoverQuad.material as THREE.MeshBasicMaterial).color.setHex(check.ok ? 0x4ade80 : 0xf87171);
      this.hoverQuad.visible = true;
      if (this.ghostGroup) {
        this.ghostGroup.position.set(wx, hh, wz);
        this.ghostGroup.rotation.y = (this.buildRot * Math.PI) / 2;
        this.ghostGroup.traverse(o => {
          const m = o as THREE.Mesh;
          if (m.isMesh) (m.material as THREE.MeshStandardMaterial).color.setHex(check.ok ? 0x4ade80 : 0xf87171);
        });
        this.ghostGroup.visible = true;
      }
    } else if (this.mode.type === 'explore') {
      // 远征目标预览: 虚线 + 旗 + 距离着色
      const cc = this.engine.cityCenter();
      const dist = Math.max(Math.abs(x - cc.x), Math.abs(y - cc.y));
      const [wx, wz] = this.tileToWorld(x, y);
      this.hoverQuad.position.set(wx, this.heightAt(x, y) + 0.1, wz);
      (this.hoverQuad.material as THREE.MeshBasicMaterial).color.setHex(dist >= 10 ? 0x22d3ee : 0xf87171);
      this.hoverQuad.visible = true;
      const [cwx, cwz] = this.tileToWorld(cc.x, cc.y);
      const pts = [
        new THREE.Vector3(cwx, this.heightAt(cc.x, cc.y) + 0.4, cwz),
        new THREE.Vector3(wx, this.heightAt(x, y) + 0.4, wz),
      ];
      this.exploreLine.geometry.dispose();
      this.exploreLine.geometry = new THREE.BufferGeometry().setFromPoints(pts);
      this.exploreLine.computeLineDistances();
      this.exploreLine.visible = true;
      this.exploreFlag.position.set(wx, this.heightAt(x, y), wz);
      this.exploreFlag.visible = true;
      if (this.ghostGroup) this.ghostGroup.visible = false;
    } else if (this.mode.type === 'chop' || this.mode.type === 'demolish' || this.mode.type === 'terrain') {
      const [wx, wz] = this.tileToWorld(x, y);
      this.hoverQuad.position.set(wx, this.heightAt(x, y) + 0.1, wz);
      let can = true;
      if (this.mode.type === 'chop') {
        const t = this.tileAtWorld(wx, wz);
        can = !!t && t.explored && (t.tree >= 0 || t.rock || (t.ruin >= 0 && !this.engine.terrain.ruins[t.ruin].scavenged));
      } else if (this.mode.type === 'demolish') {
        can = !!this.engine.buildingAt(x, y);
      }
      (this.hoverQuad.material as THREE.MeshBasicMaterial).color.setHex(can ? 0x4ade80 : 0xf87171);
      this.hoverQuad.visible = true;
      if (this.ghostGroup) this.ghostGroup.visible = false;
    } else {
      this.hoverQuad.visible = false;
      this.exploreLine.visible = false;
      this.exploreFlag.visible = false;
      if (this.ghostGroup) this.ghostGroup.visible = false;
    }
  }

  // ---------- 相机 ----------
  private applyCamera() {
    // v5: 战斗震屏
    let shakeX = 0, shakeZ = 0;
    if (this.camShake > 0.001) {
      this.camShake = Math.max(0, this.camShake - 0.016);
      const s = this.camShake * this.camShake;
      shakeX = (Math.random() - 0.5) * s * 2;
      shakeZ = (Math.random() - 0.5) * s * 2;
    }
    const sinPhi = Math.sin(this.camPhi);
    this.camera.position.set(
      this.camTarget.x + this.camDist * sinPhi * Math.cos(this.camTheta) + shakeX,
      this.camTarget.y + this.camDist * Math.cos(this.camPhi),
      this.camTarget.z + this.camDist * sinPhi * Math.sin(this.camTheta) + shakeZ,
    );
    this.camera.lookAt(this.camTarget);
  }

  private handleKeys(dt: number) {
    const pan = this.camDist * 0.9 * dt;
    const forward = new THREE.Vector3();
    this.camera.getWorldDirection(forward);
    forward.y = 0; forward.normalize();
    const right = new THREE.Vector3().crossVectors(new THREE.Vector3(0, 1, 0), forward).normalize();
    let moved = false;
    if (this.keys.has('w') || this.keys.has('arrowup')) { this.camTarget.addScaledVector(forward, pan); moved = true; }
    if (this.keys.has('s') || this.keys.has('arrowdown')) { this.camTarget.addScaledVector(forward, -pan); moved = true; }
    if (this.keys.has('a') || this.keys.has('arrowleft')) { this.camTarget.addScaledVector(right, pan); moved = true; }
    if (this.keys.has('d') || this.keys.has('arrowright')) { this.camTarget.addScaledVector(right, -pan); moved = true; }
    if (this.keys.has('q')) { this.camTheta += dt * 1.2; moved = true; }
    if (this.keys.has('e')) { this.camTheta -= dt * 1.2; moved = true; }
    if (moved) {
      const lim = 400;
      this.camTarget.x = Math.max(-lim, Math.min(lim, this.camTarget.x));
      this.camTarget.z = Math.max(-lim, Math.min(lim, this.camTarget.z));
    }
  }

  focusOn(x: number, y: number) {
    this.battleCam = null;   // 程序化聚焦同样取消战斗镜头动画
    const [wx, wz] = this.tileToWorld(x, y);
    this.camTarget.set(wx, 0, wz);
  }

  // ---------- 昼夜 ----------
  private updateDayNight() {
    const hour = this.engine.hour;
    const dayT = (hour - 5.5) / 13;
    const isDay = dayT >= 0 && dayT <= 1;
    const angle = dayT * Math.PI;
    const sunH = Math.sin(angle);
    const cx = this.camTarget.x, cz = this.camTarget.z;
    this.sun.position.set(cx + Math.cos(angle) * 50, 10 + Math.max(0, sunH) * 55, cz - 22);
    this.sun.target.position.set(cx, 0, cz);

    const nightFactor = isDay ? Math.max(0, Math.min(1, sunH * 3)) : 0;
    const duskGlow = isDay ? Math.max(0, 1 - Math.abs(sunH) * 4) : 0;
    this.sun.intensity = 0.18 + nightFactor * 1.5;
    this.sun.color.setHSL(0.09 + nightFactor * 0.04, 0.5 - nightFactor * 0.3 + duskGlow * 0.35, 0.55 + nightFactor * 0.3);
    this.hemi.intensity = (this.quality === 'low' ? 0.9 : 0.24) + nightFactor * (this.quality === 'low' ? 0.4 : 0.56);
    this.hemi.color.setHex(nightFactor > 0.15 ? 0xcfe8ff : 0x33415e);

    const skyDay = new THREE.Color(0x87b5d4);
    const skyNight = new THREE.Color(0x101a2e);
    const skyDusk = new THREE.Color(0xe8946a);
    const sky = skyNight.clone().lerp(skyDay, nightFactor);
    if (duskGlow > 0) sky.lerp(skyDusk, duskGlow * 0.55);
    if (this.engine.stormDays > 0) sky.lerp(new THREE.Color(0x4a5568), 0.6);
    (this.scene.background as THREE.Color).copy(sky);
    (this.scene.fog as THREE.Fog).color.copy(sky);
    const fog = this.scene.fog as THREE.Fog;
    fog.near = this.engine.stormDays > 0 ? 40 : 90;
    fog.far = this.engine.stormDays > 0 ? 120 : 260;

    this.cloudMat.opacity = 0.22 + nightFactor * 0.63;
    this.cloudMat.color.setHex(nightFactor > 0.35 ? 0xffffff : 0x2e3a54);

    const lit = 1 - nightFactor;
    for (const m of this.windowMeshes) {
      const mat = m.material as THREE.MeshStandardMaterial;
      mat.emissiveIntensity = lit * 1.4;
    }
    const lampO = Math.max(0, lit - 0.25) * 0.62;
    for (const s of this.lampSprites) (s.material as THREE.SpriteMaterial).opacity = lampO;

    // 建筑光源
    const powerDim = this.engine.powerDemand > this.engine.powerSupply ? 0.35 : 1;
    const litF = Math.max(0, lit - 0.12) * 0.72;
    for (const [id, spr] of this.lightGlows) {
      const mat = spr.material as THREE.SpriteMaterial;
      const b = this.engine.buildings.get(id);
      const def = b ? BUILDING_DEFS[b.defId] : null;
      const powered = def?.powerNeed ? (this.engine.isBuildingPowered(id) ? powerDim : 0) : 1;
      let o = litF * powered;
      if (o > 0 && spr.userData.flicker) {
        o *= 0.78 + Math.sin(this.time * 11 + spr.userData.seed) * 0.14 + Math.sin(this.time * 23 + spr.userData.seed * 2) * 0.08;
      }
      mat.opacity = Math.max(0, o);
    }
    for (const spr of this.workGlows.values()) {
      const mat = spr.material as THREE.SpriteMaterial;
      mat.opacity = litF * (0.55 + Math.sin(this.time * 7 + spr.userData.seed) * 0.1);
    }
    // 真实点光源: 镜头最近的几盏
    const poolN = this.quality === 'low' ? 0 : this.quality === 'high' ? 10 : 6;
    if (litF > 0.05 && this.lightGlows.size > 0) {
      const cands: { spr: THREE.Sprite; d: number; color: number }[] = [];
      for (const [id, spr] of this.lightGlows) {
        const mat = spr.material as THREE.SpriteMaterial;
        if (mat.opacity < 0.05) continue;
        cands.push({ spr, d: spr.position.distanceToSquared(this.camTarget), color: mat.color.getHex() });
      }
      cands.sort((a, b) => a.d - b.d);
      for (let i = 0; i < this.lightPool.length; i++) {
        const pl = this.lightPool[i];
        if (i >= poolN) { pl.visible = false; continue; }
        const c = cands[i];
        if (c && c.d < 45 * 45) {
          pl.position.copy(c.spr.position);
          pl.color.setHex(c.color);
          pl.intensity = 0.55 + litF * 0.75;
          pl.visible = true;
        } else {
          pl.visible = false;
        }
      }
    } else {
      for (const pl of this.lightPool) pl.visible = false;
    }
    // 星空与月亮
    const starO = Math.max(0, 1 - nightFactor * 1.6);
    (this.stars.material as THREE.PointsMaterial).opacity = starO * 0.85;
    this.stars.visible = starO > 0.03 && this.quality !== 'low';
    this.stars.position.set(this.camTarget.x, 0, this.camTarget.z);
    this.stars.rotation.y = this.time * 0.004;
    const mo = Math.max(0, 1 - nightFactor * 1.4);
    (this.moon.material as THREE.SpriteMaterial).opacity = mo;
    this.moon.visible = mo > 0.03;
    this.moon.position.set(this.camTarget.x - 110, 128, this.camTarget.z - 150);
    const nowNight = nightFactor < 0.2;
    if (nowNight !== this.wasNight) {
      this.wasNight = nowNight;
      this.cb.onSfx?.(nowNight ? 'night' : 'morning');
    }
    return nightFactor;
  }

  // ---------- 特效消费 ----------
  private consumeFx() {
    const fx = this.engine.pendingFx;
    while (fx.length > 0) {
      const f = fx.shift()!;
      if (f.kind === 'place') {
        if (f.buildingId! >= 0) {
          this.addBuildingMesh(f.buildingId!);
          const b = this.engine.buildings.get(f.buildingId!);
          if (b) {
            const [wx, wz] = this.tileToWorld(b.x, b.y);
            for (let i = 0; i < 6; i++) {
              this.spawnParticle(wx + (Math.random() - 0.5), this.heightAt(b.x, b.y) + 0.2, wz + (Math.random() - 0.5), {
                color: 0xc9b48a, life: 0.8, vx: (Math.random() - 0.5), vy: 0.8, vz: (Math.random() - 0.5), size: 0.3, grow: 0.4, opacity: 0.5,
              });
            }
            const d = BUILDING_DEFS[b.defId];
            this.cb.onSfx?.(d.road || d.pipe ? 'road' : 'place');
          }
        } else if (f.buildingId! <= -100) {
          this.updateTreeInstances();
        }
      } else if (f.kind === 'remove') {
        if (f.buildingId! >= 0) {
          this.removeBuildingMesh(f.buildingId!);
          this.cb.onSfx?.('demolish');
        } else {
          this.updateTreeInstances();
        }
      } else if (f.kind === 'complete') {
        const b = this.engine.buildings.get(f.buildingId!);
        this.removeBuildingMesh(f.buildingId!);
        if (b) {
          this.addBuildingMesh(b.id);
          this.refreshRoadOrientations();
          const [wx, wz] = this.tileToWorld(b.x + (b.size - 1) / 2, b.y + (b.size - 1) / 2);
          this.spawnFloatText(wx, this.heightAt(b.x, b.y) + 1.6 + b.size * 0.4, wz, `${BUILDING_DEFS[b.defId].name} 建成`, '#ffe28a');
          for (let i = 0; i < 10; i++) {
            this.spawnParticle(wx + (Math.random() - 0.5) * b.size, this.heightAt(b.x, b.y) + 0.3, wz + (Math.random() - 0.5) * b.size, {
              color: 0xf1e0a8, life: 1.1, vx: (Math.random() - 0.5) * 0.8, vy: 1 + Math.random(), vz: (Math.random() - 0.5) * 0.8, size: 0.22, grow: 0.3, opacity: 0.75,
            });
          }
          this.cb.onSfx?.('complete');
          this.rebuildWires();
        }
      } else if (f.kind === 'rotate') {
        const b = this.engine.buildings.get(f.buildingId!);
        const g = this.buildingGroups.get(f.buildingId!);
        if (b && g) g.rotation.y = (b.rot * Math.PI) / 2;
        this.cb.onSfx?.('click');
      } else if (f.kind === 'fire') {
        this.cb.onSfx?.('fire');
      } else if (f.kind === 'extinguish') {
        this.cb.onSfx?.('extinguish');
        const b = this.engine.buildings.get(f.buildingId!);
        if (b) {
          const [wx, wz] = this.tileToWorld(b.x, b.y);
          for (let i = 0; i < 8; i++) {
            this.spawnParticle(wx, this.heightAt(b.x, b.y) + 0.4, wz, {
              color: 0xdfe8ec, life: 1.2, vx: (Math.random() - 0.5) * 1.4, vy: 1.2, vz: (Math.random() - 0.5) * 1.4, size: 0.35, grow: 0.5, opacity: 0.5,
            });
          }
        }
      } else if (f.kind === 'nuke') {
        this.cb.onSfx?.('nuke');
        const b = this.engine.buildings.get(f.buildingId!);
        if (b) {
          const [wx, wz] = this.tileToWorld(b.x, b.y);
          for (let i = 0; i < 40; i++) {
            const a = Math.random() * Math.PI * 2;
            this.spawnParticle(wx, this.heightAt(b.x, b.y) + 0.5, wz, {
              color: 0x9ef01a, life: 2.2, vx: Math.cos(a) * (1 + Math.random() * 3), vy: 2 + Math.random() * 3, vz: Math.sin(a) * (1 + Math.random() * 3),
              size: 0.6, grow: 0.8, additive: true, opacity: 0.7,
            });
          }
        }
      } else if (f.kind === 'stormOn') {
        this.cb.onSfx?.('storm');
      } else if (f.kind === 'riotOn') {
        this.cb.onSfx?.('riot');
      } else if (f.kind === 'dig') {
        // 遗迹搜刮: 尘土特效 + 更新模型
        this.updateRuins();
        this.cb.onSfx?.('dig');
        if (f.tx != null && f.ty != null) {
          const [wx, wz] = this.tileToWorld(f.tx, f.ty);
          for (let i = 0; i < 10; i++) {
            this.spawnParticle(wx + (Math.random() - 0.5) * 0.6, this.heightAt(f.tx, f.ty) + 0.3, wz + (Math.random() - 0.5) * 0.6, {
              color: 0xb8a888, life: 1.1, vx: (Math.random() - 0.5) * 0.8, vy: 0.8 + Math.random() * 0.8, vz: (Math.random() - 0.5) * 0.8, size: 0.2, grow: 0.4, opacity: 0.6,
            });
          }
        }
      } else if (f.kind === 'network') {
        this.rebuildWires();
        if (this.viewMode === 'power' || this.viewMode === 'water') this.rebuildUtilView();
      } else if (f.kind === 'battle') {
        this.cb.onSfx?.(f.buildingId === -2 ? 'victory' : 'battle');
      } else if (f.kind === 'expedition') {
        this.cb.onSfx?.('march');
      }
    }
    this.rainPoints.visible = this.engine.stormDays > 0;
    if (this.rainPoints.visible) {
      this.rainPoints.position.set(this.camTarget.x, 0, this.camTarget.z);
    }
  }

  // ---------- 施工氛围 ----------
  private constructionAmbientTimer = 0;

  private updateConstructionAmbient(dt: number) {
    const sites: Building[] = [];
    for (const b of this.engine.buildings.values()) {
      if (b.progress < 1 && b.progress > 0.02) sites.push(b);
    }
    if (sites.length === 0) { this.constructionAmbientTimer = 0; return; }
    this.constructionAmbientTimer -= dt;
    if (this.constructionAmbientTimer > 0) return;
    this.constructionAmbientTimer = 0.8 + Math.random() * 1.2;
    const hear = Math.max(22, this.camDist * 1.7);
    const cands = sites.filter(b => {
      const [wx, wz] = this.tileToWorld(b.x, b.y);
      return Math.hypot(wx - this.camTarget.x, wz - this.camTarget.z) < hear;
    });
    if (cands.length === 0) return;
    const b = cands[Math.floor(Math.random() * cands.length)];
    const def = BUILDING_DEFS[b.defId];
    const wood = def.cost.wood ?? 0, stone = def.cost.stone ?? 0, metal = def.cost.metal ?? 0;
    const r = Math.random();
    let sfx: string;
    if (this.engine.era >= 2 && metal >= wood && metal >= stone) sfx = r < 0.5 ? 'drill' : 'hammer';
    else if (wood >= stone) sfx = r < 0.45 ? 'saw' : 'hammer';
    else sfx = 'hammer';
    this.cb.onSfx?.(sfx);
    const [wx, wz] = this.tileToWorld(b.x + (b.size - 1) / 2, b.y + (b.size - 1) / 2);
    for (let i = 0; i < 3; i++) {
      this.spawnParticle(
        wx + (Math.random() - 0.5) * b.size * 0.8,
        this.heightAt(b.x, b.y) + 0.25 + Math.random() * (0.6 + b.size * 0.5),
        wz + (Math.random() - 0.5) * b.size * 0.8,
        {
          color: 0xb8a888, life: 0.7 + Math.random() * 0.4,
          vx: (Math.random() - 0.5) * 0.5, vy: 0.3 + Math.random() * 0.4, vz: (Math.random() - 0.5) * 0.5,
          size: 0.16, grow: 0.5, opacity: 0.38,
        },
      );
    }
  }

  // ---------- 开荒任务 (派人砍树/采石/搜刮遗迹) ----------
  addChopTask(x: number, y: number): { ok: boolean; reason?: string } {
    const t = this.engine.terrain.peek(x, y);
    if (!t || !t.explored) return { ok: false, reason: '迷雾之外' };
    if (t.occupied) return { ok: false, reason: '此处有建筑' };
    const ruin = t.ruin >= 0 ? this.engine.terrain.ruins[t.ruin] : undefined;
    const isRuin = !!ruin && !ruin.scavenged;
    if (t.tree < 0 && !t.rock && !isRuin) return { ok: false, reason: '这里没有树木、石块或遗迹' };
    if (this.chopTasks.some(tk => tk.tileX === x && tk.tileY === y)) return { ok: false, reason: '已派人在路上' };

    const workSpots = this.getWorkSpots(x, y);
    if (workSpots.length === 0) {
      return { ok: false, reason: '目标周围被建筑或水域封住，公民无法靠近' };
    }

    // 至少验证一条从现有公民/出生点/住宅门口出发的真实路线，避免接受必然卡死的指令。
    const starts: CitizenPathPoint[] = this.citizens.map(c => ({ x: c.x, z: c.z }));
    const spawn = this.engine.terrain.spawn;
    starts.push({ x: spawn.x + 0.5, z: spawn.y + 0.5 });
    for (const b of this.engine.buildings.values()) {
      if (!BUILDING_DEFS[b.defId]?.housing) continue;
      const [doorX, doorZ] = this.tileToWorld(b.x + (b.size - 1) / 2, b.y + b.size);
      starts.push({ x: doorX, z: doorZ });
    }
    const reachable = starts
      .filter(st => this.isWalkableTile(Math.floor(st.x), Math.floor(st.z)))
      .sort((a, b) => Math.hypot(a.x - (x + 0.5), a.z - (y + 0.5)) - Math.hypot(b.x - (x + 0.5), b.z - (y + 0.5)))
      .slice(0, 8)
      .some(st => !!this.findPathToGoals(st.x, st.z, workSpots));
    if (starts.some(st => this.isWalkableTile(Math.floor(st.x), Math.floor(st.z))) && !reachable) {
      return { ok: false, reason: '目标与城镇之间没有可通行路线，请检查建筑是否堵住了道路' };
    }

    const [wx, wz] = this.tileToWorld(x, y);
    this.chopTasks.push({ tileX: x, tileY: y, wx, wz, isRock: t.rock && t.tree < 0, isRuin, retryIn: 0 });
    this.cb.onSfx?.('order');
    return { ok: true };
  }

  /** 资源点周围可站立的工作格。公民不会再把树/石头/遗迹中心当作落脚点。 */
  private getWorkSpots(tileX: number, tileY: number): { x: number; y: number }[] {
    const offsets = [[0, -1], [1, 0], [0, 1], [-1, 0], [1, -1], [1, 1], [-1, 1], [-1, -1]];
    const spots: { x: number; y: number }[] = [];
    for (const [dx, dy] of offsets) {
      const x = tileX + dx, y = tileY + dy;
      if (this.isWalkableTile(x, y)) spots.push({ x, y });
    }
    return spots;
  }

  /** 建筑、水域和未探索地块不可通行；道路建筑本身是可行走地面。 */
  private isWalkableTile(x: number, y: number): boolean {
    const t = this.engine.terrain.peek(x, y);
    if (!t || !t.explored) return false;
    if (t.occupied) {
      const building = t.buildingId >= 0 ? this.engine.buildings.get(t.buildingId) : undefined;
      // 木栈道是铺在水面上的道路，也必须允许公民通过。
      return !!building && !!BUILDING_DEFS[building.defId]?.road;
    }
    return t.terrain !== 'water';
  }

  /** A* 八方向寻路。对角移动禁止切过建筑/水域拐角，避免出现视觉穿墙。 */
  private findPathToGoals(startX: number, startZ: number, goals: { x: number; y: number }[]): CitizenPathResult | null {
    const sx = Math.floor(startX), sy = Math.floor(startZ);
    if (!this.isWalkableTile(sx, sy)) return null;
    const validGoals = goals.filter(g => this.isWalkableTile(g.x, g.y));
    if (validGoals.length === 0) return null;

    const keyOf = (x: number, y: number) => `${x},${y}`;
    const startKey = keyOf(sx, sy);
    const goalKeys = new Set(validGoals.map(g => keyOf(g.x, g.y)));
    const heuristic = (x: number, y: number) => {
      let best = Infinity;
      for (const goal of validGoals) {
        const dx = Math.abs(goal.x - x), dy = Math.abs(goal.y - y);
        const diagonal = Math.min(dx, dy);
        const distance = Math.max(dx, dy) + (Math.SQRT2 - 1) * diagonal;
        if (distance < best) best = distance;
      }
      return best;
    };

    type Node = { x: number; y: number; key: string; g: number; f: number };
    const heap: Node[] = [];
    const push = (node: Node) => {
      heap.push(node);
      let i = heap.length - 1;
      while (i > 0) {
        const parent = (i - 1) >> 1;
        if (heap[parent].f <= node.f) break;
        heap[i] = heap[parent]; i = parent;
      }
      heap[i] = node;
    };
    const pop = (): Node | undefined => {
      if (heap.length === 0) return undefined;
      const first = heap[0];
      const last = heap.pop()!;
      if (heap.length > 0) {
        let i = 0;
        while (true) {
          const left = i * 2 + 1, right = left + 1;
          if (left >= heap.length) break;
          let child = left;
          if (right < heap.length && heap[right].f < heap[left].f) child = right;
          if (heap[child].f >= last.f) break;
          heap[i] = heap[child]; i = child;
        }
        heap[i] = last;
      }
      return first;
    };

    const gScore = new Map<string, number>([[startKey, 0]]);
    const cameFrom = new Map<string, string>();
    push({ x: sx, y: sy, key: startKey, g: 0, f: heuristic(sx, sy) });
    const directions = [
      [0, -1, 1], [1, 0, 1], [0, 1, 1], [-1, 0, 1],
      [1, -1, Math.SQRT2], [1, 1, Math.SQRT2], [-1, 1, Math.SQRT2], [-1, -1, Math.SQRT2],
    ] as const;

    let visited = 0;
    let found: Node | null = null;
    while (heap.length > 0 && visited < 12000) {
      const current = pop()!;
      if (current.g !== gScore.get(current.key)) continue;
      visited++;
      if (goalKeys.has(current.key)) { found = current; break; }

      for (const [dx, dy, cost] of directions) {
        const nx = current.x + dx, ny = current.y + dy;
        if (!this.isWalkableTile(nx, ny)) continue;
        if (dx !== 0 && dy !== 0) {
          // 两侧正交格都必须畅通，禁止从建筑墙角斜穿。
          if (!this.isWalkableTile(current.x + dx, current.y) || !this.isWalkableTile(current.x, current.y + dy)) continue;
        }
        const nextKey = keyOf(nx, ny);
        const nextG = current.g + cost;
        if (nextG >= (gScore.get(nextKey) ?? Infinity)) continue;
        cameFrom.set(nextKey, current.key);
        gScore.set(nextKey, nextG);
        push({ x: nx, y: ny, key: nextKey, g: nextG, f: nextG + heuristic(nx, ny) });
      }
    }
    if (!found) return null;

    const path: CitizenPathPoint[] = [];
    let cursor = found.key;
    while (cursor !== startKey) {
      const [x, y] = cursor.split(',').map(Number);
      path.push({ x: x + 0.5, z: y + 0.5 });
      const previous = cameFrom.get(cursor);
      if (!previous) return null;
      cursor = previous;
    }
    path.reverse();
    if (path.length === 0) path.push({ x: found.x + 0.5, z: found.y + 0.5 });
    return { path, goalX: found.x, goalY: found.y, cost: found.g };
  }

  /** 老存档或建筑更新可能让居民出生/停在建筑格内；将其恢复到最近的可走地块。 */
  private normalizeCitizenPosition(c: CitizenAgent): boolean {
    const x = Math.floor(c.x), y = Math.floor(c.z);
    if (this.isWalkableTile(x, y)) return true;
    for (let radius = 1; radius <= 5; radius++) {
      let best: { x: number; y: number; d: number } | null = null;
      for (let dy = -radius; dy <= radius; dy++) {
        for (let dx = -radius; dx <= radius; dx++) {
          if (Math.max(Math.abs(dx), Math.abs(dy)) !== radius) continue;
          const tx = x + dx, ty = y + dy;
          if (!this.isWalkableTile(tx, ty)) continue;
          const d = dx * dx + dy * dy;
          if (!best || d < best.d) best = { x: tx, y: ty, d };
        }
      }
      if (best) {
        c.x = best.x + 0.5; c.z = best.y + 0.5;
        c.stuckTime = 0;
        return true;
      }
    }
    return false;
  }

  private planCitizenRoute(c: CitizenAgent, targetX: number, targetZ: number): boolean {
    if (!this.normalizeCitizenPosition(c)) return false;
    const gx = Math.floor(targetX), gy = Math.floor(targetZ);
    const result = this.findPathToGoals(c.x, c.z, [{ x: gx, y: gy }]);
    if (!result) return false;
    c.path = result.path;
    const last = c.path[c.path.length - 1];
    // 游荡点可带少量随机偏移，但末端仍必须留在同一个安全格内。
    if (last && Math.hypot(last.x - targetX, last.z - targetZ) > 0.06) {
      c.path.push({ x: targetX, z: targetZ });
    }
    c.pathIndex = 0;
    c.tx = targetX; c.tz = targetZ;
    c.stuckTime = 0;
    return true;
  }

  private releaseStuckCitizen(c: CitizenAgent) {
    if (c.task) {
      const order = this.chopTasks.find(t => t.tileX === c.task!.tileX && t.tileY === c.task!.tileY);
      if (order) order.retryIn = Math.max(order.retryIn, 1.25);
      c.task = null;
    }
    c.path = []; c.pathIndex = 0; c.stuckTime = 0;
    const wander = this.pickWanderPoint(c);
    if (!this.planCitizenRoute(c, wander[0], wander[1])) {
      c.tx = c.x; c.tz = c.z;
    }
  }

  private updateChopTasks(dt: number) {
    for (const order of this.chopTasks) order.retryIn = Math.max(0, order.retryIn - dt);

    for (const order of this.chopTasks) {
      if (this.citizens.some(c => c.task && c.task.tileX === order.tileX && c.task.tileY === order.tileY)) continue;
      if (order.retryIn > 0) continue;
      const workSpots = this.getWorkSpots(order.tileX, order.tileY);
      if (workSpots.length === 0) { order.retryIn = 2; continue; }

      // 选择“有路可走且路线最短”的闲置公民，而不是只看直线距离。
      let best: { citizen: CitizenAgent; route: CitizenPathResult } | null = null;
      const candidates = this.citizens.filter(c => !c.task)
        .sort((a, b) => Math.hypot(a.x - order.wx, a.z - order.wz) - Math.hypot(b.x - order.wx, b.z - order.wz))
        .slice(0, 8);
      for (const citizen of candidates) {
        if (!this.normalizeCitizenPosition(citizen)) continue;
        const route = this.findPathToGoals(citizen.x, citizen.z, workSpots);
        if (route && (!best || route.cost < best.route.cost)) best = { citizen, route };
      }
      if (!best) { order.retryIn = 1.2; continue; }

      const c = best.citizen;
      const workX = best.route.goalX + 0.5, workZ = best.route.goalY + 0.5;
      c.task = {
        tileX: order.tileX, tileY: order.tileY, wx: order.wx, wz: order.wz,
        workX, workZ, isRock: order.isRock, isRuin: order.isRuin,
      };
      c.path = best.route.path;
      c.pathIndex = 0;
      c.tx = workX; c.tz = workZ;
      c.stuckTime = 0;
    }

    for (let i = this.chopTasks.length - 1; i >= 0; i--) {
      const task = this.chopTasks[i];
      const tile = this.engine.terrain.peek(task.tileX, task.tileY);
      const ruin = tile && tile.ruin >= 0 ? this.engine.terrain.ruins[tile.ruin] : undefined;
      const resourceStillExists = !!tile && (task.isRuin
        ? !!ruin && !ruin.scavenged
        : task.isRock ? tile.rock : tile.tree >= 0);
      const worker = this.citizens.find(c => c.task && c.task.tileX === task.tileX && c.task.tileY === task.tileY);
      if (!resourceStillExists) {
        if (worker) { worker.task = null; worker.path = []; worker.pathIndex = 0; }
        this.chopTasks.splice(i, 1);
        continue;
      }
      if (!worker || !worker.task) continue;
      const d = Math.hypot(worker.x - worker.task.workX, worker.z - worker.task.workZ);
      if (d < 0.2) {
        if (task.isRuin) {
          this.engine.scavengeRuin(task.tileX, task.tileY, false);
          this.cb.onSfx?.('discover');
          this.spawnFloatText(task.wx, this.heightAt(task.tileX, task.tileY) + 1.25, task.wz, '遗迹搜刮!', '#a5f3fc');
        } else {
          const got = this.engine.chopAt(task.tileX, task.tileY);
          if (got.wood > 0) {
            this.engine.notify('info', '砍伐完成', `工人砍倒了树木, +${got.wood} 木材。`, 'good');
            this.cb.onSfx?.('chop');
            this.cb.onSfx?.('treefall');
            this.spawnFloatText(task.wx, this.heightAt(task.tileX, task.tileY) + 1.25, task.wz, `+${got.wood} 木材`, '#f0d9a8');
            for (let p = 0; p < 7; p++) {
              this.spawnParticle(task.wx + (Math.random() - 0.5) * 0.5, this.heightAt(task.tileX, task.tileY) + 0.5, task.wz + (Math.random() - 0.5) * 0.5, {
                color: 0x8a5a33, life: 0.9, vx: (Math.random() - 0.5) * 1.2, vy: 0.6 + Math.random(), vz: (Math.random() - 0.5) * 1.2, size: 0.22, grow: 0.3, opacity: 0.8,
              });
            }
          } else if (got.stone > 0) {
            this.engine.notify('info', '开采完成', `工人采下了石块, +${got.stone} 石料。`, 'good');
            this.cb.onSfx?.('mine');
            this.spawnFloatText(task.wx, this.heightAt(task.tileX, task.tileY) + 1.25, task.wz, `+${got.stone} 石料`, '#cfd8e3');
            for (let p = 0; p < 7; p++) {
              this.spawnParticle(task.wx + (Math.random() - 0.5) * 0.5, this.heightAt(task.tileX, task.tileY) + 0.4, task.wz + (Math.random() - 0.5) * 0.5, {
                color: 0x9aa3ab, life: 0.9, vx: (Math.random() - 0.5) * 1.2, vy: 0.5 + Math.random(), vz: (Math.random() - 0.5) * 1.2, size: 0.2, grow: 0.3, opacity: 0.8,
              });
            }
          }
        }
        worker.task = null;
        worker.path = []; worker.pathIndex = 0;
        const nc = this.pickWanderPoint(worker);
        if (!this.planCitizenRoute(worker, nc[0], nc[1])) { worker.tx = worker.x; worker.tz = worker.z; }
        this.chopTasks.splice(i, 1);
      }
    }

    for (let i = 0; i < this.taskMarkers.length; i++) {
      const mk = this.taskMarkers[i];
      if (i < this.chopTasks.length) {
        const t = this.chopTasks[i];
        mk.position.set(t.wx, this.heightAt(t.tileX, t.tileY) + 0.12, t.wz);
        const pulse = 1 + Math.sin(this.time * 5) * 0.15;
        mk.scale.setScalar(pulse);
        (mk.material as THREE.MeshBasicMaterial).color.setHex(t.isRuin ? 0x22d3ee : t.isRock ? 0x94a3b8 : 0xfbbf24);
        mk.visible = true;
      } else {
        mk.visible = false;
      }
    }
  }

  // ---------- 远征队 (v5: 每人独立模型 + 载具随行) ----------
  private updateExpeditionVisuals(dt: number) {
    const engine = this.engine;
    const alive = new Set<number>();
    for (const e of engine.expeditions) {
      alive.add(e.id);
      let party = this.parties.get(e.id);
      if (!party) {
        const g = new THREE.Group();
        const members: THREE.Group[] = [];
        const total = Math.min(8, Math.max(1, e.members));
        for (let i = 0; i < total; i++) {
          const { g: mg } = squadMemberModel(i, engine.weaponTier);
          mg.scale.setScalar(0.8);
          const ang = (i / total) * Math.PI * 2 + 0.4;
          const rr = total <= 1 ? 0 : 0.26;
          mg.position.set(Math.cos(ang) * rr, 0, Math.sin(ang) * rr);
          mg.rotation.y = -ang + Math.PI / 2;
          mg.traverse(o => { const m = o as THREE.Mesh; if (m.isMesh) m.castShadow = true; });
          g.add(mg);
          members.push(mg);
        }
        // 随队载具 (两翼护航)
        const vehicles: THREE.Group[] = [];
        let vi = 0;
        for (const kind of ['apc', 'tank', 'heli'] as const) {
          for (let i = 0; i < (e.vehicles[kind] ?? 0); i++) {
            const { g: vg } = battleUnitModel(kind);
            vg.scale.setScalar(0.82);
            const side = vi % 2 === 0 ? 1 : -1;
            vg.position.set(side * (0.6 + Math.floor(vi / 2) * 0.55), 0, (vi % 3 - 1) * 0.25);
            vg.rotation.y = 0.35 * side;
            vg.traverse(o => { const m = o as THREE.Mesh; if (m.isMesh) m.castShadow = true; });
            g.add(vg);
            vehicles.push(vg);
            vi++;
          }
        }
        // 队旗
        const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.012, 0.012, 0.66, 4), mat(0x6b4423));
        pole.position.set(0.02, 0.33, 0);
        g.add(pole);
        const cloth = new THREE.Mesh(new THREE.PlaneGeometry(0.26, 0.16), new THREE.MeshBasicMaterial({ color: 0xf59e0b, side: THREE.DoubleSide }));
        cloth.position.set(0.15, 0.56, 0);
        g.add(cloth);
        this.scene.add(g);
        party = { group: g, members, vehicles, lastX: e.x, lastZ: e.y };
        this.parties.set(e.id, party);
      }
      // 同步队员数量 (战斗减员)
      const wantM = Math.min(8, Math.max(0, e.members));
      party.members.forEach((m, i) => { m.visible = i < wantM; });
      // 位置与行走动画
      const h = this.heightAt(Math.floor(e.x), Math.floor(e.y));
      party.group.position.set(e.x, h, e.y);
      const dx = e.x - party.lastX, dz = e.y - party.lastZ;
      if (Math.abs(dx) + Math.abs(dz) > 0.0005) {
        party.group.rotation.y = Math.atan2(dx, dz);
        party.lastX = e.x; party.lastZ = e.y;
      }
      const bob = Math.sin(this.time * 9) * 0.025;
      party.group.position.y = h + Math.abs(bob);
      party.members.forEach((m, i) => { m.position.y = Math.abs(Math.sin(this.time * 9 + i * 1.4)) * 0.035; });
      // 直升机旋翼旋转
      for (const v of party.vehicles) {
        const rotor = v.getObjectByName('rotor');
        if (rotor) rotor.rotation.y += dt * 16;
      }
      // 目标旗
      let marker = this.expMarkers.get(e.id);
      if (!marker) {
        const mk = new THREE.Group();
        const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.016, 0.02, 0.8, 4), mat(0x6b4423));
        pole.position.y = 0.4;
        mk.add(pole);
        const cloth = new THREE.Mesh(new THREE.PlaneGeometry(0.3, 0.19), new THREE.MeshBasicMaterial({ color: 0x22d3ee, side: THREE.DoubleSide }));
        cloth.position.set(0.15, 0.66, 0);
        mk.add(cloth);
        this.scene.add(mk);
        marker = mk;
        this.expMarkers.set(e.id, mk);
      }
      const mh = this.heightAt(e.tx, e.ty);
      marker.position.set(e.tx + 0.5, mh, e.ty + 0.5);
      marker.children[1].rotation.y = Math.sin(this.time * 2.2) * 0.25;
    }
    // 清理已结束的远征
    for (const [id, party] of this.parties) {
      if (!alive.has(id)) {
        this.scene.remove(party.group);
        this.disposeGroup(party.group);
        this.parties.delete(id);
      }
    }
    for (const [id, marker] of this.expMarkers) {
      if (!alive.has(id)) {
        this.scene.remove(marker);
        this.disposeGroup(marker);
        this.expMarkers.delete(id);
      }
    }
    void dt;
  }

  // ---------- v5: 地图内战斗层 ----------
  /** 战斗单位头顶世界坐标 → 屏幕像素 (BattlePanel 血条/飘字用) */
  battleProject(uid: string): { x: number; y: number; visible: boolean } {
    const v = this.battleUnits.get(uid);
    if (!v) return { x: 0, y: 0, visible: false };
    const p = new THREE.Vector3(v.base.x, v.base.y + v.headY + 0.18, v.base.z).project(this.camera);
    const w = this.canvas.clientWidth, h = this.canvas.clientHeight;
    return { x: (p.x * 0.5 + 0.5) * w, y: (-p.y * 0.5 + 0.5) * h, visible: p.z < 1 };
  }

  private clearBattleScene() {
    for (const [, v] of this.battleUnits) {
      this.battleLayer.remove(v.group);
      this.battleLayer.remove(v.ring);
      this.battleLayer.remove(v.shield);
      this.disposeGroup(v.group);
    }
    this.battleUnits.clear();
    for (const p of this.battleProjectiles) {
      this.battleFxLayer.remove(p.mesh);
      p.mesh.geometry.dispose();
      (p.mesh.material as THREE.Material).dispose();
    }
    this.battleProjectiles = [];
    this.battleJobs = [];
    while (this.battleFxLayer.children.length > 0) {
      const c = this.battleFxLayer.children[0];
      this.battleFxLayer.remove(c);
    }
  }

  private buildBattleUnits(b: BattleState) {
    const [cx, cz] = this.tileToWorld(b.pos.x, b.pos.y);
    const ang = Math.random() * Math.PI * 2;
    const cosA = Math.cos(ang), sinA = Math.sin(ang);
    const playerYaw = Math.atan2(cosA, -sinA);
    const place = (units: BattleUnit[], side: 'player' | 'enemy') => {
      const n = units.length;
      units.forEach((u, i) => {
        const { g, headY } = battleUnitModel(u.kind);
        const lx = (side === 'player' ? -1 : 1) * (2.05 + (i % 2) * 0.55);
        const lz = n === 1 ? 0 : (i - (n - 1) / 2) * 1.08;
        const wx = cx + lx * cosA + lz * sinA;
        const wz = cz - lx * sinA + lz * cosA;
        const h = this.heightAt(Math.floor(wx), Math.floor(wz));
        g.position.set(wx, h, wz);
        g.rotation.y = side === 'player' ? playerYaw : playerYaw + Math.PI;
        this.battleLayer.add(g);
        // 行动光环
        const ring = new THREE.Mesh(
          new THREE.RingGeometry(0.3, 0.42, 26),
          new THREE.MeshBasicMaterial({ color: side === 'player' ? 0xfbbf24 : 0xef4444, transparent: true, opacity: 0.85, side: THREE.DoubleSide, depthWrite: false }),
        );
        ring.rotation.x = -Math.PI / 2;
        ring.position.set(wx, h + 0.05, wz);
        ring.visible = false;
        ring.renderOrder = 7;
        this.battleLayer.add(ring);
        // 格挡盾
        const shield = new THREE.Mesh(
          new THREE.CircleGeometry(0.32, 18),
          new THREE.MeshBasicMaterial({ color: 0x38bdf8, transparent: true, opacity: 0.4, side: THREE.DoubleSide, depthWrite: false }),
        );
        shield.visible = false;
        shield.rotation.y = g.rotation.y;
        shield.position.set(wx, h + 0.45, wz);
        shield.translateX(side === 'player' ? 0.3 : -0.3);
        this.battleLayer.add(shield);
        this.battleUnits.set(u.uid, {
          uid: u.uid, group: g, base: g.position.clone(), headY, side, ring, shield,
          alive: u.alive, fallen: false, kind: u.kind,
        });
      });
    };
    place(b.units.filter(u => u.side === 'player'), 'player');
    place(b.units.filter(u => u.side === 'enemy'), 'enemy');
  }

  private battleFireEvent(ev: BattleEvent) {
    const actor = this.battleUnits.get(ev.actorUid);
    const target = ev.targetUid ? this.battleUnits.get(ev.targetUid) : null;
    switch (ev.type) {
      case 'attack': {
        if (actor && target) {
          const ranged = ['spear', 'rock', 'volley', 'shell', 'missile'].includes(ev.moveId);
          if (ranged) {
            this.spawnBattleProjectile(actor, target, !!ev.crit, ev.moveId === 'shell' || ev.moveId === 'missile');
          } else {
            this.battleJobs.push({ type: 'lunge', uid: ev.actorUid, to: target.base.clone(), t: 0, dur: 0.5, crit: ev.crit });
          }
        }
        break;
      }
      case 'miss':
        if (target) this.battleJobs.push({ type: 'dodge', uid: ev.targetUid!, t: 0, dur: 0.4 });
        break;
      case 'guard':
        if (actor) {
          actor.shield.visible = true;
          this.battleJobs.push({ type: 'guard', uid: ev.actorUid, t: 0, dur: 0.5 });
        }
        break;
      case 'death':
        if (target && !target.fallen) {
          target.fallen = true;
          this.battleJobs.push({ type: 'death', uid: ev.targetUid!, t: 0, dur: 0.55 });
        }
        break;
      case 'flee': break;
    }
  }

  private spawnBattleProjectile(actor: { base: THREE.Vector3; headY: number }, target: { base: THREE.Vector3; headY: number; uid: string }, crit: boolean, big: boolean) {
    const geo = big ? new THREE.SphereGeometry(0.1, 8, 8) : new THREE.SphereGeometry(0.055, 8, 8);
    const mesh = new THREE.Mesh(geo, new THREE.MeshBasicMaterial({ color: big ? 0xffa94d : 0xd8dce0 }));
    const from = actor.base.clone(); from.y = actor.base.y + actor.headY * 0.8;
    const to = target.base.clone(); to.y = target.base.y + target.headY * 0.7;
    mesh.position.copy(from);
    this.battleFxLayer.add(mesh);
    this.battleProjectiles.push({ mesh, from, to, t: 0, dur: 0.34, targetUid: target.uid, crit });
  }

  private battleImpact(uid: string, crit: boolean) {
    const v = this.battleUnits.get(uid);
    if (!v) return;
    // 受击闪光
    const spr = new THREE.Sprite(new THREE.SpriteMaterial({
      map: this.dotTex, transparent: true, opacity: 0.95, blending: THREE.AdditiveBlending, depthWrite: false,
      color: crit ? 0xffca6b : 0xfff2d9,
    }));
    spr.position.set(v.base.x, v.base.y + v.headY * 0.72, v.base.z);
    spr.scale.setScalar(crit ? 1.6 : 1.0);
    this.battleFxLayer.add(spr);
    this.battleJobs.push({ type: 'shake', uid, t: 0, dur: crit ? 0.42 : 0.28, crit });
    if (crit) this.camShake = 0.3;
    this.cb.onSfx?.(crit ? 'crit' : 'hit');
  }

  private tickBattleCam(dt: number) {
    const c = this.battleCam;
    if (!c) return;
    c.t += dt;
    const k = Math.min(1, c.t / c.dur);
    const e = k < 0.5 ? 4 * k * k * k : 1 - Math.pow(-2 * k + 2, 3) / 2;
    this.camTarget.x = c.fromX + (c.toX - c.fromX) * e;
    this.camTarget.z = c.fromZ + (c.toZ - c.fromZ) * e;
    this.camDist = c.fromDist + (c.toDist - c.fromDist) * e;
    if (k >= 1) this.battleCam = null;
  }

  private tickBattleAnims(dt: number) {
    // 动作任务 (冲撞/闪避/震颤/倒地/格挡)
    for (let i = this.battleJobs.length - 1; i >= 0; i--) {
      const j = this.battleJobs[i];
      const v = this.battleUnits.get(j.uid);
      j.t += dt;
      const p = Math.min(1, j.t / j.dur);
      if (v) {
        const isHeli = v.kind === 'heli';
        const baseY = isHeli ? v.base.y + 0.55 : v.base.y;
        switch (j.type) {
          case 'lunge': {
            const dir = (j.to as THREE.Vector3).clone().sub(v.base);
            dir.y = 0;
            const reach = Math.max(0.1, dir.length() - 0.95);
            dir.normalize();
            const k = Math.sin(Math.PI * p);
            v.group.position.copy(v.base).addScaledVector(dir, reach * k * 0.95);
            v.group.position.y = baseY + Math.abs(Math.sin(p * Math.PI * 2)) * 0.12;
            v.group.rotation.z = -0.22 * k * (v.side === 'player' ? 1 : -1);
            if (p >= 0.5 && !j.hit) {
              j.hit = true;
              const tv = j.to ? [...this.battleUnits.entries()].find(([, x]) => Math.abs(x.base.x - (j.to as THREE.Vector3).x) < 0.05 && Math.abs(x.base.z - (j.to as THREE.Vector3).z) < 0.05) : null;
              if (tv) this.battleImpact(tv[0], !!j.crit);
            }
            break;
          }
          case 'dodge': {
            const k = Math.sin(Math.PI * p);
            v.group.position.copy(v.base);
            v.group.position.x += k * 0.5 * Math.cos(v.group.rotation.y + Math.PI / 2);
            v.group.position.z += k * 0.5 * -Math.sin(v.group.rotation.y + Math.PI / 2);
            break;
          }
          case 'shake': {
            const decay = 1 - p;
            v.group.position.copy(v.base);
            if (v.kind === 'heli') v.group.position.y = v.base.y + 0.55;
            v.group.position.x += (Math.random() - 0.5) * 0.1 * decay * 2;
            v.group.position.z += (Math.random() - 0.5) * 0.1 * decay * 2;
            break;
          }
          case 'death': {
            const fall = (-Math.PI / 2) * Math.min(1, p * 1.6);
            v.group.rotation.z = v.side === 'player' ? fall : -fall;
            v.group.position.y = baseY - 0.1 * Math.min(1, p * 1.6);
            if (p >= 1) v.ring.visible = false;
            break;
          }
          case 'guard': {
            const k = Math.sin(Math.PI * p);
            v.group.position.copy(v.base);
            v.group.position.y = baseY + k * 0.06;
            v.shield.scale.setScalar(1 + k * 0.25);
            break;
          }
        }
        if (p >= 1) {
          if (j.type === 'lunge') { v.group.position.copy(v.base); if (isHeli) v.group.position.y = v.base.y + 0.55; v.group.rotation.z = 0; }
          if (j.type === 'dodge' || j.type === 'shake') { v.group.position.copy(v.base); if (isHeli) v.group.position.y = v.base.y + 0.55; }
          if (j.type === 'guard') { v.group.position.copy(v.base); if (isHeli) v.group.position.y = v.base.y + 0.55; v.shield.scale.setScalar(1); }
        }
      }
      if (p >= 1) this.battleJobs.splice(i, 1);
    }
    // 投射物
    for (let i = this.battleProjectiles.length - 1; i >= 0; i--) {
      const pr = this.battleProjectiles[i];
      pr.t += dt;
      const p = Math.min(1, pr.t / pr.dur);
      pr.mesh.position.lerpVectors(pr.from, pr.to, p);
      pr.mesh.position.y += Math.sin(p * Math.PI) * 0.5;
      if (p >= 1) {
        this.battleFxLayer.remove(pr.mesh);
        pr.mesh.geometry.dispose();
        (pr.mesh.material as THREE.Material).dispose();
        this.battleImpact(pr.targetUid, pr.crit);
        this.battleProjectiles.splice(i, 1);
      }
    }
    // 闪光衰减
    for (let i = this.battleFxLayer.children.length - 1; i >= 0; i--) {
      const c = this.battleFxLayer.children[i];
      if ((c as THREE.Sprite).isSprite) {
        const sm = (c as THREE.Sprite).material as THREE.SpriteMaterial;
        sm.opacity -= dt * 3.2;
        c.scale.multiplyScalar(1 + dt * 1.8);
        if (sm.opacity <= 0) {
          this.battleFxLayer.remove(c);
          sm.dispose();
        }
      }
    }
    // 行动者光环呼吸 + 空闲浮动
    for (const v of this.battleUnits.values()) {
      if (v.ring.visible) v.ring.scale.setScalar(1 + Math.sin(this.time * 5) * 0.1);
      if (v.shield.visible && !v.fallen) v.shield.rotation.z = this.time * 1.2;
      if (v.alive && !v.fallen && v.kind === 'heli' && !this.battleJobs.some(j => j.uid === v.uid)) {
        v.group.position.y = v.base.y + 0.55 + Math.sin(this.time * 2.2) * 0.06;
      }
    }
    // 直升机旋翼
    for (const v of this.battleUnits.values()) {
      if (v.kind === 'heli') {
        const rotor = v.group.getObjectByName('rotor');
        if (rotor) rotor.rotation.y += dt * 18;
      }
    }
  }

  /** 每帧驱动: 战斗布阵/事件/镜头 (在主循环调用) */
  private updateBattleScene(dt: number) {
    const b = this.engine.battle;
    if (!b) {
      if (this.battleId !== -1) {
        this.clearBattleScene();
        // 镜头缓缓回到城市
        if (this.battleReturnCam) {
          this.battleCam = {
            t: 0, dur: 1.5,
            fromX: this.camTarget.x, fromZ: this.camTarget.z,
            toX: this.battleReturnCam.x, toZ: this.battleReturnCam.z,
            fromDist: this.camDist, toDist: this.battleReturnCam.dist,
          };
          this.battleReturnCam = null;
        }
        this.battleId = -1;
      }
      this.tickBattleCam(dt);
      this.tickBattleAnims(dt);
      return;
    }
    if (b.id !== this.battleId) {
      // 新战斗: 敌人实地刷新 + 镜头缓缓飞抵
      this.clearBattleScene();
      this.buildBattleUnits(b);
      this.battleSeenEvents.clear();
      this.battleId = b.id;
      if (!this.battleReturnCam) {
        this.battleReturnCam = { x: this.camTarget.x, z: this.camTarget.z, dist: this.camDist };
      }
      const [cx, cz] = this.tileToWorld(b.pos.x, b.pos.y);
      this.battleCam = {
        t: 0, dur: 2.0,
        fromX: this.camTarget.x, fromZ: this.camTarget.z, toX: cx, toZ: cz,
        fromDist: this.camDist, toDist: Math.max(7.5, Math.min(14, 6.5 + b.units.length * 0.8)),
      };
      this.camShake = 0.22;
    }
    // 事件演出 (攻击/闪避/格挡/倒地)
    for (const ev of b.events) {
      if (this.battleSeenEvents.has(ev.key)) continue;
      this.battleSeenEvents.add(ev.key);
      this.battleFireEvent(ev);
      if (ev.type === 'attack') this.cb.onSfx?.('slash');
      else if (ev.type === 'miss') this.cb.onSfx?.('miss');
      else if (ev.type === 'guard') this.cb.onSfx?.('guard');
    }
    // 同步存活/行动者/格挡
    for (const u of b.units) {
      const v = this.battleUnits.get(u.uid);
      if (!v) continue;
      if (!u.alive && !v.fallen) {
        v.fallen = true;
        this.battleJobs.push({ type: 'death', uid: u.uid, t: 0, dur: 0.55 });
      }
      v.ring.visible = u.alive && u.uid === b.activeUid && !v.fallen;
      v.shield.visible = u.guarding && u.alive;
      v.alive = u.alive;
    }
    this.tickBattleCam(dt);
    this.tickBattleAnims(dt);
  }

  // ---------- 居民 ----------
  private updateCitizens(dt: number) {
    const pop = this.engine.pop;
    const hour = this.engine.hour;
    const isNight = hour < 6 || hour >= 20;
    const riot = this.engine.riotDays > 0;
    const idle = Math.max(0, this.engine.availableWorkers - this.engine.workersEmployed);
    let target = Math.min(22, idle) + Math.min(4, Math.floor(pop / 30));
    if (isNight) target = Math.max(2, Math.floor(target * 0.35));
    if (pop < 1) target = 0;
    if (this.chopTasks.length > 0) target = Math.max(target, this.chopTasks.length + 1);
    while (this.citizens.length < target) this.citizens.push(this.newCitizen());
    while (this.citizens.length > target) {
      const idx = this.citizens.findIndex(c => !c.task);
      if (idx >= 0) this.citizens.splice(idx, 1); else this.citizens.pop();
    }

    const mtx = new THREE.Matrix4();
    const q = new THREE.Quaternion();
    const col = new THREE.Color();
    this.bodyMesh.count = this.citizens.length;
    this.headMesh.count = this.citizens.length;
    const t = this.time;
    for (let i = 0; i < this.citizens.length; i++) {
      const c = this.citizens[i];
      this.normalizeCitizenPosition(c);

      // 路径由格子中心组成；逐个走完路点，不再直接朝目标穿过建筑。
      while (c.pathIndex < c.path.length) {
        const wp = c.path[c.pathIndex];
        if (Math.hypot(wp.x - c.x, wp.z - c.z) > 0.13) break;
        c.pathIndex++;
      }
      const beforeX = c.x, beforeZ = c.z;
      if (c.pathIndex < c.path.length) {
        const wp = c.path[c.pathIndex];
        const dx = wp.x - c.x, dz = wp.z - c.z;
        const d = Math.hypot(dx, dz);
        if (d > 0.001) {
          const speed = c.task ? c.speed * 1.45 : c.speed;
          const step = Math.min(d, speed * dt);
          const nx = c.x + dx / d * step;
          const nz = c.z + dz / d * step;
          if (!this.tileBlocked(nx, nz)) {
            c.x = nx; c.z = nz;
          }
        }
      }
      const moved = Math.hypot(c.x - beforeX, c.z - beforeZ);
      const remaining = c.pathIndex < c.path.length
        ? Math.hypot(c.path[c.pathIndex].x - c.x, c.path[c.pathIndex].z - c.z)
        : Math.hypot(c.tx - c.x, c.tz - c.z);
      if (remaining > 0.2 && moved < 0.001) c.stuckTime += dt;
      else c.stuckTime = 0;

      // 动态建筑/地形变化挡住原路线时重新寻路；连续失败则释放任务，让任务队列重新派人。
      if (c.stuckTime > 0.65) {
        c.stuckTime = 0;
        if (!this.planCitizenRoute(c, c.tx, c.tz)) this.releaseStuckCitizen(c);
      }

      if (!c.task && c.pathIndex >= c.path.length && Math.hypot(c.tx - c.x, c.tz - c.z) < 0.18) {
        const nc = this.pickWanderPoint(c);
        if (!this.planCitizenRoute(c, nc[0], nc[1])) { c.tx = c.x; c.tz = c.z; }
      }

      const tile = this.tileAtWorld(c.x, c.z);
      const h = tile && tile.explored ? this.heightAt(tile.x, tile.y) : 0.05;
      const bob = Math.abs(Math.sin(t * 9 * c.speed + c.phase)) * 0.035;
      const ang = Math.atan2(c.tx - c.x, c.tz - c.z);
      q.setFromAxisAngle(new THREE.Vector3(0, 1, 0), ang);
      mtx.compose(new THREE.Vector3(c.x, h + bob, c.z), q, new THREE.Vector3(1, 1, 1));
      this.bodyMesh.setMatrixAt(i, mtx);
      this.headMesh.setMatrixAt(i, mtx);
      if (riot && i % 3 === 0) col.setHex(0xd62828);
      else col.setHSL(c.hue, 0.55, 0.5);
      this.bodyMesh.setColorAt(i, col);
    }
    this.bodyMesh.instanceMatrix.needsUpdate = true;
    this.headMesh.instanceMatrix.needsUpdate = true;
    if (this.bodyMesh.instanceColor) this.bodyMesh.instanceColor.needsUpdate = true;
  }

  private newCitizen(): CitizenAgent {
    const spawns = [...this.engine.buildings.values()].filter(b => BUILDING_DEFS[b.defId]?.housing);
    let sx: number, sz: number;
    if (spawns.length > 0) {
      const h = spawns[Math.floor(Math.random() * spawns.length)];
      const size = BUILDING_DEFS[h.defId].size;
      const [wx, wz] = this.tileToWorld(h.x + (size - 1) / 2, h.y + size);
      [sx, sz] = this.freeWanderPoint(wx, wz + 0.15, 0.3);
    } else {
      const s = this.engine.terrain.spawn;
      const [wx, wz] = this.tileToWorld(s.x, s.y);
      [sx, sz] = this.freeWanderPoint(wx, wz, 0.6);
    }
    const citizen: CitizenAgent = {
      x: sx + (Math.random() - 0.5) * 0.2, z: sz + (Math.random() - 0.5) * 0.2,
      tx: sx, tz: sz,
      speed: 0.38 + Math.random() * 0.3, phase: Math.random() * 10,
      hue: (Math.random() * 0.95 + 0.03) % 1,
      path: [], pathIndex: 0, stuckTime: 0,
      task: null, working: false,
    };
    const p = this.pickWanderPoint(citizen);
    this.planCitizenRoute(citizen, p[0], p[1]);
    return citizen;
  }

  /** 兼容原有调用点：true 表示建筑/水域/迷雾阻挡。 */
  private tileBlocked(wx: number, wz: number): boolean {
    return !this.isWalkableTile(Math.floor(wx), Math.floor(wz));
  }

  /** 尝试取一个安全游荡点；随机候选被挡住时，逐圈找最近可走格。 */
  private freeWanderPoint(wx: number, wz: number, jitter = 0.7): [number, number] {
    if (!this.tileBlocked(wx, wz)) return [wx, wz];
    const ring = [[1, 0], [-1, 0], [0, 1], [0, -1], [0.7, 0.7], [-0.7, 0.7], [0.7, -0.7], [-0.7, -0.7]] as const;
    for (const [dx, dz] of ring) {
      if (!this.tileBlocked(wx + dx, wz + dz)) return [Math.floor(wx + dx) + 0.5, Math.floor(wz + dz) + 0.5];
    }
    for (let radius = 2; radius <= 5; radius++) {
      let best: { x: number; y: number; d: number } | null = null;
      const cx = Math.floor(wx), cy = Math.floor(wz);
      for (let dy = -radius; dy <= radius; dy++) for (let dx = -radius; dx <= radius; dx++) {
        if (Math.max(Math.abs(dx), Math.abs(dy)) !== radius || !this.isWalkableTile(cx + dx, cy + dy)) continue;
        const d = dx * dx + dy * dy;
        if (!best || d < best.d) best = { x: cx + dx, y: cy + dy, d };
      }
      if (best) return [best.x + 0.5, best.y + 0.5];
    }
    return [wx + (Math.random() - 0.5) * jitter * 2, wz + (Math.random() - 0.5) * jitter * 2];
  }

  private pickWanderPoint(c: CitizenAgent | null): [number, number] {
    const hour = this.engine.hour;
    const isNight = hour < 6 || hour >= 20;
    if (isNight && this.buildingGroups.size > 0) {
      const housings = [...this.engine.buildings.values()].filter(b => BUILDING_DEFS[b.defId]?.housing);
      if (housings.length > 0) {
        const h = housings[Math.floor(Math.random() * housings.length)];
        const size = BUILDING_DEFS[h.defId].size;
        const [wx, wz] = this.tileToWorld(h.x + (size - 1) / 2, h.y + size);
        return this.freeWanderPoint(wx, wz + (Math.random() - 0.5) * 0.3, 0.4);
      }
    }
    if (this.roadTiles.length > 0 && Math.random() < 0.6) {
      const r = this.roadTiles[Math.floor(Math.random() * this.roadTiles.length)];
      const [wx, wz] = this.tileToWorld(r.x, r.y);
      return this.freeWanderPoint(wx + (Math.random() - 0.5) * 0.35, wz + (Math.random() - 0.5) * 0.35);
    }
    const all = [...this.engine.buildings.values()];
    if (all.length > 0) {
      const b = all[Math.floor(Math.random() * all.length)];
      const size = BUILDING_DEFS[b.defId].size;
      const [wx, wz] = this.tileToWorld(b.x + (size - 1) / 2, b.y + size);
      return this.freeWanderPoint(wx + (Math.random() - 0.5) * 0.7, wz + (Math.random() - 0.5) * 0.5);
    }
    const s = this.engine.terrain.spawn;
    const [wx, wz] = this.tileToWorld(s.x, s.y);
    return this.freeWanderPoint(wx + (Math.random() - 0.5) * 2, wz + (Math.random() - 0.5) * 2);
  }

  // ---------- 车辆 ----------
  private hornTimer = 8 + Math.random() * 14;

  private updateCars(dt: number) {
    const era = this.engine.era;
    if (era < 1 || this.roadTiles.length < 3) {
      this.carMesh.count = 0; this.cartMesh.count = 0;
      this.cars.length = 0;
      return;
    }
    let cartTarget = 0, carTarget = 0;
    if (era === 1) { cartTarget = Math.min(10, Math.floor(this.roadTiles.length / 6) + 1); }
    else if (era === 2) { cartTarget = Math.min(14, Math.floor(this.roadTiles.length / 5) + 2); }
    else if (era === 3) { cartTarget = Math.min(6, Math.floor(this.roadTiles.length / 12)); carTarget = Math.min(28, Math.floor(this.roadTiles.length / 3) + 2); }
    else { cartTarget = 2; carTarget = Math.min(38, Math.floor(this.roadTiles.length / 2) + 4); }
    if (this.engine.research.includes('automotive')) carTarget = Math.min(40, carTarget + 6);

    const total = cartTarget + carTarget;
    while (this.cars.length < total) {
      const kind: 0 | 1 = this.cars.length < cartTarget ? 0 : 1;
      const c = this.newCar(kind);
      if (!c) break;
      this.cars.push(c);
    }
    while (this.cars.length > total) this.cars.pop();

    const mtx = new THREE.Matrix4();
    const q = new THREE.Quaternion();
    let ci = 0, ki = 0;
    for (const c of this.cars) {
      const dx = c.tx - c.x, dz = c.tz - c.z;
      const d = Math.hypot(dx, dz);
      if (d < 0.1) {
        const nc = this.nextRoadTile(c);
        if (nc) { c.tx = nc[0]; c.tz = nc[1]; }
        else { const rc = this.newCar(c.kind); if (rc) { c.x = rc.x; c.z = rc.z; c.tx = rc.tx; c.tz = rc.tz; } }
      } else {
        c.x += (dx / d) * c.speed * dt;
        c.z += (dz / d) * c.speed * dt;
      }
      const ndx = d > 0.001 ? dx / d : 0, ndz = d > 0.001 ? dz / d : 1;
      const laneOff = c.kind === 0 ? 0.14 : 0.17;
      const ox = -ndz * laneOff, oz = ndx * laneOff;
      const tile = this.tileAtWorld(c.x + ox, c.z + oz);
      const h = tile && tile.explored ? this.heightAt(tile.x, tile.y) : 0.06;
      const ang = Math.atan2(dx, dz);
      q.setFromAxisAngle(new THREE.Vector3(0, 1, 0), ang);
      mtx.compose(new THREE.Vector3(c.x + ox, h + 0.02, c.z + oz), q, new THREE.Vector3(1, 1, 1));
      if (c.kind === 0) this.cartMesh.setMatrixAt(ci++, mtx);
      else this.carMesh.setMatrixAt(ki++, mtx);
    }
    this.cartMesh.count = ci;
    this.carMesh.count = ki;
    this.cartMesh.instanceMatrix.needsUpdate = true;
    this.carMesh.instanceMatrix.needsUpdate = true;

    if (era >= 3 && ki > 0) {
      this.hornTimer -= dt;
      if (this.hornTimer <= 0) {
        this.hornTimer = 14 + Math.random() * 26;
        const near = this.cars.some(c =>
          c.kind === 1 && Math.hypot(c.x - this.camTarget.x, c.z - this.camTarget.z) < Math.max(18, this.camDist * 1.2));
        if (near) this.cb.onSfx?.('horn');
      }
    }
  }

  private newCar(kind: 0 | 1): CarAgent | null {
    if (this.roadTiles.length === 0) return null;
    const r = this.roadTiles[Math.floor(Math.random() * this.roadTiles.length)];
    const [wx, wz] = this.tileToWorld(r.x, r.y);
    const n = this.nextRoadTile({ x: wx, z: wz });
    const speed = kind === 0 ? 0.6 + Math.random() * 0.25
      : this.engine.era >= 4 ? 1.9 + Math.random() * 0.8 : 1.5 + Math.random() * 0.6;
    return { x: wx, z: wz, tx: n ? n[0] : wx, tz: n ? n[1] : wz, speed, kind };
  }

  private nextRoadTile(c: { x: number; z: number }): [number, number] | null {
    const [cx, cy] = this.worldToTile(c.x, c.z);
    const dirs = [[1, 0], [-1, 0], [0, 1], [0, -1]];
    const options: [number, number][] = [];
    for (const [dx, dy] of dirs) {
      const x = cx + dx, y = cy + dy;
      const t = this.engine.terrain.peek(x, y);
      if (t && t.buildingId >= 0 && BUILDING_DEFS[this.engine.buildings.get(t.buildingId)!.defId]?.road) {
        const [wx, wz] = this.tileToWorld(x, y);
        options.push([wx, wz]);
      }
    }
    if (options.length === 0) return null;
    return options[Math.floor(Math.random() * options.length)];
  }

  // ---------- 每帧动画装饰 ----------
  private animateDecorations(dt: number) {
    const t = this.time;
    for (const [id, g] of this.buildingGroups) {
      g.traverse(o => {
        const m = o as any;
        if (m.isWindRotor) m.rotation.z += dt * 2.2;
        else if (m.isRotor) m.rotation.y += dt * 6;
        else if (m.isPump) m.position.y = (m.userData.baseY ?? (m.userData.baseY = m.position.y)) + Math.sin(t * 2.4) * 0.05;
        else if (m.isFlame) { m.scale.setScalar(1 + Math.sin(t * 12 + id) * 0.18); }
        else if (m.isBeacon) { (m.material as THREE.MeshStandardMaterial).emissiveIntensity = 0.4 + (Math.sin(t * 5 + id) > 0 ? 1.2 : 0.1); }
        else if (m.isCart) m.position.z = (m.userData.baseZ ?? (m.userData.baseZ = m.position.z)) + Math.sin(t * 1.2 + id) * 0.1;
        else if (m.isStir) m.rotation.y += dt * 0.8;
        else if (m.isFountain) m.scale.y = 1 + Math.sin(t * 3 + id) * 0.25;
        else if (m.isCrops) { const s = 0.85 + Math.sin(t * 1.8 + id) * 0.05; m.scale.set(s, 0.85 + Math.sin(t * 1.8 + id) * 0.08, s); }
        else if (m.isPlane) m.rotation.y = (m.userData.baseR ?? (m.userData.baseR = m.rotation.y)) + Math.sin(t * 0.4) * 0.2;
      });
    }
    // 烟囱烟雾
    if (Math.random() < dt * 3) {
      for (const [id, g] of this.buildingGroups) {
        const spots = (g as any).smokeSpots as THREE.Vector3[] | undefined;
        if (!spots) continue;
        const b = this.engine.buildings.get(id);
        if (!b || b.efficiency < 0.15) continue;
        const s = spots[Math.floor(Math.random() * spots.length)];
        this.spawnParticle(g.position.x + s.x, g.position.y + s.y, g.position.z + s.z, {
          color: 0x9aa0a6, life: 2.4, vx: (Math.random() - 0.5) * 0.12 + 0.1, vy: 0.45 + Math.random() * 0.2, vz: (Math.random() - 0.5) * 0.12,
          size: 0.16, grow: 0.24, opacity: 0.32,
        });
      }
    }
    // 火灾
    for (const b of this.engine.buildings.values()) {
      if (b.fire <= 0) continue;
      const g = this.buildingGroups.get(b.id);
      if (!g) continue;
      if (Math.random() < dt * 45) {
        const ang = Math.random() * Math.PI * 2;
        const rr = 0.3 + Math.random() * 0.4 * b.size;
        this.spawnParticle(
          g.position.x + Math.cos(ang) * rr,
          g.position.y + 0.15 + Math.random() * 0.9,
          g.position.z + Math.sin(ang) * rr,
          { color: Math.random() < 0.5 ? 0xe8590c : 0xfab005, life: 0.8, vx: (Math.random() - 0.5) * 0.5, vy: 1.7 + Math.random(), vz: (Math.random() - 0.5) * 0.5, size: 0.55, grow: 0.3, additive: true, opacity: 0.95, noDepth: true },
        );
      }
      if (Math.random() < dt * 5) {
        this.spawnParticle(g.position.x + (Math.random() - 0.5) * 0.4, g.position.y + 0.9, g.position.z + (Math.random() - 0.5) * 0.4, {
          color: 0x3a3a3a, life: 1.8, vx: 0.1, vy: 0.9, vz: 0, size: 0.5, grow: 0.5, opacity: 0.5,
        });
      }
    }
    // 雨
    if (this.rainPoints.visible) {
      const pos = this.rainPoints.geometry.attributes.position as THREE.BufferAttribute;
      const arr = pos.array as Float32Array;
      for (let i = 0; i < arr.length; i += 3) {
        arr[i + 1] -= dt * 14;
        if (arr[i + 1] < 0) {
          arr[i + 1] = 14 + Math.random() * 4;
          arr[i] = (Math.random() - 0.5) * 80;
          arr[i + 2] = (Math.random() - 0.5) * 80;
        }
      }
      pos.needsUpdate = true;
    }
    // 云 (环绕镜头目标漂移)
    for (const c of this.clouds) {
      c.position.x += dt * 0.4;
      if (c.position.x > this.camTarget.x + 95) c.position.x = this.camTarget.x - 95;
      if (c.position.z > this.camTarget.z + 95) c.position.z = this.camTarget.z - 95;
      if (c.position.z < this.camTarget.z - 95) c.position.z = this.camTarget.z + 95;
    }
    // 海面涟漪
    if (this.oceanMesh) {
      const pos = this.oceanMesh.geometry.attributes.position as THREE.BufferAttribute;
      const arr = pos.array as Float32Array;
      for (let i = 0; i < arr.length; i += 3) {
        arr[i + 1] = Math.sin(this.time * 0.8 + arr[i] * 0.08) * 0.045 + Math.cos(this.time * 0.6 + arr[i + 2] * 0.1) * 0.04 - 0.06;
      }
      pos.needsUpdate = true;
    }
    // 选择环
    if (this.selectRing.visible) {
      this.selectRing.rotation.y += dt * 0.9;
      const base = (this.selectRing.userData.baseScale as number) ?? 1;
      this.selectRing.scale.setScalar(base * (1 + Math.sin(this.time * 3.4) * 0.05));
    }
    // 萤火虫
    const ffOn = this.engine.era <= 1 && (this.engine.hour >= 19.8 || this.engine.hour < 5.2) && this.quality !== 'low';
    for (const f of this.fireflies) {
      if (!ffOn) { f.spr.visible = false; continue; }
      f.spr.visible = true;
      const tt = this.time + f.phase;
      const x = f.cx + Math.cos(tt * 0.35) * f.r + Math.sin(tt * 0.9) * 0.6;
      const z = f.cz + Math.sin(tt * 0.27) * f.r + Math.cos(tt * 0.8) * 0.6;
      const tx = Math.floor(x), ty = Math.floor(z);
      f.spr.position.set(x, this.heightAt(tx, ty) + 0.35 + Math.sin(tt * 1.3) * 0.22, z);
      (f.spr.material as THREE.SpriteMaterial).opacity = 0.25 + Math.max(0, Math.sin(tt * 1.9)) * 0.65;
    }
    if (ffOn && this.fireflies.length > 0 && Math.random() < dt * 0.4) {
      const ff = this.fireflies[Math.floor(Math.random() * this.fireflies.length)];
      ff.cx = this.camTarget.x + (Math.random() - 0.5) * 22;
      ff.cz = this.camTarget.z + (Math.random() - 0.5) * 22;
    }
    // 迷雾边界飘雾: 缓慢漂移呼吸
    for (let i = 0; i < this.fogSprites.length; i++) {
      const spr = this.fogSprites[i];
      if (!spr.visible) continue;
      const s = spr.userData.seed as number;
      spr.position.x += Math.sin(t * 0.11 + s) * dt * 0.14;
      spr.position.z += Math.cos(t * 0.09 + s) * dt * 0.11;
      (spr.material as THREE.SpriteMaterial).opacity = 0.3 + Math.sin(t * 0.24 + s) * 0.14;
      const b = 1 + Math.sin(t * 0.2 + s) * 0.08;
      spr.scale.set((3.5 + (i % 4) * 1.2) * b, (1.6 + (i % 3) * 0.5) * b, 1);
    }
    // 探索旗飘动
    if (this.exploreFlag.visible) {
      this.exploreFlag.children[1].rotation.y = Math.sin(this.time * 3) * 0.3;
    }
  }

  // ---------- 主循环 ----------
  private loop = () => {
    if (this.disposed) return;
    this.raf = requestAnimationFrame(this.loop);
    const now = performance.now();
    const dt = Math.min(0.1, (now - this.lastTime) / 1000);
    this.lastTime = now;
    this.time += dt;
    this.engine.update(dt);
    // 开场镜头
    if (this.intro.t < this.intro.dur) {
      this.intro.t += dt;
      const k = Math.min(1, this.intro.t / this.intro.dur);
      const e = 1 - Math.pow(1 - k, 3);
      this.camDist = this.intro.fromDist + (this.intro.toDist - this.intro.fromDist) * e;
      this.camPhi = this.intro.fromPhi + (this.intro.toPhi - this.intro.fromPhi) * e;
      this.camTheta = this.intro.fromTheta + 0.85 * e;
    }
    if (this.cine) {
      this.cine.t += dt;
      const k = Math.min(1, this.cine.t / this.cine.dur);
      const e = k < 0.5 ? 4 * k * k * k : 1 - Math.pow(-2 * k + 2, 3) / 2;
      this.camDist = this.cine.fd + (this.cine.td - this.cine.fd) * e;
      this.camTheta = this.cine.fth + (this.cine.tth - this.cine.fth) * e;
      this.camPhi = this.cine.fph + (this.cine.tph - this.cine.fph) * e;
      if (k >= 1) this.cine = null;
    }
    this.handleKeys(dt);
    this.applyCamera();
    this.updateDayNight();
    this.updateTerrainChunks();
    this.consumeFx();
    this.updateParticles(dt);
    this.updateFloatTexts(dt);
    this.updateCitizens(dt);
    this.updateCars(dt);
    this.updateChopTasks(dt);
    this.updateExpeditionVisuals(dt);
    this.updateBattleScene(dt);      // v5: 地图内战斗
    this.updateUtilFlow(dt);         // v5: 管网流向粒子
    this.updateConstructionAmbient(dt);
    this.updateAlertsAndBars();
    this.animateDecorations(dt);
    this.animateRuinGlows(this.time);
    // 电网变化
    if (this.engine.networkVersion !== this.wireVersion) this.rebuildWires();
    if ((this.viewMode === 'power' || this.viewMode === 'water') && this.engine.networkVersion !== this.utilVersion) {
      this.rebuildUtilView();
    }
    // 数据视图
    if (this.viewMode !== 'none') {
      this.overlayTimer += dt;
      if (this.overlayTimer > 1.2) {
        this.overlayTimer = 0;
        this.rebuildOverlayChunks();
        this.updateOverlayColors();
        this.updateViewMarkers();
      }
      this.animateViewMarkers(this.time);
    } else if (this.viewMarkerPool.length > 0) {
      this.viewMarkerPool.forEach(m => { m.visible = false; });
    }
    if (this.selectedBuildingId != null && !this.engine.buildings.has(this.selectedBuildingId)) {
      this.selectBuilding(null);
    }
    this.renderer.render(this.scene, this.camera);
    this.uiTimer += dt;
    if (this.uiTimer > (this.engine.battle ? 0.12 : 0.3)) { this.uiTimer = 0; this.cb.syncUI(); }
  };

  resize = () => {
    const w = this.canvas.clientWidth || window.innerWidth;
    const h = this.canvas.clientHeight || window.innerHeight;
    this.renderer.setSize(w, h, false);
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
  };

  dispose() {
    this.disposed = true;
    cancelAnimationFrame(this.raf);
    this.canvas.removeEventListener('pointerdown', this.onPointerDown);
    this.canvas.removeEventListener('pointermove', this.onPointerMove);
    this.canvas.removeEventListener('pointerup', this.onPointerUp);
    this.canvas.removeEventListener('pointerleave', this.onPointerLeave);
    this.canvas.removeEventListener('wheel', this.onWheel);
    window.removeEventListener('keydown', this.onKeyDown);
    window.removeEventListener('keyup', this.onKeyUp);
    window.removeEventListener('resize', this.resize);
    this.renderer.dispose();
  }

  private buildSkyDecor() {
    const N = 380;
    const geo = new THREE.BufferGeometry();
    const pos = new Float32Array(N * 3);
    for (let i = 0; i < N; i++) {
      const a = Math.random() * Math.PI * 2;
      const e = Math.random() * Math.PI * 0.46;
      const r = 380;
      pos[i * 3] = Math.cos(a) * Math.cos(e) * r;
      pos[i * 3 + 1] = Math.sin(e) * r + 30;
      pos[i * 3 + 2] = Math.sin(a) * Math.cos(e) * r;
    }
    geo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
    const m = new THREE.PointsMaterial({ color: 0xdfe9ff, size: 1.5, map: this.dotTex, transparent: true, opacity: 0, depthWrite: false, sizeAttenuation: true });
    (m as any).fog = false;
    this.stars = new THREE.Points(geo, m);
    this.stars.visible = false;
    this.scene.add(this.stars);
    const cv = document.createElement('canvas'); cv.width = cv.height = 128;
    const ctx = cv.getContext('2d')!;
    const g = ctx.createRadialGradient(64, 64, 20, 64, 64, 62);
    g.addColorStop(0, 'rgba(255,252,240,1)');
    g.addColorStop(0.62, 'rgba(250,246,228,0.95)');
    g.addColorStop(0.68, 'rgba(240,236,220,0.35)');
    g.addColorStop(1, 'rgba(240,236,220,0)');
    ctx.fillStyle = g; ctx.beginPath(); ctx.arc(64, 64, 62, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = 'rgba(215,210,195,0.5)';
    ctx.beginPath(); ctx.arc(50, 52, 9, 0, Math.PI * 2); ctx.fill();
    ctx.beginPath(); ctx.arc(74, 70, 6, 0, Math.PI * 2); ctx.fill();
    const mm = new THREE.SpriteMaterial({ map: new THREE.CanvasTexture(cv), transparent: true, opacity: 0, depthWrite: false });
    (mm as any).fog = false;
    this.moon = new THREE.Sprite(mm);
    this.moon.scale.set(42, 42, 1);
    this.moon.visible = false;
    this.scene.add(this.moon);
  }

  private buildFireflies() {
    for (let i = 0; i < 26; i++) {
      const spr = new THREE.Sprite(new THREE.SpriteMaterial({
        map: this.dotTex, color: i % 3 === 0 ? 0xd8f5a8 : 0xffe98a,
        transparent: true, opacity: 0, blending: THREE.AdditiveBlending, depthWrite: false,
      }));
      spr.scale.setScalar(0.16);
      spr.visible = false;
      spr.renderOrder = 8;
      this.fireflies.push({ spr, cx: 0, cz: 0, phase: Math.random() * 20, r: 2 + Math.random() * 5 });
      this.scene.add(spr);
    }
    // 迷雾边界飘雾精灵 (柔化探索边界)
    for (let i = 0; i < 40; i++) {
      const spr = new THREE.Sprite(new THREE.SpriteMaterial({
        map: this.dotTex, color: i % 3 === 0 ? 0x36415a : 0x2c3648,
        transparent: true, opacity: 0.4, depthWrite: false,
      }));
      spr.scale.set(3.5 + (i % 4) * 1.2, 1.6 + (i % 3) * 0.5, 1);
      spr.visible = false;
      spr.renderOrder = 4;
      spr.userData.seed = Math.random() * 10;
      this.fogSprites.push(spr);
      this.scene.add(spr);
    }
  }
}
