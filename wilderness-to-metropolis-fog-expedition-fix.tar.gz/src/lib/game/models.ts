// ===== 荒野筑城 · 程序化 3D 模型工厂 (v2 全面重制) =====
import * as THREE from 'three';
import { BUILDING_DEFS } from './buildings';

// ---------- 调色板 ----------
const C = {
  wood: 0x8a5a33, woodDark: 0x6b4423, woodLight: 0xa97548,
  straw: 0xd9b36a, strawDark: 0xb8944f,
  stone: 0x9aa3ab, stoneDark: 0x7d868e, brick: 0xa85f4a,
  cream: 0xe8dcc5, white: 0xf2f2ee,
  roofRed: 0xb5482f, roofBlue: 0x4a6b8a, roofGreen: 0x5d7a4a, roofDark: 0x4a4f55,
  glass: 0x8fb9cc, metal: 0xb8bec4, metalDark: 0x5f666d,
  leaf: 0x4c8c3f, pine: 0x2f6b3a, birch: 0x9db06a,
  dirt: 0x8a6f4d, soil: 0x6e5236, gravel: 0x8d8d8d, asphalt: 0x3d4045,
  gold: 0xd9a536, red: 0xc0392b, fireRed: 0xe8590c, fireYellow: 0xfab005,
  grass: 0x5da24a, grassDark: 0x4a8a3c, water: 0x3a86b8,
  accent: 0xd97706, copper: 0xb0703c, concrete: 0xb8b2a6,
};

// ---------- 材质缓存 ----------
const matCache = new Map<string, THREE.MeshStandardMaterial>();
export function mat(color: number, o: Partial<{
  roughness: number; metalness: number; flatShading: boolean; emissive: number; emissiveIntensity: number; transparent: boolean; opacity: number;
}> = {}): THREE.MeshStandardMaterial {
  const key = `${color}|${o.roughness ?? 0.9}|${o.metalness ?? 0}|${o.flatShading ? 1 : 0}|${o.emissive ?? 0}|${o.emissiveIntensity ?? 0}|${o.transparent ? 1 : 0}|${o.opacity ?? 1}`;
  let m = matCache.get(key);
  if (!m) {
    m = new THREE.MeshStandardMaterial({
      color, roughness: o.roughness ?? 0.9, metalness: o.metalness ?? 0,
      flatShading: o.flatShading ?? true, emissive: o.emissive ?? 0x000000,
      emissiveIntensity: o.emissiveIntensity ?? 1, transparent: o.transparent ?? false,
      opacity: o.opacity ?? 1,
    });
    matCache.set(key, m);
  }
  return m;
}

// ---------- 基础几何助手 ----------
export function box(w: number, h: number, d: number, m: THREE.Material, x = 0, y = 0, z = 0): THREE.Mesh {
  const mesh = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), m);
  mesh.position.set(x, y, z);
  mesh.castShadow = true; mesh.receiveShadow = true;
  return mesh;
}
export function cyl(rt: number, rb: number, h: number, m: THREE.Material, x = 0, y = 0, z = 0, seg = 8): THREE.Mesh {
  const mesh = new THREE.Mesh(new THREE.CylinderGeometry(rt, rb, h, seg), m);
  mesh.position.set(x, y, z);
  mesh.castShadow = true; mesh.receiveShadow = true;
  return mesh;
}
export function cone(r: number, h: number, m: THREE.Material, x = 0, y = 0, z = 0, seg = 6): THREE.Mesh {
  const mesh = new THREE.Mesh(new THREE.ConeGeometry(r, h, seg), m);
  mesh.position.set(x, y, z);
  mesh.castShadow = true; mesh.receiveShadow = true;
  return mesh;
}
function sph(r: number, m: THREE.Material, x = 0, y = 0, z = 0, seg = 6): THREE.Mesh {
  const mesh = new THREE.Mesh(new THREE.SphereGeometry(r, seg, seg), m);
  mesh.position.set(x, y, z);
  mesh.castShadow = true; mesh.receiveShadow = true;
  return mesh;
}

/** 人字坡屋顶 (两个斜面 + 山墙填充) */
function gable(w: number, d: number, h: number, roofMat: THREE.Material, x = 0, y = 0, z = 0): THREE.Group {
  const g = new THREE.Group();
  const slopeLen = Math.sqrt((d / 2) ** 2 + h ** 2);
  const ang = Math.atan2(h, d / 2);
  for (const s of [-1, 1]) {
    const face = box(w, 0.05, slopeLen, roofMat, 0, h / 2, (s * d) / 4);
    face.rotation.x = s * ang;
    face.position.set(0, y + h / 2, z + (s * d) / 4);
    g.add(face);
  }
  // 山墙
  const gableMat = mat(0xd8c9a8);
  for (const s of [-1, 1]) {
    const tri = new THREE.Mesh(new THREE.CylinderGeometry(0.005, 0.005, 0.01, 3), gableMat);
    // 用薄三棱柱近似山墙
    const shape = new THREE.Shape();
    shape.moveTo(-w / 2, 0); shape.lineTo(w / 2, 0); shape.lineTo(0, h); shape.closePath();
    const geo = new THREE.ExtrudeGeometry(shape, { depth: 0.02, bevelEnabled: false });
    const wall = new THREE.Mesh(geo, gableMat);
    wall.rotation.y = Math.PI / 2;
    wall.position.set(x + (s * w) / 2 - (s > 0 ? 0.02 : 0), y, z + d / 2);
    wall.castShadow = true;
    g.add(wall);
  }
  return g;
}

// ---------- 窗户贴图(夜景灯光) ----------
const winTexCache = new Map<string, { map: THREE.Texture; emissive: THREE.Texture }>();
function windowTex(key: string, cols: number, rows: number, litRatio: number, wallHex: string, litHex = '#ffd98a') {
  const cached = winTexCache.get(key);
  if (cached) return cached;
  const w = cols * 16, h = rows * 16;
  const wall = document.createElement('canvas'); wall.width = w; wall.height = h;
  const emi = document.createElement('canvas'); emi.width = w; emi.height = h;
  const wc = wall.getContext('2d')!, ec = emi.getContext('2d')!;
  wc.fillStyle = wallHex; wc.fillRect(0, 0, w, h);
  ec.fillStyle = '#000'; ec.fillRect(0, 0, w, h);
  for (let y = 0; y < rows; y++) {
    for (let x = 0; x < cols; x++) {
      const px = x * 16 + 4, py = y * 16 + 4;
      const lit = Math.random() < litRatio;
      wc.fillStyle = lit ? '#ffe9b0' : '#2d3d4d';
      wc.fillRect(px, py, 8, 9);
      if (lit) { ec.fillStyle = litHex; ec.fillRect(px, py, 8, 9); }
    }
  }
  const map = new THREE.CanvasTexture(wall);
  const emissive = new THREE.CanvasTexture(emi);
  map.colorSpace = THREE.SRGBColorSpace;
  winTexCache.set(key, { map, emissive });
  return { map, emissive };
}

/** 带窗户贴图的立方体(夜晚亮灯) */
function winBox(w: number, h: number, d: number, key: string, cols: number, rows: number, litRatio: number, wallHex: string): THREE.Mesh {
  const { map, emissive } = windowTex(key, cols, rows, litRatio, wallHex);
  const m = new THREE.MeshStandardMaterial({
    map, emissiveMap: emissive, emissive: 0xffd98a, emissiveIntensity: 0, roughness: 0.85,
  });
  const mesh = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), m);
  mesh.castShadow = true; mesh.receiveShadow = true;
  (mesh as any).isWindowMesh = true;
  return mesh;
}

/** 地基底座 (v3: 带埋地裙边 —— 坡地建造时遮住下坡侧悬空缝隙, 平地不可见) */
function plinth(size = 1, color = C.soil, h = 0.07): THREE.Group {
  const grp = new THREE.Group();
  const p = box(size * 0.96, h, size * 0.96, mat(color, { roughness: 1 }));
  p.position.y = h / 2;
  grp.add(p);
  const skirt = box(size * 0.93, 0.55, size * 0.93, mat(color, { roughness: 1 }));
  skirt.position.y = -0.26;
  grp.add(skirt);
  return grp;
}

/** 门前小径 (现代建筑配套) */
function frontPath(len = 0.5, w = 0.34, zOff = 0.42): THREE.Mesh {
  const p = box(w, 0.03, len, mat(0xa8a29a, { roughness: 1 }), 0, 0.045, zOff);
  p.receiveShadow = true;
  return p;
}

/** 路缘石草坪 */
function yard(): THREE.Mesh {
  return box(0.9, 0.05, 0.9, mat(0x63a84e, { roughness: 1 }), 0, 0.05, 0);
}

// ---------- 建筑 ----------
type Factory = () => THREE.Group;

const roadTextureCache = new Map<string, THREE.Texture>();
function roadTex(key: string, base: string, painter: (ctx: CanvasRenderingContext2D, s: number) => void) {
  let t = roadTextureCache.get(key);
  if (t) return t;
  const s = 128;
  const cv = document.createElement('canvas'); cv.width = s; cv.height = s;
  const ctx = cv.getContext('2d')!;
  ctx.fillStyle = base; ctx.fillRect(0, 0, s, s);
  painter(ctx, s);
  t = new THREE.CanvasTexture(cv);
  t.colorSpace = THREE.SRGBColorSpace;
  roadTextureCache.set(key, t);
  return t;
}

const factories: Record<string, Factory> = {
  // ================= 道路 =================
  // v5: 地下管线 —— 无模型 (视图模式下由渲染器画地下线)
  none: () => new THREE.Group(),
  path: () => {
    const g = new THREE.Group();
    const m = new THREE.MeshStandardMaterial({ color: C.dirt, roughness: 1 });
    const p = new THREE.Mesh(new THREE.BoxGeometry(1, 0.05, 1), m);
    p.position.y = 0.025; p.receiveShadow = true;
    g.add(p);
    for (let i = 0; i < 4; i++) {
      const s = box(0.1, 0.06, 0.1, mat(C.stone), (Math.random() - 0.5) * 0.7, 0.05, (Math.random() - 0.5) * 0.7);
      g.add(s);
    }
    return g;
  },
  boardwalk: () => {
    const g = new THREE.Group();
    // 木板 (垂直于道路方向的板条)
    for (let i = 0; i < 7; i++) {
      const plank = box(1.0, 0.06, 0.125, mat(i % 2 ? C.wood : C.woodDark, { roughness: 1 }), 0, 0.14, -0.44 + i * 0.145);
      g.add(plank);
    }
    // 支撑桩 (深入水下)
    for (const [dx, dz] of [[-0.42, -0.42], [0.42, -0.42], [-0.42, 0.42], [0.42, 0.42], [0, 0]]) {
      g.add(cyl(0.05, 0.06, 0.5, mat(C.woodDark), dx, -0.05, dz, 5));
    }
    // 缆桩
    g.add(cyl(0.035, 0.04, 0.12, mat(C.wood), -0.44, 0.24, 0, 6));
    g.add(cyl(0.035, 0.04, 0.12, mat(C.wood), 0.44, 0.24, 0, 6));
    return g;
  },
  gravel: () => {
    const g = new THREE.Group();
    const m = new THREE.MeshStandardMaterial({ color: C.gravel, roughness: 1 });
    const p = new THREE.Mesh(new THREE.BoxGeometry(1, 0.06, 1), m);
    p.position.y = 0.03; p.receiveShadow = true;
    g.add(p);
    // 碎石点缀
    for (let i = 0; i < 6; i++) {
      g.add(sph(0.035, mat(0x9b9b9b), (Math.random() - 0.5) * 0.8, 0.06, (Math.random() - 0.5) * 0.8, 4));
    }
    return g;
  },
  paved: () => {
    const g = new THREE.Group();
    const t = roadTex('paved', '#3d4045', (ctx, s) => {
      ctx.fillStyle = '#e8e8e8';
      ctx.fillRect(s / 2 - 2, 10, 4, 26); ctx.fillRect(s / 2 - 2, s - 36, 4, 26);
      ctx.strokeStyle = '#565a60'; ctx.lineWidth = 3;
      ctx.strokeRect(1.5, 1.5, s - 3, s - 3);
    });
    const m = new THREE.MeshStandardMaterial({ map: t, roughness: 0.95 });
    const p = new THREE.Mesh(new THREE.BoxGeometry(1, 0.07, 1), m);
    p.position.y = 0.035; p.receiveShadow = true;
    g.add(p);
    return g;
  },
  highway: () => {
    const g = new THREE.Group();
    const t = roadTex('highway', '#33363b', (ctx, s) => {
      ctx.fillStyle = '#f5d90a';
      ctx.fillRect(s / 2 - 8, 8, 4, 40); ctx.fillRect(s / 2 - 8, s - 48, 4, 40);
      ctx.fillStyle = '#eee';
      ctx.fillRect(s / 2 + 4, 20, 3, 22); ctx.fillRect(s / 2 + 4, s - 42, 3, 22);
      ctx.strokeStyle = '#e8e8e8'; ctx.lineWidth = 4;
      ctx.beginPath(); ctx.moveTo(4, 0); ctx.lineTo(4, s); ctx.moveTo(s - 4, 0); ctx.lineTo(s - 4, s); ctx.stroke();
    });
    const m = new THREE.MeshStandardMaterial({ map: t, roughness: 0.9 });
    const p = new THREE.Mesh(new THREE.BoxGeometry(1, 0.08, 1), m);
    p.position.y = 0.04; p.receiveShadow = true;
    g.add(p);
    for (const [dx, dz, w, d] of [[0, 0.46, 1, 0.04], [0, -0.46, 1, 0.04]] as const) {
      g.add(box(w, 0.1, d, mat(C.metal, { metalness: 0.5, roughness: 0.5 }), dx, 0.12, dz));
    }
    return g;
  },

  // ================= 管线 =================
  // 电线杆 (v3 手动接线版: 刻意纤细低调 —— 视觉主体是杆与杆之间的悬垂导线,
  // 由渲染器实时绘制; 杆本身只留必要的木杆+横担+绝缘子)

  // ================= 住房 =================
  tent: () => {
    const g = new THREE.Group();
    g.add(plinth(1, C.grass));
    // 帐篷主体: 双层布料叠出褶皱感, 顶部略弯 (更像帐篷而非金字塔)
    const t = cone(0.42, 0.62, mat(0xc9a06a, { roughness: 1 }), 0, 0.37, 0, 5);
    t.rotation.y = Math.PI / 4;
    g.add(t);
    const fold = cone(0.43, 0.6, mat(0xb8944f, { roughness: 1 }), 0.02, 0.36, 0.01, 5);
    fold.rotation.y = Math.PI / 4 + 0.22;
    g.add(fold);
    // 敞开的门帘 (两片掀起的布)
    const flapL = box(0.16, 0.3, 0.016, mat(0xb8944f, { roughness: 1 }), -0.12, 0.2, 0.36);
    flapL.rotation.z = 0.5; flapL.rotation.x = -0.2;
    g.add(flapL);
    const flapR = box(0.16, 0.3, 0.016, mat(0xc9a06a, { roughness: 1 }), 0.12, 0.2, 0.36);
    flapR.rotation.z = -0.5; flapR.rotation.x = -0.2;
    g.add(flapR);
    // 门口黑暗内庭
    g.add(box(0.15, 0.24, 0.02, mat(0x2a241c), 0, 0.18, 0.35));
    // 中杆 + 拉绳 + 地钉
    g.add(cyl(0.012, 0.012, 0.72, mat(C.woodDark), 0, 0.42, 0, 4));
    for (const [ax, az, r] of [[0.45, 0.45, 2.35], [-0.45, 0.45, 0.8], [0.5, -0.4, -2.1]] as const) {
      const rope = cyl(0.006, 0.006, 0.62, mat(0xd8cbb0, { roughness: 1 }), ax * 0.55, 0.16, az * 0.55, 3);
      rope.rotation.z = r;
      g.add(rope);
      g.add(sph(0.02, mat(C.woodDark), ax * 0.85, 0.02, az * 0.85, 4)); // 地钉
    }
    return g;
  },
  hut: () => {
    const g = new THREE.Group();
    g.add(plinth(1, C.soil));
    g.add(box(0.68, 0.5, 0.6, mat(C.wood, { roughness: 1 }), 0, 0.32, 0));
    const roof = cone(0.62, 0.4, mat(C.straw, { roughness: 1 }), 0, 0.77, 0, 4);
    roof.rotation.y = Math.PI / 4;
    g.add(roof);
    // 茅草层叠感
    const roof2 = cone(0.58, 0.34, mat(C.strawDark, { roughness: 1 }), 0, 0.71, 0, 4);
    roof2.rotation.y = Math.PI / 4 + 0.2;
    g.add(roof2);
    g.add(box(0.15, 0.24, 0.03, mat(C.woodDark), 0, 0.18, 0.31));
    g.add(box(0.17, 0.17, 0.02, mat(0x3d3a33), 0.19, 0.34, 0.301)); // 窗
    return g;
  },
  longhouse: () => {
    const g = new THREE.Group();
    g.add(plinth(2, C.soil));
    // 修长的主体 (2×2)
    g.add(box(1.85, 0.8, 1.0, mat(C.wood, { roughness: 1 }), 0, 0.47, 0));
    // 长脊屋顶
    const r1 = box(1.95, 0.06, 0.66, mat(C.straw, { roughness: 1 }), 0, 1.1, -0.26);
    r1.rotation.x = 0.5; g.add(r1);
    const r2 = box(1.95, 0.06, 0.66, mat(C.strawDark, { roughness: 1 }), 0, 1.1, 0.26);
    r2.rotation.x = -0.5; g.add(r2);
    g.add(box(1.95, 0.07, 0.16, mat(C.woodDark), 0, 1.24, 0));
    // 门与支柱
    for (const dx of [-0.8, -0.45, -0.15, 0.15, 0.45, 0.8]) g.add(cyl(0.05, 0.06, 0.8, mat(C.woodDark), dx, 0.48, 0.52, 5));
    g.add(box(0.28, 0.48, 0.04, mat(C.woodDark), 0, 0.3, 0.53));
    // 门口挂饰
    g.add(box(0.14, 0.16, 0.02, mat(0xc0392b), -0.6, 0.6, 0.545));
    return g;
  },
  wood_house: () => {
    const g = new THREE.Group();
    g.add(yard());
    g.add(box(0.72, 0.6, 0.6, mat(C.woodLight, { roughness: 0.95 }), 0, 0.35, 0));
    // 木板纹理 (横向深条纹)
    for (let i = 0; i < 4; i++) g.add(box(0.73, 0.02, 0.61, mat(C.woodDark), 0, 0.15 + i * 0.14, 0));
    const roofG = gable(0.8, 0.72, 0.34, mat(C.roofRed, { roughness: 0.9 }), 0, 0.65, 0);
    g.add(roofG);
    g.add(box(0.18, 0.3, 0.03, mat(C.woodDark), -0.16, 0.22, 0.31));
    g.add(box(0.15, 0.15, 0.03, mat(0xffe9b0, { emissive: 0xffd98a, emissiveIntensity: 0 }), 0.17, 0.4, 0.301));
    g.add(cyl(0.09, 0.1, 0.34, mat(C.stone), 0.28, 0.95, -0.2)); // 烟囱
    g.add(frontPath());
    return g;
  },
  stone_house: () => {
    const g = new THREE.Group();
    g.add(yard());
    g.add(box(0.74, 0.68, 0.64, mat(C.cream, { roughness: 0.95 }), 0, 0.39, 0));
    // 砖层线
    for (let i = 0; i < 4; i++) g.add(box(0.75, 0.025, 0.65, mat(0xd8c9a8), 0, 0.2 + i * 0.16, 0));
    g.add(gable(0.84, 0.76, 0.36, mat(C.roofDark, { roughness: 0.9 }), 0, 0.73, 0));
    g.add(box(0.2, 0.34, 0.04, mat(C.woodDark), -0.17, 0.24, 0.33));
    g.add(box(0.16, 0.16, 0.03, mat(0xffe9b0, { emissive: 0xffd98a, emissiveIntensity: 0 }), 0.18, 0.46, 0.325));
    g.add(box(0.16, 0.16, 0.03, mat(0xffe9b0, { emissive: 0xffd98a, emissiveIntensity: 0 }), -0.18, 0.46, 0.325));
    g.add(cyl(0.08, 0.09, 0.3, mat(C.brick), 0.27, 1.02, -0.22));
    g.add(frontPath());
    return g;
  },
  townhouse: () => {
    const g = new THREE.Group();
    g.add(plinth(2, C.stoneDark));
    // 四连排小楼 (2×2)
    const hues = ['#c8a882', '#b8c4c0', '#c9b8a0', '#bfae92'];
    for (let i = 0; i < 4; i++) {
      const dx = -0.68 + i * 0.45;
      const body = winBox(0.42, 1.55, 1.2, `th${i}`, 3, 6, 0.5, hues[i]);
      body.position.set(dx, 0.84, 0); g.add(body);
      // 各家小坡顶
      const roof = box(0.46, 0.05, 1.26, mat(i % 2 ? C.roofBlue : C.roofRed, { roughness: 0.9 }), dx, 1.65, 0);
      roof.rotation.x = 0.1;
      g.add(roof);
      // 门
      g.add(box(0.14, 0.34, 0.02, mat(C.woodDark), dx, 0.28, 0.61));
      // 门台阶
      g.add(box(0.2, 0.05, 0.14, mat(C.stone), dx, 0.16, 0.68));
      // 屋顶烟囱
      if (i === 1 || i === 2) g.add(cyl(0.05, 0.055, 0.34, mat(C.brick), dx, 1.82, -0.3, 6));
    }
    g.add(frontPath(0.5, 1.6, 0.95));
    return g;
  },
  apartment: () => {
    const g = new THREE.Group();
    g.add(plinth(2, C.stoneDark));
    // 六层主楼 (2×2)
    const main = winBox(1.8, 3.1, 1.45, 'apt2', 8, 14, 0.5, '#c8b89a');
    main.position.y = 1.65; g.add(main);
    // 楼顶女儿墙 + 设备
    g.add(box(1.9, 0.1, 1.55, mat(C.roofDark), 0, 3.25, 0));
    g.add(box(0.42, 0.24, 0.36, mat(C.metalDark), -0.5, 3.42, 0.3));
    g.add(cyl(0.05, 0.05, 0.4, mat(C.metal), 0.55, 3.5, -0.35));
    // 阳台 (正面两列 × 5 层)
    for (let f = 0; f < 5; f++)
      for (const dx of [-0.5, 0.5]) {
        g.add(box(0.52, 0.03, 0.18, mat(C.concrete), dx, 0.55 + f * 0.5, 0.79));
        g.add(box(0.52, 0.15, 0.02, mat(0x9aa8b0, { transparent: true, opacity: 0.7 }), dx, 0.64 + f * 0.5, 0.87));
      }
    // 单元门雨棚
    g.add(box(0.66, 0.04, 0.26, mat(C.roofDark), 0, 0.5, 0.82));
    g.add(frontPath(0.55, 0.5, 1.05));
    return g;
  },
  condo: () => {
    const g = new THREE.Group();
    g.add(plinth(2, C.stoneDark));
    const hue = ['#6b8494', '#7d8a96', '#5d7486'][Math.floor(Math.random() * 3)];
    // 双塔 (2×2)
    const t1 = winBox(1.15, 4.4, 1.15, `cd1${hue}`, 6, 20, 0.45, hue);
    t1.position.set(-0.35, 2.27, -0.2); g.add(t1);
    const t2 = winBox(0.78, 2.5, 0.78, `cd2${hue}`, 4, 12, 0.45, hue);
    t2.position.set(0.62, 1.32, 0.55); g.add(t2);
    g.add(box(1.25, 0.06, 1.25, mat(C.metalDark), -0.35, 4.52, -0.2));
    g.add(cyl(0.02, 0.02, 0.6, mat(0xd9a536, { metalness: 0.7, roughness: 0.3 }), -0.35, 4.82, -0.2));
    g.add(box(0.85, 0.05, 0.85, mat(C.metalDark), 0.62, 2.6, 0.55));
    // 顶部电梯机房
    g.add(box(0.36, 0.2, 0.36, mat(C.concrete), -0.05, 4.62, 0.15));
    g.add(frontPath(0.55, 0.5, 1.05));
    return g;
  },
  skyscraper: () => {
    const g = new THREE.Group();
    g.add(plinth(3, C.stoneDark));
    const hue = ['#5d7486', '#6b7d8d', '#57707e'][Math.floor(Math.random() * 3)];
    // 三段式主塔 (3×3, 总高约 12.5)
    const t1 = winBox(2.55, 7.4, 2.55, `sky${hue}`, 10, 24, 0.45, hue);
    t1.position.y = 3.77; g.add(t1);
    const t2 = winBox(1.9, 2.5, 1.9, `sky2${hue}`, 7, 9, 0.45, hue);
    t2.position.y = 8.72; g.add(t2);
    const t3 = winBox(1.1, 1.15, 1.1, `sky3${hue}`, 4, 4, 0.45, hue);
    t3.position.y = 10.55; g.add(t3);
    g.add(box(2.0, 0.06, 2.0, mat(C.metalDark), 0, 10.02, 0));
    g.add(cyl(0.022, 0.022, 1.0, mat(0xd9a536, { metalness: 0.7, roughness: 0.3 }), 0, 11.6, 0));
    // 航空障碍灯
    const beacon = sph(0.05, mat(0xc0392b, { emissive: 0xc0392b, emissiveIntensity: 1 }), 0, 12.2, 0, 6);
    (beacon as any).isBeacon = true;
    g.add(beacon);
    // 底部大堂 (玻璃)
    g.add(box(2.6, 0.5, 2.6, mat(0x9fc8dd, { roughness: 0.2, metalness: 0.1, transparent: true, opacity: 0.85 }), 0, 0.3, 0));
    // 门前广场
    g.add(box(2.85, 0.04, 0.8, mat(0xa8a29a, { roughness: 1 }), 0, 0.05, 1.05));
    return g;
  },

  // ================= 食物 =================
  berry: () => {
    const g = new THREE.Group();
    g.add(plinth(1, C.grass));
    // 白色小栅栏围出浆果园
    for (const [x, z, w, d] of [[0, 0.46, 0.96, 0.03], [0, -0.46, 0.96, 0.03], [0.46, 0, 0.03, 0.96], [-0.46, 0, 0.03, 0.96]] as const) {
      g.add(box(w, 0.12, d, mat(0xe8e3da, { roughness: 0.9 }), x, 0.09, z));
    }
    for (const p of [[-0.42, -0.42], [0, -0.42], [0.42, -0.42], [-0.42, 0.42], [0, 0.42], [0.42, 0.42]] as const) {
      g.add(box(0.035, 0.18, 0.035, mat(0xe8e3da, { roughness: 0.9 }), p[0], 0.14, p[1]));
    }
    // 三丛饱满的浆果灌木 (圆冠 + 密集红果)
    for (let i = 0; i < 3; i++) {
      const bx = (i - 1) * 0.27;
      const bz = (i % 2 === 0 ? 0.17 : -0.15);
      g.add(box(0.28, 0.08, 0.24, mat(C.soil), bx, 0.09, bz));
      g.add(sph(0.13, mat(0x3f7a34), bx, 0.24, bz, 7));
      g.add(sph(0.09, mat(0x4c8c3f), bx + 0.07, 0.32, bz + 0.04, 6));
      for (let b = 0; b < 7; b++) {
        const a = b * 0.9 + i;
        g.add(sph(0.038, mat(b % 2 ? 0xc0392b : 0xe8590c, { emissive: 0x431008, roughness: 0.6 }),
          bx + Math.cos(a) * 0.1, 0.25 + Math.sin(b * 1.7) * 0.11, bz + Math.sin(a) * 0.1, 5));
      }
    }
    return g;
  },
  farm: () => {
    const g = new THREE.Group();
    g.add(box(0.96, 0.06, 0.96, mat(C.soil, { roughness: 1 }), 0, 0.03, 0));
    // 金色麦浪: 垄沟走向一致, 麦穗饱满下垂
    const crops = new THREE.Group();
    for (let i = 0; i < 5; i++) {
      g.add(box(0.9, 0.02, 0.04, mat(0x5a4430, { roughness: 1 }), 0, 0.07, -0.38 + i * 0.19)); // 垄沟
      for (let j = 0; j < 6; j++) {
        const cx = -0.36 + j * 0.145, cz = -0.38 + i * 0.19;
        crops.add(box(0.028, 0.26, 0.028, mat(0x9fae4e), cx, 0.19, cz));       // 麦秆
        crops.add(sph(0.05, mat(0xd9b36a), cx, 0.34, cz, 5));                   // 麦穗
        crops.add(sph(0.032, mat(0xe8c97a), cx + 0.03, 0.38, cz, 4));
      }
    }
    (crops as any).isCrops = true;
    g.add(crops);
    // 稻草人 (大檐草帽 + 张开的双臂)
    g.add(cyl(0.025, 0.03, 0.42, mat(C.woodDark), 0.41, 0.26, 0.41, 5));
    g.add(box(0.3, 0.035, 0.04, mat(C.woodDark), 0.41, 0.44, 0.41));
    g.add(sph(0.055, mat(0xc9a06a), 0.41, 0.52, 0.41, 6));
    g.add(box(0.24, 0.03, 0.24, mat(C.straw), 0.41, 0.555, 0.41)); // 帽檐
    g.add(cone(0.09, 0.09, mat(C.strawDark), 0.41, 0.6, 0.41, 6));
    return g;
  },
  orchard: () => {
    const g = new THREE.Group();
    g.add(box(0.96, 0.05, 0.96, mat(0x63a84e, { roughness: 1 }), 0, 0.025, 0));
    // 果树行列
    for (let i = 0; i < 2; i++)
      for (let j = 0; j < 2; j++) {
        const dx = -0.22 + i * 0.44, dz = -0.22 + j * 0.44;
        g.add(cyl(0.045, 0.06, 0.34, mat(C.woodDark), dx, 0.2, dz, 5));
        g.add(sph(0.15, mat(0x5d9a48), dx, 0.5, dz));
        g.add(sph(0.1, mat(0x6fae52), dx + 0.08, 0.6, dz + 0.04));
        // 红苹果点缀
        g.add(sph(0.028, mat(0xc0392b), dx + 0.1, 0.48, dz));
        g.add(sph(0.028, mat(0xc0392b), dx - 0.08, 0.54, dz + 0.09));
        g.add(sph(0.028, mat(0xe8590c), dx + 0.03, 0.58, dz - 0.1));
      }
    return g;
  },
  pasture: () => {
    const g = new THREE.Group();
    g.add(box(0.96, 0.05, 0.96, mat(0x6fae52, { roughness: 1 }), 0, 0.025, 0));
    for (const [x, z, w, d] of [[0, 0.46, 0.96, 0.04], [0, -0.46, 0.96, 0.04], [0.46, 0, 0.04, 0.96], [-0.46, 0, 0.04, 0.96]] as const) {
      g.add(box(w, 0.16, d, mat(C.woodDark), x, 0.12, z));
    }
    // 栅栏柱
    for (const p of [[-0.46, -0.46], [0, -0.46], [0.46, -0.46], [-0.46, 0.46], [0, 0.46], [0.46, 0.46], [0.46, 0], [-0.46, 0]] as const) {
      g.add(cyl(0.02, 0.025, 0.2, mat(C.wood), p[0], 0.15, p[1], 4));
    }
    for (const [cx, cz, rot] of [[-0.2, -0.12, 0.4], [0.24, 0.2, 2.6]] as const) {
      const cow = new THREE.Group();
      cow.add(box(0.24, 0.15, 0.13, mat(0xe8e3da), 0, 0.17, 0));
      cow.add(box(0.09, 0.11, 0.12, mat(0xe8e3da), -0.16, 0.2, 0));
      cow.add(box(0.05, 0.05, 0.06, mat(0xf5b5b5), -0.22, 0.24, 0));
      cow.add(box(0.02, 0.06, 0.02, mat(0x4a4038), -0.14, 0.27, 0.03));
      cow.add(box(0.02, 0.06, 0.02, mat(0x4a4038), -0.14, 0.27, -0.03));
      // 花斑
      cow.add(box(0.07, 0.07, 0.131, mat(0x4a4440), -0.02, 0.19, 0));
      for (const [lx, lz] of [[0.08, 0.045], [0.08, -0.045], [-0.08, 0.045], [-0.08, -0.045]] as const) {
        cow.add(cyl(0.018, 0.018, 0.12, mat(0x4a4038), lx, 0.06, lz, 4));
      }
      cow.position.set(cx, 0, cz); cow.rotation.y = rot;
      (cow as any).isAnimal = true;
      g.add(cow);
    }
    // 食槽
    g.add(box(0.2, 0.07, 0.09, mat(C.woodDark), 0.3, 0.09, -0.3));
    return g;
  },
  fishery: () => {
    const g = new THREE.Group();
    // 木栈桥 (更宽更稳)
    g.add(box(0.94, 0.1, 0.64, mat(C.woodDark), 0, 0.09, 0.14));
    for (const p of [[-0.38, -0.1], [0.38, -0.1], [-0.38, 0.42], [0.38, 0.42]] as const) {
      g.add(cyl(0.035, 0.04, 0.42, mat(C.woodDark), p[0], -0.06, p[1], 5));
    }
    // 渔家小屋 (加大 + 挂鱼旗)
    g.add(box(0.4, 0.34, 0.32, mat(C.wood), 0, 0.32, 0.18));
    g.add(gable(0.46, 0.38, 0.15, mat(C.roofBlue), 0, 0.49, 0.18));
    g.add(box(0.12, 0.18, 0.02, mat(C.woodDark), 0, 0.22, 0.35));
    // 晾鱼架: A 字架 + 横杆 + 挂着的鱼
    g.add(cyl(0.018, 0.02, 0.34, mat(C.woodDark), -0.3, 0.17, -0.28, 4));
    g.add(cyl(0.018, 0.02, 0.34, mat(C.woodDark), -0.14, 0.17, -0.28, 4));
    g.add(box(0.28, 0.03, 0.03, mat(C.wood), -0.22, 0.3, -0.28));
    for (const dx of [-0.28, -0.22, -0.16]) {
      g.add(box(0.045, 0.11, 0.02, mat(0x9fc8dd, { roughness: 0.5, metalness: 0.2 }), dx, 0.23, -0.28)); // 晾晒的鱼
      g.add(box(0.02, 0.04, 0.015, mat(0x7fb0c8, { roughness: 0.5 }), dx, 0.155, -0.28));
    }
    // 渔网堆 + 鱼篓 + 浮子
    const net = box(0.36, 0.02, 0.3, mat(0xdad5c5, { transparent: true, opacity: 0.85 }), 0.26, 0.16, -0.3);
    g.add(net);
    g.add(cyl(0.07, 0.05, 0.13, mat(C.strawDark), 0.36, 0.17, 0.36, 7));
    for (const [dx, dz, c] of [[-0.42, 0.05, 0xc0392b], [-0.46, -0.1, 0xf5d90a], [0.4, 0.02, 0x3a86b8]] as const) {
      g.add(sph(0.03, mat(c, { roughness: 0.6 }), dx, 0.155, dz, 5)); // 浮球
    }
    // 小木船 (侧翻晒网)
    const boat = new THREE.Group();
    boat.add(box(0.34, 0.05, 0.16, mat(C.wood), 0, 0.04, 0));
    boat.add(box(0.34, 0.07, 0.025, mat(C.woodDark), 0, 0.09, 0.07));
    boat.add(box(0.34, 0.07, 0.025, mat(C.woodDark), 0, 0.09, -0.07));
    boat.add(box(0.025, 0.07, 0.16, mat(C.woodDark), 0.17, 0.09, 0));
    boat.add(cone(0.09, 0.14, mat(C.wood), -0.24, 0.1, 0, 4));
    boat.position.set(-0.05, 0, -0.48);
    boat.rotation.y = 0.25;
    g.add(boat);
    return g;
  },
  greenhouse: () => {
    const g = new THREE.Group();
    g.add(box(0.94, 0.08, 0.94, mat(C.soil), 0, 0.04, 0));
    // 玻璃拱棚
    const glassMat = mat(0xbfe3f0, { roughness: 0.15, metalness: 0.1, transparent: true, opacity: 0.55 });
    const arch = cyl(0.42, 0.42, 0.9, glassMat, 0, 0.42, 0, 10);
    arch.rotation.z = Math.PI / 2;
    arch.scale.y = 0.62;
    g.add(arch);
    // 拱棚框架
    for (let i = 0; i < 4; i++) {
      const ring = new THREE.Mesh(new THREE.TorusGeometry(0.41, 0.012, 4, 12), mat(C.metal, { metalness: 0.5 }));
      ring.rotation.y = Math.PI / 2;
      ring.scale.y = 0.62;
      ring.position.set(-0.36 + i * 0.24, 0.42, 0);
      ring.castShadow = true;
      g.add(ring);
    }
    // 棚内作物
    const crops = new THREE.Group();
    for (let i = 0; i < 3; i++)
      for (let j = 0; j < 4; j++) {
        crops.add(box(0.1, 0.26, 0.1, mat(0x5fae4e), -0.25 + i * 0.25, 0.19, -0.3 + j * 0.2));
      }
    (crops as any).isCrops = true;
    g.add(crops);
    return g;
  },
  ifarm: () => {
    const g = new THREE.Group();
    g.add(box(0.96, 0.06, 0.96, mat(C.soil), 0, 0.03, 0));
    // 灌溉渠 (蓝色水带横穿田间 —— 区别于普通农田)
    g.add(box(0.96, 0.045, 0.12, mat(0x3a86b8, { roughness: 0.35, metalness: 0.1 }), 0, 0.06, 0.08));
    for (const dx of [-0.42, -0.14, 0.14, 0.42]) g.add(box(0.05, 0.06, 0.13, mat(C.metalDark), dx, 0.09, 0.08));
    // 嫩绿整齐的作物行
    const crops = new THREE.Group();
    for (let i = 0; i < 4; i++)
      for (let j = 0; j < 6; j++) {
        crops.add(box(0.1, 0.34, 0.1, mat(0x5fae4e), -0.33 + i * 0.22, 0.2, -0.4 + j * 0.14));
      }
    (crops as any).isCrops = true;
    g.add(crops);
    // 喷灌水塔
    g.add(cyl(0.055, 0.055, 0.55, mat(C.metal), 0.4, 0.3, -0.38, 6));
    g.add(cyl(0.11, 0.11, 0.16, mat(C.metalDark), 0.4, 0.66, -0.38, 8));
    // 旋转喷灌臂 (洒水)
    const arm = box(0.55, 0.03, 0.035, mat(0x5f87a3, { metalness: 0.4 }), 0.12, 0.56, -0.38);
    (arm as any).isStir = true;
    g.add(arm);
    for (const dx of [0.0, 0.16, 0.32]) g.add(sph(0.014, mat(0x8fd4f5, { transparent: true, opacity: 0.8 }), dx, 0.53, -0.38, 4));
    // 红色拖拉机 (加大)
    const tractor = new THREE.Group();
    tractor.add(box(0.24, 0.15, 0.14, mat(0xc0392b), 0, 0.16, 0));
    tractor.add(box(0.1, 0.12, 0.12, mat(0xc0392b), -0.12, 0.26, 0));
    tractor.add(box(0.08, 0.09, 0.02, mat(0x9fd4e8, { roughness: 0.2 }), -0.12, 0.27, 0.065));
    tractor.add(cyl(0.065, 0.065, 0.05, mat(0x2b2b2b), -0.06, 0.1, 0.075, 8));
    tractor.add(cyl(0.045, 0.045, 0.04, mat(0x2b2b2b), 0.07, 0.11, 0.075, 8));
    tractor.add(cyl(0.02, 0.02, 0.12, mat(0x333), 0.14, 0.24, 0.05, 4));
    tractor.position.set(-0.28, 0, 0.38);
    tractor.rotation.y = 0.8;
    (tractor as any).isAnimal = true;
    g.add(tractor);
    return g;
  },
  hydro: () => {
    const g = new THREE.Group();
    g.add(plinth(1, C.stoneDark));
    // 水培塔群: 白色立管 + 顶部水箱 + 伸出管壁的绿叶 (垂直农场一目了然)
    for (let i = 0; i < 3; i++) {
      const x = -0.28 + i * 0.28;
      g.add(cyl(0.12, 0.14, 1.05, mat(0xdfe8ec, { roughness: 0.4 }), x, 0.6, 0, 8));
      // 顶部水槽
      g.add(cyl(0.16, 0.16, 0.14, mat(0x5f87a3, { roughness: 0.5 }), x, 1.18, 0, 8));
      g.add(cyl(0.12, 0.12, 0.02, mat(0x8fd4f5, { roughness: 0.3 }), x, 1.26, 0, 8));
      // 层层伸出的植物杯 (十字交错)
      for (let lvl = 0; lvl < 3; lvl++) {
        const y = 0.35 + lvl * 0.26;
        for (let k = 0; k < 4; k++) {
          const a = k * Math.PI / 2 + lvl * 0.4 + i;
          const px = x + Math.cos(a) * 0.13, pz = Math.sin(a) * 0.13;
          g.add(sph(0.055, mat(0x6fae52, { roughness: 0.9 }), px, y, pz, 6));
          g.add(sph(0.038, mat(0x8bc34a, { roughness: 0.9 }), px + 0.03, y + 0.05, pz, 5));
        }
      }
    }
    // 营养液管路 (蓝色, 塔间串联)
    for (const dz of [-0.18, 0.18]) {
      const pipe = cyl(0.028, 0.028, 0.62, mat(0x3a86b8, { roughness: 0.5 }), 0, 0.2, dz, 6);
      pipe.rotation.z = Math.PI / 2;
      g.add(pipe);
    }
    g.add(box(0.12, 0.2, 0.12, mat(C.metalDark, { metalness: 0.4 }), 0.42, 0.16, 0.42)); // 控制柜
    g.add(box(0.08, 0.05, 0.015, mat(0x4ade80, { emissive: 0x4ade80, emissiveIntensity: 0.8 }), 0.42, 0.2, 0.483));
    return g;
  },

  // ================= 资源 =================
  lumber: () => {
    const g = new THREE.Group();
    g.add(plinth(1, C.dirt));
    for (let i = 0; i < 3; i++) {
      const log = cyl(0.08, 0.08, 0.6, mat(C.woodDark), (i - 1) * 0.17, 0.12, -0.24, 6);
      log.rotation.z = Math.PI / 2;
      g.add(log);
    }
    const log2 = cyl(0.08, 0.08, 0.6, mat(C.wood), 0, 0.26, -0.24, 6); log2.rotation.z = Math.PI / 2;
    g.add(log2);
    g.add(box(0.44, 0.4, 0.38, mat(C.woodLight), 0.18, 0.27, 0.18));
    g.add(gable(0.5, 0.44, 0.18, mat(C.woodDark), 0.18, 0.47, 0.18));
    const saw = cyl(0.09, 0.09, 0.03, mat(C.metal, { metalness: 0.6 }), 0.18, 0.44, 0.4, 10);
    (saw as any).isRotor = true;
    g.add(saw);
    return g;
  },
  workshop: () => {
    const g = new THREE.Group();
    g.add(plinth(1, C.dirt));
    // 石砌工坊主体
    g.add(box(0.6, 0.5, 0.5, mat(C.stone, { roughness: 1 }), -0.1, 0.32, 0));
    g.add(gable(0.66, 0.56, 0.24, mat(C.roofDark), -0.1, 0.57, 0));
    // 门廊
    g.add(box(0.3, 0.3, 0.24, mat(C.wood), 0.28, 0.22, 0.1));
    g.add(box(0.36, 0.04, 0.3, mat(C.straw), 0.28, 0.4, 0.1));
    // 展示的货品
    g.add(box(0.14, 0.12, 0.14, mat(C.woodLight), 0.32, 0.09, 0.34));
    g.add(sph(0.06, mat(0x8a6f4d), 0.12, 0.1, 0.38)); // 陶罐
    g.add(cyl(0.035, 0.035, 0.3, mat(C.woodDark), 0.4, 0.28, -0.32, 5)); // 木桩
    g.add(sph(0.05, mat(C.metal, { metalness: 0.5 }), 0.4, 0.46, -0.32));
    // 工作台
    g.add(box(0.26, 0.05, 0.16, mat(C.woodLight), -0.28, 0.3, 0.3));
    g.add(box(0.04, 0.28, 0.04, mat(C.woodDark), -0.36, 0.15, 0.26));
    g.add(box(0.04, 0.28, 0.04, mat(C.woodDark), -0.2, 0.15, 0.26));
    return g;
  },
  quarry: () => {
    const g = new THREE.Group();
    g.add(box(0.96, 0.2, 0.96, mat(C.stoneDark, { roughness: 1 }), 0, 0.1, 0));
    // 阶梯开采面
    g.add(box(0.7, 0.16, 0.6, mat(C.stone, { roughness: 1 }), -0.08, 0.28, -0.1));
    g.add(box(0.44, 0.14, 0.36, mat(0xa8b0b6, { roughness: 1 }), -0.08, 0.42, -0.12));
    g.add(sph(0.13, mat(0xb0b8bc), 0.28, 0.34, 0.2));
    g.add(sph(0.09, mat(0xa8b0b6), 0.42, 0.28, 0.06));
    g.add(box(0.28, 0.24, 0.24, mat(C.wood), 0.3, 0.32, -0.32)); // 工棚
    g.add(gable(0.34, 0.28, 0.13, mat(C.woodDark), 0.3, 0.44, -0.32));
    for (let i = 0; i < 4; i++) g.add(box(0.1, 0.1, 0.1, mat(C.stone), -0.14 + i * 0.13, 0.25, 0.36));
    // 铁镐
    g.add(cyl(0.014, 0.014, 0.34, mat(C.wood), 0.14, 0.3, 0.2, 4));
    return g;
  },
  sawmill: () => {
    const g = new THREE.Group();
    g.add(plinth(1, C.dirt));
    g.add(box(0.7, 0.42, 0.48, mat(C.wood, { roughness: 1 }), -0.08, 0.28, 0.05));
    g.add(gable(0.78, 0.56, 0.2, mat(C.roofDark), -0.08, 0.49, 0.05));
    // 大圆锯 (外露传动)
    const saw = cyl(0.14, 0.14, 0.025, mat(C.metal, { metalness: 0.7, roughness: 0.3 }), 0.32, 0.36, 0.18, 12);
    (saw as any).isRotor = true;
    g.add(saw);
    // 蒸汽机烟囱
    g.add(cyl(0.05, 0.07, 0.55, mat(0x33383d, { metalness: 0.4 }), -0.28, 0.75, -0.12, 7));
    (g as any).smokeSpots = [new THREE.Vector3(-0.28, 1.05, -0.12)];
    // 原木堆
    for (let i = 0; i < 3; i++) {
      const log = cyl(0.075, 0.075, 0.55, mat(i % 2 ? C.woodDark : C.wood), -0.1 + i * 0.0, 0.1 + 0, -0.32, 6);
      log.rotation.z = Math.PI / 2;
      log.position.x = 0.0;
      log.position.y = 0.1;
      g.add(log);
    }
    const log2 = cyl(0.075, 0.075, 0.55, mat(C.woodLight), 0, 0.24, -0.32, 6); log2.rotation.z = Math.PI / 2;
    g.add(log2);
    return g;
  },
  mine: () => {
    const g = new THREE.Group();
    g.add(plinth(1, C.stoneDark));
    g.add(box(0.34, 0.5, 0.14, mat(C.woodDark), 0, 0.32, -0.32)); // 支撑架
    g.add(box(0.42, 0.09, 0.2, mat(C.wood), 0, 0.6, -0.32));
    g.add(box(0.38, 0.46, 0.07, mat(0x2b2b2b), 0, 0.28, -0.25)); // 洞口
    // 矿车轨道
    g.add(box(0.04, 0.025, 0.5, mat(C.metal, { metalness: 0.7 }), -0.08, 0.09, 0.05));
    g.add(box(0.04, 0.025, 0.5, mat(C.metal, { metalness: 0.7 }), 0.08, 0.09, 0.05));
    const cart = box(0.18, 0.12, 0.14, mat(0x8a4a2a), 0, 0.16, 0.18);
    (cart as any).isCart = true;
    g.add(cart);
    g.add(sph(0.05, mat(0xd9a536, { metalness: 0.4 }), 0.3, 0.12, 0.34, 5));
    g.add(sph(0.04, mat(0x7dd3fc, { metalness: 0.4 }), 0.38, 0.1, 0.28, 5));
    return g;
  },
  deep_mine: () => {
    const g = new THREE.Group();
    g.add(plinth(2, C.stoneDark));
    // 钢井架 (2×2, 高效机械化矿井)
    for (const [dx, dz] of [[-0.42, -0.3], [0.42, -0.3], [-0.42, 0.3], [0.42, 0.3]] as const) {
      const leg = cyl(0.05, 0.05, 2.1, mat(0x4a5056, { metalness: 0.5 }), dx * 0.85, 1.12, dz * 0.85, 4);
      leg.rotation.x = -dz * 0.28; leg.rotation.z = dx * 0.28;
      g.add(leg);
    }
    g.add(box(0.78, 0.08, 0.08, mat(0x4a5056, { metalness: 0.5 }), 0, 1.7, 0));
    g.add(box(0.08, 0.08, 0.78, mat(0x4a5056, { metalness: 0.5 }), 0, 1.7, 0));
    g.add(box(0.56, 0.12, 0.56, mat(C.metalDark), 0, 2.18, 0));
    // 升降机笼
    const cage = box(0.26, 0.36, 0.22, mat(0xc0392b), 0, 0.9, 0);
    (cage as any).isPump = true;
    g.add(cage);
    // 矿石传送带
    g.add(box(0.95, 0.08, 0.22, mat(0x50565c), 0.55, 0.5, 0.55));
    g.add(box(0.9, 0.03, 0.18, mat(0x2b2b2b), 0.55, 0.55, 0.55));
    for (const dx of [0.25, 0.55, 0.85]) g.add(sph(0.07, mat(0xd9a536), dx, 0.62, 0.55, 4));
    // 卷扬机房
    g.add(box(0.46, 0.42, 0.38, mat(0x8d99a4), -0.65, 0.32, 0.62));
    g.add(box(0.52, 0.06, 0.44, mat(C.roofDark), -0.65, 0.56, 0.62));
    // 矿车
    g.add(box(0.3, 0.16, 0.2, mat(0x50565c), -0.55, 0.14, -0.6));
    g.add(box(0.26, 0.1, 0.16, mat(0x2b2b2b), -0.55, 0.26, -0.6));
    return g;
  },
  derrick: () => {
    const g = new THREE.Group();
    g.add(plinth(1, C.dirt));
    for (const [dx, dz] of [[-0.2, -0.2], [0.2, -0.2], [-0.2, 0.2], [0.2, 0.2]] as const) {
      const leg = cyl(0.026, 0.026, 1.1, mat(C.metalDark), dx * 0.8, 0.58, dz * 0.8, 4);
      leg.rotation.x = -dz * 0.5; leg.rotation.z = dx * 0.5;
      g.add(leg);
    }
    g.add(box(0.44, 0.05, 0.05, mat(C.metalDark), 0, 0.38, 0));
    g.add(box(0.05, 0.05, 0.44, mat(C.metalDark), 0, 0.38, 0));
    g.add(box(0.4, 0.08, 0.4, mat(C.metalDark), 0, 1.14, 0));
    const pump = box(0.22, 0.09, 0.12, mat(0xc0392b), 0, 1.24, 0);
    (pump as any).isPump = true;
    g.add(pump);
    g.add(box(0.26, 0.22, 0.22, mat(0x50565c), -0.34, 0.17, 0.32)); // 储油罐
    g.add(cyl(0.055, 0.055, 0.12, mat(0x333), -0.34, 0.33, 0.32, 8));
    return g;
  },
  refinery: () => {
    const g = new THREE.Group();
    g.add(plinth(2, C.stoneDark));
    // 精馏塔 ×2
    for (const dx of [-0.55, -0.15]) {
      g.add(cyl(0.13, 0.14, 1.3, mat(0xc8ccd0, { roughness: 0.5, metalness: 0.3 }), dx, 0.71, -0.4, 10));
      g.add(cyl(0.05, 0.05, 0.2, mat(C.metalDark), dx, 1.44, -0.4, 6));
      // 塔顶火苗
      const flare = cone(0.05, 0.14, mat(0xfab005, { emissive: 0xfab005, emissiveIntensity: 2 }), dx, 1.58, -0.4, 5);
      (flare as any).isFlame = true;
      g.add(flare);
    }
    // 卧式储罐
    for (let i = 0; i < 3; i++) {
      const tank = cyl(0.14, 0.14, 0.5, mat(0xd8dde0, { roughness: 0.45, metalness: 0.3 }), 0.35 + (i === 2 ? 0 : 0), 0.2, -0.5 + i * 0.32, 10);
      tank.rotation.z = Math.PI / 2;
      g.add(tank);
    }
    // 管廊
    for (let i = 0; i < 4; i++) {
      const pipe = cyl(0.025, 0.025, 1.2, mat(i % 2 ? 0xc0392b : 0x9aa3ab, { metalness: 0.4 }), -0.3, 0.16 + i * 0.06, 0.3, 6);
      pipe.rotation.z = Math.PI / 2;
      g.add(pipe);
    }
    for (const dx of [-0.8, -0.3, 0.2, 0.7]) g.add(box(0.04, 0.3, 0.04, mat(C.metalDark), dx, 0.15, 0.3));
    // 控制室
    const ctrl = winBox(0.5, 0.34, 0.36, 'ref', 3, 2, 0.6, '#9fb4be');
    ctrl.position.set(0.45, 0.24, 0.55); g.add(ctrl);
    g.add(box(0.56, 0.05, 0.42, mat(C.roofDark), 0.45, 0.44, 0.55));
    (g as any).smokeSpots = [new THREE.Vector3(-0.15, 1.5, -0.4)];
    return g;
  },

  // ================= 电力 =================
  coal_plant: () => {
    const g = new THREE.Group();
    g.add(plinth(2, C.stoneDark));
    g.add(box(1.0, 0.62, 0.8, mat(C.brick, { roughness: 1 }), -0.32, 0.38, -0.2)); // 厂房
    g.add(gable(1.08, 0.88, 0.16, mat(C.roofDark), -0.32, 0.69, -0.2));
    const win = winBox(0.56, 0.34, 0.1, 'coalw', 4, 2, 0.3, '#8a5a44');
    win.position.set(-0.32, 0.32, 0.22); g.add(win);
    // 大烟囱 ×2 (加高冒浓烟)
    for (const dx of [-0.08, 0.4]) {
      g.add(cyl(0.09, 0.13, 1.85, mat(C.stone, { roughness: 1 }), dx, 1.05, -0.62, 8));
      g.add(cyl(0.1, 0.09, 0.08, mat(C.roofRed), dx, 1.98, -0.62, 8));
    }
    // 冷却塔 (宏伟双曲线)
    const points: THREE.Vector2[] = [];
    for (let i = 0; i <= 10; i++) {
      const t = i / 10;
      points.push(new THREE.Vector2(0.3 - 0.12 * Math.sin(t * Math.PI) + 0.09 * t, t * 1.75));
    }
    const tower = new THREE.Mesh(new THREE.LatheGeometry(points, 14), mat(0xcfd6da, { roughness: 0.9 }));
    tower.position.set(0.62, 0.07, 0.45); tower.castShadow = true;
    g.add(tower);
    (g as any).smokeSpots = [new THREE.Vector3(-0.08, 2.02, -0.62), new THREE.Vector3(0.4, 2.02, -0.62)];
    return g;
  },
  wind: () => {
    const g = new THREE.Group();
    g.add(cyl(0.045, 0.07, 1.2, mat(C.white, { roughness: 0.6 }), 0, 0.64, 0, 8));
    const rotor = new THREE.Group();
    rotor.position.set(0, 1.24, 0.07);
    for (let i = 0; i < 3; i++) {
      const blade = box(0.06, 0.58, 0.014, mat(C.white, { roughness: 0.5 }), 0, 0.29, 0);
      const arm = new THREE.Group();
      arm.rotation.z = (i * Math.PI * 2) / 3;
      arm.add(blade);
      rotor.add(arm);
    }
    rotor.add(sph(0.05, mat(C.metal), 0, 0, 0, 6));
    (rotor as any).isWindRotor = true;
    g.add(rotor);
    g.add(cyl(0.11, 0.13, 0.12, mat(0x9aa3ab), 0, 0.06, 0, 8));
    return g;
  },
  solar: () => {
    const g = new THREE.Group();
    g.add(box(0.94, 0.06, 0.94, mat(0x6e6258, { roughness: 1 }), 0, 0.03, 0));
    // 光伏板阵列 (倾斜朝南)
    for (let i = 0; i < 3; i++)
      for (let j = 0; j < 3; j++) {
        const panel = box(0.26, 0.02, 0.2, mat(0x1d3a5f, { roughness: 0.3, metalness: 0.5 }), -0.3 + i * 0.3, 0.22, -0.3 + j * 0.3);
        panel.rotation.x = 0.35;
        g.add(panel);
        // 支架
        g.add(cyl(0.014, 0.014, 0.18, mat(C.metalDark), -0.3 + i * 0.3, 0.12, -0.36 + j * 0.3, 4));
      }
    // 逆变器柜
    g.add(box(0.14, 0.22, 0.12, mat(0x50565c, { metalness: 0.4 }), 0.4, 0.17, 0.4));
    g.add(box(0.1, 0.06, 0.02, mat(0x4ade80, { emissive: 0x4ade80, emissiveIntensity: 0.8 }), 0.4, 0.2, 0.465));
    return g;
  },
  geothermal: () => {
    const g = new THREE.Group();
    g.add(plinth(2, C.stoneDark));
    // 钻井井口 (居中布局)
    g.add(cyl(0.16, 0.18, 0.5, mat(0x9aa3ab, { roughness: 0.6, metalness: 0.4 }), -0.5, 0.32, -0.35, 10));
    g.add(cyl(0.1, 0.1, 0.14, mat(0x50565c, { metalness: 0.5 }), -0.5, 0.62, -0.35, 8));
    // 汽轮机厂房 (回中)
    const hall = winBox(0.92, 0.5, 0.72, 'geo', 5, 3, 0.6, '#aab8b0');
    hall.position.set(0.16, 0.32, -0.12); g.add(hall);
    g.add(box(1.0, 0.06, 0.8, mat(C.roofDark), 0.16, 0.6, -0.12));
    // 蒸汽白烟
    (g as any).smokeSpots = [new THREE.Vector3(-0.5, 0.7, -0.35)];
    // 管道 (井口 → 厂房)
    for (const dz of [-0.04, 0.06]) {
      const pipe = cyl(0.035, 0.035, 0.7, mat(0xd8dde0, { metalness: 0.4, roughness: 0.4 }), -0.12, 0.24, dz, 6);
      pipe.rotation.z = Math.PI / 2;
      g.add(pipe);
    }
    // 散热格栅 (前排居中)
    g.add(box(0.7, 0.36, 0.08, mat(0x50565c, { metalness: 0.3 }), 0.1, 0.24, 0.3));
    // 地热标识: 地面裂纹微光
    for (let i = 0; i < 3; i++) {
      g.add(box(0.22 + i * 0.1, 0.012, 0.02, mat(0xe8590c, { emissive: 0xe8590c, emissiveIntensity: 0.8, roughness: 0.6 }), 0.3 - i * 0.14, 0.075, 0.52 - i * 0.1));
    }
    return g;
  },
  nuclear: () => {
    const g = new THREE.Group();
    g.add(plinth(2, C.stoneDark));
    // 双冷却塔 (高耸入云: 3.4 单位, 远超树木)
    for (const dx of [-0.52, 0.52]) {
      const points: THREE.Vector2[] = [];
      for (let i = 0; i <= 12; i++) {
        const t = i / 12;
        points.push(new THREE.Vector2(0.34 - 0.12 * Math.sin(t * Math.PI) + 0.1 * t, t * 3.4));
      }
      const tower = new THREE.Mesh(new THREE.LatheGeometry(points, 18), mat(0xd8dee2, { roughness: 0.9 }));
      tower.position.set(dx, 0.07, 0.5); tower.castShadow = true; tower.receiveShadow = true;
      g.add(tower);
      // 塔顶水汽
      const steam = sph(0.16, mat(0xffffff, { transparent: true, opacity: 0.5, roughness: 1 }), dx, 3.55, 0.5, 6);
      (steam as any).isFountain = true;
      g.add(steam);
    }
    // 安全壳穹顶 (加大)
    const dome = cyl(0.42, 0.45, 0.95, mat(0xcfd6da, { roughness: 0.8 }), -0.55, 0.55, -0.45, 16);
    g.add(dome);
    const cap = sph(0.42, mat(0xcfd6da, { roughness: 0.8 }), -0.55, 1.0, -0.45, 14);
    g.add(cap);
    // 汽轮机厂房 (长条)
    const ctrl = winBox(0.9, 0.5, 0.5, 'nuke', 5, 3, 0.55, '#8fa3ad');
    ctrl.position.set(0.4, 0.32, -0.5); g.add(ctrl);
    g.add(box(0.98, 0.05, 0.58, mat(C.roofDark), 0.4, 0.59, -0.5));
    // 高压电线架
    for (const dx of [-0.8, 0.8]) {
      g.add(cyl(0.028, 0.028, 1.5, mat(C.metal, { metalness: 0.5 }), dx, 0.82, -0.05, 5));
      g.add(box(0.3, 0.03, 0.03, mat(C.metal, { metalness: 0.5 }), dx, 1.5, -0.05));
    }
    g.add(box(0.8, 0.04, 0.04, mat(0xf5d90a), -0.55, 1.32, -0.45)); // 警示条
    (g as any).smokeSpots = [new THREE.Vector3(-0.52, 3.6, 0.5), new THREE.Vector3(0.52, 3.6, 0.5)];
    g.scale.setScalar(1.5); // 3×3 巨型核电站
    (g as any).smokeSpots = (g as any).smokeSpots.map((s: THREE.Vector3) => s.multiplyScalar(1.5));
    return g;
  },

  // ================= 供水 =================
  well: () => {
    const g = new THREE.Group();
    g.add(cyl(0.24, 0.27, 0.24, mat(C.stone), 0, 0.16, 0, 9));
    g.add(cyl(0.19, 0.19, 0.025, mat(0x2e6b9e, { roughness: 0.3, metalness: 0.1 }), 0, 0.27, 0, 9));
    for (const dx of [-0.19, 0.19]) g.add(box(0.05, 0.56, 0.05, mat(C.woodDark), dx, 0.48, 0));
    g.add(gable(0.52, 0.5, 0.12, mat(C.straw, { roughness: 1 }), 0, 0.76, 0));
    g.add(cyl(0.012, 0.012, 0.5, mat(0x4a4a4a), 0, 0.6, 0, 4));
    g.add(cyl(0.05, 0.04, 0.08, mat(C.wood), 0, 0.4, 0, 6));
    // 石台
    g.add(box(0.5, 0.06, 0.5, mat(C.stoneDark, { roughness: 1 }), 0, 0.03, 0));
    return g;
  },
  water_tower: () => {
    const g = new THREE.Group();
    for (const [dx, dz] of [[-0.18, -0.18], [0.18, -0.18], [-0.18, 0.18], [0.18, 0.18]] as const) {
      const leg = cyl(0.024, 0.03, 1.0, mat(C.metalDark), dx, 0.53, dz, 4);
      leg.rotation.x = -dz * 0.14; leg.rotation.z = dx * 0.14;
      g.add(leg);
    }
    // 交叉撑
    g.add(box(0.42, 0.03, 0.03, mat(C.metalDark), 0, 0.35, -0.16));
    g.add(box(0.42, 0.03, 0.03, mat(C.metalDark), 0, 0.35, 0.16));
    g.add(box(0.03, 0.03, 0.42, mat(C.metalDark), -0.16, 0.5, 0));
    g.add(box(0.03, 0.03, 0.42, mat(C.metalDark), 0.16, 0.5, 0));
    g.add(cyl(0.28, 0.28, 0.42, mat(0x5f87a3, { roughness: 0.6 }), 0, 1.24, 0, 12));
    g.add(cone(0.3, 0.16, mat(0x48697e, { roughness: 0.6 }), 0, 1.53, 0, 12));
    g.add(box(0.4, 0.04, 0.4, mat(C.metalDark), 0, 1.02, 0));
    const pipe = cyl(0.035, 0.035, 1.0, mat(0x8fb9cc, { metalness: 0.3 }), 0.28, 0.5, 0.28, 6);
    g.add(pipe);
    // 水位标
    g.add(box(0.02, 0.3, 0.02, mat(0xf5d90a), 0.29, 1.2, 0.29));
    return g;
  },
  treatment: () => {
    const g = new THREE.Group();
    g.add(plinth(2, C.stoneDark));
    for (const dx of [-0.45, 0.15]) {
      g.add(cyl(0.34, 0.36, 0.22, mat(0xb8bec4), dx, 0.18, 0.36, 16));
      g.add(cyl(0.3, 0.3, 0.025, mat(0x3a86b8, { roughness: 0.3 }), dx, 0.3, 0.36, 16));
      const arm = box(0.5, 0.025, 0.06, mat(C.metalDark), dx, 0.36, 0.36);
      (arm as any).isStir = true;
      g.add(arm);
      // 曝气泡
      for (let i = 0; i < 3; i++) {
        const b = sph(0.03, mat(0x8fd4f5, { transparent: true, opacity: 0.7 }), dx - 0.1 + i * 0.1, 0.31, 0.36, 4);
        (b as any).isFountain = true;
        g.add(b);
      }
    }
    const lab = winBox(0.78, 0.5, 0.48, 'treat', 5, 3, 0.5, '#9fb4be');
    lab.position.set(-0.15, 0.32, -0.42); g.add(lab);
    g.add(box(0.86, 0.06, 0.56, mat(C.roofDark), -0.15, 0.6, -0.42));
    // 氯瓶与管道
    g.add(cyl(0.07, 0.07, 0.22, mat(0xf5d90a), 0.66, 0.18, -0.3, 8));
    const pipe = cyl(0.03, 0.03, 0.9, mat(0x707a84, { metalness: 0.4 }), 0.62, 0.14, 0, 6);
    g.add(pipe);
    return g;
  },

  // ================= 照明 =================
  torch: () => {
    const g = new THREE.Group();
    // 底座石堆
    for (let i = 0; i < 5; i++) {
      const a = (i / 5) * Math.PI * 2 + 0.3;
      g.add(sph(0.055, mat(C.stoneDark), Math.cos(a) * 0.11, 0.045, Math.sin(a) * 0.11, 5));
    }
    // 木桩 (略粗)
    const pole = cyl(0.032, 0.045, 0.74, mat(C.woodDark), 0, 0.4, 0, 5);
    pole.rotation.z = 0.04;
    g.add(pole);
    // 铁箍 + 缠布火头 (加大)
    g.add(cyl(0.05, 0.05, 0.05, mat(C.metalDark), 0, 0.76, 0, 6));
    const wrap = cyl(0.058, 0.044, 0.16, mat(0xc9a06a), 0, 0.85, 0, 6);
    g.add(wrap);
    // 火焰 (发光, 夜间闪烁)
    const flame = cone(0.085, 0.28, mat(C.fireRed, { emissive: 0xe8590c, emissiveIntensity: 1.8, roughness: 0.4 }), 0, 1.05, 0, 6);
    const flame2 = cone(0.048, 0.17, mat(C.fireYellow, { emissive: 0xfab005, emissiveIntensity: 2.2, roughness: 0.4 }), 0, 1.1, 0, 6);
    (flame as any).isFlame = true; (flame2 as any).isFlame = true;
    g.add(flame, flame2);
    return g;
  },
  oil_lamp: () => {
    const g = new THREE.Group();
    // 基座 (双层台阶)
    g.add(cyl(0.11, 0.14, 0.08, mat(C.stoneDark), 0, 0.04, 0, 7));
    g.add(cyl(0.08, 0.1, 0.05, mat(C.stone), 0, 0.1, 0, 7));
    // 铸铁灯柱
    g.add(cyl(0.024, 0.032, 1.02, mat(C.metalDark, { metalness: 0.5, roughness: 0.6 }), 0, 0.62, 0, 6));
    // 柱头托盘
    g.add(cyl(0.06, 0.045, 0.05, mat(C.metalDark, { metalness: 0.5 }), 0, 1.14, 0, 7));
    // 玻璃灯箱 (加大, 四面体)
    g.add(box(0.14, 0.19, 0.14, mat(0x8fb9cc, { transparent: true, opacity: 0.45, roughness: 0.15 }), 0, 1.27, 0));
    // 火苗 (加大)
    const flame = sph(0.045, mat(C.fireYellow, { emissive: 0xfab005, emissiveIntensity: 2.4, roughness: 0.4 }), 0, 1.27, 0, 6);
    (flame as any).isFlame = true;
    g.add(flame);
    // 灯罩尖顶 + 顶球
    g.add(cone(0.11, 0.12, mat(C.metalDark, { metalness: 0.5 }), 0, 1.43, 0, 4));
    g.add(sph(0.02, mat(C.gold, { metalness: 0.6 }), 0, 1.51, 0, 5));
    // 横臂挂小牌 (灯油铺幌子)
    const arm = cyl(0.012, 0.012, 0.22, mat(C.metalDark, { metalness: 0.5 }), 0.1, 1.05, 0, 4);
    arm.rotation.z = Math.PI / 2;
    g.add(arm);
    g.add(box(0.1, 0.07, 0.012, mat(0xd9b36a), 0.2, 0.98, 0));
    return g;
  },
  street_lamp: () => {
    const g = new THREE.Group();
    g.add(cyl(0.1, 0.13, 0.08, mat(C.concrete), 0, 0.04, 0, 7));
    // 弯管灯柱
    g.add(cyl(0.024, 0.03, 1.5, mat(C.metalDark, { metalness: 0.6, roughness: 0.45 }), 0, 0.82, 0, 6));
    const arm = cyl(0.02, 0.024, 0.34, mat(C.metalDark, { metalness: 0.6, roughness: 0.45 }), 0.16, 1.56, 0, 6);
    arm.rotation.z = Math.PI / 2 - 0.35;
    g.add(arm);
    // 灯头外壳
    g.add(box(0.15, 0.07, 0.11, mat(C.metalDark, { metalness: 0.6, roughness: 0.4 }), 0.3, 1.62, 0));
    // LED 灯珠 (自发光, 夜间点亮由渲染器控制)
    const bulb = box(0.12, 0.035, 0.08, mat(0xfff4d6, { emissive: 0xffe9b0, emissiveIntensity: 1.5 }), 0.3, 1.585, 0);
    (bulb as any).isWindowMesh = true; // 夜间点亮
    g.add(bulb);
    // 检修脚扣
    for (let i = 0; i < 3; i++) g.add(box(0.05, 0.015, 0.015, mat(C.metal), 0, 0.35 + i * 0.4, 0.033));
    return g;
  },
  floodlight: () => {
    const g = new THREE.Group();
    g.add(cyl(0.13, 0.17, 0.1, mat(C.concrete), 0, 0.05, 0, 8));
    // 格构塔架 (中灰, 远看不清爽的问题修复)
    const th = 1.9;
    const legMat = mat(0x9aa2a8, { metalness: 0.45, roughness: 0.5 });
    for (const [dx, dz] of [[-0.1, -0.1], [0.1, -0.1], [-0.1, 0.1], [0.1, 0.1]] as const) {
      const leg = cyl(0.018, 0.024, th, legMat, dx * (1 - th * 0.16), 0.1 + th / 2, dz * (1 - th * 0.16), 5);
      leg.rotation.z = dx > 0 ? -0.09 : 0.09;
      leg.rotation.x = dz > 0 ? 0.09 : -0.09;
      g.add(leg);
    }
    // 横撑
    for (let f = 1; f <= 3; f++) {
      const y = 0.1 + (th * f) / 3.4;
      const s = 1 - f * 0.13;
      g.add(box(0.2 * s, 0.02, 0.02, legMat, 0, y, 0.1 * s));
      g.add(box(0.2 * s, 0.02, 0.02, legMat, 0, y, -0.1 * s));
      g.add(box(0.02, 0.02, 0.2 * s, legMat, 0.1 * s, y, 0));
      g.add(box(0.02, 0.02, 0.2 * s, legMat, -0.1 * s, y, 0));
    }
    // 顶部平台
    g.add(box(0.32, 0.04, 0.32, mat(0x8a9298, { metalness: 0.45 }), 0, 0.1 + th, 0));
    // 大面板灯组: 2×2 灯板统一朝前下方 (体育场泛光灯) —— 替代旧十字布局
    const bank = new THREE.Group();
    bank.position.set(0, 0.1 + th + 0.16, 0.02);
    bank.rotation.x = -0.5;               // 明显朝下照
    for (const [dx, dy] of [[-0.09, 0.07], [0.09, 0.07], [-0.09, -0.07], [0.09, -0.07]] as const) {
      const panel = box(0.15, 0.12, 0.03, mat(0xf2f2ee, { emissive: 0xdfe8ff, emissiveIntensity: 1.6 }), dx, dy, 0.02);
      (panel as any).isWindowMesh = true;
      bank.add(panel);
    }
    // 灯组背板框架
    bank.add(box(0.38, 0.3, 0.02, mat(0x8a9298, { metalness: 0.45 }), 0, 0, -0.005));
    g.add(bank);
    // 支撑斜撑
    g.add(box(0.03, 0.2, 0.03, legMat, 0, 0.1 + th + 0.06, 0.1).rotateX(0.5) as THREE.Mesh);
    // 航空警示红灯
    g.add(sph(0.025, mat(0xc0392b, { emissive: 0xc0392b, emissiveIntensity: 2 }), 0, 0.1 + th + 0.34, 0, 5));
    return g;
  },

  // ================= 市政 =================
  campfire: () => {
    const g = new THREE.Group();
    for (let i = 0; i < 5; i++) {
      const a = (i / 5) * Math.PI * 2;
      const log = cyl(0.035, 0.035, 0.38, mat(C.woodDark), Math.cos(a) * 0.12, 0.06, Math.sin(a) * 0.12, 5);
      log.rotation.z = Math.PI / 2.4; log.rotation.y = a;
      g.add(log);
    }
    for (let i = 0; i < 6; i++) {
      const s = sph(0.055, mat(C.stone), Math.cos(i * 1.05) * 0.28, 0.035, Math.sin(i * 1.05) * 0.28, 5);
      g.add(s);
    }
    const flame = cone(0.11, 0.3, mat(0xe8590c, { emissive: 0xe8590c, emissiveIntensity: 1.6, roughness: 0.4 }), 0, 0.2, 0, 6);
    const flame2 = cone(0.06, 0.19, mat(0xfab005, { emissive: 0xfab005, emissiveIntensity: 2, roughness: 0.4 }), 0, 0.25, 0, 6);
    (flame as any).isFlame = true; (flame2 as any).isFlame = true;
    g.add(flame, flame2);
    // 周围坐垫圆木
    for (let i = 0; i < 3; i++) {
      const a = i * 2.1 + 0.5;
      const seat = cyl(0.06, 0.06, 0.3, mat(C.wood), Math.cos(a) * 0.5, 0.07, Math.sin(a) * 0.5, 6);
      seat.rotation.z = Math.PI / 2; seat.rotation.y = a;
      g.add(seat);
    }
    return g;
  },
  totem: () => {
    const g = new THREE.Group();
    g.add(cyl(0.11, 0.14, 0.28, mat(C.stoneDark), 0, 0.14, 0, 7));
    const pole = cyl(0.1, 0.12, 1.0, mat(C.woodDark), 0, 0.78, 0, 6);
    g.add(pole);
    g.add(box(0.3, 0.24, 0.17, mat(C.wood), 0, 0.56, 0));
    g.add(box(0.34, 0.22, 0.15, mat(C.wood), 0, 0.86, 0));
    g.add(box(0.27, 0.18, 0.16, mat(C.wood), 0, 1.12, 0));
    g.add(box(0.07, 0.06, 0.19, mat(0xe8dcc5), -0.13, 0.58, 0));
    g.add(box(0.07, 0.06, 0.19, mat(0xe8dcc5), 0.13, 0.58, 0));
    g.add(cone(0.07, 0.14, mat(0xd9a536), 0, 1.3, 0, 5));
    g.add(box(0.06, 0.06, 0.06, mat(0xc0392b), 0, 0.92, 0.09));
    // 羽毛装饰
    g.add(box(0.02, 0.16, 0.05, mat(0xe8590c), -0.17, 1.0, 0));
    g.add(box(0.02, 0.16, 0.05, mat(0xe8590c), 0.17, 1.0, 0));
    return g;
  },
  granary: () => {
    const g = new THREE.Group();
    g.add(plinth(1, C.soil));
    // 架高粮仓 (防潮)
    for (const [dx, dz] of [[-0.25, -0.25], [0.25, -0.25], [-0.25, 0.25], [0.25, 0.25]] as const) {
      g.add(cyl(0.035, 0.04, 0.28, mat(C.woodDark), dx, 0.14, dz, 4));
    }
    g.add(cyl(0.34, 0.38, 0.56, mat(C.straw, { roughness: 1 }), 0, 0.56, 0, 9));
    g.add(cone(0.42, 0.32, mat(C.strawDark), 0, 1.0, 0, 9));
    g.add(box(0.14, 0.2, 0.03, mat(C.woodDark), 0, 0.42, 0.37));
    // 麻袋
    g.add(sph(0.07, mat(0xc9a06a), 0.36, 0.08, 0.3));
    g.add(sph(0.06, mat(0xb8944f), 0.28, 0.07, 0.38));
    return g;
  },
  warehouse: () => {
    const g = new THREE.Group();
    g.add(plinth(1, C.stoneDark));
    g.add(box(0.86, 0.5, 0.66, mat(0x8d99a4, { roughness: 0.9 }), 0, 0.32, 0));
    const roof = cyl(0.33, 0.33, 0.88, mat(0xb04a3a, { roughness: 0.8 }), 0, 0.57, 0, 14);
    roof.rotation.z = Math.PI / 2;
    g.add(roof);
    // 卷帘门
    g.add(box(0.22, 0.3, 0.025, mat(0x6a7480), -0.16, 0.2, 0.335));
    g.add(box(0.22, 0.3, 0.025, mat(0x6a7480), 0.16, 0.2, 0.335));
    for (let i = 0; i < 4; i++) {
      g.add(box(0.22, 0.015, 0.028, mat(0x50565c), -0.16, 0.1 + i * 0.07, 0.336));
      g.add(box(0.22, 0.015, 0.028, mat(0x50565c), 0.16, 0.1 + i * 0.07, 0.336));
    }
    // 木箱与叉车货位
    g.add(box(0.11, 0.11, 0.11, mat(0xc9a06a), 0.36, 0.13, 0.34));
    g.add(box(0.11, 0.11, 0.11, mat(0xb8944f), 0.36, 0.24, 0.34));
    g.add(box(0.11, 0.11, 0.11, mat(0xc9a06a), 0.24, 0.13, 0.38));
    return g;
  },
  church: () => {
    const g = new THREE.Group();
    g.add(plinth(1, C.stoneDark));
    // 中殿
    g.add(box(0.5, 0.6, 0.72, mat(0xd8d0c0, { roughness: 0.95 }), -0.14, 0.37, 0));
    g.add(gable(0.56, 0.8, 0.28, mat(C.roofDark), -0.14, 0.67, 0));
    // 钟塔 (更高)
    g.add(box(0.22, 1.05, 0.22, mat(0xd8d0c0, { roughness: 0.95 }), 0.28, 0.6, 0));
    g.add(box(0.26, 0.05, 0.26, mat(C.roofDark), 0.28, 1.15, 0));
    g.add(cone(0.17, 0.34, mat(C.roofDark), 0.28, 1.35, 0, 4));
    // 大十字 (塔尖加大, 远看可辨)
    g.add(box(0.05, 0.22, 0.025, mat(C.gold, { metalness: 0.5, emissive: 0x4a3a10, emissiveIntensity: 0.3 }), 0.28, 1.68, 0));
    g.add(box(0.13, 0.05, 0.025, mat(C.gold, { metalness: 0.5, emissive: 0x4a3a10, emissiveIntensity: 0.3 }), 0.28, 1.71, 0));
    g.add(cyl(0.012, 0.012, 0.18, mat(C.gold, { metalness: 0.6 }), 0.28, 1.52, 0, 4));
    // 钟窗 (黑色尖拱)
    g.add(box(0.1, 0.16, 0.02, mat(0x2b2b2b), 0.28, 0.92, 0.115));
    g.add(cone(0.05, 0.06, mat(0x2b2b2b), 0.28, 1.03, 0.115, 4));
    // 大门 (尖拱)
    g.add(box(0.16, 0.3, 0.03, mat(C.woodDark), -0.14, 0.19, 0.365));
    g.add(cone(0.09, 0.1, mat(C.woodDark), -0.14, 0.39, 0.365, 4));
    // 玫瑰圆窗 (彩色发光)
    const rose = cyl(0.075, 0.075, 0.015, mat(0x5f87a3, { emissive: 0x2a4a6a, emissiveIntensity: 0.4 }), -0.14, 0.48, 0.368, 10);
    rose.rotation.x = Math.PI / 2;
    g.add(rose);
    g.add(box(0.04, 0.04, 0.017, mat(0xc0392b, { emissive: 0x5a1a1a }), -0.14, 0.48, 0.369));
    g.add(box(0.017, 0.04, 0.04, mat(0xc0392b, { emissive: 0x5a1a1a }), -0.14, 0.48, 0.369));
    // 侧窗
    g.add(box(0.08, 0.16, 0.02, mat(0x5f87a3, { emissive: 0x2a4a6a }), -0.34, 0.45, 0.26));
    g.add(box(0.08, 0.16, 0.02, mat(0x5f87a3, { emissive: 0x2a4a6a }), 0.02, 0.45, 0.26));
    return g;
  },
  market: () => {
    const g = new THREE.Group();
    g.add(plinth(1, 0x9a9488));
    for (const dx of [-0.24, 0.24]) {
      g.add(box(0.42, 0.07, 0.34, mat(C.woodDark), dx, 0.44, 0));
      for (const [lx, lz] of [[-0.17, -0.13], [0.17, -0.13], [-0.17, 0.13], [0.17, 0.13]] as const) {
        g.add(cyl(0.017, 0.017, 0.44, mat(C.wood), dx + lx, 0.22, lz, 4));
      }
      // 条纹遮阳棚 (更饱满 + 红边垂帘)
      const canopy = new THREE.Group();
      for (let s = 0; s < 4; s++) {
        canopy.add(box(0.105, 0.022, 0.4, mat(s % 2 ? 0xc0392b : 0xe8dcc5, { roughness: 0.9 }), -0.157 + s * 0.105, 0, 0));
      }
      canopy.add(box(0.42, 0.05, 0.045, mat(0xc0392b, { roughness: 0.9 }), 0, -0.02, 0.2)); // 垂帘
      canopy.position.set(dx, 0.47, 0);
      canopy.rotation.x = 0.12;
      g.add(canopy);
      // 台面上堆满货品 (瓜果菜陶)
      g.add(sph(0.055, mat(0xe8590c), dx - 0.1, 0.52, 0.06));
      g.add(sph(0.055, mat(0xfab005), dx + 0.01, 0.53, -0.07));
      g.add(sph(0.05, mat(0x8bc34a), dx + 0.1, 0.52, 0.07));
      g.add(sph(0.04, mat(0xc0392b), dx - 0.02, 0.57, 0.02));
      g.add(cyl(0.045, 0.034, 0.1, mat(0x7dd3fc), dx + 0.15, 0.52, -0.1, 6));
      g.add(cyl(0.04, 0.03, 0.09, mat(0xa85f4a), dx - 0.15, 0.52, -0.1, 6));
    }
    // 中央价牌柱
    g.add(cyl(0.016, 0.02, 0.5, mat(C.woodDark), 0, 0.28, 0.3, 4));
    g.add(box(0.16, 0.11, 0.014, mat(0xf5d90a, { roughness: 0.8 }), 0, 0.48, 0.3));
    return g;
  },
  plaza: () => {
    const g = new THREE.Group();
    // 石板广场
    g.add(box(0.96, 0.07, 0.96, mat(0xb8b0a2, { roughness: 1 }), 0, 0.035, 0));
    for (let i = 0; i < 4; i++)
      for (let j = 0; j < 4; j++) {
        g.add(box(0.2, 0.015, 0.2, mat((i + j) % 2 ? 0xc0b8aa : 0xaaa294, { roughness: 1 }), -0.36 + i * 0.24, 0.075, -0.36 + j * 0.24));
      }
    // 中央雕塑基座
    g.add(cyl(0.12, 0.15, 0.12, mat(C.stone), 0, 0.13, 0, 8));
    g.add(sph(0.09, mat(0xd9cba8, { roughness: 0.8 }), 0, 0.28, 0));
    g.add(cone(0.03, 0.18, mat(0xd9a536, { metalness: 0.4, roughness: 0.4 }), 0, 0.4, 0, 5));
    // 长椅与路灯
    for (const [dx, dz, rot] of [[0.32, 0.32, 0.8], [-0.34, 0.3, -0.5], [0.3, -0.34, 2.2]] as const) {
      const bench = new THREE.Group();
      bench.add(box(0.2, 0.025, 0.07, mat(C.wood), 0, 0.1, 0));
      bench.add(box(0.2, 0.1, 0.02, mat(C.wood), 0, 0.15, -0.03));
      for (const lx of [-0.08, 0.08]) bench.add(box(0.02, 0.08, 0.05, mat(C.metalDark), lx, 0.05, 0));
      bench.position.set(dx, 0.07, dz); bench.rotation.y = rot;
      g.add(bench);
    }
    for (const [dx, dz] of [[-0.36, -0.36], [0.36, 0.36]] as const) {
      g.add(cyl(0.018, 0.022, 0.4, mat(0x2b2f33, { metalness: 0.4 }), dx, 0.26, dz, 5));
      const lamp = sph(0.035, mat(0xfff2c0, { emissive: 0xffd98a, emissiveIntensity: 0.9 }), dx, 0.47, dz, 5);
      (lamp as any).isWindowMesh = true; // 夜间点亮
      g.add(lamp);
    }
    return g;
  },
  library: () => {
    const g = new THREE.Group();
    // 知识殿堂 (v3: 阅读室穹顶 + 书脊墙 + 前廊书卷 + 侧翼书架塔)
    g.add(plinth(1, C.stoneDark));
    // 台阶
    g.add(box(0.86, 0.04, 0.16, mat(0xc0b8aa, { roughness: 0.9 }), -0.06, 0.05, 0.4));
    // 主体
    const main = winBox(0.72, 0.58, 0.56, 'lib', 5, 4, 0.55, '#c8b89a');
    main.position.set(-0.06, 0.36, 0); g.add(main);
    // 阅读室鼓座 + 穹顶 (绿色铜穹)
    g.add(cyl(0.2, 0.22, 0.1, mat(0xd8d0c0, { roughness: 0.85 }), -0.06, 0.71, 0, 12));
    const dome = sph(0.2, mat(C.roofGreen, { roughness: 0.7 }), -0.06, 0.74, 0, 12);
    dome.scale.y = 0.75;
    g.add(dome);
    g.add(cyl(0.012, 0.012, 0.09, mat(C.gold, { metalness: 0.6 }), -0.06, 0.92, 0, 5));
    g.add(sph(0.02, mat(C.gold, { metalness: 0.6 }), -0.06, 0.97, 0, 5));
    // 罗马柱门廊
    for (const dx of [-0.24, -0.06, 0.12]) g.add(cyl(0.028, 0.032, 0.42, mat(0xe8dcc5), dx, 0.27, 0.32, 8));
    g.add(box(0.4, 0.05, 0.1, mat(0xe8dcc5), -0.06, 0.5, 0.32));
    g.add(gable(0.42, 0.12, 0.08, mat(C.roofGreen), -0.06, 0.53, 0.32));
    // 书脊墙 (彩色书脊一排排, 加大加饱满 —— 远看即知是图书馆)
    const spineColors = [0xc0392b, 0x4a6b8a, 0xd9b36a, 0x5d7a4a, 0x8a5a8a, 0xb0703c];
    for (let row = 0; row < 3; row++) {
      for (let i = 0; i < 6; i++) {
        g.add(box(0.045, 0.14 - row * 0.014, 0.075, mat(spineColors[(i + row) % spineColors.length], { roughness: 0.75 }),
          -0.35 + i * 0.055, 0.22 + row * 0.145, 0.275));
      }
      // 书架横板
      g.add(box(0.3, 0.014, 0.08, mat(C.woodDark), -0.2, 0.15 + row * 0.145, 0.275));
    }
    // 门前摊开的书卷
    g.add(box(0.12, 0.012, 0.09, mat(0xf2ead5, { roughness: 0.9 }), -0.06, 0.095, 0.45));
    g.add(box(0.055, 0.02, 0.09, mat(0xe8dcc5, { roughness: 0.9 }), -0.09, 0.1, 0.45));
    g.add(box(0.055, 0.02, 0.09, mat(0xe8dcc5, { roughness: 0.9 }), -0.03, 0.1, 0.45));
    return g;
  },
  factory: () => {
    const g = new THREE.Group();
    g.add(plinth(2, C.stoneDark));
    // 主厂房 (锯齿顶)
    for (let i = 0; i < 3; i++) {
      const bay = winBox(0.52, 0.5, 0.72, `fac${i}`, 3, 2, 0.35, i % 2 ? '#8a6a54' : '#94745c');
      bay.position.set(-0.48 + i * 0.52, 0.32, -0.1); g.add(bay);
      // 锯齿天窗
      const sawTooth = box(0.5, 0.16, 0.2, mat(0xbfc8cc, { roughness: 0.4, transparent: true, opacity: 0.8 }), -0.48 + i * 0.52, 0.62, -0.32);
      sawTooth.rotation.x = -0.5;
      g.add(sawTooth);
    }
    // 大烟囱
    g.add(cyl(0.11, 0.16, 1.3, mat(C.brick, { roughness: 1 }), 0.72, 0.72, -0.5, 9));
    g.add(cyl(0.12, 0.11, 0.09, mat(0x3d3a36), 0.72, 1.4, -0.5, 9));
    (g as any).smokeSpots = [new THREE.Vector3(0.72, 1.46, -0.5)];
    // 水塔
    g.add(cyl(0.03, 0.03, 0.5, mat(C.metalDark), -0.7, 0.32, 0.55, 4));
    g.add(cyl(0.12, 0.12, 0.16, mat(0x8d99a4), -0.7, 0.66, 0.55, 10));
    // 装卸台与货物
    g.add(box(0.7, 0.14, 0.2, mat(0x6a7480), 0.1, 0.14, 0.55));
    for (let i = 0; i < 3; i++) g.add(box(0.12, 0.12, 0.12, mat(0xc9a06a), -0.1 + i * 0.16, 0.27, 0.55));
    return g;
  },
  train_station: () => {
    const g = new THREE.Group();
    g.add(plinth(1, C.stoneDark));
    // 站台 (加长, 边缘黄线)
    g.add(box(0.96, 0.16, 0.36, mat(0xb8bec4), 0, 0.11, 0.3));
    g.add(box(0.96, 0.015, 0.035, mat(0xf5d90a, { roughness: 0.8 }), 0, 0.195, 0.44));
    // 铁轨 (枕木 + 双轨)
    for (const dz of [0.02, 0.15]) {
      g.add(box(0.96, 0.05, 0.04, mat(0x555c61, { metalness: 0.6, roughness: 0.4 }), 0, 0.07, dz));
    }
    for (let i = 0; i < 8; i++) g.add(box(0.06, 0.035, 0.18, mat(C.woodDark), -0.44 + i * 0.125, 0.05, 0.085));
    // 站房 (加大)
    const house = winBox(0.5, 0.46, 0.34, 'station', 3, 3, 0.65, '#c8b89a');
    house.position.set(-0.2, 0.39, -0.18); g.add(house);
    g.add(gable(0.58, 0.42, 0.2, mat(C.roofRed), -0.2, 0.62, -0.18));
    // 月台雨棚 (铁柱 + 坡顶, 覆盖站台)
    for (const dx of [-0.34, 0.12, 0.4]) g.add(cyl(0.016, 0.018, 0.44, mat(0x2b2f33, { metalness: 0.5 }), dx, 0.42, 0.3, 5));
    const canopy = box(0.9, 0.03, 0.3, mat(C.roofDark), 0.03, 0.66, 0.3);
    canopy.rotation.z = 0.06;
    g.add(canopy);
    // 大钟楼 (立面大钟盘)
    g.add(box(0.16, 0.56, 0.16, mat(0xd9cba8), 0.24, 0.52, -0.3));
    g.add(cone(0.14, 0.2, mat(C.roofDark), 0.24, 0.9, -0.3, 4));
    g.add(cyl(0.055, 0.055, 0.02, mat(0xf5f0dc, { roughness: 0.4 }), 0.24, 0.68, -0.215, 10));
    g.add(box(0.012, 0.04, 0.005, mat(0x2b2b2b), 0.24, 0.68, -0.204));
    g.add(box(0.03, 0.012, 0.005, mat(0x2b2b2b), 0.245, 0.68, -0.204));
    // 站牌 (蓝底白字样式)
    g.add(cyl(0.014, 0.016, 0.4, mat(0x2b2f33), -0.36, 0.38, 0.44, 4));
    g.add(box(0.26, 0.13, 0.015, mat(0x1a4a7c), -0.36, 0.56, 0.44));
    g.add(box(0.2, 0.018, 0.017, mat(0xffffff), -0.36, 0.56, 0.449));
    // 候车椅
    g.add(box(0.18, 0.02, 0.06, mat(C.wood), 0.05, 0.26, 0.36));
    for (const dx of [0.0, 0.14]) g.add(box(0.02, 0.08, 0.05, mat(C.metalDark), dx, 0.21, 0.36));
    return g;
  },
  school: () => {
    const g = new THREE.Group();
    g.add(yard());
    // v5 比例修复: 三层教学楼
    const main = winBox(0.74, 0.85, 0.6, 'school', 5, 6, 0.6, '#d9cba8');
    main.position.set(-0.08, 0.48, 0); g.add(main);
    g.add(gable(0.82, 0.68, 0.22, mat(C.roofRed), -0.08, 0.92, 0));
    // 钟楼
    g.add(box(0.18, 1.08, 0.18, mat(0xd9cba8), 0.32, 0.62, 0));
    g.add(box(0.22, 0.05, 0.22, mat(C.roofDark), 0.32, 1.18, 0));
    g.add(cone(0.15, 0.18, mat(C.roofDark), 0.32, 1.3, 0, 4));
    g.add(cyl(0.02, 0.02, 0.14, mat(C.gold, { metalness: 0.6 }), 0.32, 1.44, 0, 6));
    // 旗杆
    g.add(cyl(0.014, 0.014, 1.1, mat(C.metal), -0.42, 0.6, 0.38, 4));
    g.add(box(0.16, 0.1, 0.006, mat(0xc0392b), -0.34, 1.05, 0.38));
    // 禁跑球场
    g.add(box(0.3, 0.02, 0.2, mat(0xc96a4a, { roughness: 1 }), 0.3, 0.06, 0.36));
    g.add(cyl(0.012, 0.012, 0.16, mat(C.white), 0.18, 0.13, 0.28, 4));
    g.add(cyl(0.012, 0.012, 0.16, mat(C.white), 0.42, 0.13, 0.28, 4));
    g.add(frontPath());
    return g;
  },
  hospital: () => {
    const g = new THREE.Group();
    g.add(plinth(1, 0x9fb4be));
    // v5 比例修复: 五层住院部塔楼
    const main = winBox(0.8, 1.05, 0.66, 'hospital', 6, 7, 0.5, '#eef2f4');
    main.position.set(-0.02, 0.6, 0); g.add(main);
    g.add(box(0.88, 0.07, 0.74, mat(0x9fb4be), -0.02, 1.15, 0));
    // 侧翼急诊部
    g.add(box(0.3, 0.52, 0.5, mat(0xe4eaee, { roughness: 0.8 }), -0.3, 0.33, 0.3));
    g.add(box(0.34, 0.05, 0.54, mat(0x8fa3ad), -0.3, 0.61, 0.3));
    // 立面大红十字 (加大加亮 —— 远看即知是医院)
    const crossV = box(0.09, 0.34, 0.03, mat(0xc0392b, { emissive: 0xc0392b, emissiveIntensity: 0.5 }), 0.08, 0.8, 0.335);
    const crossH = box(0.28, 0.09, 0.03, mat(0xc0392b, { emissive: 0xc0392b, emissiveIntensity: 0.5 }), 0.08, 0.8, 0.335);
    g.add(crossV, crossH);
    // 屋顶直升机停机坪 H
    g.add(cyl(0.2, 0.2, 0.015, mat(0x50565c, { roughness: 0.9 }), -0.02, 1.19, -0.1, 14));
    g.add(box(0.16, 0.012, 0.035, mat(0xf2f2ee), -0.02, 1.2, -0.1));
    g.add(box(0.035, 0.012, 0.16, mat(0xf2f2ee), -0.02, 1.2, -0.1));
    // 急诊灯箱
    g.add(box(0.2, 0.08, 0.02, mat(0xc0392b, { emissive: 0xc0392b, emissiveIntensity: 0.7 }), -0.3, 0.55, 0.556));
    // 救护车
    const amb = new THREE.Group();
    amb.add(box(0.22, 0.1, 0.11, mat(0xf2f2ee), 0, 0.09, 0));
    amb.add(box(0.1, 0.09, 0.1, mat(0xf2f2ee), -0.1, 0.15, 0));
    amb.add(box(0.032, 0.032, 0.011, mat(0xc0392b, { emissive: 0xc0392b, emissiveIntensity: 0.8 }), -0.02, 0.09, 0.057));
    amb.add(box(0.011, 0.032, 0.032, mat(0xc0392b, { emissive: 0xc0392b, emissiveIntensity: 0.8 }), -0.02, 0.09, 0.057));
    for (const lx of [-0.07, 0.02]) {
      amb.add(cyl(0.022, 0.022, 0.016, mat(0x2b2b2b), lx, 0.04, 0.056, 6));
      amb.add(cyl(0.022, 0.022, 0.016, mat(0x2b2b2b), lx, 0.04, -0.056, 6));
    }
    const beacon = cyl(0.025, 0.03, 0.03, mat(0x3a86b8, { emissive: 0x3a86b8, emissiveIntensity: 1 }), -0.1, 0.21, 0, 6);
    (beacon as any).isBeacon = true;
    amb.add(beacon);
    amb.position.set(0.34, 0, 0.3); amb.rotation.y = 0.7;
    g.add(amb);
    g.add(frontPath());
    return g;
  },
  police: () => {
    const g = new THREE.Group();
    g.add(plinth(1, 0x7d8a94));
    // v5 比例修复: 三层警局大楼
    const main = winBox(0.78, 0.82, 0.62, 'police', 5, 6, 0.5, '#7d8a94');
    main.position.set(0, 0.48, 0); g.add(main);
    g.add(box(0.86, 0.06, 0.7, mat(C.roofDark), 0, 0.92, 0));
    // 蓝白警用色带 (环楼一圈 —— 警察局符号)
    g.add(box(0.8, 0.09, 0.64, mat(0x2e5f8a), 0, 0.72, 0));
    const beacon = cyl(0.05, 0.06, 0.06, mat(0x3a86b8, { emissive: 0x3a86b8, emissiveIntensity: 1 }), 0.26, 0.98, -0.18, 6);
    (beacon as any).isBeacon = true;
    g.add(beacon);
    // 警徽门牌 (盾形 + 蓝底)
    g.add(box(0.2, 0.15, 0.02, mat(0x1a3a5c), 0, 0.6, 0.315));
    g.add(box(0.09, 0.1, 0.022, mat(C.gold, { metalness: 0.5 }), 0, 0.6, 0.319));
    g.add(box(0.04, 0.04, 0.024, mat(0x1a3a5c), 0, 0.61, 0.321));
    // 警车 (顶灯红蓝闪烁)
    const car = new THREE.Group();
    car.add(box(0.19, 0.075, 0.095, mat(0xf2f2ee), 0, 0.085, 0));
    car.add(box(0.1, 0.065, 0.085, mat(0xf2f2ee), -0.02, 0.14, 0));
    car.add(box(0.085, 0.05, 0.087, mat(0x2e5f8a), 0.05, 0.085, 0)); // 车门蓝条
    const bar1 = box(0.032, 0.028, 0.038, mat(0xc0392b, { emissive: 0xc0392b, emissiveIntensity: 1 }), -0.035, 0.185, 0);
    const bar2 = box(0.032, 0.028, 0.038, mat(0x3a86b8, { emissive: 0x3a86b8, emissiveIntensity: 1 }), 0.005, 0.185, 0);
    (bar1 as any).isBeacon = true;
    car.add(bar1, bar2);
    for (const lx of [-0.06, 0.05]) {
      car.add(cyl(0.02, 0.02, 0.016, mat(0x2b2b2b), lx, 0.04, 0.048, 6));
      car.add(cyl(0.02, 0.02, 0.016, mat(0x2b2b2b), lx, 0.04, -0.048, 6));
    }
    car.position.set(-0.34, 0, 0.32); car.rotation.y = 0.5;
    g.add(car);
    // 路障锥
    g.add(cone(0.035, 0.09, mat(0xe8590c, { roughness: 0.7 }), 0.4, 0.07, 0.42, 6));
    g.add(frontPath());
    return g;
  },
  fire_station: () => {
    const g = new THREE.Group();
    g.add(plinth(1, C.brick));
    // v5 比例修复: 三层消防局 + 高耸瞭望塔
    const main = winBox(0.78, 0.8, 0.62, 'firest', 5, 5, 0.4, '#b0604a');
    main.position.set(0, 0.47, 0); g.add(main);
    g.add(gable(0.86, 0.7, 0.18, mat(C.roofRed), 0, 0.9, 0));
    g.add(box(0.24, 0.44, 0.04, mat(0x4a3f35), -0.16, 0.28, 0.315)); // 车库门
    for (let i = 0; i < 5; i++) g.add(box(0.24, 0.02, 0.045, mat(0x6a5a4a), -0.16, 0.1 + i * 0.09, 0.317));
    // 瞭望塔楼
    g.add(box(0.16, 0.5, 0.16, mat(0xb0604a), 0.3, 1.1, -0.16));
    g.add(box(0.2, 0.04, 0.2, mat(C.roofDark), 0.3, 1.37, -0.16));
    const beacon = cyl(0.045, 0.055, 0.05, mat(0xf5d90a, { emissive: 0xf5d90a, emissiveIntensity: 0.8 }), 0.3, 1.43, -0.16, 6);
    (beacon as any).isBeacon = true;
    g.add(beacon);
    g.add(cyl(0.028, 0.028, 0.2, mat(0xc0392b), 0.3, 1.25, 0.18, 6)); // 警铃
    // 云梯消防车
    const truck = new THREE.Group();
    truck.add(box(0.24, 0.1, 0.1, mat(0xc0392b), 0, 0.09, 0));
    truck.add(box(0.09, 0.08, 0.09, mat(0xc0392b), -0.11, 0.12, 0));
    const ladder = box(0.3, 0.02, 0.04, mat(0xd8dde0, { metalness: 0.6 }), 0.05, 0.16, 0);
    ladder.rotation.z = 0.25;
    truck.add(ladder);
    for (const lx of [-0.08, -0.01, 0.06]) {
      truck.add(cyl(0.022, 0.022, 0.016, mat(0x2b2b2b), lx, 0.04, 0.05, 6));
      truck.add(cyl(0.022, 0.022, 0.016, mat(0x2b2b2b), lx, 0.04, -0.05, 6));
    }
    truck.position.set(0.3, 0, 0.3); truck.rotation.y = -0.6;
    g.add(truck);
    g.add(frontPath());
    return g;
  },
  bank: () => {
    const g = new THREE.Group();
    // 神庙式银行 (v3: 台阶 + 三角山花 + 环形金币穹标 + 侧翼营业厅)
    g.add(plinth(1, 0x9a9488));
    // 台阶
    g.add(box(0.9, 0.04, 0.2, mat(0xc0b8aa, { roughness: 0.9 }), 0, 0.05, 0.38));
    g.add(box(0.82, 0.04, 0.14, mat(0xc8c0b2, { roughness: 0.9 }), 0, 0.09, 0.34));
    // 主体
    g.add(box(0.72, 0.52, 0.56, mat(0xd8d0c0, { roughness: 0.85 }), 0, 0.35, 0));
    // 希腊柱廊
    for (const dx of [-0.3, -0.15, 0, 0.15, 0.3]) {
      g.add(cyl(0.032, 0.036, 0.46, mat(0xe8dcc5), dx, 0.31, 0.33, 10));
      g.add(cyl(0.045, 0.045, 0.03, mat(0xd8d0c0), dx, 0.555, 0.33, 10)); // 柱头
    }
    // 檐部 + 三角山花
    g.add(box(0.78, 0.06, 0.16, mat(0xe8dcc5), 0, 0.58, 0.33));
    const ped = new THREE.Shape();
    ped.moveTo(-0.39, 0); ped.lineTo(0.39, 0); ped.lineTo(0, 0.14); ped.closePath();
    const pedMesh = new THREE.Mesh(new THREE.ExtrudeGeometry(ped, { depth: 0.05, bevelEnabled: false }), mat(0xe8dcc5));
    pedMesh.rotation.y = 0;
    pedMesh.position.set(0, 0.61, 0.36);
    pedMesh.castShadow = true;
    g.add(pedMesh);
    // 山花中央金币浮雕 (加大加亮, 远看即知是银行)
    g.add(cyl(0.062, 0.062, 0.02, mat(C.gold, { metalness: 0.75, roughness: 0.25, emissive: 0x8a6914, emissiveIntensity: 0.4 }), 0, 0.665, 0.385, 14));
    // 金库大门 (厚重钢门 + 转轮)
    g.add(cyl(0.09, 0.09, 0.03, mat(0x6a7480, { metalness: 0.6, roughness: 0.35 }), 0, 0.28, 0.285, 12));
    g.add(cyl(0.028, 0.028, 0.04, mat(C.gold, { metalness: 0.7, roughness: 0.3 }), 0, 0.28, 0.3, 8));
    // 侧翼营业厅 (玻璃幕墙, 夜间亮灯)
    const annex = winBox(0.34, 0.34, 0.4, 'bankannex', 3, 2, 0.75, '#9fb4be');
    annex.position.set(0.42, 0.24, 0.08);
    g.add(annex);
    g.add(box(0.38, 0.04, 0.44, mat(C.roofDark), 0.42, 0.43, 0.08));
    // 顶部金币装饰 (旋转的钱币: 中式铜钱造型, 加大)
    g.add(cyl(0.075, 0.075, 0.022, mat(C.gold, { metalness: 0.75, roughness: 0.25, emissive: 0x8a6914, emissiveIntensity: 0.3 }), 0, 0.7, 0, 14));
    const coin = box(0.13, 0.13, 0.02, mat(C.gold, { metalness: 0.8, roughness: 0.22, emissive: 0xb08a2e, emissiveIntensity: 0.45 }), 0, 0.82, 0);
    coin.rotation.x = Math.PI / 2;
    (coin as any).isStir = true; // 缓缓旋转
    g.add(coin);
    // 铜钱方孔
    const hole = box(0.036, 0.036, 0.026, mat(0x6b5a2a, { metalness: 0.6, roughness: 0.3 }), 0, 0.82, 0);
    hole.rotation.x = Math.PI / 2;
    g.add(hole);
    g.add(cyl(0.012, 0.012, 0.1, mat(C.gold, { metalness: 0.7 }), 0, 0.74, 0, 5));
    return g;
  },
  broadcast: () => {
    const g = new THREE.Group();
    g.add(plinth(1, 0x7d8a94));
    // 塔基机房 (远离塔腿, 不穿插)
    g.add(box(0.3, 0.3, 0.3, mat(0x8d99a4), 0.34, 0.22, 0.34));
    g.add(box(0.36, 0.05, 0.36, mat(C.roofDark), 0.34, 0.4, 0.34));
    // 格构塔
    for (let i = 0; i < 6; i++) {
      const t = i / 6;
      const w = 0.26 * (1 - t * 0.75);
      for (const [sx, sz] of [[1, 1], [-1, 1], [1, -1], [-1, -1]] as const) {
        const leg = cyl(0.016, 0.02, 0.26, mat(0xc0392b, { metalness: 0.3 }), sx * w / 2, 0.13 + i * 0.24, sz * w / 2, 4);
        leg.rotation.x = -sz * 0.06; leg.rotation.z = -sx * 0.06;
        g.add(leg);
      }
      // 横撑
      g.add(box(w, 0.015, 0.015, mat(0xc0392b), 0, 0.24 + i * 0.24, 0));
    }
    // 塔顶天线与红灯
    g.add(cyl(0.012, 0.012, 0.35, mat(C.metal), 0, 1.72, 0, 4));
    for (const h of [1.3, 1.55]) {
      const beacon = sph(0.028, mat(0xc0392b, { emissive: 0xc0392b, emissiveIntensity: 1 }), 0, h, 0, 5);
      (beacon as any).isBeacon = true;
      g.add(beacon);
    }
    // 发射偶极子
    for (const h of [0.95, 1.15]) {
      g.add(box(0.3, 0.015, 0.015, mat(C.metal), 0, h, 0));
      g.add(box(0.015, 0.015, 0.3, mat(C.metal), 0, h, 0));
    }
    return g;
  },
  harbor: () => {
    const g = new THREE.Group();
    // 码头桩基 (延伸入水)
    g.add(box(1.9, 0.12, 0.7, mat(C.woodDark), 0, 0.1, 0.35));
    for (let i = 0; i < 5; i++)
      for (const dz of [0.05, 0.65]) {
        g.add(cyl(0.04, 0.05, 0.4, mat(C.woodDark), -0.85 + i * 0.42, -0.05, dz, 5));
      }
    // 集装箱吊桥
    for (const dx of [-0.7, -0.2, 0.3]) g.add(box(0.07, 0.55, 0.07, mat(0xc0392b, { metalness: 0.2 }), dx, 0.42, 0.05));
    g.add(box(1.1, 0.07, 0.09, mat(0xc0392b, { metalness: 0.2 }), -0.2, 0.68, 0.05));
    const trolley = box(0.12, 0.08, 0.1, mat(0x50565c), -0.2, 0.6, 0.05);
    (trolley as any).isCart = true;
    g.add(trolley);
    // 集装箱堆
    const boxColors = [0xc0392b, 0x3a86b8, 0xd9a536, 0x4a8a3c];
    for (let i = 0; i < 4; i++) {
      g.add(box(0.3, 0.13, 0.14, mat(boxColors[i], { roughness: 0.8 }), -0.6 + i * 0.34, 0.22, 0.28));
    }
    g.add(box(0.3, 0.13, 0.14, mat(boxColors[1], { roughness: 0.8 }), -0.26, 0.35, 0.28));
    // 塔吊控制室
    g.add(box(0.14, 0.12, 0.12, mat(0x8d99a4), -0.2, 0.74, 0.05));
    return g;
  },
  park: () => {
    const g = new THREE.Group();
    g.add(box(0.96, 0.06, 0.96, mat(0x5fae4e, { roughness: 1 }), 0, 0.03, 0));
    // 喷泉
    g.add(cyl(0.22, 0.25, 0.1, mat(C.stone), 0, 0.1, 0, 12));
    g.add(cyl(0.18, 0.18, 0.03, mat(0x3a86b8, { roughness: 0.2 }), 0, 0.16, 0, 12));
    g.add(cyl(0.04, 0.05, 0.3, mat(C.stone), 0, 0.3, 0, 8));
    const water = cyl(0.07, 0.025, 0.16, mat(0x8fd4f5, { transparent: true, opacity: 0.85 }), 0, 0.46, 0, 8);
    (water as any).isFountain = true;
    g.add(water);
    g.add(sph(0.04, mat(0x8fd4f5, { transparent: true, opacity: 0.8 }), 0, 0.56, 0, 6));
    // 环形小径
    const ring = new THREE.Mesh(new THREE.TorusGeometry(0.32, 0.045, 4, 20), mat(0xc9bfa8, { roughness: 1 }));
    ring.rotation.x = Math.PI / 2;
    ring.position.y = 0.065;
    ring.receiveShadow = true;
    g.add(ring);
    // 树
    for (const [dx, dz, type] of [[-0.36, -0.34, 0], [0.38, -0.32, 2], [-0.34, 0.38, 1]] as const) {
      g.add(cyl(0.035, 0.05, 0.24, mat(C.woodDark), dx, 0.18, dz, 5));
      g.add(sph(0.14, mat(type === 0 ? C.pine : type === 1 ? C.leaf : C.birch), dx, 0.38, dz));
      g.add(sph(0.09, mat(type === 0 ? C.pine : type === 1 ? C.leaf : C.birch), dx + 0.05, 0.5, dz));
    }
    // 长椅
    for (const [dx, dz, rot] of [[0.36, 0.36, 0.7], [-0.38, 0.02, -0.4]] as const) {
      const bench = new THREE.Group();
      bench.add(box(0.18, 0.025, 0.06, mat(C.wood), 0, 0.09, 0));
      bench.add(box(0.18, 0.1, 0.018, mat(C.wood), 0, 0.14, -0.028));
      for (const lx of [-0.07, 0.07]) bench.add(box(0.018, 0.07, 0.05, mat(C.metalDark), lx, 0.045, 0));
      bench.position.set(dx, 0.06, dz); bench.rotation.y = rot;
      g.add(bench);
    }
    // 草坪花丛
    for (let i = 0; i < 6; i++) {
      const a = i * 1.05 + 0.3;
      g.add(sph(0.022, mat(i % 2 ? 0xe8590c : 0xfab005), Math.cos(a) * 0.42, 0.09, Math.sin(a) * 0.42, 4));
    }
    return g;
  },
  mall: () => {
    const g = new THREE.Group();
    g.add(plinth(2, C.stoneDark));
    // v5 比例修复: 五层购物中心 —— 3×3 地块上的消费殿堂
    const main = winBox(1.62, 1.18, 1.22, 'mall', 9, 7, 0.6, '#c2b49a');
    main.position.set(0, 0.67, 0.08); g.add(main);
    g.add(box(1.72, 0.08, 1.32, mat(C.roofDark), 0, 1.29, 0.08));
    // 玻璃拱顶中庭
    const arch = cyl(0.34, 0.34, 1.15, mat(0x9fd4e8, { roughness: 0.15, metalness: 0.1, transparent: true, opacity: 0.65 }), 0, 1.34, 0.08, 12);
    arch.rotation.z = Math.PI / 2;
    g.add(arch);
    // 入口雨棚
    g.add(box(0.6, 0.05, 0.3, mat(0x50565c, { metalness: 0.4 }), 0, 0.5, 0.73));
    // 招牌柱
    g.add(cyl(0.055, 0.065, 0.95, mat(0x50565c), -0.78, 0.55, 0.78, 8));
    g.add(box(0.4, 0.28, 0.04, mat(0xc0392b, { emissive: 0xc0392b, emissiveIntensity: 0.35 }), -0.78, 1.12, 0.78));
    g.add(box(0.36, 0.06, 0.05, mat(0xf5d90a, { emissive: 0xf5d90a, emissiveIntensity: 0.5 }), -0.78, 1.2, 0.81));
    // 停车场标线
    g.add(box(1.5, 0.02, 0.55, mat(C.asphalt), 0, 0.02, -0.72));
    for (let i = 0; i < 6; i++) g.add(box(0.02, 0.01, 0.45, mat(0xe8e8e8), -0.6 + i * 0.24, 0.03, -0.72));
    g.scale.setScalar(1.55); // 3×3 购物中心 (v5: 体量增强)
    return g;
  },
  office: () => {
    const g = new THREE.Group();
    g.add(plinth(2, C.stoneDark));
    // 蓝绿玻璃幕墙塔 (2×2, 高约 5.6)
    const t1 = winBox(1.5, 5.0, 1.5, 'office2', 7, 18, 0.55, '#5a8a9e');
    t1.position.y = 2.62; g.add(t1);
    g.add(box(1.6, 0.06, 1.6, mat(C.metalDark), 0, 5.15, 0));
    // 屋顶冷却塔
    g.add(cyl(0.12, 0.15, 0.22, mat(C.metal, { metalness: 0.4 }), -0.4, 5.3, 0.3, 8));
    g.add(cyl(0.09, 0.09, 0.16, mat(C.metal, { metalness: 0.4 }), 0.35, 5.27, -0.3, 8));
    // 航空灯
    const beacon = sph(0.04, mat(0xc0392b, { emissive: 0xc0392b, emissiveIntensity: 1 }), 0, 5.32, 0, 5);
    (beacon as any).isBeacon = true;
    g.add(beacon);
    // 底层大厅
    g.add(box(1.7, 0.4, 1.7, mat(0x9fc8dd, { roughness: 0.2, metalness: 0.1, transparent: true, opacity: 0.85 }), 0, 0.25, 0));
    g.add(box(1.76, 0.04, 1.76, mat(C.metalDark), 0, 0.47, 0));
    g.add(frontPath(0.55, 0.5, 1.05));
    return g;
  },
  stadium: () => {
    const g = new THREE.Group();
    g.add(plinth(2, C.stoneDark));
    // 环形看台 (椭圆碗)
    const bowlMat = mat(0x8d99a4, { roughness: 0.85 });
    for (let i = 0; i < 3; i++) {
      const ring = new THREE.Mesh(new THREE.CylinderGeometry(0.92 - i * 0.12, 0.98 - i * 0.12, 0.16, 20, 1, true), bowlMat);
      ring.position.y = 0.1 + i * 0.15;
      ring.castShadow = true; ring.receiveShadow = true;
      g.add(ring);
    }
    // 场地 (足球场)
    g.add(cyl(0.66, 0.66, 0.03, mat(0x4a9a3c, { roughness: 1 }), 0, 0.07, 0, 20));
    g.add(box(0.5, 0.01, 0.32, mat(0x63b24e, { roughness: 1 }), 0, 0.09, 0));
    // 球门
    for (const dz of [-0.28, 0.28]) {
      g.add(box(0.14, 0.02, 0.02, mat(C.white), 0, 0.14, dz));
      g.add(box(0.02, 0.07, 0.02, mat(C.white), -0.07, 0.11, dz));
      g.add(box(0.02, 0.07, 0.02, mat(C.white), 0.07, 0.11, dz));
    }
    // 灯塔 ×4
    for (const [dx, dz] of [[-0.85, -0.85], [0.85, -0.85], [-0.85, 0.85], [0.85, 0.85]] as const) {
      g.add(cyl(0.025, 0.035, 1.0, mat(C.metalDark), dx, 0.55, dz, 5));
      g.add(box(0.16, 0.1, 0.03, mat(0x50565c), dx, 1.08, dz));
      g.add(box(0.13, 0.07, 0.015, mat(0xfff2c0, { emissive: 0xfff2c0, emissiveIntensity: 0.9 }), dx, 1.08, dz + 0.02));
    }
    g.scale.setScalar(1.42); // 3×3 体育场
    return g;
  },
  subway: () => {
    const g = new THREE.Group();
    // 玻璃入口罩棚 (弧形)
    const arch = cyl(0.3, 0.3, 0.62, mat(0x9fd4e8, { roughness: 0.15, transparent: true, opacity: 0.55 }), 0, 0.32, 0.05, 12);
    arch.rotation.z = Math.PI / 2;
    arch.scale.y = 0.55;
    g.add(arch);
    for (const dx of [-0.3, 0.3]) g.add(cyl(0.02, 0.024, 0.55, mat(C.metalDark, { metalness: 0.5 }), dx, 0.28, 0.05, 5));
    // 地面站厅
    g.add(box(0.66, 0.42, 0.5, mat(0x8d99a4, { roughness: 0.8 }), 0, 0.24, -0.18));
    g.add(box(0.74, 0.05, 0.58, mat(C.metalDark), 0, 0.47, -0.18));
    // 下行阶梯 (步入黑暗的洞口 —— 地铁感的关键)
    g.add(box(0.42, 0.05, 0.4, mat(0x50565c, { metalness: 0.3 }), 0, 0.16, 0.3));
    for (let s = 0; s < 5; s++) {
      g.add(box(0.38, 0.022, 0.075, mat(0x9aa3ab, { roughness: 0.7 }), 0, 0.015 + s * 0.026, 0.26 - s * 0.078));
    }
    g.add(box(0.36, 0.14, 0.02, mat(0x0a0c10), 0, 0.05, -0.09)); // 洞口黑幕
    // 大 M 标识柱 (立体发光)
    g.add(cyl(0.03, 0.035, 0.78, mat(C.metalDark), 0.42, 0.39, 0.2, 6));
    g.add(box(0.22, 0.22, 0.035, mat(0x1a3a5c), 0.42, 0.84, 0.2));
    const legL = box(0.05, 0.13, 0.037, mat(0x4fc3f7, { emissive: 0x22a7e0, emissiveIntensity: 0.9 }), 0.395, 0.84, 0.2);
    const legR = box(0.05, 0.13, 0.037, mat(0x4fc3f7, { emissive: 0x22a7e0, emissiveIntensity: 0.9 }), 0.445, 0.84, 0.2);
    const legM = box(0.05, 0.05, 0.037, mat(0x4fc3f7, { emissive: 0x22a7e0, emissiveIntensity: 0.9 }), 0.42, 0.8, 0.2);
    g.add(legL, legR, legM);
    // 闸机
    g.add(box(0.07, 0.16, 0.05, mat(0x3a4a58), -0.26, 0.24, 0.42));
    g.add(box(0.07, 0.16, 0.05, mat(0x3a4a58), -0.12, 0.24, 0.42));
    // 通风口
    g.add(cyl(0.08, 0.09, 0.1, mat(C.metal), -0.42, 0.52, -0.3, 8));
    const fan = cyl(0.065, 0.065, 0.02, mat(0x707a84, { metalness: 0.6 }), -0.42, 0.58, -0.3, 8);
    (fan as any).isRotor = true;
    g.add(fan);
    return g;
  },
  airport: () => {
    const g = new THREE.Group();
    // 跑道
    g.add(box(1.96, 0.07, 0.66, mat(0x4a4d52, { roughness: 0.95 }), 0, 0.035, 0.55));
    for (let i = 0; i < 9; i++) g.add(box(0.18, 0.012, 0.05, mat(0xe8e8e8), -0.85 + i * 0.21, 0.075, 0.55));
    g.add(box(0.02, 0.012, 0.55, mat(0xf5d90a), 0.93, 0.075, 0.55));
    // 滑行道灯
    for (const dx of [-0.8, -0.4, 0, 0.4, 0.8]) {
      g.add(sph(0.018, mat(0x4ade80, { emissive: 0x4ade80, emissiveIntensity: 0.8 }), dx, 0.08, 0.22, 4));
    }
    // 航站楼
    const term = winBox(1.4, 0.52, 0.5, 'airport', 8, 3, 0.7, '#aebfc9');
    term.position.set(-0.15, 0.33, -0.3); g.add(term);
    g.add(box(1.5, 0.06, 0.6, mat(C.roofDark), -0.15, 0.61, -0.3));
    // 玻璃廊桥
    g.add(box(0.5, 0.14, 0.14, mat(0x9fd4e8, { roughness: 0.2, transparent: true, opacity: 0.65 }), 0.2, 0.2, 0.02));
    // 塔台
    g.add(cyl(0.08, 0.11, 0.75, mat(C.white, { roughness: 0.7 }), 0.72, 0.44, -0.3, 8));
    g.add(cyl(0.14, 0.11, 0.16, mat(0x8fb9cc, { roughness: 0.3 }), 0.72, 0.89, -0.3, 8));
    g.add(cone(0.15, 0.1, mat(C.roofDark), 0.72, 1.02, -0.3, 8));
    const beacon = sph(0.035, mat(0xc0392b, { emissive: 0xc0392b, emissiveIntensity: 1 }), 0.72, 1.1, -0.3, 6);
    (beacon as any).isBeacon = true;
    g.add(beacon);
    // 停机坪飞机
    const plane = new THREE.Group();
    const fus = cyl(0.035, 0.035, 0.44, mat(C.white, { roughness: 0.6 }), 0, 0.12, 0, 8);
    fus.rotation.x = Math.PI / 2;
    plane.add(fus);
    plane.add(cone(0.035, 0.1, mat(C.white, { roughness: 0.6 }), 0, 0.12, -0.27, 8));
    plane.add(box(0.05, 0.02, 0.14, mat(0x3a86b8), 0, 0.21, 0.09));
    plane.add(box(0.26, 0.015, 0.09, mat(C.white), 0, 0.13, 0));
    plane.add(box(0.02, 0.1, 0.02, mat(C.metalDark), 0, 0.17, -0.2));
    plane.add(cyl(0.02, 0.02, 0.05, mat(0x2b2b2b), -0.08, 0.06, 0.08, 6));
    plane.add(cyl(0.02, 0.02, 0.05, mat(0x2b2b2b), 0.08, 0.06, 0.08, 6));
    plane.position.set(0.18, 0, 0.2); plane.rotation.y = 0.5;
    (plane as any).isPlane = true;
    g.add(plane);
    // 行李车
    g.add(box(0.12, 0.05, 0.07, mat(0x8d99a4), -0.5, 0.1, 0.2));
    g.add(box(0.1, 0.06, 0.06, mat(0xc9a06a), -0.5, 0.16, 0.2));
    g.scale.setScalar(1.42); // 3×3 机场
    return g;
  },
  // ================= 军事 =================
  barracks: () => {
    const g = new THREE.Group();
    g.add(plinth(1, 0x8a7a5c));
    // 操练场围栏
    for (const [dx, dz, w, d] of [[0, -0.46, 0.94, 0.03], [0, 0.46, 0.94, 0.03], [-0.46, 0, 0.03, 0.94], [0.46, 0, 0.03, 0.94]] as const) {
      g.add(box(w, 0.24, d, mat(0x8a5a33, { roughness: 1 }), dx, 0.12, dz));
    }
    for (const [dx, dz] of [[-0.46, -0.46], [0.46, -0.46], [-0.46, 0.46], [0.46, 0.46], [-0.46, 0], [0.46, 0]] as const) {
      g.add(cyl(0.022, 0.026, 0.34, mat(C.woodDark), dx, 0.17, dz, 5));
    }
    // 营帐 (军绿色)
    const tent1 = cone(0.2, 0.3, mat(0x5d6b4a, { roughness: 1 }), -0.18, 0.22, -0.16, 4);
    tent1.rotation.y = Math.PI / 4; g.add(tent1);
    const tent2 = cone(0.15, 0.24, mat(0x4a5a3c, { roughness: 1 }), 0.14, 0.19, -0.22, 4);
    tent2.rotation.y = Math.PI / 4; g.add(tent2);
    // 篝火盆 (夜间训练)
    g.add(cyl(0.07, 0.09, 0.07, mat(C.metalDark), 0.3, 0.09, 0.18, 8));
    const ember = sph(0.045, mat(0xfab005, { emissive: 0xe8590c, emissiveIntensity: 1 }), 0.3, 0.13, 0.18, 5);
    (ember as any).isFlame = true;
    g.add(ember);
    // 木人桩 ×2 (训练假人)
    for (const dx of [-0.05, 0.26]) {
      g.add(cyl(0.026, 0.03, 0.42, mat(C.wood), dx, 0.3, 0.28, 5));
      g.add(sph(0.05, mat(0xc9a06a, { roughness: 1 }), dx, 0.54, 0.28, 5));
      g.add(box(0.24, 0.04, 0.04, mat(C.woodDark), dx, 0.44, 0.28)); // 横臂
      g.add(box(0.16, 0.16, 0.03, mat(0xd9cba8, { roughness: 1 }), dx, 0.36, 0.28)); // 靶心
      g.add(cyl(0.02, 0.02, 0.012, mat(0xc0392b), dx, 0.36, 0.296, 6));
    }
    // 武器架 (斜靠的长矛)
    for (let i = 0; i < 3; i++) {
      const spear = cyl(0.008, 0.008, 0.5, mat(C.woodDark), -0.34 + i * 0.05, 0.3, -0.3, 4);
      spear.rotation.z = 0.22 - i * 0.06;
      g.add(spear);
      g.add(cone(0.014, 0.05, mat(C.metal, { metalness: 0.6 }), -0.36 + i * 0.05, 0.56, -0.3, 4));
    }
    // 军旗
    g.add(cyl(0.012, 0.012, 0.62, mat(C.woodDark), 0.4, 0.34, -0.36, 4));
    g.add(box(0.16, 0.1, 0.006, mat(0xc0392b), 0.48, 0.56, -0.36));
    g.add(sph(0.018, mat(C.gold, { metalness: 0.6 }), 0.4, 0.66, -0.36, 5));
    return g;
  },
  armory: () => {
    const g = new THREE.Group();
    g.add(plinth(1, C.stoneDark));
    // 石砌锻工坊 (封闭主体 —— 不是敞棚, 一眼是正经工房)
    g.add(box(0.66, 0.48, 0.5, mat(C.stone, { roughness: 1 }), -0.1, 0.31, -0.1));
    g.add(gable(0.74, 0.56, 0.18, mat(0x5f666d, { roughness: 0.9 }), -0.1, 0.55, -0.1));
    // 大烟囱 (砖色, 冒烟)
    g.add(cyl(0.055, 0.075, 0.66, mat(C.brick, { roughness: 1 }), -0.38, 0.7, -0.32, 7));
    g.add(cyl(0.06, 0.055, 0.07, mat(0x3d3a36), -0.38, 1.05, -0.32, 7));
    (g as any).smokeSpots = [new THREE.Vector3(-0.38, 1.1, -0.32)];
    // 门口大锻炉 (炉口喷火)
    g.add(box(0.2, 0.22, 0.08, mat(0x3d3a33, { roughness: 1 }), -0.32, 0.2, 0.18));
    const forgeGlow = sph(0.06, mat(0xfab005, { emissive: 0xe8590c, emissiveIntensity: 1.4 }), -0.32, 0.2, 0.23, 5);
    (forgeGlow as any).isFlame = true;
    g.add(forgeGlow);
    // 门口铁砧 + 烧红的剑坯
    g.add(box(0.15, 0.08, 0.08, mat(0x3a3f44, { metalness: 0.6, roughness: 0.4 }), -0.02, 0.21, 0.14));
    g.add(box(0.05, 0.13, 0.05, mat(C.woodDark), -0.02, 0.11, 0.14));
    g.add(box(0.24, 0.014, 0.03, mat(0xd8dde0, { metalness: 0.8, roughness: 0.3, emissive: 0xb45309, emissiveIntensity: 0.45 }), -0.02, 0.265, 0.14));
    // 淬火桶 (蓝水)
    g.add(cyl(0.06, 0.055, 0.11, mat(C.woodDark), 0.14, 0.13, 0.18, 8));
    g.add(cyl(0.052, 0.052, 0.02, mat(0x2e6b9e, { roughness: 0.25 }), 0.14, 0.19, 0.18, 8));
    // 武器展示架 (大号立式, 剑斧各一)
    g.add(box(0.34, 0.05, 0.06, mat(C.wood), 0.28, 0.46, 0.24));
    g.add(box(0.05, 0.46, 0.05, mat(C.woodDark), 0.28, 0.24, 0.24));
    for (let i = 0; i < 3; i++) {
      g.add(box(0.016, 0.3, 0.016, mat(C.metal, { metalness: 0.7, roughness: 0.3 }), 0.16 + i * 0.12, 0.44, 0.24));
      g.add(cone(0.022, 0.06, mat(0xd8dde0, { metalness: 0.7 }), 0.16 + i * 0.12, 0.61, 0.24, 4));
      g.add(box(0.06, 0.02, 0.02, mat(0x8a6a3c), 0.16 + i * 0.12, 0.3, 0.24)); // 护手
    }
    // 门口战鼓
    g.add(cyl(0.06, 0.06, 0.09, mat(0x8a4a2a, { roughness: 0.9 }), 0.38, 0.09, 0.02, 8));
    g.add(cyl(0.062, 0.062, 0.012, mat(0xe8dcc5), 0.38, 0.135, 0.02, 8));
    return g;
  },
  armor: () => {
    const g = new THREE.Group();
    g.add(plinth(1, C.stoneDark));
    // 甲胄工坊: 石砌工房 + 明亮木板墙店面
    const main = winBox(0.62, 0.46, 0.52, 'armorshop', 4, 3, 0.6, '#a89478');
    main.position.set(-0.14, 0.3, -0.16); g.add(main);
    g.add(gable(0.7, 0.58, 0.17, mat(0x5f666d, { roughness: 0.9 }), -0.14, 0.53, -0.16));
    // 招牌: 大盾牌 + 交叉剑徽 (金色饰边, 高挂山墙上 —— 远看即知)
    g.add(cyl(0.105, 0.105, 0.02, mat(0x6a4a26, { roughness: 0.7 }), -0.14, 0.42, 0.104, 12).rotateX(Math.PI / 2) as THREE.Mesh);
    g.add(box(0.17, 0.2, 0.016, mat(0x3a6ea5, { roughness: 0.6, emissive: 0x0d2135, emissiveIntensity: 0.4 }), -0.14, 0.42, 0.115));
    g.add(box(0.065, 0.065, 0.018, mat(C.gold, { metalness: 0.6, emissive: 0x4a3a10, emissiveIntensity: 0.5 }), -0.14, 0.42, 0.122));
    g.add(box(0.018, 0.17, 0.018, mat(C.metal, { metalness: 0.7 }), -0.185, 0.42, 0.124));
    g.add(box(0.018, 0.17, 0.018, mat(C.metal, { metalness: 0.7 }), -0.095, 0.42, 0.124));
    // 前檐挂饰: 一排小盾牌 (蓝金相间)
    for (let i = 0; i < 3; i++) {
      g.add(cyl(0.032, 0.032, 0.014, mat(i % 2 ? 0x3a6ea5 : 0xd9a536, { metalness: 0.4, roughness: 0.5 }), -0.26 + i * 0.12, 0.36, 0.098, 8).rotateX(Math.PI / 2) as THREE.Mesh);
    }
    // 门前高台盔甲模特 (加大 —— 招牌景观)
    for (const dx of [0.18, 0.4]) {
      g.add(box(0.14, 0.05, 0.14, mat(C.stoneDark), dx, 0.05, 0.32)); // 石台
      // 钢腿
      for (const lx of [-0.03, 0.03]) g.add(box(0.03, 0.18, 0.03, mat(0x7d868e, { metalness: 0.5, roughness: 0.4 }), dx + lx, 0.16, 0.32));
      // 胸甲 (金属光泽 + 金饰)
      g.add(box(0.13, 0.16, 0.09, mat(0xb8bec4, { metalness: 0.55, roughness: 0.35 }), dx, 0.33, 0.32));
      g.add(box(0.05, 0.05, 0.095, mat(C.gold, { metalness: 0.6, roughness: 0.4 }), dx, 0.33, 0.32));
      // 肩甲
      for (const sx of [-0.08, 0.08]) g.add(sph(0.035, mat(0x9aa3ab, { metalness: 0.55, roughness: 0.35 }), dx + sx, 0.42, 0.32, 5));
      // 头盔 (带红缨)
      g.add(sph(0.046, mat(0xb8bec4, { metalness: 0.55, roughness: 0.35 }), dx, 0.5, 0.32, 6));
      g.add(box(0.012, 0.032, 0.005, mat(0x2b2b2b), dx, 0.5, 0.36));
      g.add(cone(0.018, 0.06, mat(0xc0392b), dx, 0.57, 0.32, 4));
      // 长戟
      g.add(cyl(0.009, 0.009, 0.56, mat(C.woodDark), dx + 0.1, 0.33, 0.32, 4));
      g.add(cone(0.016, 0.05, mat(C.metal, { metalness: 0.7 }), dx + 0.1, 0.63, 0.32, 4));
    }
    // 门口晾甲架: 挂着的胸甲与头盔
    g.add(cyl(0.018, 0.02, 0.44, mat(C.woodDark), -0.44, 0.25, 0.28, 4));
    g.add(cyl(0.014, 0.014, 0.3, mat(C.woodDark), -0.44, 0.44, 0.28, 4).rotateZ(Math.PI / 2) as THREE.Mesh);
    g.add(box(0.1, 0.12, 0.05, mat(0xb8bec4, { metalness: 0.5, roughness: 0.4 }), -0.5, 0.36, 0.28));
    g.add(sph(0.04, mat(0x9aa3ab, { metalness: 0.5 }), -0.38, 0.38, 0.28, 5));
    return g;
  },
  watchtower: () => {
    const g = new THREE.Group();
    // 高脚瞭望塔
    for (const [dx, dz] of [[-0.16, -0.16], [0.16, -0.16], [-0.16, 0.16], [0.16, 0.16]] as const) {
      const leg = cyl(0.03, 0.04, 0.9, mat(C.woodDark, { roughness: 1 }), dx, 0.47, dz, 5);
      leg.rotation.x = -dz * 0.12; leg.rotation.z = dx * 0.12;
      g.add(leg);
    }
    // 交叉撑
    g.add(box(0.36, 0.025, 0.025, mat(C.wood), 0, 0.3, -0.12));
    g.add(box(0.36, 0.025, 0.025, mat(C.wood), 0, 0.3, 0.12));
    g.add(box(0.025, 0.025, 0.36, mat(C.wood), -0.12, 0.44, 0));
    g.add(box(0.025, 0.025, 0.36, mat(C.wood), 0.12, 0.44, 0));
    // 塔室 (带围栏平台 + 尖顶)
    g.add(box(0.4, 0.26, 0.4, mat(C.wood, { roughness: 1 }), 0, 1.0, 0));
    for (const [dx, dz, w, d] of [[0, -0.23, 0.52, 0.03], [0, 0.23, 0.52, 0.03], [-0.23, 0, 0.03, 0.52], [0.23, 0, 0.03, 0.52]] as const) {
      g.add(box(w, 0.1, d, mat(C.woodDark, { roughness: 1 }), dx, 1.14, dz));
    }
    g.add(cone(0.34, 0.24, mat(C.straw, { roughness: 1 }), 0, 1.32, 0, 4));
    // 瞭望窗 (发光)
    g.add(box(0.1, 0.1, 0.02, mat(0xffe9b0, { emissive: 0xffd98a, emissiveIntensity: 0.8 }), 0, 1.0, 0.21));
    g.add(box(0.02, 0.1, 0.1, mat(0xffe9b0, { emissive: 0xffd98a, emissiveIntensity: 0.8 }), 0.21, 1.0, 0));
    // 塔顶火盆
    g.add(cyl(0.04, 0.05, 0.05, mat(C.metalDark), 0, 1.47, 0, 7));
    const fire = sph(0.035, mat(0xfab005, { emissive: 0xe8590c, emissiveIntensity: 1.1 }), 0, 1.5, 0, 5);
    (fire as any).isFlame = true;
    g.add(fire);
    // 信号旗
    g.add(cyl(0.008, 0.008, 0.2, mat(C.woodDark), 0.15, 1.42, 0.15, 4));
    g.add(box(0.1, 0.06, 0.005, mat(0xd97706), 0.2, 1.46, 0.15));
    return g;
  },
  reservoir: () => {
    const g = new THREE.Group();
    g.add(plinth(1, C.stoneDark));
    // 地上蓄水池 (石砌圆池 + 水)
    g.add(cyl(0.4, 0.44, 0.3, mat(0x9aa3ab, { roughness: 0.95 }), 0, 0.19, 0, 14));
    g.add(cyl(0.34, 0.34, 0.05, mat(0x2e6b9e, { roughness: 0.25, metalness: 0.1 }), 0, 0.34, 0, 14));
    // 环形走道护栏
    for (let i = 0; i < 10; i++) {
      const a = (i / 10) * Math.PI * 2;
      g.add(cyl(0.014, 0.014, 0.14, mat(C.metalDark, { metalness: 0.4 }), Math.cos(a) * 0.4, 0.4, Math.sin(a) * 0.4, 4));
    }
    g.add(cyl(0.42, 0.42, 0.02, mat(C.metal, { metalness: 0.4, roughness: 0.6 }), 0, 0.47, 0, 14));
    // 中央水位塔标
    g.add(cyl(0.02, 0.02, 0.44, mat(C.metal), 0, 0.55, 0, 5));
    const float = sph(0.035, mat(0xf5d90a), 0, 0.42, 0, 6);
    (float as any).isPump = true; // 上下浮动
    g.add(float);
    // 进出水管
    const p1 = cyl(0.03, 0.03, 0.3, mat(0x707a84, { metalness: 0.4 }), -0.42, 0.1, 0, 6);
    p1.rotation.z = Math.PI / 2;
    g.add(p1);
    const p2 = cyl(0.03, 0.03, 0.3, mat(0x3a86b8, { roughness: 0.5 }), 0.42, 0.1, 0, 6);
    p2.rotation.z = Math.PI / 2;
    g.add(p2);
    // 水面涟漪标记
    const ripple = cyl(0.14, 0.14, 0.008, mat(0x8fd4f5, { transparent: true, opacity: 0.6 }), 0, 0.365, 0, 12);
    (ripple as any).isFountain = true;
    g.add(ripple);
    return g;
  },

  // ================= 遗迹 =================
  ruin_circle: () => {
    const g = new THREE.Group();
    // 巨石阵: 完整感更强的环形立石 (仅一两块倾倒, 环形一目了然)
    const n = 8;
    const R = 0.34;
    for (let i = 0; i < n; i++) {
      const a = (i / n) * Math.PI * 2;
      const fallen = i === 5;
      if (fallen) {
        const stone = box(0.1, 0.42, 0.14, mat(0x8d8a80, { roughness: 1 }), Math.cos(a) * R, 0.07, Math.sin(a) * R);
        stone.rotation.z = Math.PI / 2 - 0.15;
        stone.rotation.y = a;
        g.add(stone);
      } else {
        const lean = i === 3 ? 0.18 : 0;
        const stone = box(0.1, 0.54 + (i % 3) * 0.05, 0.14, mat(i % 2 ? 0x8d8a80 : 0x7d7a72, { roughness: 1 }), Math.cos(a) * R, 0.29, Math.sin(a) * R);
        stone.rotation.y = a;
        stone.rotation.z = lean;
        g.add(stone);
        // 楣石 (连续的环形梁)
        const a2 = ((i + 1) / n) * Math.PI * 2;
        const mx = (Math.cos(a) + Math.cos(a2)) / 2 * R;
        const mz = (Math.sin(a) + Math.sin(a2)) / 2 * R;
        const lintel = box(0.32, 0.09, 0.12, mat(0x85827a, { roughness: 1 }), mx, 0.6, mz);
        lintel.rotation.y = a + Math.PI / 2 + Math.PI / n;
        g.add(lintel);
      }
    }
    // 中央祭坛石 + 苔藓
    g.add(cyl(0.13, 0.16, 0.1, mat(0x7d7a72, { roughness: 1 }), 0, 0.09, 0, 8));
    g.add(box(0.18, 0.06, 0.13, mat(0x85827a, { roughness: 1 }), 0, 0.16, 0));
    g.add(sph(0.045, mat(0x4c8c3f, { roughness: 1 }), 0.08, 0.05, 0.1, 4));
    g.add(sph(0.04, mat(0x4c8c3f, { roughness: 1 }), -0.2, 0.045, -0.06, 4));
    return g;
  },
  ruin_tower: () => {
    const g = new THREE.Group();
    // 残破石塔: 断裂圆柱塔身 + 裂口 + 碎石
    const body = cyl(0.24, 0.3, 0.8, mat(0x8d8a80, { roughness: 1 }), 0, 0.44, 0, 10);
    g.add(body);
    // 断裂顶部 (不规则缺口用几个斜块模拟)
    const broken1 = box(0.2, 0.18, 0.12, mat(0x85827a, { roughness: 1 }), -0.06, 0.88, 0.02);
    broken1.rotation.z = 0.3;
    g.add(broken1);
    const broken2 = box(0.14, 0.14, 0.14, mat(0x7d7a72, { roughness: 1 }), 0.12, 0.86, -0.05);
    broken2.rotation.z = -0.25;
    broken2.rotation.x = 0.15;
    g.add(broken2);
    // 窗洞 (黑色凹陷)
    g.add(box(0.09, 0.14, 0.05, mat(0x2b2823, { roughness: 1 }), 0, 0.55, 0.26));
    g.add(box(0.09, 0.12, 0.05, mat(0x2b2823, { roughness: 1 }), 0.25, 0.38, 0.05));
    // 塔基门洞
    g.add(box(0.12, 0.2, 0.06, mat(0x2b2823, { roughness: 1 }), 0, 0.12, 0.27));
    // 爬藤
    g.add(box(0.02, 0.4, 0.02, mat(0x3d7a33, { roughness: 1 }), -0.22, 0.24, 0.12));
    g.add(sph(0.06, mat(0x4c8c3f, { roughness: 1 }), -0.22, 0.44, 0.12, 5));
    // 周围碎石
    for (const [dx, dz, s] of [[0.34, 0.2, 0.06], [-0.36, 0.16, 0.05], [0.18, -0.36, 0.07], [-0.24, -0.32, 0.045]] as const) {
      g.add(box(s, s * 0.7, s, mat(0x7d7a72, { roughness: 1 }), dx, s * 0.35, dz));
    }
    return g;
  },
  ruin_camp: () => {
    const g = new THREE.Group();
    // 远古营地: 半塌的大帐篷 + 熄灭篝火圈 + 补给箱 (整体加大)
    // 半塌帐篷: A 字骨架 + 塌下的帆布 (保留帐篷轮廓)
    g.add(box(0.44, 0.05, 0.36, mat(0x8a7a5c, { roughness: 1 }), -0.16, 0.04, -0.14));
    for (const [dx, dz, rz] of [[-0.3, -0.18, 0.55], [-0.02, -0.24, -0.5], [-0.26, 0.02, 0.3]] as const) {
      const pole = cyl(0.017, 0.017, 0.5, mat(C.woodDark), dx, 0.2, dz, 4);
      pole.rotation.z = rz;
      g.add(pole);
    }
    const cloth = box(0.42, 0.02, 0.34, mat(0x9a8468, { roughness: 1 }), -0.16, 0.18, -0.14);
    cloth.rotation.z = 0.28; cloth.rotation.y = 0.15;
    g.add(cloth);
    const cloth2 = box(0.3, 0.016, 0.22, mat(0x8a7660, { roughness: 1 }), -0.1, 0.26, -0.2);
    cloth2.rotation.z = -0.4;
    g.add(cloth2);
    // 熄灭的篝火 (大灰烬环 + 焦木)
    g.add(cyl(0.16, 0.19, 0.05, mat(0x4a4440, { roughness: 1 }), 0.24, 0.035, 0.16, 10));
    for (let i = 0; i < 7; i++) {
      const a = (i / 7) * Math.PI * 2;
      g.add(sph(0.035, mat(0x6a655e, { roughness: 1 }), 0.24 + Math.cos(a) * 0.16, 0.03, 0.16 + Math.sin(a) * 0.16, 5));
    }
    for (let i = 0; i < 5; i++) {
      const a = (i / 5) * Math.PI * 2;
      const log = cyl(0.02, 0.02, 0.2, mat(0x3a332c, { roughness: 1 }), 0.24 + Math.cos(a) * 0.07, 0.07, 0.16 + Math.sin(a) * 0.07, 4);
      log.rotation.z = 1.25;
      log.rotation.y = a;
      g.add(log);
    }
    // 埋着的补给箱 (半掩埋 ×2)
    g.add(box(0.2, 0.12, 0.13, mat(0x6b5a42, { roughness: 1 }), 0.42, 0.07, -0.3));
    g.add(box(0.22, 0.022, 0.15, mat(C.metalDark, { metalness: 0.3 }), 0.42, 0.14, -0.3));
    g.add(box(0.16, 0.1, 0.11, mat(0x75634a, { roughness: 1 }), 0.28, 0.06, -0.42));
    // 陶罐 + 木桩标牌
    g.add(cyl(0.06, 0.04, 0.12, mat(0xa85f4a, { roughness: 1 }), -0.46, 0.07, 0.26, 8));
    g.add(cyl(0.024, 0.034, 0.035, mat(0x8a4a3a, { roughness: 1 }), -0.46, 0.145, 0.26, 7));
    g.add(cyl(0.018, 0.022, 0.34, mat(C.woodDark), 0.06, 0.18, 0.44, 4));
    g.add(box(0.15, 0.1, 0.014, mat(0x8a7a5c, { roughness: 1 }), 0.06, 0.3, 0.44));
    return g;
  },
  ruin_obelisk: () => {
    const g = new THREE.Group();
    // 神秘石碑: 高耸方尖碑 + 发光符文 + 碎石基座
    g.add(box(0.34, 0.08, 0.34, mat(0x7d7a72, { roughness: 1 }), 0, 0.04, 0));
    // 碑身 (略微倾斜, 岁月痕迹)
    const obelisk = box(0.14, 0.85, 0.14, mat(0x85827a, { roughness: 0.95 }), 0, 0.48, 0);
    obelisk.rotation.z = 0.06;
    g.add(obelisk);
    // 顶尖 (金字塔顶)
    const tip = cone(0.1, 0.16, mat(0x8d8a80, { roughness: 0.9 }), 0.005, 0.98, 0, 4);
    tip.rotation.z = 0.06;
    g.add(tip);
    // 发光符文 (青色神秘纹路)
    for (let i = 0; i < 4; i++) {
      const rune = box(0.02, 0.06 - (i % 2) * 0.015, 0.015, mat(0x67e8f9, { emissive: 0x22d3ee, emissiveIntensity: 1.2 }), -0.072, 0.3 + i * 0.15, 0.055);
      rune.rotation.z = 0.06;
      g.add(rune);
      g.add(box(0.015, 0.015, 0.015, mat(0x67e8f9, { emissive: 0x22d3ee, emissiveIntensity: 1.2 }), -0.072, 0.36 + i * 0.15, 0.055));
    }
    // 环绕小石柱
    for (let i = 0; i < 3; i++) {
      const a = (i / 3) * Math.PI * 2 + 0.5;
      g.add(cyl(0.03, 0.04, 0.18 + i * 0.04, mat(0x7d7a72, { roughness: 1 }), Math.cos(a) * 0.28, 0.1 + i * 0.02, Math.sin(a) * 0.28, 6));
    }
    return g;
  },

  ruin_ship: () => {
    const g = new THREE.Group();
    // 搁浅沉船: 清晰的船体轮廓 (龙骨弯曲 + 高耸艏艉) + 折断桅杆
    const woodDark = mat(0x5a4a3a, { roughness: 1 });
    const woodMid = mat(0x6a5a46, { roughness: 1 });
    // 船底龙骨 (弧形: 中间低两头翘)
    const keel = box(0.9, 0.16, 0.3, woodDark, 0, 0.12, 0);
    keel.rotation.z = 0.1; keel.rotation.y = 0.45;
    g.add(keel);
    // 船艏 (翘起尖削) + 艉楼
    const bow = box(0.34, 0.3, 0.26, woodMid, 0.52, 0.3, -0.14);
    bow.rotation.z = 0.5; bow.rotation.y = 0.45;
    g.add(bow);
    const bowTip = box(0.18, 0.18, 0.16, woodDark, 0.68, 0.42, -0.22);
    bowTip.rotation.z = 0.62; bowTip.rotation.y = 0.45;
    g.add(bowTip);
    const stern = box(0.3, 0.34, 0.3, woodMid, -0.42, 0.34, 0.1);
    stern.rotation.z = -0.3; stern.rotation.y = 0.45;
    g.add(stern);
    // 船舷板 (两侧, 有破洞)
    for (const s of [-1, 1]) {
      const side = box(0.8, 0.18, 0.05, woodMid, 0, 0.28, s * 0.17);
      side.rotation.z = 0.1; side.rotation.y = 0.45;
      g.add(side);
      if (s === 1) {
        g.add(box(0.18, 0.13, 0.06, mat(0x14100c, { roughness: 1 }), -0.05, 0.28, 0.2)); // 破洞
      }
    }
    // 甲板 (半塌, 露出货舱黑洞)
    const deck = box(0.7, 0.05, 0.3, mat(0x7a664e, { roughness: 1 }), 0.02, 0.38, 0);
    deck.rotation.z = 0.12; deck.rotation.y = 0.45;
    g.add(deck);
    g.add(box(0.24, 0.1, 0.2, mat(0x0e0a08, { roughness: 1 }), 0.1, 0.36, 0.02)); // 货舱口
    // 主桅 (折断斜倒) + 残帆
    const mast = cyl(0.03, 0.038, 1.1, mat(0x4a3c2e, { roughness: 1 }), -0.08, 0.7, 0.2, 6);
    mast.rotation.z = 1.05; mast.rotation.y = 0.35;
    g.add(mast);
    const yard = cyl(0.018, 0.018, 0.5, mat(0x4a3c2e, { roughness: 1 }), 0.24, 0.88, 0.3, 5);
    yard.rotation.z = Math.PI / 2; yard.rotation.y = 0.55;
    g.add(yard);
    const sail = box(0.34, 0.26, 0.014, mat(0xa8a094, { roughness: 1 }), 0.1, 0.78, 0.36);
    sail.rotation.z = 0.35; sail.rotation.y = 0.45;
    g.add(sail);
    // 艏斜桅
    const bowsprit = cyl(0.02, 0.024, 0.4, mat(0x5a4a3a, { roughness: 1 }), 0.8, 0.5, -0.3, 5);
    bowsprit.rotation.z = 1.0; bowsprit.rotation.y = 0.45;
    g.add(bowsprit);
    // 货箱与木桶散落
    g.add(box(0.15, 0.12, 0.12, mat(0x7a664e, { roughness: 1 }), -0.62, 0.07, -0.32));
    const crate2 = box(0.12, 0.11, 0.11, mat(0x6e5c46, { roughness: 1 }), -0.48, 0.06, -0.42);
    crate2.rotation.y = 0.7;
    g.add(crate2);
    g.add(cyl(0.05, 0.045, 0.13, mat(0x5f4d38, { roughness: 1 }), 0.66, 0.07, 0.28, 8));
    // 锚
    g.add(box(0.03, 0.18, 0.02, mat(0x4a4a4e, { metalness: 0.4, roughness: 0.7 }), 0.7, 0.11, -0.44));
    g.add(box(0.12, 0.028, 0.02, mat(0x4a4a4e, { metalness: 0.4, roughness: 0.7 }), 0.7, 0.03, -0.44));
    return g;
  },
  ruin_gas: () => {
    const g = new THREE.Group();
    const rust = { roughness: 0.9, metalness: 0.2 };
    // 便利店主体 (破窗)
    g.add(box(0.4, 0.32, 0.32, mat(0xb0a894, { roughness: 1 }), -0.22, 0.19, -0.16));
    g.add(box(0.44, 0.04, 0.36, mat(0x6a625a, { roughness: 1 }), -0.22, 0.37, -0.16));
    // 破橱窗 (黑)
    g.add(box(0.26, 0.16, 0.02, mat(0x15171a, { roughness: 1 }), -0.22, 0.22, 0.005));
    // 加油岛 + 两台锈泵
    g.add(box(0.34, 0.08, 0.2, mat(0x9a948a, { roughness: 1 }), 0.2, 0.05, 0.18));
    for (const dx of [0.1, 0.3]) {
      g.add(box(0.1, 0.26, 0.09, mat(0x9a5a3c, rust), dx, 0.22, 0.18));
      g.add(box(0.11, 0.03, 0.1, mat(0x7c746c, rust), dx, 0.36, 0.18));
      g.add(box(0.03, 0.1, 0.02, mat(0x3a3a3e, rust), dx, 0.24, 0.23));
    }
    // 雨棚 (一角塌陷)
    const canopyMat = mat(0xd8d4c8, { roughness: 0.9 });
    const c1 = box(0.5, 0.035, 0.26, canopyMat, 0.2, 0.56, 0.18);
    c1.rotation.z = 0.14;
    g.add(c1);
    for (const [dx, dz, h] of [[0.02, 0.08, 0.42], [0.38, 0.08, 0.44], [0.02, 0.28, 0.4], [0.38, 0.28, 0.3]] as const) {
      g.add(cyl(0.018, 0.018, h, mat(0x8a847c, rust), dx, h / 2 + 0.08, dz, 5));
    }
    // 招牌柱 (只剩骨架)
    g.add(cyl(0.02, 0.024, 0.66, mat(0x7c746c, rust), -0.4, 0.37, 0.28, 5));
    const sign = box(0.24, 0.14, 0.02, mat(0x8a4a3a, rust), -0.4, 0.74, 0.28);
    sign.rotation.z = 0.2;
    g.add(sign);
    // 地面油渍
    const stain = cyl(0.16, 0.16, 0.008, mat(0x2a2620, { roughness: 1 }), 0.44, 0.012, -0.3, 10);
    g.add(stain);
    // 杂草
    for (const [dx, dz] of [[-0.42, 0.34], [0.44, -0.12], [-0.05, 0.4]] as const) {
      g.add(sph(0.035, mat(0x5d7a4a, { roughness: 1 }), dx, 0.04, dz, 4));
    }
    return g;
  },
  ruin_drone: () => {
    const g = new THREE.Group();
    const gun = { roughness: 0.55, metalness: 0.5 };
    const gunMat = mat(0x4a5258, gun);
    // 坠毁无人机: 清晰的机身 + 双平直翼 + 垂尾 + 机头传感器
    const body = box(0.46, 0.16, 0.18, gunMat, 0, 0.11, 0);
    body.rotation.y = -0.5;
    body.rotation.z = 0.06;   // 机头触地
    g.add(body);
    // 机鼻: 传感器球 + 天线
    g.add(sph(0.075, mat(0x39424a, gun), 0.26, 0.21, -0.1, 8));
    g.add(cyl(0.014, 0.014, 0.14, mat(0x2c3238, gun), 0.34, 0.3, -0.12, 4));
    // 主翼: 左右平直 (完整翼 + 折断短翼, 翼尖红灯)
    const wingL = box(0.56, 0.035, 0.15, mat(0x525a60, gun), -0.1, 0.22, 0.1);
    wingL.rotation.z = 0.3; wingL.rotation.y = -0.4;
    g.add(wingL);
    const tipLight = sph(0.02, mat(0xc0392b, { emissive: 0xc0392b, emissiveIntensity: 1.2 }), -0.38, 0.32, 0.19, 5);
    (tipLight as any).isBeacon = true;
    g.add(tipLight);
    const wingR = box(0.3, 0.035, 0.14, gunMat, 0.24, 0.08, 0.22);
    wingR.rotation.z = -0.12; wingR.rotation.y = 0.8;
    g.add(wingR);
    // 翼上红色识别条
    g.add(box(0.14, 0.038, 0.155, mat(0x8a3a2a, { roughness: 0.7 }), -0.06, 0.26, 0.15));
    // 垂尾 + 平尾
    const fin = box(0.03, 0.2, 0.14, mat(0x525a60, gun), -0.28, 0.28, -0.05);
    fin.rotation.z = -0.25;
    g.add(fin);
    g.add(box(0.16, 0.028, 0.1, mat(0x525a60, gun), -0.3, 0.2, -0.06));
    // 螺旋桨 (散落两片)
    g.add(cyl(0.014, 0.014, 0.32, mat(0x2c3238, gun), 0.34, 0.26, 0.0, 4));
    const blade = box(0.22, 0.014, 0.035, mat(0x2c3238, gun), 0.4, 0.09, 0.32);
    blade.rotation.y = 0.7; blade.rotation.z = 0.25;
    g.add(blade);
    // 滑行犁沟 + 掀起的土堆
    g.add(box(0.6, 0.02, 0.13, mat(0x6a5a44, { roughness: 1 }), -0.28, 0.03, -0.18));
    g.add(sph(0.07, mat(0x7a6a50, { roughness: 1 }), -0.55, 0.045, -0.22, 5));
    g.add(sph(0.05, mat(0x6a5a44, { roughness: 1 }), -0.44, 0.04, -0.3, 4));
    // 数据核心 (青光微闪 —— 可搜刮)
    const core = sph(0.038, mat(0x67e8f9, { emissive: 0x22d3ee, emissiveIntensity: 1.4 }), 0.04, 0.26, 0.05, 6);
    (core as any).isFlame = true;
    g.add(core);
    return g;
  },

  ruin_cellar: () => {
    const g = new THREE.Group();
    // 掩埋地窖: 土丘 + 半开的木舱门 + 石砌门框
    const mound = sph(0.34, mat(0x74604a, { roughness: 1 }), 0, 0.1, 0, 8);
    mound.scale.set(1.15, 0.42, 1.15);
    g.add(mound);
    // 石砌门缘
    for (const dx of [-0.14, 0.14]) g.add(box(0.07, 0.16, 0.22, mat(0x85827a, { roughness: 1 }), dx, 0.14, 0.16));
    g.add(box(0.35, 0.07, 0.22, mat(0x8d8a80, { roughness: 1 }), 0, 0.21, 0.16));
    // 半开的舱门 (斜搭)
    const hatch = box(0.28, 0.03, 0.26, mat(0x6b5844, { roughness: 1 }), -0.02, 0.26, 0.22);
    hatch.rotation.x = -0.85;
    g.add(hatch);
    // 门下黑洞
    g.add(box(0.2, 0.02, 0.12, mat(0x0e0c0a, { roughness: 1 }), 0.03, 0.115, 0.15));
    // 台阶下探
    g.add(box(0.22, 0.03, 0.08, mat(0x7d7a72, { roughness: 1 }), 0.03, 0.05, 0.1));
    // 陶罐与木桶
    g.add(cyl(0.055, 0.04, 0.11, mat(0xa85f4a, { roughness: 1 }), 0.3, 0.06, 0.02, 8));
    g.add(cyl(0.02, 0.03, 0.025, mat(0x8a4a3a, { roughness: 1 }), 0.3, 0.13, 0.02, 7));
    g.add(cyl(0.05, 0.05, 0.09, mat(0x5f4d38, { roughness: 1 }), -0.32, 0.05, 0.14, 8));
    // 麻袋 (半埋)
    g.add(sph(0.06, mat(0xb8944f, { roughness: 1 }), -0.22, 0.05, -0.2, 5));
    g.add(sph(0.05, mat(0xc9a06a, { roughness: 1 }), -0.12, 0.04, -0.28, 5));
    // 木叉斜插
    const fork = cyl(0.012, 0.012, 0.4, mat(0x8a7a5c, { roughness: 1 }), 0.34, 0.2, -0.24, 4);
    fork.rotation.z = 0.35;
    g.add(fork);
    return g;
  },

  // 废墟
  rubble: () => {
    const g = new THREE.Group();
    g.add(box(0.6, 0.12, 0.6, mat(0x6b625a, { roughness: 1 }), 0, 0.06, 0));
    g.add(box(0.24, 0.14, 0.16, mat(0x7d746b), 0.1, 0.12, 0.1));
    g.add(box(0.14, 0.1, 0.24, mat(0x7d746b), -0.14, 0.09, -0.06));
    g.add(cyl(0.045, 0.055, 0.28, mat(0x5a5248), 0.2, 0.14, -0.16, 5));
    g.add(box(0.1, 0.06, 0.14, mat(0x8d8478), -0.22, 0.09, 0.18));
    return g;
  },

  // ================= v5: 市政增压设施 =================
  transformer: () => {
    const g = new THREE.Group();
    g.add(plinth(1, C.stoneDark));
    // 主控楼 (两层)
    const house = winBox(0.56, 0.5, 0.44, 'transf', 4, 3, 0.5, '#b8b2a6');
    house.position.set(-0.17, 0.31, -0.14); g.add(house);
    g.add(gable(0.62, 0.5, 0.14, mat(C.roofDark), -0.17, 0.57, -0.14));
    // 变压器本体: 冷却管排 + 绝缘子
    const casingMat = mat(0x6b7580, { roughness: 0.6, metalness: 0.5 });
    g.add(box(0.4, 0.36, 0.34, casingMat, 0.18, 0.26, 0.06));
    for (let i = 0; i < 4; i++) {
      g.add(cyl(0.026, 0.026, 0.3, mat(0x3a4148, { metalness: 0.7, roughness: 0.4 }), 0.05 + i * 0.09, 0.26, 0.24, 6));
    }
    // 高压绝缘子 (瓷瓶) ×3
    for (const dx of [-0.08, 0.02, 0.12]) {
      for (let s = 0; s < 3; s++) g.add(cyl(0.028 - s * 0.004, 0.03 - s * 0.004, 0.024, mat(0xcdd6dd, { roughness: 0.3 }), dx, 0.46 + s * 0.03, 0.24, 8));
      g.add(cyl(0.008, 0.008, 0.14, mat(0x8d959c, { metalness: 0.6 }), dx, 0.58, 0.24, 4));
    }
    // 警示牌 ⚡
    g.add(box(0.14, 0.12, 0.012, mat(0xf5d90a, { emissive: 0xf5d90a, emissiveIntensity: 0.25 }), -0.17, 0.34, 0.1));
    g.add(box(0.05, 0.05, 0.014, mat(0x1a1a1a), -0.17, 0.34, 0.108));
    const beacon = sph(0.028, mat(0xc0392b, { emissive: 0xc0392b, emissiveIntensity: 0.9 }), 0.36, 0.48, -0.14, 5);
    (beacon as any).isBeacon = true;
    g.add(beacon);
    g.add(frontPath(0.4, 0.3, 0.44));
    return g;
  },
  pump_station: () => {
    const g = new THREE.Group();
    g.add(plinth(1, 0x8a94a0));
    // 泵房
    const house = winBox(0.58, 0.44, 0.46, 'pumpst', 4, 3, 0.5, '#9aa8b4');
    house.position.set(-0.15, 0.29, -0.12); g.add(house);
    g.add(gable(0.64, 0.52, 0.13, mat(0x4a6b8a), -0.15, 0.52, -0.12));
    // 露天泵组: 泵体 + 电机 + 管道
    const pumpMat = mat(0x3a86b8, { roughness: 0.5, metalness: 0.4 });
    g.add(cyl(0.09, 0.09, 0.24, pumpMat, 0.22, 0.2, 0.16, 10));   // 泵壳
    g.add(cyl(0.06, 0.06, 0.16, mat(0x2f3a44, { metalness: 0.6 }), 0.22, 0.4, 0.16, 8)); // 电机
    g.add(cyl(0.016, 0.016, 0.2, mat(0x8d959c, { metalness: 0.7 }), 0.22, 0.36, 0.05, 6)); // 轴
    // 进出水管 (地上弯管)
    const pipeMat = mat(0xb0703c, { roughness: 0.5, metalness: 0.4 });
    const p1 = cyl(0.038, 0.038, 0.34, pipeMat, 0.36, 0.17, 0.16, 8);
    p1.rotation.z = Math.PI / 2; g.add(p1);
    const p2 = cyl(0.038, 0.038, 0.3, pipeMat, 0.36, 0.32, 0.16, 8);
    g.add(p2);
    const p3 = cyl(0.038, 0.038, 0.2, pipeMat, 0.08, 0.32, 0.16, 8);
    p3.rotation.z = Math.PI / 2; g.add(p3);
    // 法兰盘
    for (const dy of [0.17, 0.32]) g.add(cyl(0.05, 0.05, 0.02, mat(0x6b4423), 0.36, dy, 0.16, 8));
    // 压力表
    g.add(cyl(0.035, 0.035, 0.02, mat(0xf2f2ee), -0.02, 0.52, 0.05, 8));
    const beacon = sph(0.026, mat(0x3a86b8, { emissive: 0x3a86b8, emissiveIntensity: 0.9 }), -0.15, 0.56, 0.05, 5);
    (beacon as any).isBeacon = true;
    g.add(beacon);
    g.add(frontPath(0.4, 0.3, 0.42));
    return g;
  },

  // ================= v5: 载具库 =================
  garage: () => {
    const g = new THREE.Group();
    g.add(plinth(1, C.stoneDark));
    // 车库主体 (大跨度卷帘门)
    const main = winBox(0.78, 0.52, 0.66, 'garage', 5, 3, 0.45, '#5d6b52');
    main.position.set(0, 0.3, -0.05); g.add(main);
    g.add(gable(0.86, 0.74, 0.16, mat(0x3f4a38), 0, 0.58, -0.05));
    // 大卷帘门 + 门轨
    g.add(box(0.42, 0.34, 0.03, mat(0x8d959c, { metalness: 0.5, roughness: 0.5 }), 0, 0.19, 0.29));
    for (let i = 0; i < 6; i++) g.add(box(0.42, 0.014, 0.036, mat(0x6b7378), 0, 0.05 + i * 0.058, 0.292));
    // 侧门 + 油桶
    g.add(box(0.12, 0.2, 0.02, mat(0x4a3f35), -0.36, 0.13, 0.29));
    for (let i = 0; i < 2; i++) g.add(cyl(0.05, 0.05, 0.13, mat(i ? 0x4a5a3c : 0x8a4a2a), 0.38, 0.1, 0.14 + i * 0.11, 8));
    // 屋顶天线 + 旗帜
    g.add(cyl(0.008, 0.008, 0.36, mat(C.metal), -0.34, 0.85, -0.2, 4));
    g.add(box(0.1, 0.07, 0.005, mat(0x5d6b52), -0.3, 0.98, -0.2));
    // 停车位标线 + 装甲车 (车库前)
    g.add(box(0.5, 0.02, 0.36, mat(C.asphalt), 0.06, 0.03, 0.48));
    const apc = new THREE.Group();
    const hull = mat(0x4d5d41, { roughness: 0.8, metalness: 0.3 });
    apc.add(box(0.22, 0.13, 0.4, hull, 0, 0.15, 0));
    apc.add(box(0.18, 0.09, 0.2, hull, 0, 0.25, -0.06));
    for (const dz of [0.14, -0.14]) for (const dx of [-0.13, 0.13]) apc.add(cyl(0.045, 0.045, 0.04, mat(0x1e1e1e), dx, 0.05, dz, 8));
    apc.position.set(0.06, 0.03, 0.5); apc.rotation.y = 0.2;
    g.add(apc);
    g.add(frontPath(0.5, 0.36, 0.46));
    return g;
  },
  tank_plant: () => {
    const g = new THREE.Group();
    g.add(plinth(2, C.stoneDark));
    // 重型厂房 (2×2): 高跨 + 天窗
    const main = winBox(1.5, 0.85, 1.15, 'tankpl', 8, 5, 0.5, '#4a5a48');
    main.position.set(-0.1, 0.5, -0.08); g.add(main);
    g.add(gable(1.6, 1.25, 0.24, mat(0x33422f), -0.1, 0.95, -0.08));
    // 天窗排
    for (let i = 0; i < 3; i++) g.add(box(0.22, 0.12, 0.3, mat(0x9fd4e8, { roughness: 0.3, transparent: true, opacity: 0.8 }), -0.45 + i * 0.35, 1.06, -0.08));
    // 巨大龙门吊 (轨道横跨)
    for (const dz of [-0.62, 0.55]) g.add(box(1.7, 0.06, 0.08, mat(0xe8b830, { metalness: 0.4 }), -0.1, 0.9, dz));
    for (const dx of [-0.85, 0.65]) g.add(cyl(0.03, 0.03, 1.0, mat(0x8d959c, { metalness: 0.6 }), dx, 0.5, -0.05, 6));
    g.add(box(1.55, 0.07, 0.09, mat(0xe8b830, { metalness: 0.4 }), -0.1, 1.0, -0.05));
    g.add(box(0.16, 0.1, 0.1, mat(0x50565c), 0.2, 0.9, -0.05));
    g.add(box(0.012, 0.24, 0.012, mat(0x3a3a3a), 0.2, 0.76, -0.05));
    // 炮管成品架
    for (let i = 0; i < 3; i++) g.add(cyl(0.018, 0.018, 0.5, mat(0x2f3a2c, { metalness: 0.5 }), 0.62, 0.1, 0.3 + i * 0.12, 6));
    // 履带部件堆
    g.add(cyl(0.09, 0.09, 0.05, mat(0x2a2a2a), 0.55, 0.05, -0.4, 10));
    g.add(cyl(0.09, 0.09, 0.05, mat(0x2a2a2a), 0.62, 0.05, -0.34, 10));
    g.add(cyl(0.09, 0.09, 0.05, mat(0x2a2a2a), 0.58, 0.1, -0.37, 10));
    // 烟囱
    g.add(cyl(0.06, 0.08, 0.8, mat(C.brick, { roughness: 1 }), -0.72, 0.95, -0.5, 7));
    (g as any).smokeSpots = [new THREE.Vector3(-0.72, 1.35, -0.5)];
    // 测试场坦克
    const tank = new THREE.Group();
    const thull = mat(0x3a4a37, { roughness: 0.75, metalness: 0.35 });
    for (const dx of [-0.14, 0.14]) tank.add(box(0.08, 0.1, 0.46, mat(0x2a2a2a), dx, 0.06, 0));
    tank.add(box(0.22, 0.09, 0.42, thull, 0, 0.15, 0));
    tank.add(cyl(0.08, 0.09, 0.07, thull, 0, 0.25, 0, 10));
    const barrel = cyl(0.02, 0.02, 0.3, mat(0x2f3a2c, { metalness: 0.5 }), 0, 0.26, 0.14, 6);
    barrel.rotation.x = Math.PI / 2;
    tank.add(barrel);
    tank.position.set(0.45, 0.02, 0.62);
    g.add(tank);
    return g;
  },
  helipad: () => {
    const g = new THREE.Group();
    // 圆形停机坪
    g.add(cyl(0.46, 0.46, 0.06, mat(0x50565c, { roughness: 0.95 }), 0, 0.04, 0, 24));
    g.add(cyl(0.42, 0.42, 0.015, mat(0x2f3a44), 0, 0.078, 0, 24));
    // H 标线
    g.add(box(0.3, 0.012, 0.07, mat(0xf2f2ee), 0, 0.09, 0));
    g.add(box(0.3, 0.012, 0.07, mat(0xf2f2ee), 0, 0.09, 0));
    g.add(box(0.07, 0.012, 0.3, mat(0xf2f2ee), -0.13, 0.09, 0));
    g.add(box(0.07, 0.012, 0.3, mat(0xf2f2ee), 0.13, 0.09, 0));
    // 边界灯 ×8 (夜间发蓝光)
    for (let i = 0; i < 8; i++) {
      const a = (i / 8) * Math.PI * 2;
      const lamp = sph(0.024, mat(0x67e8f9, { emissive: 0x22d3ee, emissiveIntensity: 1 }), Math.cos(a) * 0.42, 0.1, Math.sin(a)  * 0.42, 5);
      (lamp as any).isWindowMesh = true;
      g.add(lamp);
    }
    // 航空灯杆
    g.add(cyl(0.018, 0.022, 0.5, mat(0x8d959c, { metalness: 0.5 }), 0.42, 0.29, -0.42, 5));
    const beacon = sph(0.032, mat(0xc0392b, { emissive: 0xc0392b, emissiveIntensity: 1 }), 0.42, 0.56, -0.42, 5);
    (beacon as any).isBeacon = true;
    g.add(beacon);
    // 待命的武装直升机
    const heli = new THREE.Group();
    const body = mat(0x2f4a5a, { roughness: 0.6, metalness: 0.4 });
    const dark = mat(0x22323d, { roughness: 0.7 });
    heli.add(box(0.13, 0.1, 0.34, body, 0, 0.14, 0));
    heli.add(box(0.09, 0.07, 0.1, mat(0x9fd4e8, { roughness: 0.2, transparent: true, opacity: 0.8 }), 0, 0.17, 0.19));
    heli.add(box(0.04, 0.04, 0.22, body, 0, 0.15, -0.24));
    heli.add(box(0.01, 0.09, 0.06, dark, 0, 0.21, -0.32));
    heli.add(box(0.24, 0.012, 0.035, dark, 0, 0.22, 0));
    heli.add(box(0.035, 0.012, 0.24, dark, 0, 0.22, 0));
    for (const dx of [-0.07, 0.07]) heli.add(cyl(0.012, 0.012, 0.08, mat(0x3a3a3a), dx, 0.06, 0.06, 4));
    heli.position.set(-0.08, 0.07, 0.05); heli.rotation.y = -0.5;
    g.add(heli);
    return g;
  },

  // ================= v5: 新遗迹 =================
  ruin_watchpost: () => {
    const g = new THREE.Group();
    // 废弃哨塔: 锈蚀铁塔 + 倾斜瞭望台 + 塌陷铁皮顶
    for (let i = 0; i < 4; i++) {
      const a = Math.PI / 4 + (i * Math.PI) / 2;
      const leg = cyl(0.02, 0.028, 0.95, mat(0x6b5a4a, { roughness: 1, metalness: 0.3 }), Math.cos(a) * 0.17, 0.48, Math.sin(a) * 0.17, 5);
      leg.rotation.z = Math.cos(a) * 0.1;
      leg.rotation.x = -Math.sin(a) * 0.1;
      g.add(leg);
    }
    for (const h of [0.3, 0.6]) {
      g.add(box(0.34, 0.025, 0.025, mat(0x5a4a3a, { roughness: 1 }), 0, h, 0.17));
      g.add(box(0.34, 0.025, 0.025, mat(0x5a4a3a, { roughness: 1 }), 0, h, -0.17));
      g.add(box(0.025, 0.025, 0.34, mat(0x5a4a3a, { roughness: 1 }), 0.17, h, 0));
      g.add(box(0.025, 0.025, 0.34, mat(0x5a4a4a, { roughness: 1 }), -0.17, h, 0));
    }
    // 瞭望台 (倾斜)
    const cab = box(0.36, 0.22, 0.36, mat(0x7a6a55, { roughness: 1 }), 0, 0.98, 0);
    cab.rotation.z = 0.08; cab.rotation.x = -0.05;
    g.add(cab);
    // 塌陷铁皮顶
    const roof = box(0.42, 0.02, 0.42, mat(0x8a7a68, { roughness: 1, metalness: 0.4 }), 0.03, 1.14, -0.02);
    roof.rotation.z = 0.28;
    g.add(roof);
    // 散落的弹药箱与沙袋
    g.add(box(0.11, 0.07, 0.07, mat(0x5d6b4a), 0.32, 0.05, 0.28));
    g.add(box(0.11, 0.07, 0.07, mat(0x4a5a3c), 0.32, 0.12, 0.28));
    g.add(sph(0.07, mat(0x9a8a6a, { roughness: 1 }), -0.3, 0.05, 0.3, 5));
    g.add(sph(0.06, mat(0x8a7a5a, { roughness: 1 }), -0.22, 0.045, 0.34, 5));
    return g;
  },
  ruin_dock: () => {
    const g = new THREE.Group();
    // 沉没码头: 枯水位木桩 + 淤泥岸 + 半沉货箱
    g.add(box(0.9, 0.06, 0.5, mat(0x6e5a42, { roughness: 1 }), 0, 0.05, -0.1));
    for (let i = 0; i < 4; i++) {
      g.add(cyl(0.024, 0.03, 0.34, mat(0x5a4632, { roughness: 1 }), -0.36 + i * 0.24, 0.2, -0.3, 5));
      g.add(cyl(0.024, 0.03, 0.3 + (i % 2) * 0.06, mat(0x5a4632, { roughness: 1 }), -0.36 + i * 0.24, 0.18, 0.1, 5));
    }
    // 甲板残段 (错位)
    g.add(box(0.4, 0.03, 0.22, mat(0x8a6f4d, { roughness: 1 }), -0.1, 0.33, -0.22, ));
    g.add(box(0.3, 0.03, 0.2, mat(0x7d6547, { roughness: 1 }), 0.24, 0.3, 0.02));
    // 系船柱
    g.add(cyl(0.035, 0.045, 0.1, mat(0x4a4038, { roughness: 1 }), -0.34, 0.39, -0.28, 6));
    g.add(cyl(0.035, 0.045, 0.09, mat(0x4a4038, { roughness: 1 }), 0.3, 0.36, -0.16, 6));
    // 半沉货箱与木桶
    const crate = box(0.16, 0.13, 0.12, mat(0x7a5a3a, { roughness: 1 }), 0.12, 0.1, 0.3);
    crate.rotation.z = 0.4; g.add(crate);
    g.add(cyl(0.05, 0.042, 0.1, mat(0x5f4d38, { roughness: 1 }), -0.28, 0.09, 0.32, 8));
    g.add(sph(0.05, mat(0x8a7a5a, { roughness: 1 }), 0.36, 0.05, 0.26, 5));
    return g;
  },
  ruin_mech: () => {
    const g = new THREE.Group();
    // 巨型残骸: 倒伏的双足机甲 —— 躯干 + 头 + 断腿 + 散落装甲板
    const armor = mat(0x707a84, { roughness: 0.55, metalness: 0.6 });
    const dark = mat(0x3a4048, { roughness: 0.7, metalness: 0.4 });
    // 躯干 (侧躺)
    const torso = box(0.55, 0.3, 0.34, armor, 0, 0.18, 0);
    torso.rotation.z = 0.22; torso.rotation.y = -0.3;
    g.add(torso);
    // 驾驶舱头 (半埋)
    g.add(box(0.2, 0.16, 0.18, armor, -0.28, 0.12, 0.14));
    g.add(box(0.12, 0.07, 0.02, mat(0x2a3a3a, { emissive: 0x67e8f9, emissiveIntensity: 0.35 }), -0.36, 0.15, 0.22));
    // 断腿 ×2 (扭曲)
    const leg1 = cyl(0.05, 0.06, 0.42, dark, 0.24, 0.15, 0.26, 6);
    leg1.rotation.z = 1.2; leg1.rotation.y = 0.5;
    g.add(leg1);
    const leg2 = cyl(0.045, 0.055, 0.36, dark, 0.1, 0.1, -0.3, 6);
    leg2.rotation.z = -1.05;
    g.add(leg2);
    // 巨脚
    g.add(box(0.2, 0.08, 0.3, dark, 0.42, 0.05, 0.38));
    // 散落装甲板 ×3
    const plate1 = box(0.24, 0.03, 0.18, armor, -0.34, 0.03, -0.22);
    plate1.rotation.y = 0.7; g.add(plate1);
    const plate2 = box(0.2, 0.03, 0.14, armor, 0.38, 0.03, -0.18);
    plate2.rotation.y = -0.4; g.add(plate2);
    g.add(box(0.12, 0.03, 0.2, mat(0x8a7a5a, { roughness: 1 }), -0.06, 0.03, 0.4));
    // 闪烁的数据核心
    const core = sph(0.05, mat(0x67e8f9, { emissive: 0x22d3ee, emissiveIntensity: 1.2 }), 0.16, 0.35, -0.05, 6);
    (core as any).isWindowMesh = true;
    g.add(core);
    return g;
  },
  ruin_well: () => {
    const g = new THREE.Group();
    // 神秘古井: 石砌井栏 + 苔藓 + 木架辘轳 + 井口微光
    g.add(cyl(0.24, 0.27, 0.26, mat(0x7d868e, { roughness: 1 }), 0, 0.13, 0, 12));
    for (let i = 0; i < 8; i++) {
      const a = (i / 8) * Math.PI * 2 + 0.2;
      g.add(box(0.1, 0.09, 0.06, mat(i % 2 ? 0x85827a : 0x74716a, { roughness: 1 }), Math.cos(a) * 0.24, 0.09 + (i % 2) * 0.13, Math.sin(a) * 0.24));
    }
    // 井内黑洞与幽光
    g.add(cyl(0.19, 0.19, 0.02, mat(0x0c1216), 0, 0.27, 0, 10));
    const glow = sph(0.05, mat(0x8ee6b8, { emissive: 0x34d399, emissiveIntensity: 1.1 }), 0, 0.24, 0, 6);
    (glow as any).isWindowMesh = true;
    g.add(glow);
    // 双柱木架 + 辘轳
    for (const dx of [-0.2, 0.2]) g.add(cyl(0.022, 0.026, 0.5, mat(0x6b5844, { roughness: 1 }), dx, 0.42, 0, 5));
    g.add(cyl(0.03, 0.03, 0.44, mat(0x8a6f4d, { roughness: 1 }), 0, 0.62, 0, 6));
    const winch = cyl(0.045, 0.045, 0.16, mat(0x5a4632, { roughness: 1 }), 0, 0.55, 0, 8);
    winch.rotation.z = Math.PI / 2;
    g.add(winch);
    g.add(cyl(0.012, 0.012, 0.2, mat(0x4a3f35), -0.13, 0.6, 0, 4));
    // 吊桶
    g.add(cyl(0.04, 0.034, 0.07, mat(0x5f4d38, { roughness: 1 }), 0.06, 0.4, 0, 7));
    g.add(cyl(0.005, 0.005, 0.16, mat(0x8a7a5c), 0.03, 0.5, 0, 4));
    // 供奉的烛台与鹅卵石
    g.add(cyl(0.03, 0.035, 0.04, mat(0xd8d2c5, { roughness: 0.9 }), 0.32, 0.03, 0.24, 6));
    const candle = cyl(0.012, 0.012, 0.06, mat(0xf2ead8, { roughness: 0.9 }), 0.32, 0.08, 0.24, 5);
    g.add(candle);
    const flame = sph(0.014, mat(0xfab005, { emissive: 0xe8590c, emissiveIntensity: 1.3 }), 0.32, 0.12, 0.24, 4);
    (flame as any).isFlame = true;
    g.add(flame);
    for (let i = 0; i < 5; i++) {
      const a = 1.2 + i * 0.9;
      g.add(sph(0.028, mat(0x9aa3a8, { roughness: 1 }), Math.cos(a) * 0.34, 0.025, Math.sin(a) * 0.34, 4));
    }
    return g;
  },
};

export function buildModel(defId: string): THREE.Group {
  // 解析顺序: 同名工厂 → 建筑定义的 model 键 → 草屋兜底
  // (修复: wind_turbine/armory2/wall 等 defId≠model 键的建筑曾全部回退成草屋)
  const def = (BUILDING_DEFS as Record<string, { model?: string }>)[defId];
  const f = factories[defId] ?? (def?.model ? factories[def.model] : undefined) ?? factories.hut;
  return f();
}

/** 所有模型键 (模型检视页用) */
export function modelKeys(): string[] {
  return Object.keys(factories);
}

/** 施工工地模型: 围栏 + 脚手架 + 塔吊 + 材料堆 (建造期间显示) */
export function constructionSite(size = 1): THREE.Group {
  const g = new THREE.Group();
  const s = size * 0.96;
  // 黄土平整地基
  g.add(box(s, 0.06, s, mat(0x9c8a68, { roughness: 1 }), 0, 0.03, 0));
  // 四周围栏
  const railMat = mat(0xd9a536, { roughness: 0.8 });
  const postMat = mat(0x8a7a5c, { roughness: 1 });
  const half = s / 2;
  for (let i = 0; i <= 4; i++) {
    const t = -half + (i / 4) * s;
    for (const [px, pz, horiz] of [[t, -half, true], [t, half, true], [-half, t, false], [half, t, false]] as const) {
      g.add(box(0.035, 0.42, 0.035, postMat, px, 0.24, pz));
      if (i < 4) {
        const rail = box(horiz ? s / 4 + 0.04 : 0.04, 0.045, horiz ? 0.04 : s / 4 + 0.04, railMat, horiz ? px + s / 8 : px, 0.38, horiz ? pz : pz + s / 8);
        g.add(rail);
      }
    }
  }
  // 脚手架塔 (角部)
  const scaffoldMat = mat(0xc8a24a, { roughness: 0.85, metalness: 0.15 });
  const sh = 0.55 + size * 0.5;
  const sx = half * 0.52, sz2 = half * 0.52;
  for (const [dx, dz] of [[-sx, -sz2], [sx, -sz2], [-sx, sz2], [sx, sz2]] as const) {
    g.add(box(0.04, sh, 0.04, scaffoldMat, dx, sh / 2 + 0.06, dz));
  }
  for (let f = 1; f <= 2; f++) {
    g.add(box(sx * 2 + 0.08, 0.035, 0.035, scaffoldMat, 0, 0.06 + (sh * f) / 2.2, -sz2));
    g.add(box(sx * 2 + 0.08, 0.035, 0.035, scaffoldMat, 0, 0.06 + (sh * f) / 2.2, sz2));
  }
  // 塔吊
  if (size >= 2) {
    const mast = cyl(0.035, 0.035, 1.3 + size * 0.35, mat(0xe8b830, { roughness: 0.6, metalness: 0.3 }), -half + 0.15, (1.3 + size * 0.35) / 2 + 0.06, -half + 0.15, 6);
    g.add(mast);
    const jib = box(s * 0.85, 0.045, 0.045, mat(0xe8b830, { roughness: 0.6, metalness: 0.3 }), s * 0.28, 1.36 + size * 0.35, -half + 0.15);
    g.add(jib);
    g.add(box(0.12, 0.1, 0.1, mat(0x50565c), -half + 0.15, 1.42 + size * 0.35, -half + 0.15));
    // 吊钩钢缆
    g.add(box(0.012, 0.34, 0.012, mat(0x3a3a3a), s * 0.45, 1.2 + size * 0.35, -half + 0.15));
    g.add(box(0.14, 0.06, 0.14, mat(0x8d8478), s * 0.45, 1.02 + size * 0.35, -half + 0.15));
  }
  // 材料堆: 砖垛 + 沙堆 + 木料
  g.add(box(0.22, 0.1, 0.14, mat(0xa85f4a), half * 0.4, 0.11, half * 0.55));
  g.add(box(0.22, 0.1, 0.14, mat(0x9c5240), half * 0.4, 0.21, half * 0.55));
  const sand = cone(0.16, 0.16, mat(0xc9b48a, { roughness: 1 }), -half * 0.45, 0.14, half * 0.5, 7);
  g.add(sand);
  for (let i = 0; i < 3; i++) g.add(box(0.3, 0.045, 0.045, mat(0x8a5a33), -half * 0.3, 0.1 + i * 0.05, -half * 0.55));
  return g;
}

// ---------- 树木几何(用于 InstancedMesh) ----------
export function treeGeometries(): { trunk: THREE.BufferGeometry; pine: THREE.BufferGeometry; oak: THREE.BufferGeometry; birch: THREE.BufferGeometry } {
  // 树干: 0 ~ 0.62 (树冠从 0.5 开始, 无悬空)
  const trunk = new THREE.CylinderGeometry(0.05, 0.09, 0.62, 6);
  trunk.translate(0, 0.31, 0);

  const mergeParts = (parts: { geo: THREE.BufferGeometry; y: number; ry?: number; sxz?: number }[]) => {
    const geos = parts.map(p => {
      // 关键修复: Box/Cone/Sphere 等都是带索引的几何体,
      // 直接拼接顶点数组会丢失面信息变成碎片 —— 必须先转非索引
      const g = p.geo.clone().toNonIndexed();
      if (p.ry) g.rotateY(p.ry);
      if (p.sxz) g.scale(p.sxz, 1, p.sxz);
      g.translate(0, p.y, 0);
      return g;
    });
    let total = 0;
    for (const g of geos) total += g.attributes.position.count;
    const pos = new Float32Array(total * 3), norm = new Float32Array(total * 3);
    let off = 0;
    for (const g of geos) {
      const p = g.attributes.position.array as ArrayLike<number>;
      const n = g.attributes.normal.array as ArrayLike<number>;
      pos.set(p, off * 3); norm.set(n, off * 3);
      off += g.attributes.position.count;
    }
    const out = new THREE.BufferGeometry();
    out.setAttribute('position', new THREE.BufferAttribute(pos, 3));
    out.setAttribute('normal', new THREE.BufferAttribute(norm, 3));
    return out;
  };

  // 松树: 三层锥 叠高 ~1.55
  const pineMerged = mergeParts([
    { geo: new THREE.ConeGeometry(0.36, 0.5, 7), y: 0.72 },
    { geo: new THREE.ConeGeometry(0.27, 0.42, 7), y: 1.02 },
    { geo: new THREE.ConeGeometry(0.17, 0.34, 7), y: 1.3 },
  ]);
  // 栎树(阔叶): 双球 叠高 ~1.35
  const oakMerged = mergeParts([
    { geo: new THREE.SphereGeometry(0.34, 7, 6), y: 0.82, sxz: 1.15 },
    { geo: new THREE.SphereGeometry(0.25, 7, 6), y: 1.1, ry: 0.5 },
  ]);
  // 桦树: 修长
  const birchMerged = mergeParts([
    { geo: new THREE.SphereGeometry(0.24, 7, 6), y: 0.78, sxz: 0.9 },
    { geo: new THREE.SphereGeometry(0.18, 7, 6), y: 1.05, ry: 0.7 },
    { geo: new THREE.SphereGeometry(0.13, 6, 5), y: 1.22 },
  ]);
  return { trunk, pine: pineMerged, oak: oakMerged, birch: birchMerged };
}

// ---------- 居民几何 (v2: 身体 + 头部 两个实例网格, 带 vertex colors) ----------
function mergeWithColors(parts: { geo: THREE.BufferGeometry; y: number; color: [number, number, number] }[]): THREE.BufferGeometry {
  const geos = parts.map(p => { const g = p.geo.clone().toNonIndexed(); g.translate(0, p.y, 0); return g; });
  let total = 0;
  for (const g of geos) total += g.attributes.position.count;
  const pos = new Float32Array(total * 3), norm = new Float32Array(total * 3), col = new Float32Array(total * 3);
  let off = 0;
  for (let i = 0; i < geos.length; i++) {
    const g = geos[i];
    const p = g.attributes.position.array as ArrayLike<number>;
    const n = g.attributes.normal.array as ArrayLike<number>;
    pos.set(p, off * 3); norm.set(n, off * 3);
    const c = parts[i].color;
    for (let v = 0; v < g.attributes.position.count; v++) {
      col[(off + v) * 3] = c[0]; col[(off + v) * 3 + 1] = c[1]; col[(off + v) * 3 + 2] = c[2];
    }
    off += g.attributes.position.count;
  }
  const out = new THREE.BufferGeometry();
  out.setAttribute('position', new THREE.BufferAttribute(pos, 3));
  out.setAttribute('normal', new THREE.BufferAttribute(norm, 3));
  out.setAttribute('color', new THREE.BufferAttribute(col, 3));
  return out;
}

/** 身体: 腿(深) + 躯干(白, 由 instanceColor 染成衣服色) + 手臂 */
export function citizenBodyGeometry(): THREE.BufferGeometry {
  const white: [number, number, number] = [1, 1, 1];
  const dark: [number, number, number] = [0.32, 0.3, 0.34];
  return mergeWithColors([
    // 腿 ×2
    { geo: new THREE.BoxGeometry(0.055, 0.12, 0.055), y: 0.06, color: dark },
    // 躯干 (圆台)
    { geo: new THREE.CylinderGeometry(0.062, 0.075, 0.15, 6), y: 0.185, color: white },
    // 手臂 ×2
    { geo: new THREE.BoxGeometry(0.03, 0.13, 0.03), y: 0.19, color: white },
    // 肩/围巾
    { geo: new THREE.CylinderGeometry(0.068, 0.068, 0.03, 6), y: 0.25, color: white },
  ]);
}

/** 头部: 肤色脸 + 深色头发 (固定色, 不染色) */
export function citizenHeadGeometry(): THREE.BufferGeometry {
  const skin: [number, number, number] = [1, 0.86, 0.7];
  const hair: [number, number, number] = [0.28, 0.22, 0.18];
  const head = new THREE.SphereGeometry(0.052, 8, 7);
  // 把上半球压成"头发": 用两个球叠加
  const hairCap = new THREE.SphereGeometry(0.055, 8, 5, 0, Math.PI * 2, 0, Math.PI * 0.55);
  return mergeWithColors([
    { geo: head, y: 0.315, color: skin },
    { geo: hairCap, y: 0.325, color: hair },
  ]);
}

// ---------- 车辆几何 ----------
/** 马车: 马(棕) + 车斗(木) */
export function cartGeometry(): THREE.BufferGeometry {
  const brown: [number, number, number] = [0.55, 0.38, 0.25];
  const dark: [number, number, number] = [0.38, 0.28, 0.2];
  const wood: [number, number, number] = [0.7, 0.55, 0.35];
  const parts: { geo: THREE.BufferGeometry; y: number; color: [number, number, number]; x?: number; z?: number; rx?: number; rz?: number }[] = [
    // 马身 (车头朝 +z)
    { geo: new THREE.BoxGeometry(0.09, 0.1, 0.17), y: 0.15, z: 0.17, color: brown },
    { geo: new THREE.BoxGeometry(0.05, 0.05, 0.06), y: 0.21, z: 0.26, color: brown },
    { geo: new THREE.ConeGeometry(0.022, 0.06, 4), y: 0.24, z: 0.28, rx: 1.35, color: brown },
    // 马尾
    { geo: new THREE.ConeGeometry(0.02, 0.07, 4), y: 0.18, z: 0.085, rx: -0.9, color: dark },
    // 马腿 ×4
    { geo: new THREE.BoxGeometry(0.02, 0.11, 0.02), y: 0.055, x: 0.03, z: 0.12, color: dark },
    { geo: new THREE.BoxGeometry(0.02, 0.11, 0.02), y: 0.055, x: -0.03, z: 0.12, color: dark },
    { geo: new THREE.BoxGeometry(0.02, 0.11, 0.02), y: 0.055, x: 0.03, z: 0.22, color: dark },
    { geo: new THREE.BoxGeometry(0.02, 0.11, 0.02), y: 0.055, x: -0.03, z: 0.22, color: dark },
    // 车斗
    { geo: new THREE.BoxGeometry(0.15, 0.09, 0.15), y: 0.11, z: -0.07, color: wood },
    { geo: new THREE.BoxGeometry(0.17, 0.02, 0.17), y: 0.065, z: -0.07, color: dark },
    // 货物 (干草/木箱)
    { geo: new THREE.BoxGeometry(0.1, 0.05, 0.09), y: 0.18, z: -0.07, color: [0.78, 0.65, 0.3] },
    // 车轮 ×2 (轴沿 x)
    { geo: new THREE.CylinderGeometry(0.058, 0.058, 0.018, 9), y: 0.058, x: 0.08, z: -0.07, rz: Math.PI / 2, color: dark },
    { geo: new THREE.CylinderGeometry(0.058, 0.058, 0.018, 9), y: 0.058, x: -0.08, z: -0.07, rz: Math.PI / 2, color: dark },
  ];
  const geos = parts.map(p => {
    const g = p.geo.clone().toNonIndexed();
    if (p.rx) g.rotateX(p.rx);
    if (p.rz) g.rotateZ(p.rz);
    g.translate(p.x ?? 0, p.y, p.z ?? 0);
    return g;
  });
  const merged = mergeGeos(geos, parts.map(p => p.color));
  merged.scale(1.62, 1.62, 1.62); // 马车整体放大: 与汽车/人物新比例匹配 (全长约 0.72)
  return merged;
}

/** 现代汽车: 车身 + 座舱 + 车轮 + 车灯 (比例: 车长约 0.62 格, 与人物 0.37 相当于真实 4.5m:1.7m) */
export function carGeometry(): THREE.BufferGeometry {
  const white: [number, number, number] = [1, 1, 1];
  const dark: [number, number, number] = [0.12, 0.12, 0.14];
  const glass: [number, number, number] = [0.55, 0.72, 0.82];
  const lamp: [number, number, number] = [1, 0.95, 0.6];
  const parts: { geo: THREE.BufferGeometry; y: number; color: [number, number, number]; x?: number; z?: number; rz?: number }[] = [
    // 车身 (长 0.62)
    { geo: new THREE.BoxGeometry(0.3, 0.11, 0.62), y: 0.16, color: white },
    // 座舱
    { geo: new THREE.BoxGeometry(0.26, 0.1, 0.32), y: 0.26, z: -0.03, color: white },
    // 挡风玻璃
    { geo: new THREE.BoxGeometry(0.24, 0.085, 0.05), y: 0.255, z: 0.145, color: glass },
    // 车轮 ×4
    { geo: new THREE.CylinderGeometry(0.072, 0.072, 0.055, 10), y: 0.072, x: 0.145, z: 0.19, rz: Math.PI / 2, color: dark },
    { geo: new THREE.CylinderGeometry(0.072, 0.072, 0.055, 10), y: 0.072, x: -0.145, z: 0.19, rz: Math.PI / 2, color: dark },
    { geo: new THREE.CylinderGeometry(0.072, 0.072, 0.055, 10), y: 0.072, x: 0.145, z: -0.19, rz: Math.PI / 2, color: dark },
    { geo: new THREE.CylinderGeometry(0.072, 0.072, 0.055, 10), y: 0.072, x: -0.145, z: -0.19, rz: Math.PI / 2, color: dark },
    // 车头灯
    { geo: new THREE.BoxGeometry(0.07, 0.04, 0.03), y: 0.17, x: 0.09, z: 0.315, color: lamp },
    { geo: new THREE.BoxGeometry(0.07, 0.04, 0.03), y: 0.17, x: -0.09, z: 0.315, color: lamp },
    // 尾灯
    { geo: new THREE.BoxGeometry(0.07, 0.035, 0.025), y: 0.17, x: 0.09, z: -0.31, color: [0.8, 0.1, 0.1] },
    { geo: new THREE.BoxGeometry(0.07, 0.035, 0.025), y: 0.17, x: -0.09, z: -0.31, color: [0.8, 0.1, 0.1] },
  ];
  const geos = parts.map(p => {
    const g = p.geo.clone().toNonIndexed();
    if (p.rz) g.rotateZ(p.rz);
    g.translate(p.x ?? 0, p.y, p.z ?? 0);
    return g;
  });
  return mergeGeos(geos, parts.map(p => p.color));
}

function mergeGeos(geos: THREE.BufferGeometry[], colors: [number, number, number][]): THREE.BufferGeometry {
  let total = 0;
  for (const g of geos) total += g.attributes.position.count;
  const pos = new Float32Array(total * 3), norm = new Float32Array(total * 3), col = new Float32Array(total * 3);
  let off = 0;
  for (let i = 0; i < geos.length; i++) {
    const g = geos[i];
    const p = g.attributes.position.array as ArrayLike<number>;
    const n = g.attributes.normal.array as ArrayLike<number>;
    pos.set(p, off * 3); norm.set(n, off * 3);
    const c = colors[i];
    for (let v = 0; v < g.attributes.position.count; v++) {
      col[(off + v) * 3] = c[0]; col[(off + v) * 3 + 1] = c[1]; col[(off + v) * 3 + 2] = c[2];
    }
    off += g.attributes.position.count;
  }
  const out = new THREE.BufferGeometry();
  out.setAttribute('position', new THREE.BufferAttribute(pos, 3));
  out.setAttribute('normal', new THREE.BufferAttribute(norm, 3));
  out.setAttribute('color', new THREE.BufferAttribute(col, 3));
  return out;
}

// ---------- 岩石几何 ----------
export function rockGeometry(): THREE.BufferGeometry {
  const g = new THREE.DodecahedronGeometry(0.19, 0);
  g.scale(1, 0.72, 0.88);
  return g;
}

export const PALETTE = C;
