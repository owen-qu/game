// ===== 荒野筑城 · 回合制战斗引擎 (宝可梦式) =====
import type { BattleState, BattleUnit, BattleMove, BattleEvent, ResourceKey } from './types';

// ---------- 移动招式表 ----------
const MOVES: Record<string, BattleMove> = {
  strike:  { id: 'strike',  name: '挥击',   kind: 'strike',  power: 1.0,  accuracy: 0.95, desc: '稳妥的一击, 命中率高' },
  heavy:   { id: 'heavy',   name: '重击',   kind: 'heavy',   power: 1.65, accuracy: 0.68, desc: '奋力猛攻, 威力大但易落空' },
  guard:   { id: 'guard',   name: '格挡',   kind: 'guard',   power: 0,    accuracy: 1,    desc: '架起防御, 本回合受伤减半并回复少量体力' },
  spear:   { id: 'spear',   name: '投矛',   kind: 'strike',  power: 1.25, accuracy: 0.82, desc: '中距离投掷, 兼顾威力与命中' },
  bite:    { id: 'bite',    name: '撕咬',   kind: 'heavy',   power: 1.5,  accuracy: 0.8,  desc: '利齿撕扯, 野兽的杀招' },
  roar:    { id: 'roar',    name: '咆哮',   kind: 'special', power: 0.6,  accuracy: 0.9,  desc: '震慑对手, 降低其攻击' },
  rock:    { id: 'rock',    name: '掷石',   kind: 'strike',  power: 1.1,  accuracy: 0.85, desc: '野人熟练的投石攻击' },
  smash:   { id: 'smash',   name: '狂暴乱舞', kind: 'heavy', power: 1.8,  accuracy: 0.62, desc: '不顾一切的疯狂连击' },
  shell:   { id: 'shell',   name: '炮击',   kind: 'heavy',   power: 2.1,  accuracy: 0.7,  desc: '战车主炮轰击, 破坏力惊人' },
  charge:  { id: 'charge',  name: '冲撞',   kind: 'heavy',   power: 1.55, accuracy: 0.75, desc: '钢铁之躯横冲直撞' },
  volley:  { id: 'volley',  name: '齐射',   kind: 'strike',  power: 1.35, accuracy: 0.8,  desc: '训练有素的火力压制' },
  missile: { id: 'missile', name: '火箭弹', kind: 'heavy',   power: 2.3,  accuracy: 0.76, desc: '空中点名, 覆甲摧毁' },
};

// ---------- 敌人图鉴 ----------
export interface EnemyDef {
  kind: string;
  name: string;
  icon: string;
  color: string;
  hp: number; atk: number; def: number; spd: number;
  moves: string[];
  tier: number; // 出场强度等级
}

export const ENEMY_DEFS: EnemyDef[] = [
  // ---- 野兽 (荒野) ----
  { kind: 'wolf',   name: '灰狼',   icon: 'Dog',        color: '#9ca3af', hp: 26, atk: 9,  def: 2, spd: 11, moves: ['bite', 'strike', 'roar'],   tier: 0 },
  { kind: 'boar',   name: '野猪',   icon: 'CircleDot',  color: '#7c5c3e', hp: 34, atk: 10, def: 5, spd: 8,  moves: ['charge', 'strike', 'guard'],  tier: 0 },
  { kind: 'bear',   name: '黑熊',   icon: 'PawPrint',   color: '#4b3621', hp: 48, atk: 14, def: 6, spd: 7,  moves: ['smash', 'bite', 'guard'],     tier: 1 },
  { kind: 'tiger',  name: '猛虎',   icon: 'Cat',        color: '#d97706', hp: 52, atk: 16, def: 5, spd: 13, moves: ['bite', 'smash', 'roar'],      tier: 2 },
  // ---- 野人 (村落) ----
  { kind: 'slinger', name: '野人投石手', icon: 'User',  color: '#a3743a', hp: 28, atk: 9,  def: 3, spd: 9,  moves: ['rock', 'strike', 'guard'],   tier: 1 },
  { kind: 'berserk', name: '野人狂战士', icon: 'Axe',   color: '#9a3412', hp: 40, atk: 13, def: 4, spd: 10, moves: ['smash', 'strike', 'heavy'],  tier: 1 },
  { kind: 'chief',  name: '野人酋长',   icon: 'Crown',  color: '#b91c1c', hp: 58, atk: 15, def: 7, spd: 9,  moves: ['smash', 'roar', 'guard'],     tier: 2 },
  // ---- 匪帮 (工业) ----
  { kind: 'thug',   name: '匪帮刀手',   icon: 'Swords', color: '#57534e', hp: 36, atk: 12, def: 5, spd: 10, moves: ['heavy', 'strike', 'guard'],  tier: 2 },
  { kind: 'gunner', name: '匪帮枪手',   icon: 'Crosshair', color: '#44403c', hp: 32, atk: 15, def: 3, spd: 12, moves: ['volley', 'strike', 'guard'], tier: 2 },
  { kind: 'boss',   name: '匪帮头目',   icon: 'Skull',  color: '#7f1d1d', hp: 66, atk: 17, def: 8, spd: 9,  moves: ['volley', 'heavy', 'guard'],   tier: 3 },
  // ---- 叛军装甲 (现代) ----
  { kind: 'rebel',  name: '叛军步兵',   icon: 'UserRound', color: '#3f4b5b', hp: 44, atk: 14, def: 8, spd: 10, moves: ['volley', 'heavy', 'guard'], tier: 3 },
  { kind: 'apc',    name: '叛军装甲车', icon: 'Truck',   color: '#4d5d41', hp: 80, atk: 17, def: 12, spd: 12, moves: ['charge', 'volley', 'shell'], tier: 4 },
  { kind: 'tank',   name: '叛军主战坦克', icon: 'ShieldAlert', color: '#3a4a37', hp: 130, atk: 24, def: 16, spd: 7, moves: ['shell', 'charge', 'volley'], tier: 5 },
];

// ---------- 玩家队员 ----------
const WARRIOR_NAMES = ['阿岩', '猎风', '铁柱', '山岚', '老雕', '云雀', '磐石', '疾电', '白桦', '赤霄', '青鸾', '断岳'];

export interface SquadStats {
  size: number;
  weaponTier: number;
  armorTier: number;
  /** v5: 随队载具 */
  vehicles?: { apc: number; tank: number; heli: number };
}

/** 载具兵种定义 (v5) */
export const VEHICLE_DEFS: Record<'apc' | 'tank' | 'heli', {
  name: string; icon: string; color: string; hp: number; atk: number; def: number; spd: number; moves: string[]; desc: string;
}> = {
  apc:  { name: '装甲车', icon: 'Truck',       color: '#4d7d61', hp: 90,  atk: 16, def: 14, spd: 11, moves: ['charge', 'volley', 'guard'], desc: '装甲突击, 火力与机动兼备' },
  tank: { name: '主战坦克', icon: 'ShieldAlert', color: '#3f6b4f', hp: 150, atk: 26, def: 18, spd: 7,  moves: ['shell', 'charge', 'guard'], desc: '陆战之王, 主炮葵靡一切' },
  heli: { name: '武装直升机', icon: 'Rocket',    color: '#2f6b8a', hp: 85,  atk: 22, def: 8,  spd: 15, moves: ['missile', 'volley', 'guard'], desc: '空中支援, 先手点名敌阵' },
};

/** 由城市军备生成玩家小队 (v5: 含载具) */
export function makePlayerSquad(st: SquadStats, rand: () => number): BattleUnit[] {
  const used = new Set<number>();
  const units: BattleUnit[] = [];
  for (let i = 0; i < st.size; i++) {
    let ni = Math.floor(rand() * WARRIOR_NAMES.length);
    while (used.has(ni)) ni = (ni + 1) % WARRIOR_NAMES.length;
    used.add(ni);
    const isLeader = i === 0;
    units.push({
      uid: `p${i}`,
      name: WARRIOR_NAMES[ni] + (isLeader ? ' (队长)' : ''),
      side: 'player',
      kind: st.weaponTier >= 3 ? 'soldier' : 'warrior',
      hp: 0, maxHp: 26 + st.armorTier * 5 + (isLeader ? 6 : 0),
      atk: 7 + st.weaponTier * 4 + (isLeader ? 2 : 0),
      def: 2 + st.armorTier * 3,
      spd: 9 + Math.floor(rand() * 3) + (isLeader ? 1 : 0),
      guarding: false, alive: true,
      moves: st.weaponTier >= 1
        ? [MOVES.strike, MOVES.heavy, MOVES.spear, MOVES.guard]
        : [MOVES.strike, MOVES.heavy, MOVES.guard],
      icon: st.weaponTier >= 3 ? 'Swords' : st.weaponTier >= 1 ? 'Sword' : 'Club',
      color: '#fbbf24',
    });
    units[i].hp = units[i].maxHp;
  }
  // v5: 载具单位
  const v = st.vehicles ?? { apc: 0, tank: 0, heli: 0 };
  const kinds: ('apc' | 'tank' | 'heli')[] = ['apc', 'tank', 'heli'];
  for (const kind of kinds) {
    for (let i = 0; i < (v[kind] ?? 0); i++) {
      const d = VEHICLE_DEFS[kind];
      units.push({
        uid: `v_${kind}_${i}`,
        name: d.name + (v[kind] > 1 ? `·${i + 1}` : ''),
        side: 'player',
        kind,
        hp: d.hp, maxHp: d.hp,
        atk: d.atk, def: d.def, spd: d.spd,
        guarding: false, alive: true,
        moves: d.moves.map(mid => MOVES[mid]),
        icon: d.icon,
        color: d.color,
      });
    }
  }
  return units;
}

/** 生成敌方队伍: 按威胁等级挑选图鉴条目 */
export function makeEnemySquad(threat: number, count: number, rand: () => number): BattleUnit[] {
  const pool = ENEMY_DEFS.filter(e => e.tier <= threat && e.tier >= threat - 2);
  const usable = pool.length > 0 ? pool : [ENEMY_DEFS[Math.max(0, Math.min(ENEMY_DEFS.length - 1, threat))]];
  const scale = 1 + Math.max(0, threat - 2) * 0.08;
  const units: BattleUnit[] = [];
  for (let i = 0; i < count; i++) {
    const d = usable[Math.floor(rand() * usable.length)];
    const isBoss = i === 0 && count > 1 && rand() < 0.5;
    const m = 1 + (isBoss ? 0.35 : 0);
    units.push({
      uid: `e${i}`,
      name: d.name + (count > 1 ? `·${String.fromCharCode(65 + i)}` : ''),
      side: 'enemy',
      kind: d.kind,
      hp: 0, maxHp: Math.round(d.hp * m * scale),
      atk: Math.round(d.atk * m * scale),
      def: Math.round(d.def * m * scale),
      spd: d.spd,
      guarding: false, alive: true,
      moves: d.moves.map(mid => MOVES[mid]),
      icon: d.icon,
      color: d.color,
    });
    units[i].hp = units[i].maxHp;
  }
  return units;
}

// ---------- 伤害公式 ----------
function rollDamage(attacker: BattleUnit, defender: BattleUnit, move: BattleMove, rand: () => number): { dmg: number; crit: boolean } {
  const atkEff = Math.max(2, attacker.atk); // 咆哮减攻后仍保底
  let dmg = atkEff * move.power - defender.def * (defender.guarding ? 1.5 : 1) * 0.7;
  dmg *= 0.85 + rand() * 0.3;
  const crit = rand() < 0.09;
  if (crit) dmg *= 1.6;
  return { dmg: Math.max(1, Math.round(dmg)), crit };
}

function pushLog(b: BattleState, text: string, tone: 'good' | 'bad' | 'info') {
  b.log.unshift({ text, tone });
  if (b.log.length > 30) b.log.pop();
}

let floatKey = 1;
function pushFloat(b: BattleState, uid: string, text: string, tone: 'good' | 'bad' | 'info') {
  b.floatTexts.push({ uid, text, tone, key: floatKey++ });
  if (b.floatTexts.length > 10) b.floatTexts.shift();
}

let eventKey = 1;
function pushEvent(b: BattleState, ev: Omit<BattleEvent, 'key'>) {
  b.events.push({ ...ev, key: eventKey++ });
  if (b.events.length > 24) b.events.shift();
}

// ---------- 回合流转 ----------
export function initTurnOrder(b: BattleState) {
  b.turnOrder = b.units
    .filter(u => u.alive)
    .sort((a, c) => c.spd - a.spd || (a.side === 'player' ? -1 : 1))
    .map(u => u.uid);
  b.turnIdx = 0;
  b.round = 1;
  advanceToNextActor(b);
}

/** 推进到下一个可行动单位; 全员行动完毕则进入下一回合 */
export function advanceToNextActor(b: BattleState) {
  // 清理已死亡单位
  for (let i = 0; i < b.turnOrder.length; i++) {
    const u = unitOf(b, b.turnOrder[i]);
    if (u && !u.alive) { b.turnOrder.splice(i, 1); i--; }
  }
  if (checkBattleEnd(b)) return;
  while (b.turnIdx >= b.turnOrder.length) {
    b.turnIdx = 0;
    b.round++;
    // 回合开始: 清除格挡
    for (const u of b.units) u.guarding = false;
  }
  b.activeUid = b.turnOrder[b.turnIdx];
  const u = unitOf(b, b.activeUid);
  if (!u || !u.alive) { b.turnIdx++; advanceToNextActor(b); return; }
  b.phase = u.side === 'player' ? 'select' : 'enemy';
}

function unitOf(b: BattleState, uid: string): BattleUnit | null {
  return b.units.find(u => u.uid === uid) ?? null;
}

/** 执行一次行动 (玩家选择或敌方 AI)。返回是否合法执行 */
export function performMove(b: BattleState, actorUid: string, moveId: string, rand: () => number): boolean {
  const actor = unitOf(b, actorUid);
  if (!actor || !actor.alive || b.phase === 'over') return false;
  const move = actor.moves.find(m => m.id === moveId);
  if (!move) return false;
  const foes = b.units.filter(u => u.alive && u.side !== actor.side);
  if (move.kind === 'guard') {
    actor.guarding = true;
    const heal = Math.min(actor.maxHp - actor.hp, 5 + Math.floor(actor.def * 0.5));
    actor.hp += heal;
    pushLog(b, `${actor.name} 架起盾牌严阵以待${heal > 0 ? `, 恢复 ${heal} 点体力` : ''}`, actor.side === 'player' ? 'info' : 'info');
    if (heal > 0) pushFloat(b, actor.uid, `+${heal}`, 'good');
    pushEvent(b, { type: 'guard', actorUid: actor.uid, targetUid: actor.uid, moveId: move.id, moveKind: 'guard', moveName: move.name, dmg: heal, crit: false });
  } else {
    if (foes.length === 0) return false;
    // 优先攻击血量最低的存活敌人 (简单智能)
    const target = foes.reduce((a, c) => (c.hp <= a.hp ? c : a), foes[0]);
    if (rand() > move.accuracy) {
      pushLog(b, `${actor.name} 的「${move.name}」被 ${target.name} 避开了!`, 'info');
      pushFloat(b, target.uid, '闪避', 'info');
      pushEvent(b, { type: 'miss', actorUid: actor.uid, targetUid: target.uid, moveId: move.id, moveKind: move.kind, moveName: move.name, dmg: 0, crit: false });
    } else {
      const { dmg, crit } = rollDamage(actor, target, move, rand);
      const before = target.hp;
      target.hp = Math.max(0, target.hp - dmg);
      const dealt = before - target.hp;
      pushLog(b,
        `${actor.name} 使出「${move.name}」${crit ? ' — 会心一击! ' : ''}对 ${target.name} 造成 ${dealt} 点伤害${target.guarding ? ' (格挡减免)' : ''}`,
        actor.side === 'player' ? 'good' : 'bad');
      pushFloat(b, target.uid, `-${dealt}${crit ? '!' : ''}`, 'bad');
      pushEvent(b, { type: 'attack', actorUid: actor.uid, targetUid: target.uid, moveId: move.id, moveKind: move.kind, moveName: move.name, dmg: dealt, crit });
      if (move.kind === 'special') {
        // 咆哮: 降低目标攻击
        target.atk = Math.max(3, Math.round(target.atk * 0.8));
        pushLog(b, `${target.name} 被震慑, 攻击下降了!`, actor.side === 'player' ? 'good' : 'bad');
      }
      if (target.hp <= 0) {
        target.alive = false;
        pushLog(b, `💥 ${target.name} 倒下了!`, target.side === 'player' ? 'bad' : 'good');
        pushEvent(b, { type: 'death', actorUid: actor.uid, targetUid: target.uid, moveId: move.id, moveKind: move.kind, moveName: move.name, dmg: dealt, crit });
      }
    }
  }
  checkBattleEnd(b);
  if ((b.phase as string) !== 'over') {
    b.turnIdx++;
    advanceToNextActor(b);
  }
  return true;
}

/** 敌方 AI 选择招式 */
export function enemyChooseMove(b: BattleState, uid: string, rand: () => number): string {
  const u = unitOf(b, uid);
  if (!u) return 'strike';
  const foes = b.units.filter(x => x.alive && x.side === 'player');
  const lowHp = u.hp < u.maxHp * 0.3;
  if (lowHp && rand() < 0.35) {
    const guard = u.moves.find(m => m.kind === 'guard');
    if (guard) return guard.id;
  }
  // 有击杀机会时优先重击
  const weakest = foes.length > 0 ? foes.reduce((a, c) => (c.hp <= a.hp ? c : a), foes[0]) : null;
  if (weakest) {
    const heavy = u.moves.find(m => m.kind === 'heavy');
    if (heavy && weakest.hp <= u.atk * heavy.power * 0.75 && rand() < 0.8) return heavy.id;
  }
  return u.moves[Math.floor(rand() * u.moves.length)].id;
}

export function checkBattleEnd(b: BattleState): boolean {
  if (b.phase === 'over') return true;
  const pAlive = b.units.some(u => u.side === 'player' && u.alive);
  const eAlive = b.units.some(u => u.side === 'enemy' && u.alive);
  if (!eAlive) {
    b.phase = 'over'; b.result = 'win';
    b.casualties = b.units.filter(u => u.side === 'player' && !u.alive).length;
    pushLog(b, '🏆 敌人被全部击败, 你们获胜了!', 'good');
    return true;
  }
  if (!pAlive) {
    b.phase = 'over'; b.result = 'lose';
    b.casualties = b.units.filter(u => u.side === 'player' && !u.alive).length;
    pushLog(b, '☠ 小队全军覆没……', 'bad');
    return true;
  }
  return false;
}

/** 撤退: 结束战斗, 无奖励, 受一次追击 */
export function fleeBattle(b: BattleState, rand: () => number) {
  if (b.phase === 'over') return;
  const foes = b.units.filter(u => u.alive && u.side === 'enemy');
  for (const f of foes.slice(0, 2)) {
    const runners = b.units.filter(u => u.alive && u.side === 'player');
    if (runners.length === 0) break;
    const victim = runners[Math.floor(rand() * runners.length)];
    const { dmg } = rollDamage(f, victim, MOVES.strike, rand);
    victim.hp = Math.max(0, victim.hp - Math.round(dmg * 0.6));
    if (victim.hp <= 0) victim.alive = false;
  }
  b.phase = 'over'; b.result = 'flee';
  b.casualties = b.units.filter(u => u.side === 'player' && !u.alive).length;
  pushEvent(b, { type: 'flee', actorUid: 'p0', targetUid: null, moveId: '', moveKind: '', moveName: '', dmg: 0, crit: false });
  pushLog(b, '🏳 小队且战且退, 撤出了战斗。', 'info');
}

/** 按威胁等级计算战利品 */
export function battleRewards(threat: number, enemyCount: number, era: number, rand: () => number): Partial<Record<ResourceKey, number>> {
  const out: Partial<Record<ResourceKey, number>> = {};
  out.food = Math.round(5 + threat * 4 + rand() * 6);
  out.money = Math.round(14 + threat * 22 + era * 12 + rand() * 15);
  if (era >= 1 && rand() < 0.6) out.wood = Math.round(10 + threat * 5);
  if (era >= 2 && rand() < 0.55) out.metal = Math.round(6 + threat * 4);
  if (era >= 3 && rand() < 0.4) out.oil = Math.round(4 + threat * 3);
  void enemyCount;
  return out;
}

// 挂载 unit() 帮助方法到每次创建的 state (engine 内使用)
export function createBattle(
  id: number, title: string, env: BattleState['env'],
  players: BattleUnit[], enemies: BattleUnit[],
  context: BattleState['context'], expeditionId: number | null,
  pos: { x: number; y: number } = { x: 0, y: 0 },
  vehicleBldgs: Record<string, number> = {},
): BattleState {
  const b: BattleState = {
    id, title, env,
    units: [...players, ...enemies],
    pos, vehicleBldgs,
    turnOrder: [], turnIdx: 0, round: 1,
    phase: 'select', activeUid: null,
    log: [], result: null, rewards: null, casualties: 0,
    context, expeditionId,
    floatTexts: [],
    events: [],
  };
  pushLog(b, `遭遇了 ${enemies.length > 1 ? enemies.length + ' 名敌人' : enemies[0].name}! 战斗开始!`, 'bad');
  initTurnOrder(b);
  return b;
}
